import React from 'react';
import { cn } from '@/lib/utils';
import { 
  Sparkles, 
  LayoutDashboard, 
  CheckSquare, 
  Shield, 
  Calendar, 
  FileText, 
  Bell, 
  Plug, 
  Settings,
  Plus,
  Search,
  Clock,
  Bookmark,
  ChevronRight
} from 'lucide-react';

interface SidebarProps {
  activeItem?: string;
  onItemClick?: (item: string) => void;
}

const mainNavItems = [
  { id: 'intelligence', icon: Sparkles, label: 'Intelligence' },
  { id: 'dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { id: 'tasks', icon: CheckSquare, label: 'Tasks', badge: 8 },
  { id: 'compliance', icon: Shield, label: 'Compliance' },
  { id: 'calendar', icon: Calendar, label: 'Calendar' },
  { id: 'documents', icon: FileText, label: 'Documents' },
  { id: 'news', icon: Bell, label: 'News / Alerts', badge: 3 },
  { id: 'integrations', icon: Plug, label: 'Integrations' },
  { id: 'settings', icon: Settings, label: 'Settings' },
];

const recentChats = [
  { title: 'HIPAA policy review', time: '2h ago' },
  { title: 'Risk assessment Q4', time: 'Yesterday' },
  { title: 'Training compliance', time: '3d ago' },
  { title: 'Document audit prep', time: '1w ago' },
];

const savedPrompts = [
  'Generate compliance report',
  'Check audit readiness',
  'Review policy gaps',
];

export const Sidebar: React.FC<SidebarProps> = ({ 
  activeItem = 'intelligence',
  onItemClick 
}) => {
  return (
    <aside className="w-64 h-screen bg-white border-r border-neutral-100 flex flex-col">
      {/* Logo */}
      <div className="p-5 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-lavender to-lavender-400 flex items-center justify-center">
            <Sparkles className="w-4.5 h-4.5 text-white" />
          </div>
          <div>
            <h1 className="font-semibold text-neutral-900 text-base">Requi</h1>
            <span className="text-xs text-neutral-400">Health</span>
          </div>
        </div>
      </div>

      {/* New Chat Button */}
      <div className="px-4 mb-4">
        <button className="w-full flex items-center gap-2 px-4 py-2.5 rounded-xl bg-neutral-900 text-white text-sm font-medium hover:bg-neutral-800 transition-colors">
          <Plus className="w-4 h-4" />
          New Chat
        </button>
      </div>

      {/* Search */}
      <div className="px-4 mb-3">
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
          <input
            type="text"
            placeholder="Search..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-neutral-50 text-sm text-neutral-900 placeholder:text-neutral-400 border-none focus:outline-none focus:ring-2 focus:ring-lavender/20"
          />
        </div>
      </div>

      {/* Main Navigation */}
      <nav className="flex-1 overflow-y-auto custom-scrollbar px-3 py-2">
        <div className="space-y-0.5">
          {mainNavItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onItemClick?.(item.id)}
              className={cn(
                'w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium transition-all duration-200',
                activeItem === item.id
                  ? 'bg-lavender-100 text-neutral-900'
                  : 'text-neutral-600 hover:bg-neutral-50 hover:text-neutral-900'
              )}
            >
              <item.icon className={cn(
                'w-4 h-4',
                activeItem === item.id ? 'text-lavender-600' : 'text-neutral-400'
              )} />
              <span className="flex-1 text-left">{item.label}</span>
              {item.badge && (
                <span className="px-2 py-0.5 rounded-full bg-lavender-100 text-lavender-700 text-xs font-medium">
                  {item.badge}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* History Section */}
        <div className="mt-6">
          <div className="px-3 mb-2 flex items-center justify-between">
            <span className="text-xs font-medium text-neutral-400 uppercase tracking-wider">
              History
            </span>
            <Clock className="w-3.5 h-3.5 text-neutral-400" />
          </div>
          <div className="space-y-0.5">
            {recentChats.map((chat, i) => (
              <button
                key={i}
                className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-sm text-neutral-600 hover:bg-neutral-50 transition-colors"
              >
                <span className="truncate">{chat.title}</span>
                <span className="text-xs text-neutral-400 flex-shrink-0">{chat.time}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Saved Prompts */}
        <div className="mt-6">
          <div className="px-3 mb-2 flex items-center justify-between">
            <span className="text-xs font-medium text-neutral-400 uppercase tracking-wider">
              Saved Prompts
            </span>
            <Bookmark className="w-3.5 h-3.5 text-neutral-400" />
          </div>
          <div className="space-y-0.5">
            {savedPrompts.map((prompt, i) => (
              <button
                key={i}
                className="w-full text-left px-3 py-2 rounded-xl text-sm text-neutral-600 hover:bg-neutral-50 transition-colors truncate"
              >
                {prompt}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* User Profile */}
      <div className="p-4 border-t border-neutral-100">
        <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-neutral-50 transition-colors">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-lavender to-softblue flex items-center justify-center">
            <span className="text-sm font-medium text-neutral-900">S</span>
          </div>
          <div className="flex-1 text-left">
            <p className="text-sm font-medium text-neutral-900">Sarah Chen</p>
            <p className="text-xs text-neutral-400">Admin</p>
          </div>
          <ChevronRight className="w-4 h-4 text-neutral-400" />
        </button>
      </div>
    </aside>
  );
};
