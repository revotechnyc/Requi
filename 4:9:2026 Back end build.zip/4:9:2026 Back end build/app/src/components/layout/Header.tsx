import React from 'react';
import { Bell, Search, ChevronDown } from 'lucide-react';

interface HeaderProps {
  title?: string;
  subtitle?: string;
  showSearch?: boolean;
  showNotifications?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  title,
  subtitle,
  showSearch = true,
  showNotifications = true,
}) => {
  return (
    <header className="h-16 bg-white/80 backdrop-blur-xl border-b border-[#F0F0F0] flex items-center justify-between px-6 sticky top-0 z-50">
      {/* Left - Title */}
      <div>
        {title && (
          <h1 className="text-xl font-semibold text-base-black">{title}</h1>
        )}
        {subtitle && (
          <p className="text-sm text-base-muted">{subtitle}</p>
        )}
      </div>

      {/* Right - Actions */}
      <div className="flex items-center gap-4">
        {showSearch && (
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-base-muted" />
            <input
              type="text"
              placeholder="Search anything..."
              className="w-64 pl-10 pr-4 py-2.5 rounded-xl bg-base-offwhite text-sm text-base-black placeholder:text-base-muted border-none focus:outline-none focus:ring-2 focus:ring-lavender/30"
            />
          </div>
        )}

        {showNotifications && (
          <button className="relative w-10 h-10 rounded-xl bg-base-offwhite flex items-center justify-center hover:bg-lavender-50 transition-colors">
            <Bell className="w-5 h-5 text-base-dark" />
            <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-lavender-500" />
          </button>
        )}

        {/* Organization Switcher */}
        <button className="flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-lavender-50 transition-colors">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-lavender-200 to-softblue flex items-center justify-center">
            <span className="text-xs font-medium text-base-black">A</span>
          </div>
          <div className="text-left">
            <p className="text-sm font-medium text-base-black">Acme Health</p>
          </div>
          <ChevronDown className="w-4 h-4 text-base-muted" />
        </button>
      </div>
    </header>
  );
};
