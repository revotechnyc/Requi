import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { cn } from '@/lib/utils';

interface StatsCardProps {
  label: string;
  value: string;
  change?: string;
  trend?: 'up' | 'down' | 'neutral';
  icon?: React.ReactNode;
}

export const StatsCard: React.FC<StatsCardProps> = ({
  label,
  value,
  change,
  trend = 'neutral',
  icon,
}) => {
  return (
    <div className="stats-card">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-neutral-500 mb-1">{label}</p>
          <p className="text-2xl font-semibold text-neutral-900">{value}</p>
          {change && (
            <div className="flex items-center gap-1 mt-1.5">
              {trend === 'up' && (
                <TrendingUp className="w-3.5 h-3.5 text-green-500" />
              )}
              {trend === 'down' && (
                <TrendingDown className="w-3.5 h-3.5 text-red-500" />
              )}
              <span className={cn(
                'text-xs font-medium',
                trend === 'up' && 'text-green-600',
                trend === 'down' && 'text-red-600',
                trend === 'neutral' && 'text-neutral-500'
              )}>
                {change}
              </span>
            </div>
          )}
        </div>
        {icon && (
          <div className="w-10 h-10 rounded-xl bg-lavender-50 flex items-center justify-center text-lavender-600">
            {icon}
          </div>
        )}
      </div>
    </div>
  );
};
