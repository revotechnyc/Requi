import React from 'react';
import { cn } from '@/lib/utils';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  variant?: 'default' | 'ai';
  icon?: React.ReactNode;
}

export const Input: React.FC<InputProps> = ({
  variant = 'default',
  icon,
  className,
  ...props
}) => {
  const inputClasses = variant === 'ai' ? 'ai-input' : 'input-field';

  return (
    <div className="relative">
      {icon && (
        <div className="absolute left-5 top-1/2 -translate-y-1/2 text-base-muted">
          {icon}
        </div>
      )}
      <input
        className={cn(
          inputClasses,
          icon && 'pl-14',
          className
        )}
        {...props}
      />
    </div>
  );
};
