import React from 'react';
import { cn } from '@/lib/utils';

interface GlowingOrbProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  animated?: boolean;
}

export const GlowingOrb: React.FC<GlowingOrbProps> = ({
  size = 'lg',
  className,
  animated = true,
}) => {
  const sizes = {
    sm: 'w-16 h-16',
    md: 'w-24 h-24',
    lg: 'w-32 h-32',
    xl: 'w-48 h-48',
  };

  return (
    <div
      className={cn(
        'glow-orb flex items-center justify-center',
        sizes[size],
        animated && 'animate-pulse-glow',
        className
      )}
    >
      <div className="w-3/4 h-3/4 rounded-full bg-gradient-to-br from-white/40 to-transparent backdrop-blur-sm" />
    </div>
  );
};
