import React from 'react';
import { cn } from '@/lib/utils';
import { Card } from './Card';

interface ScoreCardProps {
  title: string;
  score: number;
  maxScore?: number;
  change?: number;
  icon?: React.ReactNode;
}

const colorClasses: Record<string, string> = {
  green: 'text-green-600 bg-green-50',
  red: 'text-red-600 bg-red-50',
  amber: 'text-amber-600 bg-amber-50',
  lavender: 'text-lavender-700 bg-lavender-50',
};

export const ScoreCard: React.FC<ScoreCardProps> = ({
  title,
  score,
  maxScore = 100,
  change,
  icon,
}) => {
  const scoreColor = score >= 80 ? 'green' : score >= 60 ? 'amber' : 'red';

  return (
    <Card className="p-6">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-base-muted mb-1">{title}</p>
          <div className="flex items-baseline gap-1">
            <span className={cn('text-4xl font-semibold', colorClasses[scoreColor].split(' ')[0])}>
              {score}
            </span>
            <span className="text-lg text-base-muted">/{maxScore}</span>
          </div>
          {change !== undefined && (
            <p className={cn(
              'text-sm mt-2',
              change >= 0 ? 'text-green-600' : 'text-red-600'
            )}>
              {change >= 0 ? '+' : ''}{change} this month
            </p>
          )}
        </div>
        {icon && (
          <div className={cn('w-14 h-14 rounded-2xl flex items-center justify-center', colorClasses[scoreColor].split(' ')[1])}>
            {icon}
          </div>
        )}
      </div>
    </Card>
  );
};
