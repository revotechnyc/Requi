import React from 'react';
import { cn } from '@/lib/utils';

interface QuickActionCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  onClick?: () => void;
}

export const QuickActionCard: React.FC<QuickActionCardProps> = ({
  title,
  description,
  icon,
  onClick,
}) => {
  return (
    <div
      onClick={onClick}
      className={cn(
        'quick-action-card group cursor-pointer'
      )}
    >
      <div className="w-10 h-10 rounded-xl bg-lavender-50 flex items-center justify-center text-lavender-600 group-hover:bg-lavender-100 transition-colors">
        {icon}
      </div>
      <div>
        <h4 className="font-medium text-base-black text-sm">{title}</h4>
        <p className="text-xs text-base-muted mt-0.5">{description}</p>
      </div>
    </div>
  );
};
