import React, { useState } from 'react';
import { 
  CheckSquare, 
  Plus, 
  Filter, 
  Calendar,
  MoreHorizontal,
  Search,
  Clock,
  AlertCircle
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Card, StatsCard } from '@/components/design-system';

interface Task {
  id: string;
  title: string;
  description: string;
  priority: 'critical' | 'high' | 'medium' | 'low';
  status: 'pending' | 'in_progress' | 'completed';
  dueDate: string;
  assignee?: string;
  category: string;
}

const tasks: Task[] = [
  {
    id: '1',
    title: 'Review updated HIPAA Security Rule requirements',
    description: 'Analyze new federal guidelines and update internal policies',
    priority: 'high',
    status: 'pending',
    dueDate: 'Jan 15, 2024',
    assignee: 'Sarah Chen',
    category: 'HIPAA',
  },
  {
    id: '2',
    title: 'Complete Q4 FWA training attestation',
    description: 'Ensure all staff complete required training modules',
    priority: 'critical',
    status: 'in_progress',
    dueDate: 'Jan 12, 2024',
    assignee: 'Michael Torres',
    category: 'FWA',
  },
  {
    id: '3',
    title: 'Upload evidence for network adequacy audit',
    description: 'Compile and submit required documentation',
    priority: 'medium',
    status: 'completed',
    dueDate: 'Jan 10, 2024',
    assignee: 'Sarah Chen',
    category: 'Reporting',
  },
  {
    id: '4',
    title: 'Review Business Associate Agreements',
    description: '3 agreements expiring this quarter need renewal',
    priority: 'high',
    status: 'pending',
    dueDate: 'Jan 20, 2024',
    category: 'Contracts',
  },
  {
    id: '5',
    title: 'Update incident response contact list',
    description: 'Verify all contact information is current',
    priority: 'medium',
    status: 'pending',
    dueDate: 'Jan 18, 2024',
    category: 'Security',
  },
];

const filters = ['All', 'Pending', 'In Progress', 'Completed', 'Overdue'];

const getPriorityColor = (priority: string) => {
  switch (priority) {
    case 'critical': return 'bg-red-50 text-red-700 border-red-100';
    case 'high': return 'bg-amber-50 text-amber-700 border-amber-100';
    case 'medium': return 'bg-blue-50 text-blue-700 border-blue-100';
    case 'low': return 'bg-neutral-50 text-neutral-600 border-neutral-200';
    default: return 'bg-neutral-50 text-neutral-600 border-neutral-200';
  }
};

const getStatusIcon = (status: string) => {
  switch (status) {
    case 'completed':
      return <div className="w-5 h-5 rounded-full bg-green-500 flex items-center justify-center"><CheckSquare className="w-3 h-3 text-white" /></div>;
    case 'in_progress':
      return <div className="w-5 h-5 rounded-full border-2 border-lavender-500 border-t-transparent animate-spin" />;
    default:
      return <div className="w-5 h-5 rounded-full border-2 border-neutral-200" />;
  }
};

export const TasksPage: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredTasks = tasks.filter(task => {
    if (activeFilter !== 'All' && task.status !== activeFilter.toLowerCase().replace(' ', '_')) {
      return false;
    }
    if (searchQuery && !task.title.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    return true;
  });

  const pendingCount = tasks.filter(t => t.status === 'pending').length;
  const inProgressCount = tasks.filter(t => t.status === 'in_progress').length;
  const completedCount = tasks.filter(t => t.status === 'completed').length;
  const criticalCount = tasks.filter(t => t.priority === 'critical').length;

  return (
    <div className="flex h-screen bg-neutral-50">
      <main className="flex-1 overflow-y-auto custom-scrollbar">
        <div className="max-w-6xl mx-auto px-8 py-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-heading-3 text-neutral-900 mb-1">Tasks</h1>
              <p className="text-body text-neutral-500">
                Manage your compliance tasks and deadlines
              </p>
            </div>
            <button className="btn-primary">
              <Plus className="w-4 h-4 mr-2" />
              New Task
            </button>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-4 gap-4 mb-8">
            <StatsCard
              label="Pending"
              value={pendingCount.toString()}
              change="3 due this week"
              trend="neutral"
              icon={<Clock className="w-5 h-5" />}
            />
            <StatsCard
              label="In Progress"
              value={inProgressCount.toString()}
              change="1 due today"
              trend="neutral"
              icon={<CheckSquare className="w-5 h-5" />}
            />
            <StatsCard
              label="Completed"
              value={completedCount.toString()}
              change="This month"
              trend="up"
              icon={<CheckSquare className="w-5 h-5" />}
            />
            <StatsCard
              label="Critical"
              value={criticalCount.toString()}
              change="Needs attention"
              trend="down"
              icon={<AlertCircle className="w-5 h-5" />}
            />
          </div>

          {/* Filters & Search */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              {filters.map((filter) => (
                <button
                  key={filter}
                  onClick={() => setActiveFilter(filter)}
                  className={cn(
                    'px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200',
                    activeFilter === filter
                      ? 'bg-lavender-100 text-neutral-900'
                      : 'text-neutral-500 hover:bg-neutral-100 hover:text-neutral-900'
                  )}
                >
                  {filter}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
                <input
                  type="text"
                  placeholder="Search tasks..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-64 pl-10 pr-4 py-2.5 rounded-xl bg-white text-sm text-neutral-900 placeholder:text-neutral-400 border border-neutral-100 focus:outline-none focus:ring-2 focus:ring-lavender/30"
                />
              </div>
              <button className="w-10 h-10 rounded-xl bg-white border border-neutral-100 flex items-center justify-center text-neutral-400 hover:bg-lavender-50 hover:text-lavender-600 transition-colors">
                <Filter className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Tasks List */}
          <div className="space-y-3">
            {filteredTasks.map((task) => (
              <Card
                key={task.id}
                className="p-5 flex items-center gap-5 cursor-pointer hover:border-lavender-200 transition-colors group"
              >
                {getStatusIcon(task.status)}
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 mb-1">
                    <h3 className={cn(
                      'font-medium text-neutral-900',
                      task.status === 'completed' && 'line-through text-neutral-400'
                    )}>
                      {task.title}
                    </h3>
                    <span className={cn(
                      'px-2 py-0.5 rounded-full text-xs font-medium border',
                      getPriorityColor(task.priority)
                    )}>
                      {task.priority}
                    </span>
                  </div>
                  <p className="text-sm text-neutral-400 truncate">{task.description}</p>
                </div>

                <div className="flex items-center gap-6">
                  <div className="flex items-center gap-2 text-sm text-neutral-400">
                    <Calendar className="w-4 h-4" />
                    {task.dueDate}
                  </div>
                  
                  {task.assignee && (
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-gradient-to-br from-lavender to-softblue flex items-center justify-center">
                        <span className="text-xs font-medium text-neutral-900">
                          {task.assignee.charAt(0)}
                        </span>
                      </div>
                    </div>
                  )}

                  <span className="px-3 py-1 rounded-lg bg-neutral-50 text-xs text-neutral-600">
                    {task.category}
                  </span>

                  <button className="w-8 h-8 rounded-lg flex items-center justify-center text-neutral-400 hover:bg-neutral-50 transition-colors opacity-0 group-hover:opacity-100">
                    <MoreHorizontal className="w-4 h-4" />
                  </button>
                </div>
              </Card>
            ))}
          </div>

          {/* Empty State */}
          {filteredTasks.length === 0 && (
            <div className="flex flex-col items-center justify-center py-20">
              <div className="w-16 h-16 rounded-2xl bg-lavender-50 flex items-center justify-center mb-4">
                <CheckSquare className="w-8 h-8 text-lavender-400" />
              </div>
              <h3 className="text-lg font-medium text-neutral-900 mb-1">No tasks found</h3>
              <p className="text-sm text-neutral-400">Try adjusting your filters or search query</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};
