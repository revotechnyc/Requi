import React from 'react';
import { 
  Calendar, 
  CheckSquare, 
  AlertTriangle, 
  FileText,
  ArrowRight,
  Sparkles,
  Activity
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Card, StatsCard } from '@/components/design-system';

const upcomingDeadlines = [
  { id: 1, title: 'Annual HIPAA Risk Assessment', date: 'Jan 15, 2024', daysLeft: 8, priority: 'critical' },
  { id: 2, title: 'Quarterly FWA Report', date: 'Jan 22, 2024', daysLeft: 15, priority: 'high' },
  { id: 3, title: 'Network Adequacy Review', date: 'Feb 1, 2024', daysLeft: 25, priority: 'medium' },
];

const priorityActions = [
  { id: 1, title: 'Review updated HIPAA Security Rule requirements', completed: false },
  { id: 2, title: 'Complete Q4 FWA training attestation', completed: false },
  { id: 3, title: 'Upload evidence for network adequacy audit', completed: true },
];

const complianceGaps = [
  { level: 'Critical', count: 2, color: 'bg-red-500' },
  { level: 'High', count: 5, color: 'bg-amber-500' },
  { level: 'Medium', count: 4, color: 'bg-yellow-500' },
  { level: 'Low', count: 3, color: 'bg-blue-500' },
];

const recentIntelligence = [
  { id: 1, title: 'CMS Final Rule: Medicare Advantage and Part D', source: 'CMS', time: '2 hours ago' },
  { id: 2, title: 'Texas Medicaid: HB 21 Implementation Guidance', source: 'Texas HHS', time: '1 day ago' },
  { id: 3, title: 'OIG Work Plan Updates for 2024', source: 'OIG', time: '2 days ago' },
];

const getPriorityColor = (priority: string) => {
  switch (priority) {
    case 'critical': return 'bg-red-50 text-red-700';
    case 'high': return 'bg-amber-50 text-amber-700';
    case 'medium': return 'bg-blue-50 text-blue-700';
    default: return 'bg-neutral-50 text-neutral-700';
  }
};

export const DashboardPage: React.FC = () => {
  return (
    <div className="flex h-screen bg-neutral-50">
      {/* Main Content */}
      <main className="flex-1 overflow-y-auto custom-scrollbar">
        <div className="max-w-6xl mx-auto px-8 py-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-heading-3 text-neutral-900 mb-1">
                Good morning, Sarah
              </h1>
              <p className="text-body text-neutral-500">
                You have 3 deadlines this week and 2 critical gaps to address
              </p>
            </div>
            <button className="btn-primary">
              <Sparkles className="w-4 h-4 mr-2" />
              Ask AI
            </button>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-4 gap-4 mb-8">
            <StatsCard
              label="Compliance Score"
              value="87"
              change="+5 this month"
              trend="up"
              icon={<CheckSquare className="w-5 h-5" />}
            />
            <StatsCard
              label="Risk Score"
              value="42"
              change="+2 this month"
              trend="down"
              icon={<AlertTriangle className="w-5 h-5" />}
            />
            <StatsCard
              label="Audit Readiness"
              value="65"
              change="+8 this month"
              trend="up"
              icon={<FileText className="w-5 h-5" />}
            />
            <StatsCard
              label="Active Tasks"
              value="23"
              change="3 due today"
              trend="neutral"
              icon={<Activity className="w-5 h-5" />}
            />
          </div>

          {/* Two Column Layout */}
          <div className="grid grid-cols-2 gap-6">
            {/* Left Column */}
            <div className="space-y-6">
              {/* Upcoming Deadlines */}
              <Card className="p-5">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-neutral-400" />
                    <h3 className="font-semibold text-neutral-900">Upcoming Deadlines</h3>
                  </div>
                  <button className="text-sm text-lavender-600 hover:text-lavender-700 transition-colors flex items-center gap-1">
                    View all
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="space-y-3">
                  {upcomingDeadlines.map((deadline) => (
                    <div
                      key={deadline.id}
                      className="flex items-center justify-between p-3 rounded-xl bg-neutral-50"
                    >
                      <div className="flex items-center gap-3">
                        <div className={cn(
                          'w-9 h-9 rounded-lg flex items-center justify-center',
                          deadline.priority === 'critical' && 'bg-red-100',
                          deadline.priority === 'high' && 'bg-amber-100',
                          deadline.priority === 'medium' && 'bg-blue-100',
                        )}>
                          <Calendar className={cn(
                            'w-4 h-4',
                            deadline.priority === 'critical' && 'text-red-600',
                            deadline.priority === 'high' && 'text-amber-600',
                            deadline.priority === 'medium' && 'text-blue-600',
                          )} />
                        </div>
                        <div>
                          <p className="font-medium text-neutral-900 text-sm">{deadline.title}</p>
                          <p className="text-xs text-neutral-400">Due {deadline.date}</p>
                        </div>
                      </div>
                      <span className={cn(
                        'px-2.5 py-1 rounded-full text-xs font-medium',
                        getPriorityColor(deadline.priority)
                      )}>
                        {deadline.daysLeft} days
                      </span>
                    </div>
                  ))}
                </div>
              </Card>

              {/* Priority Actions */}
              <Card className="p-5">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <CheckSquare className="w-4 h-4 text-neutral-400" />
                    <h3 className="font-semibold text-neutral-900">Priority Actions</h3>
                  </div>
                  <button className="text-sm text-lavender-600 hover:text-lavender-700 transition-colors flex items-center gap-1">
                    View all
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="space-y-2">
                  {priorityActions.map((action) => (
                    <div
                      key={action.id}
                      className="flex items-center gap-3 p-3 rounded-xl border border-neutral-100"
                    >
                      <div className={cn(
                        'w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0',
                        action.completed ? 'bg-green-500 border-green-500' : 'border-neutral-200'
                      )}>
                        {action.completed && <CheckSquare className="w-3 h-3 text-white" />}
                      </div>
                      <span className={cn(
                        'flex-1 text-sm',
                        action.completed ? 'text-neutral-400 line-through' : 'text-neutral-700'
                      )}>
                        {action.title}
                      </span>
                      {!action.completed && (
                        <button className="px-3 py-1.5 rounded-lg border border-neutral-200 text-xs text-neutral-600 hover:bg-neutral-50 transition-colors">
                          Start
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </Card>
            </div>

            {/* Right Column */}
            <div className="space-y-6">
              {/* Compliance Gaps */}
              <Card className="p-5">
                <div className="flex items-center gap-2 mb-4">
                  <AlertTriangle className="w-4 h-4 text-neutral-400" />
                  <h3 className="font-semibold text-neutral-900">Compliance Gaps</h3>
                </div>
                <div className="space-y-3">
                  {complianceGaps.map((gap) => (
                    <div key={gap.level} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={cn('w-2.5 h-2.5 rounded-full', gap.color)} />
                        <span className="text-sm text-neutral-600">{gap.level}</span>
                      </div>
                      <span className={cn(
                        'font-semibold text-sm',
                        gap.level === 'Critical' && 'text-red-600',
                        gap.level === 'High' && 'text-amber-600',
                        gap.level === 'Medium' && 'text-yellow-600',
                        gap.level === 'Low' && 'text-blue-600',
                      )}>
                        {gap.count}
                      </span>
                    </div>
                  ))}
                </div>
                <button className="w-full mt-4 py-2.5 rounded-xl border border-neutral-200 text-sm text-neutral-600 hover:bg-neutral-50 transition-colors">
                  View All Gaps
                </button>
              </Card>

              {/* Recent Intelligence */}
              <Card className="p-5">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-neutral-400" />
                    <h3 className="font-semibold text-neutral-900">Recent Intelligence</h3>
                  </div>
                  <button className="text-sm text-lavender-600 hover:text-lavender-700 transition-colors flex items-center gap-1">
                    View all
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="space-y-3">
                  {recentIntelligence.map((item) => (
                    <div
                      key={item.id}
                      className="group cursor-pointer"
                    >
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 rounded-lg bg-lavender-50 flex items-center justify-center flex-shrink-0 group-hover:bg-lavender-100 transition-colors">
                          <FileText className="w-4 h-4 text-lavender-600" />
                        </div>
                        <div>
                          <p className="font-medium text-neutral-900 text-sm group-hover:text-lavender-600 transition-colors line-clamp-2">
                            {item.title}
                          </p>
                          <p className="text-xs text-neutral-400 mt-0.5">
                            {item.source} • {item.time}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              {/* Quick Links */}
              <Card className="p-5">
                <h3 className="font-semibold text-neutral-900 mb-4">Quick Links</h3>
                <div className="space-y-1">
                  {['Billing & Plan', 'Team Members', 'Help & Support'].map((link) => (
                    <button
                      key={link}
                      className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-neutral-50 transition-colors text-left"
                    >
                      <span className="text-sm text-neutral-600">{link}</span>
                      <ArrowRight className="w-4 h-4 text-neutral-300" />
                    </button>
                  ))}
                </div>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
