import React, { useState } from 'react';
import { Sparkles, Eye, EyeOff, ArrowRight, Building2, User, CheckCircle } from 'lucide-react';


const demoAccounts = [
  { type: 'admin', email: 'demo.admin@acme-health.com', name: 'Admin User', access: 'Full dashboard access' },
  { type: 'user', email: 'demo.user@acme-health.com', name: 'Standard User', access: 'Limited access' },
];

const features = [
  'AI-powered compliance monitoring',
  'Real-time risk assessment',
  'Automated audit readiness',
  'Team collaboration tools',
];

export const LoginPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [selectedDemo, setSelectedDemo] = useState<string | null>(null);

  const handleDemoSelect = (type: string) => {
    setSelectedDemo(type);
    const account = demoAccounts.find(a => a.type === type);
    if (account) {
      setEmail(account.email);
      setPassword('DemoPass123!');
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Left Side - Branding */}
      <div className="w-1/2 bg-gradient-to-br from-lavender-100 via-lavender-50 to-softblue-50 flex flex-col justify-between p-12">
        <div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-lavender to-lavender-500 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-semibold text-neutral-900 text-lg">Requi</h1>
              <span className="text-xs text-neutral-500">Health</span>
            </div>
          </div>
        </div>

        <div>
          <h2 className="text-heading-1 text-neutral-900 mb-4">
            Enterprise<br />
            <span className="text-gradient">Compliance</span> Platform
          </h2>
          <p className="text-body text-neutral-500 mb-8 max-w-md">
            AI-powered healthcare compliance management. Stay ahead of regulations with intelligent monitoring and automated workflows.
          </p>
          <div className="space-y-3">
            {features.map((feature, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="w-5 h-5 rounded-full bg-lavender-200 flex items-center justify-center">
                  <CheckCircle className="w-3 h-3 text-lavender-700" />
                </div>
                <span className="text-sm text-neutral-600">{feature}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="text-sm text-neutral-400">
          © 2024 Requi Health. All rights reserved.
        </div>
      </div>

      {/* Right Side - Login Form */}
      <div className="w-1/2 bg-white flex items-center justify-center p-12">
        <div className="w-full max-w-md">
          <div className="mb-8">
            <h2 className="text-heading-3 text-neutral-900 mb-2">Welcome back</h2>
            <p className="text-body text-neutral-500">Sign in to your organization</p>
          </div>

          {/* Demo Credentials */}
          <div className="bg-lavender-50 rounded-2xl p-4 mb-6">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-4 h-4 text-lavender-600" />
              <span className="text-sm font-medium text-neutral-900">Demo Credentials</span>
            </div>
            <p className="text-xs text-neutral-500 mb-3">Click to auto-fill:</p>
            <div className="grid grid-cols-2 gap-2">
              {demoAccounts.map((account) => (
                <button
                  key={account.type}
                  onClick={() => handleDemoSelect(account.type)}
                  className={`p-3 rounded-xl border text-left transition-all duration-200 ${
                    selectedDemo === account.type
                      ? 'border-lavender-500 bg-white shadow-soft'
                      : 'border-neutral-200 bg-white hover:border-lavender-300'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    {account.type === 'admin' ? (
                      <Building2 className="w-4 h-4 text-lavender-600" />
                    ) : (
                      <User className="w-4 h-4 text-lavender-600" />
                    )}
                    <span className="text-sm font-medium text-neutral-900">{account.name}</span>
                  </div>
                  <p className="text-xs text-neutral-400">{account.access}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Login Form */}
          <form className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-2">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@company.com"
                className="input"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-2">Password</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="input pr-12"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" className="w-4 h-4 rounded border-neutral-300 text-lavender-500 focus:ring-lavender-500" />
                <span className="text-sm text-neutral-500">Remember me</span>
              </label>
              <button type="button" className="text-sm text-lavender-600 hover:text-lavender-700 transition-colors">
                Forgot password?
              </button>
            </div>

            <button type="submit" className="w-full btn-primary py-3">
              Sign In
              <ArrowRight className="w-4 h-4 ml-2" />
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-neutral-100">
            <p className="text-center text-sm text-neutral-400 mb-4">Or continue with</p>
            <div className="grid grid-cols-2 gap-3">
              <button className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-neutral-200 text-sm text-neutral-700 hover:bg-neutral-50 transition-colors">
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none">
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                  <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                  <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                  <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                </svg>
                Google
              </button>
              <button className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-neutral-200 text-sm text-neutral-700 hover:bg-neutral-50 transition-colors">
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none">
                  <path d="M11.55 21H3.55V10.2L12 2.45L20.45 10.2V21H11.55Z" fill="#00A4EF"/>
                  <path d="M12 2.45L20.45 10.2H12V2.45Z" fill="#7FBA00"/>
                  <path d="M3.55 10.2H12V21H3.55V10.2Z" fill="#FFB900"/>
                  <path d="M12 10.2H20.45V21H12V10.2Z" fill="#F25022"/>
                </svg>
                Microsoft
              </button>
            </div>
          </div>

          <p className="text-center text-sm text-neutral-500 mt-6">
            Don't have an account?{' '}
            <button className="text-lavender-600 hover:text-lavender-700 font-medium transition-colors">
              Start free trial
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};
