import React, { useState } from 'react';
import { 
  Sparkles, 
  Check, 
  Minus, 
  ArrowRight, 
  ChevronDown,
  Users,
  Building2,
  Shield,
  Clock,
  BarChart3,
  FileText,
  MessageSquare
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Card } from '@/components/design-system';

const pricingTiers = [
  {
    id: 'intelligence',
    label: 'For individuals',
    name: 'Requi Intelligence',
    price: '$199',
    priceSubtext: '/month',
    userText: '1 user · intelligence only',
    description: 'Your AI compliance expert on demand.',
    features: [
      'Ask compliance questions anytime',
      'Federal guidance and structured answers',
      'Basic state-level awareness',
      'Saved conversations',
      'Prompt templates',
      'Guided summaries and checklists',
    ],
    excluded: [
      'No task management',
      'No reminders',
      'No integrations',
      'No dashboard automation',
    ],
    cta: 'Start Free Trial',
    ctaVariant: 'secondary' as const,
    icon: MessageSquare,
  },
  {
    id: 'pro',
    label: 'For teams',
    badge: 'Most Popular',
    name: 'Requi Pro',
    price: '$500–$750',
    priceSubtext: 'per user / month',
    userText: 'Minimum 10 users',
    description: 'Turn compliance intelligence into trackable team execution.',
    features: [
      'Everything in Intelligence',
      'Task management',
      'Deadline tracking',
      'Reminders',
      'Dashboard overview',
      'Compliance score',
      'Risk score',
      'Audit readiness preview',
      'Multi-user collaboration',
      'AI-to-task suggestions',
    ],
    limited: 'Limited payer-specific intelligence and advanced automation',
    cta: 'Book a Demo',
    ctaVariant: 'primary' as const,
    icon: Users,
    highlighted: true,
  },
  {
    id: 'enterprise',
    label: 'For organizations',
    name: 'Requi Enterprise',
    price: 'Custom',
    priceSubtext: 'or starting at $1,000+ / user / month',
    userText: 'Minimum 25 users',
    description: 'The full healthcare compliance operating system.',
    features: [
      'Everything in Pro',
      'Health plan / payer intelligence',
      'CalAIM and managed care intelligence',
      'Advanced compliance scoring',
      'Live gap detection',
      'Document intelligence',
      'Enterprise integrations',
      'AI workflow orchestration',
      'Audit trail automation',
      'Multi-state and multi-entity support',
    ],
    cta: 'Talk to Sales',
    ctaVariant: 'secondary' as const,
    icon: Building2,
  },
];

const comparisonFeatures = [
  { feature: 'AI compliance Q&A', intelligence: true, pro: true, enterprise: true },
  { feature: 'Federal guidance', intelligence: true, pro: true, enterprise: true },
  { feature: 'Basic state-level awareness', intelligence: true, pro: true, enterprise: true },
  { feature: 'Full state-level mapping', intelligence: false, pro: true, enterprise: true },
  { feature: 'Saved conversations', intelligence: true, pro: true, enterprise: true },
  { feature: 'Prompt templates', intelligence: true, pro: true, enterprise: true },
  { feature: 'Task management', intelligence: false, pro: true, enterprise: true },
  { feature: 'Deadline tracking', intelligence: false, pro: true, enterprise: true },
  { feature: 'Reminders', intelligence: false, pro: true, enterprise: true },
  { feature: 'Dashboard', intelligence: false, pro: true, enterprise: true },
  { feature: 'Compliance score', intelligence: false, pro: 'Basic', enterprise: 'Advanced' },
  { feature: 'Risk score', intelligence: false, pro: 'Basic', enterprise: 'Advanced' },
  { feature: 'Audit readiness', intelligence: false, pro: 'Preview', enterprise: 'Full' },
  { feature: 'Multi-user collaboration', intelligence: false, pro: true, enterprise: true },
  { feature: 'Health plan / payer intelligence', intelligence: false, pro: false, enterprise: true },
  { feature: 'CalAIM / managed care intelligence', intelligence: false, pro: false, enterprise: true },
  { feature: 'Document intelligence', intelligence: false, pro: 'Limited', enterprise: 'Advanced' },
  { feature: 'Integrations', intelligence: false, pro: 'Limited', enterprise: true },
  { feature: 'Workflow automation', intelligence: false, pro: 'Partial', enterprise: 'Full' },
  { feature: 'Audit trail automation', intelligence: false, pro: false, enterprise: true },
];

const upgradeCards = [
  {
    step: '01',
    title: 'Start with answers',
    description: 'Use Intelligence to get fast, structured guidance.',
    icon: MessageSquare,
  },
  {
    step: '02',
    title: 'Move into execution',
    description: 'Use Pro to turn guidance into tasks, deadlines, and visibility.',
    icon: Check,
  },
  {
    step: '03',
    title: 'Scale with control',
    description: 'Use Enterprise to automate compliance across teams, plans, and states.',
    icon: Building2,
  },
];

const faqs = [
  {
    question: "What's included in Requi Intelligence?",
    answer: "Requi Intelligence is a single-user AI compliance assistant. It includes unlimited AI Q&A, federal guidance, basic state-level awareness, saved conversations, and prompt templates. It's designed for individuals who need direct compliance intelligence without operational features.",
  },
  {
    question: 'Does Intelligence include task management?',
    answer: "No. Task management, deadline tracking, reminders, and the dashboard are exclusive to Requi Pro and Enterprise. Intelligence is focused purely on AI-powered compliance guidance and answers.",
  },
  {
    question: 'Can I start as a single user and upgrade later?',
    answer: "Absolutely. Many teams start with Intelligence to evaluate the AI, then upgrade to Pro when they're ready to operationalize compliance across their team. Your data and conversations transfer seamlessly.",
  },
  {
    question: "What's the minimum seat count for Pro?",
    answer: 'Requi Pro requires a minimum of 10 users. This ensures the collaboration, task management, and dashboard features deliver value across your organization.',
  },
  {
    question: 'What makes Enterprise different?',
    answer: 'Enterprise unlocks the full operating system: payer-specific intelligence, CalAIM and managed care logic, advanced compliance scoring, live gap detection, document intelligence, enterprise integrations, and multi-state support. It also includes dedicated onboarding and support.',
  },
  {
    question: 'Do you support payer-specific intelligence?',
    answer: 'Yes, but only in Enterprise. This includes health plan-specific guidance, CalAIM requirements, managed care regulations, and payer-specific compliance workflows.',
  },
  {
    question: 'Are integrations included in every plan?',
    answer: 'Integrations are limited in Pro and fully available in Enterprise. Intelligence does not include integrations as it is a single-user product focused on AI guidance.',
  },
  {
    question: 'Do you offer a free trial?',
    answer: 'Yes. We offer a 14-day free trial for Intelligence and Pro. Enterprise trials are arranged through our sales team with a customized onboarding experience.',
  },
];

const getComparisonValue = (value: boolean | string) => {
  if (value === true) return <Check className="w-5 h-5 text-lavender-600" />;
  if (value === false) return <Minus className="w-5 h-5 text-neutral-300" />;
  return <span className="text-sm text-neutral-500">{value}</span>;
};

export const PricingPage: React.FC = () => {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-neutral-50 overflow-y-auto custom-scrollbar">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-20 pb-16">
        <div className="absolute inset-0 bg-gradient-to-br from-lavender-50/80 via-white to-softblue-50/60" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-radial from-lavender-200/30 to-transparent rounded-full blur-3xl" />
        
        <div className="relative max-w-5xl mx-auto px-8 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-lavender-100 text-lavender-700 text-sm font-medium mb-8">
            <Sparkles className="w-4 h-4" />
            AI-powered healthcare compliance
          </div>
          
          <h1 className="text-4xl md:text-5xl font-semibold text-neutral-900 mb-6 tracking-tight">
            Simple pricing for healthcare<br />compliance intelligence
          </h1>
          
          <p className="text-lg text-neutral-500 max-w-2xl mx-auto mb-10">
            Requi helps healthcare teams move from answers… to action… to full compliance control.
          </p>
          
          <div className="flex items-center justify-center gap-4">
            <button className="btn-primary px-8 py-4 text-base">
              Start Free Trial
              <ArrowRight className="w-5 h-5 ml-2" />
            </button>
            <button className="btn-secondary px-8 py-4 text-base">
              Talk to Sales
            </button>
          </div>
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="py-16 px-8">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-3 gap-6">
            {pricingTiers.map((tier) => (
              <Card
                key={tier.id}
                className={cn(
                  'relative p-8 flex flex-col',
                  tier.highlighted && 'ring-2 ring-lavender-300 shadow-xl'
                )}
              >
                {tier.badge && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="px-4 py-1.5 rounded-full bg-lavender-500 text-white text-sm font-medium">
                      {tier.badge}
                    </span>
                  </div>
                )}
                
                <div className="mb-6">
                  <p className="text-sm text-neutral-400 mb-2">{tier.label}</p>
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-xl bg-lavender-50 flex items-center justify-center">
                      <tier.icon className="w-5 h-5 text-lavender-600" />
                    </div>
                    <h3 className="text-xl font-semibold text-neutral-900">{tier.name}</h3>
                  </div>
                  <div className="flex items-baseline gap-1 mb-1">
                    <span className="text-3xl font-semibold text-neutral-900">{tier.price}</span>
                    <span className="text-neutral-400">{tier.priceSubtext}</span>
                  </div>
                  <p className="text-sm text-neutral-400">{tier.userText}</p>
                </div>
                
                <p className="text-neutral-600 mb-6">{tier.description}</p>
                
                <div className="flex-1">
                  <ul className="space-y-3 mb-6">
                    {tier.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-lavender-600 flex-shrink-0 mt-0.5" />
                        <span className="text-sm text-neutral-600">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  {tier.excluded && (
                    <ul className="space-y-2 mb-6 pt-4 border-t border-neutral-100">
                      {tier.excluded.map((item, i) => (
                        <li key={i} className="flex items-start gap-3">
                          <Minus className="w-5 h-5 text-neutral-300 flex-shrink-0 mt-0.5" />
                          <span className="text-sm text-neutral-400">{item}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                  
                  {tier.limited && (
                    <p className="text-sm text-neutral-400 pt-4 border-t border-neutral-100">
                      {tier.limited}
                    </p>
                  )}
                </div>
                
                <button
                  className={cn(
                    'w-full mt-8 py-3 rounded-xl font-medium transition-all',
                    tier.ctaVariant === 'primary'
                      ? 'bg-neutral-900 text-white hover:bg-neutral-800'
                      : 'bg-lavender-50 text-lavender-700 hover:bg-lavender-100'
                  )}
                >
                  {tier.cta}
                </button>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Feature Comparison */}
      <section className="py-16 px-8 bg-white">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-semibold text-neutral-900 text-center mb-12">
            Feature comparison
          </h2>
          
          <div className="border border-neutral-100 rounded-2xl overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="bg-neutral-50">
                  <th className="text-left py-4 px-6 text-sm font-medium text-neutral-500">Feature</th>
                  <th className="text-center py-4 px-6 text-sm font-medium text-neutral-500">Intelligence</th>
                  <th className="text-center py-4 px-6 text-sm font-medium text-neutral-500">Pro</th>
                  <th className="text-center py-4 px-6 text-sm font-medium text-neutral-500">Enterprise</th>
                </tr>
              </thead>
              <tbody>
                {comparisonFeatures.map((row, i) => (
                  <tr key={i} className="border-t border-neutral-100">
                    <td className="py-4 px-6 text-sm text-neutral-700">{row.feature}</td>
                    <td className="py-4 px-6 text-center">{getComparisonValue(row.intelligence)}</td>
                    <td className="py-4 px-6 text-center">{getComparisonValue(row.pro)}</td>
                    <td className="py-4 px-6 text-center">{getComparisonValue(row.enterprise)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Why Teams Upgrade */}
      <section className="py-16 px-8">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-2xl font-semibold text-neutral-900 text-center mb-12">
            How teams grow with Requi
          </h2>
          
          <div className="grid grid-cols-3 gap-6">
            {upgradeCards.map((card, i) => (
              <Card key={i} className="p-8 text-center">
                <div className="w-12 h-12 rounded-xl bg-lavender-50 flex items-center justify-center mx-auto mb-4">
                  <card.icon className="w-6 h-6 text-lavender-600" />
                </div>
                <p className="text-sm text-lavender-600 font-medium mb-2">{card.step}</p>
                <h3 className="text-lg font-semibold text-neutral-900 mb-2">{card.title}</h3>
                <p className="text-sm text-neutral-500">{card.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Value Band */}
      <section className="py-16 px-8 bg-gradient-to-br from-lavender-50 to-softblue-50">
        <div className="max-w-5xl mx-auto text-center">
          <h2 className="text-2xl font-semibold text-neutral-900 mb-12">
            The value of compliance confidence
          </h2>
          
          <div className="grid grid-cols-4 gap-8">
            {[
              { icon: Clock, label: 'Faster research', desc: 'Get answers in seconds' },
              { icon: Shield, label: 'Lower risk', desc: 'Never miss deadlines' },
              { icon: BarChart3, label: 'Better visibility', desc: 'Track compliance health' },
              { icon: FileText, label: 'Audit-ready', desc: 'Less overhead, more control' },
            ].map((item, i) => (
              <div key={i} className="text-center">
                <div className="w-12 h-12 rounded-xl bg-white flex items-center justify-center mx-auto mb-4 shadow-sm">
                  <item.icon className="w-6 h-6 text-lavender-600" />
                </div>
                <h4 className="font-medium text-neutral-900 mb-1">{item.label}</h4>
                <p className="text-sm text-neutral-500">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 px-8 bg-white">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-2xl font-semibold text-neutral-900 text-center mb-12">
            Frequently asked questions
          </h2>
          
          <div className="space-y-3">
            {faqs.map((faq, i) => (
              <div
                key={i}
                className="border border-neutral-100 rounded-xl overflow-hidden"
              >
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between p-5 text-left hover:bg-neutral-50 transition-colors"
                >
                  <span className="font-medium text-neutral-900">{faq.question}</span>
                  <ChevronDown
                    className={cn(
                      'w-5 h-5 text-neutral-400 transition-transform',
                      openFaq === i && 'rotate-180'
                    )}
                  />
                </button>
                {openFaq === i && (
                  <div className="px-5 pb-5">
                    <p className="text-neutral-600">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 px-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-lavender-100/50 to-softblue-50/50" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-radial from-lavender-200/20 to-transparent rounded-full blur-3xl" />
        
        <div className="relative max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-semibold text-neutral-900 mb-4">
            Start with intelligence.<br />Scale into control.
          </h2>
          <p className="text-lg text-neutral-500 mb-10">
            Whether you need direct compliance answers or a full operating system, Requi grows with your team.
          </p>
          <div className="flex items-center justify-center gap-4">
            <button className="btn-primary px-8 py-4 text-base">
              Start Free Trial
              <ArrowRight className="w-5 h-5 ml-2" />
            </button>
            <button className="btn-secondary px-8 py-4 text-base bg-white/80">
              Talk to Sales
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-8 border-t border-neutral-100 bg-white">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-lavender to-lavender-500 flex items-center justify-center">
              <Sparkles className="w-4.5 h-4.5 text-white" />
            </div>
            <div>
              <span className="font-semibold text-neutral-900">Requi</span>
              <span className="text-neutral-400 ml-1">Health</span>
            </div>
          </div>
          <p className="text-sm text-neutral-400">
            © 2024 Requi Health. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};
