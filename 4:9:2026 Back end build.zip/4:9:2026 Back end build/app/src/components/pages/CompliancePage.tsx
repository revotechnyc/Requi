import React, { useState } from 'react';
import { 
  Shield, 
  ChevronRight, 
  AlertTriangle,
  FileText,
  CheckCircle2,
  Clock,
  TrendingUp,
  TrendingDown,
  ArrowRight,
  Sparkles
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Card, StatsCard } from '@/components/design-system';

interface ComplianceCategory {
  id: string;
  name: string;
  icon: React.ElementType;
  score: number;
  gaps: number;
  lastUpdated: string;
  status: 'good' | 'warning' | 'critical';
}

const categories: ComplianceCategory[] = [
  { id: '1', name: 'HIPAA', icon: Shield, score: 92, gaps: 1, lastUpdated: '2 days ago', status: 'good' },
  { id: '2', name: 'FWA', icon: AlertTriangle, score: 78, gaps: 3, lastUpdated: '1 week ago', status: 'warning' },
  { id: '3', name: 'Reporting', icon: FileText, score: 85, gaps: 2, lastUpdated: '3 days ago', status: 'good' },
  { id: '4', name: 'Documentation', icon: CheckCircle2, score: 71, gaps: 5, lastUpdated: '5 days ago', status: 'warning' },
  { id: '5', name: 'Training', icon: Clock, score: 88, gaps: 1, lastUpdated: 'Yesterday', status: 'good' },
];

const recentGaps = [
  { id: '1', title: 'Missing Business Associate Agreement', category: 'HIPAA', severity: 'high', daysOpen: 5 },
  { id: '2', title: 'Incomplete risk assessment documentation', category: 'HIPAA', severity: 'medium', daysOpen: 12 },
  { id: '3', title: 'Staff training overdue', category: 'Training', severity: 'critical', daysOpen: 3 },
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'good': return 'text-green-600 bg-green-50';
    case 'warning': return 'text-amber-600 bg-amber-50';
    case 'critical': return 'text-red-600 bg-red-50';
    default: return 'text-neutral-600 bg-neutral-50';
  }
};

const getSeverityColor = (severity: string) => {
  switch (severity) {
    case 'critical': return 'bg-red-500';
    case 'high': return 'bg-amber-500';
    case 'medium': return 'bg-yellow-500';
    case 'low': return 'bg-blue-500';
    default: return 'bg-neutral-500';
  }
};

export const CompliancePage: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  return (
    <div className="flex h-screen bg-neutral-50">
      <main className="flex-1 overflow-y-auto custom-scrollbar">
        <div className="max-w-6xl mx-auto px-8 py-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-heading-3 text-neutral-900 mb-1">Compliance</h1>
              <p className="text-body text-neutral-500">
                Monitor and manage your compliance across all categories
              </p>
            </div>
            <button className="btn-primary">
              <Sparkles className="w-4 h-4 mr-2" />
              AI Review
            </button>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-4 gap-4 mb-8">
            <StatsCard
              label="Overall Score"
              value="87"
              change="+5 this month"
              trend="up"
              icon={<Shield className="w-5 h-5" />}
            />
            <StatsCard
              label="Open Gaps"
              value="14"
              change="-2 resolved"
              trend="up"
              icon={<AlertTriangle className="w-5 h-5" />}
            />
            <StatsCard
              label="At Risk Areas"
              value="3"
              change="Needs attention"
              trend="down"
              icon={<TrendingDown className="w-5 h-5" />}
            />
            <StatsCard
              label="Days to Audit"
              value="45"
              change="On track"
              trend="neutral"
              icon={<Clock className="w-5 h-5" />}
            />
          </div>

          {/* Categories Grid */}
          <div className="mb-8">
            <h2 className="text-heading-4 text-neutral-900 mb-4">Compliance Categories</h2>
            <div className="grid grid-cols-3 gap-4">
              {categories.map((category) => (
                <Card
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={cn(
                    'p-5 cursor-pointer transition-all duration-200',
                    selectedCategory === category.id ? 'ring-2 ring-lavender-300' : 'hover:border-lavender-200'
                  )}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className={cn(
                      'w-12 h-12 rounded-xl flex items-center justify-center',
                      getStatusColor(category.status)
                    )}>
                      <category.icon className="w-6 h-6" />
                    </div>
                    <div className={cn(
                      'flex items-center gap-1 text-sm font-medium',
                      category.score >= 80 ? 'text-green-600' : category.score >= 60 ? 'text-amber-600' : 'text-red-600'
                    )}>
                      {category.score >= 80 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                      {category.score}%
                    </div>
                  </div>
                  <h3 className="font-semibold text-neutral-900 mb-1">{category.name}</h3>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-neutral-400">{category.gaps} gaps</span>
                    <span className="text-neutral-400">{category.lastUpdated}</span>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          {/* Two Column Layout */}
          <div className="grid grid-cols-2 gap-6">
            {/* Recent Gaps */}
            <Card className="p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-neutral-900">Recent Gaps</h3>
                <button className="text-sm text-lavender-600 hover:text-lavender-700 transition-colors flex items-center gap-1">
                  View all
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="space-y-3">
                {recentGaps.map((gap) => (
                  <div
                    key={gap.id}
                    className="flex items-center gap-4 p-4 rounded-xl bg-neutral-50 cursor-pointer hover:bg-lavender-50 transition-colors group"
                  >
                    <div className={cn('w-3 h-3 rounded-full', getSeverityColor(gap.severity))} />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-neutral-900 text-sm truncate">{gap.title}</p>
                      <p className="text-xs text-neutral-400">{gap.category} • {gap.daysOpen} days open</p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-neutral-300 group-hover:text-lavender-600 transition-colors" />
                  </div>
                ))}
              </div>
            </Card>

            {/* Upcoming Reviews */}
            <Card className="p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-neutral-900">Upcoming Reviews</h3>
                <button className="text-sm text-lavender-600 hover:text-lavender-700 transition-colors flex items-center gap-1">
                  View calendar
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="space-y-3">
                {[
                  { title: 'HIPAA Annual Review', date: 'Jan 15, 2024', type: 'Mandatory' },
                  { title: 'FWA Training Audit', date: 'Jan 22, 2024', type: 'Internal' },
                  { title: 'Documentation Review', date: 'Feb 1, 2024', type: 'External' },
                ].map((review, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between p-4 rounded-xl bg-neutral-50"
                  >
                    <div>
                      <p className="font-medium text-neutral-900 text-sm">{review.title}</p>
                      <p className="text-xs text-neutral-400">{review.date}</p>
                    </div>
                    <span className="px-3 py-1 rounded-lg bg-lavender-50 text-lavender-700 text-xs font-medium">
                      {review.type}
                    </span>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
};
