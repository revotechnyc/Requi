import React, { useState } from 'react';
import { 
  Send, 
  Paperclip, 
  Mic, 
  Sparkles,
  FileCheck,
  ClipboardCheck,
  TrendingUp,
  CheckSquare,
  Clock,
  MoreHorizontal,
  ArrowRight,
  Zap
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Card } from '@/components/design-system';

interface SuggestedAction {
  id: string;
  title: string;
  description: string;
  type: 'task' | 'reminder' | 'compliance';
}

const quickActions = [
  {
    title: 'Generate compliance plan',
    description: 'Create a tailored plan',
    icon: <FileCheck className="w-5 h-5" />,
  },
  {
    title: 'Check reporting requirements',
    description: 'Review upcoming deadlines',
    icon: <ClipboardCheck className="w-5 h-5" />,
  },
  {
    title: 'Audit readiness check',
    description: 'Assess your preparedness',
    icon: <TrendingUp className="w-5 h-5" />,
  },
];

const suggestedActions: SuggestedAction[] = [
  {
    id: '1',
    title: 'Review HIPAA Security Rule updates',
    description: 'New federal guidelines released - 3 policies need updates',
    type: 'compliance',
  },
  {
    id: '2',
    title: 'Complete staff training module',
    description: '12 employees overdue for cybersecurity training',
    type: 'task',
  },
  {
    id: '3',
    title: 'Quarterly compliance report',
    description: 'Auto-generated report ready for review',
    type: 'reminder',
  },
];

const recentChats = [
  { id: '1', title: 'HIPAA policy review questions', time: '2 hours ago' },
  { id: '2', title: 'Risk assessment for Q4', time: 'Yesterday', unread: true },
  { id: '3', title: 'Training compliance check', time: '3 days ago' },
  { id: '4', title: 'Document audit preparation', time: '1 week ago' },
];

export const IntelligencePage: React.FC = () => {
  const [inputValue, setInputValue] = useState('');
  const [isFocused, setIsFocused] = useState(false);

  return (
    <div className="flex h-screen bg-neutral-50">
      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-14 bg-white border-b border-neutral-100 flex items-center justify-between px-6">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-lavender-500" />
            <span className="font-medium text-neutral-900">Intelligence</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-full bg-lavender-50 text-lavender-700 text-xs font-medium flex items-center gap-1.5">
              <Zap className="w-3 h-3" />
              AI Ready
            </span>
          </div>
        </header>

        {/* Center Content */}
        <div className="flex-1 overflow-y-auto custom-scrollbar">
          <div className="max-w-3xl mx-auto px-8 py-12">
            {/* Greeting with Orb */}
            <div className="flex flex-col items-center mb-10">
              <div className="w-24 h-24 rounded-full glow-orb animate-pulse-glow mb-6" />
              <h1 className="text-heading-2 text-neutral-900 mb-1">
                Hello, <span className="text-gradient">Sarah</span>
              </h1>
              <p className="text-body text-neutral-500">
                How can I assist you today?
              </p>
            </div>

            {/* AI Input */}
            <div className="relative mb-8">
              <div
                className={cn(
                  'relative transition-all duration-300',
                  isFocused && 'transform scale-[1.01]'
                )}
              >
                <input
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onFocus={() => setIsFocused(true)}
                  onBlur={() => setIsFocused(false)}
                  placeholder="Ask about compliance, requirements, deadlines..."
                  className="ai-input pr-28"
                />
                <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                  <button className="w-9 h-9 rounded-xl bg-neutral-50 flex items-center justify-center text-neutral-400 hover:bg-lavender-50 hover:text-lavender-600 transition-colors">
                    <Paperclip className="w-4 h-4" />
                  </button>
                  <button className="w-9 h-9 rounded-xl bg-neutral-50 flex items-center justify-center text-neutral-400 hover:bg-lavender-50 hover:text-lavender-600 transition-colors">
                    <Mic className="w-4 h-4" />
                  </button>
                  <button className="w-10 h-10 rounded-xl bg-gradient-to-br from-lavender to-lavender-500 flex items-center justify-center text-neutral-900 hover:shadow-glow transition-shadow">
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="mb-8">
              <p className="text-sm font-medium text-neutral-400 mb-3">Quick actions</p>
              <div className="grid grid-cols-3 gap-3">
                {quickActions.map((action, i) => (
                  <button
                    key={i}
                    className="flex flex-col gap-2 p-4 rounded-2xl bg-white border border-neutral-100 hover:border-lavender-200 hover:shadow-soft transition-all text-left group"
                  >
                    <div className="w-9 h-9 rounded-xl bg-lavender-50 flex items-center justify-center text-lavender-600 group-hover:bg-lavender-100 transition-colors">
                      {action.icon}
                    </div>
                    <div>
                      <h4 className="font-medium text-neutral-900 text-sm">{action.title}</h4>
                      <p className="text-xs text-neutral-400 mt-0.5">{action.description}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Suggested Actions */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <p className="text-sm font-medium text-neutral-400">Suggested for you</p>
                <button className="text-sm text-lavender-600 hover:text-lavender-700 transition-colors flex items-center gap-1">
                  View all
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="space-y-2">
                {suggestedActions.map((action) => (
                  <Card
                    key={action.id}
                    className="p-4 flex items-center gap-4 cursor-pointer hover:border-lavender-200 transition-colors group"
                  >
                    <div className={cn(
                      'w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0',
                      action.type === 'task' && 'bg-lavender-50 text-lavender-600',
                      action.type === 'reminder' && 'bg-softblue-50 text-softblue-600',
                      action.type === 'compliance' && 'bg-amber-50 text-amber-600',
                    )}>
                      {action.type === 'task' && <CheckSquare className="w-4 h-4" />}
                      {action.type === 'reminder' && <Clock className="w-4 h-4" />}
                      {action.type === 'compliance' && <Sparkles className="w-4 h-4" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-neutral-900 text-sm truncate">{action.title}</h4>
                      <p className="text-xs text-neutral-400 truncate">{action.description}</p>
                    </div>
                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="px-3 py-1.5 rounded-lg bg-lavender-50 text-lavender-700 text-xs font-medium hover:bg-lavender-100 transition-colors">
                        Convert to Task
                      </button>
                      <button className="px-3 py-1.5 rounded-lg bg-neutral-50 text-neutral-600 text-xs font-medium hover:bg-lavender-50 transition-colors">
                        Reminder
                      </button>
                    </div>
                    <button className="w-8 h-8 rounded-lg flex items-center justify-center text-neutral-400 hover:bg-neutral-50 transition-colors">
                      <MoreHorizontal className="w-4 h-4" />
                    </button>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Right Sidebar - Recent Chats */}
      <aside className="w-64 bg-white border-l border-neutral-100 flex flex-col">
        <div className="p-4 border-b border-neutral-100">
          <h3 className="font-medium text-neutral-900 text-sm">Recent Conversations</h3>
        </div>
        <div className="flex-1 overflow-y-auto custom-scrollbar p-3">
          <div className="space-y-1">
            {recentChats.map((chat) => (
              <button
                key={chat.id}
                className="w-full text-left p-3 rounded-xl hover:bg-neutral-50 transition-colors group"
              >
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-lavender-50 flex items-center justify-center flex-shrink-0 group-hover:bg-lavender-100 transition-colors">
                    <Sparkles className="w-4 h-4 text-lavender-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-neutral-900 truncate">{chat.title}</p>
                    <p className="text-xs text-neutral-400 mt-0.5">{chat.time}</p>
                  </div>
                  {chat.unread && (
                    <div className="w-2 h-2 rounded-full bg-lavender-500 mt-1.5 flex-shrink-0" />
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className="p-4 border-t border-neutral-100">
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 rounded-xl bg-lavender-50">
              <p className="text-xl font-semibold text-lavender-700">87</p>
              <p className="text-xs text-neutral-400">Compliance</p>
            </div>
            <div className="p-3 rounded-xl bg-softblue-50">
              <p className="text-xl font-semibold text-softblue-700">23</p>
              <p className="text-xs text-neutral-400">Tasks</p>
            </div>
          </div>
        </div>
      </aside>
    </div>
  );
};
