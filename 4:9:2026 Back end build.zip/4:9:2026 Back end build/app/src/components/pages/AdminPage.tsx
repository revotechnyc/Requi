import React from 'react';
import { 
  Users, 
  Building2, 
  CreditCard, 
  Settings,
  Shield,
  Activity,
  TrendingUp,
  MoreHorizontal,
  Plus,
  ArrowRight,
  Zap
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Card, StatsCard } from '@/components/design-system';

const adminSections = [
  { id: 'organization', name: 'Organization', icon: Building2, description: 'Manage org settings and details' },
  { id: 'members', name: 'Members', icon: Users, description: 'Manage team and permissions' },
  { id: 'billing', name: 'Billing', icon: CreditCard, description: 'Subscription and payments' },
  { id: 'security', name: 'Security', icon: Shield, description: 'Access control and audit logs' },
  { id: 'settings', name: 'Settings', icon: Settings, description: 'Platform configuration' },
];

const platformStats = [
  { label: 'Total Users', value: '127', change: '+12 this month', trend: 'up' as const },
  { label: 'Active Workspaces', value: '8', change: '+2 this month', trend: 'up' as const },
  { label: 'API Calls (24h)', value: '45.2K', change: '+18%', trend: 'up' as const },
  { label: 'Avg Response Time', value: '124ms', change: '-8%', trend: 'up' as const },
];

const recentActivity = [
  { id: '1', user: 'Sarah Chen', action: 'Updated HIPAA policy', time: '2 hours ago', type: 'update' },
  { id: '2', user: 'Michael Torres', action: 'Added new team member', time: '4 hours ago', type: 'create' },
  { id: '3', user: 'System', action: 'Completed daily compliance scan', time: '6 hours ago', type: 'system' },
  { id: '4', user: 'Emma Wilson', action: 'Exported audit report', time: 'Yesterday', type: 'export' },
];

export const AdminPage: React.FC = () => {
  return (
    <div className="flex h-screen bg-neutral-50">
      <main className="flex-1 overflow-y-auto custom-scrollbar">
        <div className="max-w-6xl mx-auto px-8 py-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-heading-3 text-neutral-900 mb-1">Admin Console</h1>
              <p className="text-body text-neutral-500">
                Manage your organization, team, and platform settings
              </p>
            </div>
            <button className="btn-primary">
              <Plus className="w-4 h-4 mr-2" />
              Invite Member
            </button>
          </div>

          {/* Platform Stats */}
          <div className="grid grid-cols-4 gap-4 mb-8">
            {platformStats.map((stat, i) => (
              <StatsCard
                key={i}
                label={stat.label}
                value={stat.value}
                change={stat.change}
                trend={stat.trend}
                icon={i === 0 ? <Users className="w-5 h-5" /> : i === 1 ? <Building2 className="w-5 h-5" /> : i === 2 ? <Activity className="w-5 h-5" /> : <Zap className="w-5 h-5" />}
              />
            ))}
          </div>

          {/* Admin Sections Grid */}
          <div className="mb-8">
            <h2 className="text-heading-4 text-neutral-900 mb-4">Administration</h2>
            <div className="grid grid-cols-3 gap-4">
              {adminSections.map((section) => (
                <Card
                  key={section.id}
                  className="p-5 cursor-pointer hover:border-lavender-200 transition-colors group"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-12 h-12 rounded-xl bg-lavender-50 flex items-center justify-center group-hover:bg-lavender-100 transition-colors">
                      <section.icon className="w-6 h-6 text-lavender-600" />
                    </div>
                    <button className="w-8 h-8 rounded-lg flex items-center justify-center text-neutral-400 hover:bg-neutral-50 transition-colors opacity-0 group-hover:opacity-100">
                      <MoreHorizontal className="w-4 h-4" />
                    </button>
                  </div>
                  <h3 className="font-semibold text-neutral-900 mb-1">{section.name}</h3>
                  <p className="text-sm text-neutral-400">{section.description}</p>
                </Card>
              ))}
            </div>
          </div>

          {/* Two Column Layout */}
          <div className="grid grid-cols-2 gap-6">
            {/* Recent Activity */}
            <Card className="p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-neutral-900">Recent Activity</h3>
                <button className="text-sm text-lavender-600 hover:text-lavender-700 transition-colors flex items-center gap-1">
                  View all
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="space-y-4">
                {recentActivity.map((activity) => (
                  <div key={activity.id} className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-lavender to-softblue flex items-center justify-center">
                      <span className="text-sm font-medium text-neutral-900">
                        {activity.user.charAt(0)}
                      </span>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-neutral-900">
                        <span className="font-medium">{activity.user}</span>{' '}
                        <span className="text-neutral-400">{activity.action}</span>
                      </p>
                      <p className="text-xs text-neutral-400">{activity.time}</p>
                    </div>
                    <span className={cn(
                      'px-2 py-1 rounded-lg text-xs font-medium',
                      activity.type === 'update' && 'bg-blue-50 text-blue-700',
                      activity.type === 'create' && 'bg-green-50 text-green-700',
                      activity.type === 'system' && 'bg-neutral-50 text-neutral-600',
                      activity.type === 'export' && 'bg-amber-50 text-amber-700',
                    )}>
                      {activity.type}
                    </span>
                  </div>
                ))}
              </div>
            </Card>

            {/* Quick Actions */}
            <Card className="p-5">
              <h3 className="font-semibold text-neutral-900 mb-4">Quick Actions</h3>
              <div className="space-y-3">
                {[
                  { label: 'Invite team member', icon: Plus, description: 'Add a new user to your organization' },
                  { label: 'Generate report', icon: Activity, description: 'Create compliance or audit report' },
                  { label: 'View audit logs', icon: Shield, description: 'Review system activity and changes' },
                  { label: 'Manage integrations', icon: TrendingUp, description: 'Connect third-party services' },
                ].map((action, i) => (
                  <button
                    key={i}
                    className="w-full flex items-center gap-4 p-4 rounded-xl hover:bg-lavender-50 transition-colors text-left group"
                  >
                    <div className="w-10 h-10 rounded-xl bg-lavender-50 flex items-center justify-center group-hover:bg-lavender-100 transition-colors">
                      <action.icon className="w-5 h-5 text-lavender-600" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-neutral-900 text-sm">{action.label}</p>
                      <p className="text-xs text-neutral-400">{action.description}</p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-neutral-300 group-hover:text-lavender-600 transition-colors" />
                  </button>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
};
