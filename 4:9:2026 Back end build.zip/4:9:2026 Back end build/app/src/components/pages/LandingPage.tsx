import React from 'react';
import { Sparkles, ArrowRight, Shield, Zap, BarChart3, Users, CheckCircle } from 'lucide-react';

const features = [
  {
    icon: Shield,
    title: 'Compliance Monitoring',
    description: 'Track your compliance scores across all regulatory frameworks in real-time.',
  },
  {
    icon: Zap,
    title: 'AI-Powered Insights',
    description: 'Get intelligent recommendations and automated gap analysis.',
  },
  {
    icon: BarChart3,
    title: 'Risk Assessment',
    description: 'Identify and mitigate risks before they become issues.',
  },
  {
    icon: Users,
    title: 'Team Collaboration',
    description: 'Assign tasks, track progress, and collaborate seamlessly.',
  },
];

const stats = [
  { value: '500+', label: 'Healthcare Organizations' },
  { value: '99.9%', label: 'Uptime SLA' },
  { value: '50M+', label: 'Compliance Checks' },
  { value: '24/7', label: 'AI Monitoring' },
];

export const LandingPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="h-16 border-b border-neutral-100 flex items-center justify-between px-8">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-lavender to-lavender-500 flex items-center justify-center">
            <Sparkles className="w-4.5 h-4.5 text-white" />
          </div>
          <div>
            <span className="font-semibold text-neutral-900">Requi</span>
            <span className="text-neutral-400 ml-1">Health</span>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <a href="#features" className="text-sm text-neutral-600 hover:text-neutral-900 transition-colors">Features</a>
          <a href="#pricing" className="text-sm text-neutral-600 hover:text-neutral-900 transition-colors">Pricing</a>
          <a href="#about" className="text-sm text-neutral-600 hover:text-neutral-900 transition-colors">About</a>
          <button className="btn-secondary text-sm">Sign In</button>
          <button className="btn-primary text-sm">Get Started</button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-lavender-50 via-white to-softblue-50" />
        <div className="relative max-w-6xl mx-auto px-8 py-24">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-lavender-100 text-lavender-700 text-sm font-medium mb-6">
              <Sparkles className="w-4 h-4" />
              Now with AI-powered compliance
            </div>
            <h1 className="text-display text-neutral-900 mb-6">
              Healthcare Compliance,<br />
              <span className="text-gradient">Simplified</span>
            </h1>
            <p className="text-body-lg text-neutral-500 mb-8 max-w-xl mx-auto">
              AI-powered platform that helps healthcare organizations stay compliant with HIPAA, FWA, and other regulatory frameworks.
            </p>
            <div className="flex items-center justify-center gap-4">
              <button className="btn-primary text-base px-8 py-4">
                Start Free Trial
                <ArrowRight className="w-5 h-5 ml-2" />
              </button>
              <button className="btn-secondary text-base px-8 py-4">
                View Demo
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white border-y border-neutral-100">
        <div className="max-w-6xl mx-auto px-8">
          <div className="grid grid-cols-4 gap-8">
            {stats.map((stat, i) => (
              <div key={i} className="text-center">
                <p className="text-3xl font-semibold text-neutral-900 mb-1">{stat.value}</p>
                <p className="text-sm text-neutral-500">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 bg-neutral-50">
        <div className="max-w-6xl mx-auto px-8">
          <div className="text-center mb-16">
            <h2 className="text-heading-2 text-neutral-900 mb-4">Everything you need for compliance</h2>
            <p className="text-body text-neutral-500 max-w-xl mx-auto">
              A complete platform to manage your healthcare compliance requirements.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-6">
            {features.map((feature, i) => (
              <div key={i} className="card-hover p-8">
                <div className="w-12 h-12 rounded-xl bg-lavender-50 flex items-center justify-center text-lavender-600 mb-4">
                  <feature.icon className="w-6 h-6" />
                </div>
                <h3 className="font-semibold text-neutral-900 text-lg mb-2">{feature.title}</h3>
                <p className="text-neutral-500">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-br from-lavender-100 to-softblue-50">
        <div className="max-w-4xl mx-auto px-8 text-center">
          <h2 className="text-heading-2 text-neutral-900 mb-4">Ready to simplify compliance?</h2>
          <p className="text-body text-neutral-500 mb-8 max-w-lg mx-auto">
            Join hundreds of healthcare organizations using Requi Health to stay compliant.
          </p>
          <div className="flex items-center justify-center gap-4">
            <button className="btn-primary text-base px-8 py-4">
              Start Free Trial
              <ArrowRight className="w-5 h-5 ml-2" />
            </button>
            <button className="btn-secondary text-base px-8 py-4 bg-white/80">
              Contact Sales
            </button>
          </div>
          <div className="flex items-center justify-center gap-6 mt-8">
            {['No credit card required', '14-day free trial', 'Cancel anytime'].map((item, i) => (
              <div key={i} className="flex items-center gap-2 text-sm text-neutral-500">
                <CheckCircle className="w-4 h-4 text-lavender-500" />
                {item}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-white border-t border-neutral-100">
        <div className="max-w-6xl mx-auto px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-lavender to-lavender-500 flex items-center justify-center">
                <Sparkles className="w-4.5 h-4.5 text-white" />
              </div>
              <div>
                <span className="font-semibold text-neutral-900">Requi</span>
                <span className="text-neutral-400 ml-1">Health</span>
              </div>
            </div>
            <p className="text-sm text-neutral-400">
              © 2024 Requi Health. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};
