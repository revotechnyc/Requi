import { useState } from 'react';
import { Sidebar } from '@/components/layout';
import { 
  IntelligencePage, 
  DashboardPage, 
  TasksPage, 
  CompliancePage, 
  AdminPage,
  LoginPage,
  LandingPage,
  PricingPage 
} from '@/components/pages';

// Simple router state
const PAGES = {
  login: LoginPage,
  landing: LandingPage,
  pricing: PricingPage,
  intelligence: IntelligencePage,
  dashboard: DashboardPage,
  tasks: TasksPage,
  compliance: CompliancePage,
  calendar: DashboardPage,
  documents: DashboardPage,
  news: DashboardPage,
  integrations: AdminPage,
  settings: AdminPage,
};

type PageKey = keyof typeof PAGES;

function App() {
  const [currentPage, setCurrentPage] = useState<PageKey>('pricing');
  const [isAuthenticated] = useState(true);

  const CurrentPageComponent = PAGES[currentPage];

  // Login flow
  if (!isAuthenticated) {
    return <LoginPage />;
  }

  return (
    <div className="flex h-screen bg-base-offwhite overflow-hidden">
      {/* Sidebar */}
      <Sidebar 
        activeItem={currentPage} 
        onItemClick={(page) => setCurrentPage(page as PageKey)} 
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <CurrentPageComponent />
      </div>
    </div>
  );
}

export default App;
