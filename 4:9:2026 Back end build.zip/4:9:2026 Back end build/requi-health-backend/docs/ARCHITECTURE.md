# Requi Health Backend Architecture

## Executive Summary

This document defines the complete backend architecture for Requi Health, an enterprise healthcare compliance AI platform.

## System Boundaries

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           EXTERNAL SYSTEMS                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │   Claude     │  │   PayPal     │  │   SendGrid   │  │     S3       │   │
│  │     API      │  │     API      │  │     API      │  │  (Storage)   │   │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         REQUI HEALTH PLATFORM                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      API GATEWAY (Express)                          │   │
│  │  - Rate limiting  - Authentication  - Request validation            │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                    SERVICE LAYER (Modular)                          │   │
│  ├─────────────────────────────────────────────────────────────────────┤   │
│  │  Auth Service    │  Workspace Service  │  Team Service              │   │
│  │  Billing Service │  Template Service   │  File Service              │   │
│  │  Source Service  │  Ingestion Service  │  Retrieval Service         │   │
│  │  Claude Service  │  Missing KB Service │  Admin Service             │   │
│  │  Audit Service   │  Notification Svc   │  Analytics Service         │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      DATA LAYER                                     │   │
│  ├─────────────────────────────────────────────────────────────────────┤   │
│  │  PostgreSQL (Primary)  │  Redis (Cache)  │  S3 (Files)             │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Primary Request Flow

```
User Request
    │
    ▼
┌─────────────┐
│ API Gateway │──► Rate Limit Check
│   Express   │──► Auth Middleware
└─────────────┘──► Permission Check
    │
    ▼
┌─────────────┐
│  Controller │──► Validate Input
└─────────────┘
    │
    ▼
┌─────────────┐
│   Service   │──► Business Logic
└─────────────┘
    │
    ▼
┌─────────────┐     ┌─────────────┐
│  Database   │◄───►│    Cache    │
└─────────────┘     └─────────────┘
    │
    ▼
Response
```

## Claude Orchestration Flow

```
User Query
    │
    ▼
┌─────────────────────┐
│ 1. Prompt Classifier│──► Class 1-11 detection
└─────────────────────┘
    │
    ▼
┌─────────────────────┐
│ 2. Jurisdiction     │──► Federal/State/Program
│    Detector         │
└─────────────────────┘
    │
    ▼
┌─────────────────────┐
│ 3. Source Retriever │──► Query vector DB
└─────────────────────┘
    │
    ▼
┌─────────────────────┐
│ 4. Prompt Assembler │──► Layer 1 + Layer 2 + Layer 3
└─────────────────────┘
    │
    ▼
┌─────────────────────┐
│ 5. Claude API Call  │──► Streaming response
└─────────────────────┘
    │
    ▼
┌─────────────────────┐
│ 6. Response Parser  │──► Structured output
└─────────────────────┘
    │
    ▼
┌─────────────────────┐
│ 7. Confidence Check │──► High/Medium/Low/Unsupported
└─────────────────────┘
    │
    ├──► High Confidence ──► Return Answer
    │
    ├──► Medium Confidence ──► Return with Caveats
    │
    ├──► Low Confidence ──► Create Missing KB Event
    │
    └──► Unsupported ──► Create Admin Task
```

## Technical Stack

| Component | Technology | Rationale |
|-----------|-----------|-----------|
| **Runtime** | Node.js 20+ | Modern JS, async/await, large ecosystem |
| **Framework** | Express.js | Battle-tested, middleware-rich, enterprise standard |
| **Language** | TypeScript 5+ | Type safety, IntelliSense, maintainability |
| **Database** | PostgreSQL 15+ | ACID compliance, JSON support, enterprise proven |
| **ORM** | Prisma | Type-safe queries, migrations, excellent DX |
| **Cache** | Redis 7+ | Session storage, rate limiting, pub/sub |
| **Queue** | BullMQ (Redis) | Job processing, retries, scheduling |
| **File Storage** | AWS S3 | Scalable, durable, CDN-ready |
| **Vector DB** | pgvector (PostgreSQL extension) | Single database, no additional infra |
| **LLM** | Anthropic Claude API | Best-in-class reasoning, large context |
| **Auth** | JWT + bcrypt | Stateless, scalable, secure |
| **Validation** | Zod | TypeScript-first, runtime validation |
| **Logging** | Winston + Pino | Structured logs, multiple transports |
| **Monitoring** | Prometheus + Grafana | Metrics, dashboards, alerting |
| **Testing** | Jest + Supertest | Unit, integration, e2e testing |

## Service Decomposition

### 1. Authentication Service
- **Purpose**: User identity, login, tokens, password management
- **Inputs**: Email/password, OAuth tokens, refresh tokens
- **Outputs**: JWT access/refresh tokens, user profiles
- **Database**: users, sessions, refresh_tokens
- **Security**: bcrypt (passwords), JWT (tokens), rate limiting

### 2. Organization & Workspace Service
- **Purpose**: Multi-tenant workspace management
- **Inputs**: Create/update workspace, settings
- **Outputs**: Workspace configs, metadata
- **Database**: organizations, workspaces, workspace_settings

### 3. Team & Permissions Service
- **Purpose**: Role-based access control (RBAC)
- **Inputs**: Invite users, assign roles, permissions
- **Outputs**: Team members, permission checks
- **Database**: teams, team_members, roles, permissions, invitations
- **Roles**: owner, admin, manager, contributor, viewer

### 4. Project & File Service
- **Purpose**: File uploads, project organization
- **Inputs**: Upload files, create projects, tag documents
- **Outputs**: File URLs, project hierarchies
- **Storage**: S3 for files, PostgreSQL for metadata

### 5. Template & Letterhead Service
- **Purpose**: Company templates with letterheads
- **Inputs**: Create template, upload letterhead, define sections
- **Outputs**: Rendered templates, template library
- **Database**: templates, template_versions, letterheads

### 6. Source Registry Service
- **Purpose**: Document source catalog and metadata
- **Inputs**: Register sources, update metadata
- **Outputs**: Source listings, authority rankings
- **Database**: sources, source_metadata, source_versions

### 7. Document Ingestion Service
- **Purpose**: PDF processing, text extraction, chunking
- **Inputs**: PDF URLs/files, source metadata
- **Outputs**: Extracted text, chunks, embeddings
- **Processing**: pdf-parse, chunking, OpenAI embeddings
- **Queue**: BullMQ for async processing

### 8. Retrieval & Source Selection Service
- **Purpose**: Semantic search, source ranking
- **Inputs**: User query, jurisdiction filters
- **Outputs**: Ranked sources, relevance scores
- **Database**: pgvector for embeddings

### 9. Claude Orchestration Service
- **Purpose**: LLM interaction, prompt assembly
- **Inputs**: User query, retrieved sources, template
- **Outputs**: AI responses, structured output
- **External**: Anthropic Claude API

### 10. Missing Knowledge Detection Service
- **Purpose**: Detect gaps, create admin tasks
- **Inputs**: Low confidence responses, unsupported queries
- **Outputs**: Missing KB events, admin tasks
- **Database**: missing_knowledge_events, admin_tasks

### 11. Billing & Subscription Service
- **Purpose**: Seat management, billing logic
- **Inputs**: Subscription changes, seat assignments
- **Outputs**: Billing records, entitlement checks
- **External**: PayPal API
- **Database**: subscriptions, billing_events, seat_allocations

### 12. Audit & Activity Logging Service
- **Purpose**: Compliance logging, audit trails
- **Inputs**: All system actions
- **Outputs**: Audit logs, activity feeds
- **Database**: audit_logs, activity_logs

## Database Schema Overview

### Core Tables
- `users` - User accounts
- `organizations` - Top-level orgs
- `workspaces` - Tenant isolation
- `teams` - Department groups
- `team_members` - User-team relationships
- `roles` - Role definitions
- `permissions` - Permission matrix
- `invitations` - Pending invites

### Content Tables
- `projects` - File organization
- `files` - File metadata
- `templates` - Document templates
- `template_versions` - Version history
- `letterheads` - Company letterheads

### Knowledge Tables
- `sources` - Document sources
- `source_metadata` - Source attributes
- `document_chunks` - Text chunks with embeddings
- `retrieval_logs` - Search history

### AI Tables
- `conversations` - Chat sessions
- `messages` - Chat messages
- `prompt_logs` - Prompt history
- `response_logs` - Response history

### Admin Tables
- `missing_knowledge_events` - Gap detection
- `admin_tasks` - Review tasks
- `task_assignments` - Task ownership
- `review_outcomes` - Resolution records

### Billing Tables
- `subscription_plans` - Plan definitions
- `subscriptions` - Active subscriptions
- `billing_events` - Payment history
- `seat_allocations` - Seat assignments

### Audit Tables
- `audit_logs` - Compliance audit trail
- `activity_logs` - User activity
- `api_usage_logs` - API metrics

## Security Architecture

### Authentication
- JWT access tokens (15 min expiry)
- Refresh tokens (7 day expiry, rotation)
- Password hashing (bcrypt, 12 rounds)
- OAuth 2.0 for SSO

### Authorization
- RBAC with permission matrix
- Workspace-scoped access
- Resource-level permissions
- API key authentication for integrations

### Data Protection
- TLS 1.3 for all connections
- AES-256 encryption at rest (S3)
- Field-level encryption for PII
- Secure secret management (AWS Secrets Manager)

### Audit & Compliance
- Immutable audit logs
- User action tracking
- Data retention policies
- HIPAA-ready architecture

## Observability

### Metrics
- API request rate/latency/errors
- Claude API usage/cost
- Database query performance
- Cache hit rates
- Queue depths

### Logging
- Structured JSON logs
- Log levels: error, warn, info, debug
- Correlation IDs for tracing
- Sensitive data redaction

### Alerting
- Error rate thresholds
- Latency SLOs
- Cost thresholds
- Queue backlog alerts

## Deployment

### Environment
- Development: Local Docker
- Staging: AWS ECS
- Production: AWS ECS + RDS

### Infrastructure
- Container orchestration: ECS Fargate
- Database: RDS PostgreSQL
- Cache: ElastiCache Redis
- Storage: S3
- CDN: CloudFront
- DNS: Route53

### CI/CD
- GitHub Actions for testing
- Automated deployments to staging
- Manual approval for production
- Database migrations via Prisma
