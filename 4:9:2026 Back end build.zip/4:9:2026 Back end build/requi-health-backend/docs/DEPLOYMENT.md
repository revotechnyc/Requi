# Deployment Guide

This guide covers deploying the Requi Health Backend to various environments.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Local Development](#local-development)
3. [Docker Deployment](#docker-deployment)
4. [Cloud Deployment](#cloud-deployment)
5. [Production Checklist](#production-checklist)

## Prerequisites

- Node.js 20+
- PostgreSQL 15+
- Redis 7+
- Anthropic API key
- PayPal credentials (for billing)

## Local Development

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Set up environment variables:**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

3. **Set up database:**
   ```bash
   npx prisma migrate dev
   npx prisma generate
   npm run db:seed
   ```

4. **Start development server:**
   ```bash
   npm run dev
   ```

5. **Start worker (in another terminal):**
   ```bash
   npm run dev:worker
   ```

## Docker Deployment

### Single Machine

1. **Build and start all services:**
   ```bash
   docker-compose up -d
   ```

2. **Run database migrations:**
   ```bash
   docker-compose exec api npx prisma migrate deploy
   ```

3. **Seed database:**
   ```bash
   docker-compose exec api npm run db:seed
   ```

4. **View logs:**
   ```bash
   docker-compose logs -f
   ```

### Stopping Services

```bash
docker-compose down
```

To remove volumes (WARNING: This will delete all data):
```bash
docker-compose down -v
```

## Cloud Deployment

### AWS ECS/Fargate

1. **Build and push Docker image:**
   ```bash
   aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin YOUR_ECR_REPO
   docker build -t requi-health-api .
   docker tag requi-health-api:latest YOUR_ECR_REPO/requi-health-api:latest
   docker push YOUR_ECR_REPO/requi-health-api:latest
   ```

2. **Create ECS Task Definition:**
   ```json
   {
     "family": "requi-health-api",
     "networkMode": "awsvpc",
     "requiresCompatibilities": ["FARGATE"],
     "cpu": "1024",
     "memory": "2048",
     "containerDefinitions": [
       {
         "name": "api",
         "image": "YOUR_ECR_REPO/requi-health-api:latest",
         "portMappings": [
           {
             "containerPort": 3001,
             "protocol": "tcp"
           }
         ],
         "environment": [
           {"name": "NODE_ENV", "value": "production"},
           {"name": "PORT", "value": "3001"}
         ],
         "secrets": [
           {"name": "DATABASE_URL", "valueFrom": "arn:aws:secretsmanager:..."},
           {"name": "JWT_SECRET", "valueFrom": "arn:aws:secretsmanager:..."},
           {"name": "ANTHROPIC_API_KEY", "valueFrom": "arn:aws:secretsmanager:..."}
         ],
         "logConfiguration": {
           "logDriver": "awslogs",
           "options": {
             "awslogs-group": "/ecs/requi-health-api",
             "awslogs-region": "us-east-1",
             "awslogs-stream-prefix": "ecs"
           }
         }
       }
     ]
   }
   ```

3. **Create ECS Service with Application Load Balancer**

### Google Cloud Run

1. **Build and push to Container Registry:**
   ```bash
   gcloud builds submit --tag gcr.io/PROJECT_ID/requi-health-api
   ```

2. **Deploy to Cloud Run:**
   ```bash
   gcloud run deploy requi-health-api \
     --image gcr.io/PROJECT_ID/requi-health-api \
     --platform managed \
     --region us-central1 \
     --allow-unauthenticated \
     --set-env-vars="NODE_ENV=production,PORT=3001" \
     --set-secrets="DATABASE_URL=database-url:latest,JWT_SECRET=jwt-secret:latest"
   ```

### Azure Container Instances

```bash
az container create \
  --resource-group myResourceGroup \
  --name requi-health-api \
  --image requihealth.azurecr.io/api:latest \
  --cpu 1 \
  --memory 2 \
  --ports 3001 \
  --environment-variables NODE_ENV=production PORT=3001 \
  --secrets DATABASE_URL=... JWT_SECRET=... \
  --ip-address Public
```

## Environment Variables

### Required

| Variable | Description |
|----------|-------------|
| `NODE_ENV` | `production` for production |
| `PORT` | Server port (default: 3001) |
| `DATABASE_URL` | PostgreSQL connection string |
| `REDIS_URL` | Redis connection string |
| `JWT_SECRET` | Secret for JWT signing |
| `ANTHROPIC_API_KEY` | Claude API key |

### Optional

| Variable | Description | Default |
|----------|-------------|---------|
| `LOG_LEVEL` | Logging level | `info` |
| `ALLOWED_ORIGINS` | CORS allowed origins | `http://localhost:5173` |
| `PAYPAL_CLIENT_ID` | PayPal client ID | - |
| `PAYPAL_CLIENT_SECRET` | PayPal client secret | - |
| `SENDGRID_API_KEY` | SendGrid API key | - |
| `MAX_FILE_SIZE` | Max upload size | `104857600` (100MB) |

## Production Checklist

### Security

- [ ] Change default JWT_SECRET to a strong random string
- [ ] Enable HTTPS/TLS
- [ ] Configure CORS with specific origins
- [ ] Set up rate limiting
- [ ] Enable audit logging
- [ ] Configure security headers (Helmet)
- [ ] Set up DDoS protection
- [ ] Enable WAF (Web Application Firewall)

### Database

- [ ] Enable database encryption at rest
- [ ] Set up automated backups
- [ ] Configure connection pooling
- [ ] Enable query logging for debugging
- [ ] Set up read replicas (if needed)

### Monitoring

- [ ] Set up application monitoring (DataDog, New Relic)
- [ ] Configure log aggregation (ELK, Splunk)
- [ ] Set up alerting for errors
- [ ] Monitor resource usage (CPU, memory, disk)
- [ ] Track API response times
- [ ] Monitor database performance

### Scaling

- [ ] Configure auto-scaling policies
- [ ] Set up load balancer
- [ ] Configure health checks
- [ ] Set up CDN for static assets
- [ ] Plan for database scaling

### Backup & Recovery

- [ ] Automated database backups
- [ ] Document recovery procedures
- [ ] Test recovery process
- [ ] Backup configuration files
- [ ] Document rollback procedures

### Compliance

- [ ] Enable HIPAA audit logging
- [ ] Configure data retention policies
- [ ] Set up access controls
- [ ] Document security procedures
- [ ] Conduct security audit

## Troubleshooting

### Common Issues

**Database connection errors:**
- Check DATABASE_URL format
- Verify network connectivity
- Check firewall rules

**Redis connection errors:**
- Verify REDIS_URL
- Check Redis is running
- Check authentication

**High memory usage:**
- Check for memory leaks
- Adjust rate limiting
- Review query performance

**Slow API responses:**
- Check database query performance
- Review Redis cache hit rate
- Monitor Claude API latency

## Support

For deployment support, contact:
- Email: devops@requi.health
- Slack: #deployment-support
