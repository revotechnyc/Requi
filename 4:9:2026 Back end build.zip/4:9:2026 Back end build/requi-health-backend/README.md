# Requi Health Backend

Enterprise Healthcare Compliance AI Platform - Backend API

## Overview

Requi Health is a closed-domain healthcare compliance reasoning engine that provides authoritative, jurisdiction-aware answers to healthcare compliance questions. The backend is built with Node.js, TypeScript, Express, PostgreSQL, and integrates with Anthropic's Claude API for AI-powered responses.

## Architecture

### Tech Stack

- **Runtime**: Node.js 20+
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL 15+ with Prisma ORM
- **Cache**: Redis 7+
- **AI**: Anthropic Claude API
- **Payments**: PayPal
- **Containerization**: Docker & Docker Compose

### Key Features

- **11-Layer Authority Hierarchy**: Federal statutes → Federal regulations → Federal guidance → State statutes → State regulations → State guidance → Program docs → Contracts → Case law → Academic → Best practices
- **Tiered Source Weighting**: Binding primary (Tier 1) through general search surfaces (Tier 6)
- **Confidence Boundaries**: HIGH/MEDIUM/LOW/UNSUPPORTED with explicit gap detection
- **Missing Knowledge Detection**: Automated detection → Admin task creation → Review queue → Resolution tracking
- **Multi-tenant Architecture**: Organizations → Workspaces → Teams → Role-based access
- **Comprehensive Audit Logging**: HIPAA-compliant audit trails

## Project Structure

```
requi-health-backend/
├── src/
│   ├── config/           # Configuration (database, Redis, Claude)
│   ├── middleware/       # Express middleware (auth, error handling, logging)
│   ├── prompts/          # AI system prompts
│   ├── routes/           # API route handlers
│   ├── services/         # Business logic services
│   ├── utils/            # Utility functions
│   └── index.ts          # Application entry point
├── prisma/
│   └── schema.prisma     # Database schema
├── docs/
│   └── ARCHITECTURE.md   # Detailed architecture documentation
├── uploads/              # File upload directory
├── .env.example          # Environment variables template
├── Dockerfile            # API server Dockerfile
├── Dockerfile.worker     # Background worker Dockerfile
├── docker-compose.yml    # Docker Compose configuration
├── package.json          # Dependencies and scripts
└── tsconfig.json         # TypeScript configuration
```

## Getting Started

### Prerequisites

- Node.js 20+
- PostgreSQL 15+
- Redis 7+
- Anthropic API key

### Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Copy environment variables:
   ```bash
   cp .env.example .env
   ```
4. Update `.env` with your configuration
5. Set up the database:
   ```bash
   npx prisma migrate dev
   npx prisma generate
   ```
6. Start the development server:
   ```bash
   npm run dev
   ```

### Docker Setup

1. Copy environment variables:
   ```bash
   cp .env.example .env
   ```
2. Update `.env` with your secrets
3. Start all services:
   ```bash
   docker-compose up -d
   ```

## API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout
- `POST /api/auth/refresh` - Refresh access token
- `GET /api/auth/me` - Get current user

### Workspaces
- `GET /api/workspaces` - List workspaces
- `POST /api/workspaces` - Create workspace
- `GET /api/workspaces/:id` - Get workspace details
- `PATCH /api/workspaces/:id` - Update workspace
- `DELETE /api/workspaces/:id` - Delete workspace
- `POST /api/workspaces/:id/invite` - Invite member

### Conversations (AI Chat)
- `GET /api/conversations` - List conversations
- `POST /api/conversations` - Create conversation
- `GET /api/conversations/:id` - Get conversation
- `POST /api/conversations/:id/messages` - Send message
- `DELETE /api/conversations/:id` - Delete conversation

### Sources (Documents)
- `GET /api/sources` - List sources
- `POST /api/sources` - Create source
- `GET /api/sources/:id` - Get source
- `PATCH /api/sources/:id` - Update source
- `DELETE /api/sources/:id` - Delete source
- `POST /api/sources/:id/upload` - Upload file
- `POST /api/sources/:id/reprocess` - Reprocess document

### Templates
- `GET /api/templates` - List templates
- `POST /api/templates` - Create template
- `GET /api/templates/:id` - Get template
- `PATCH /api/templates/:id` - Update template
- `DELETE /api/templates/:id` - Delete template
- `POST /api/templates/:id/render` - Render template

### Admin
- `GET /api/admin/dashboard` - Admin dashboard stats
- `GET /api/admin/users` - List users
- `GET /api/admin/missing-knowledge` - Missing knowledge events
- `GET /api/admin/tasks` - Admin tasks
- `GET /api/admin/audit-logs` - Audit logs

### Billing
- `GET /api/billing/subscription` - Get subscription
- `GET /api/billing/plans` - List plans
- `PATCH /api/billing/subscription` - Update subscription
- `GET /api/billing/usage` - Usage history
- `GET /api/billing/quota` - Check quota

### Health
- `GET /health` - Basic health check
- `GET /health/detailed` - Detailed health check
- `GET /health/ready` - Kubernetes readiness probe
- `GET /health/live` - Kubernetes liveness probe

## Services

### Core Services

- **ClaudeService**: AI orchestration and response generation
- **RetrievalService**: Semantic search and source ranking
- **MissingKnowledgeService**: Gap detection and admin task creation
- **IngestionService**: Document processing pipeline
- **BillingService**: Subscription and usage management
- **TemplateService**: Prompt template management
- **AuditService**: Comprehensive audit logging
- **NotificationService**: User and admin notifications

## Database Schema

The database includes 30+ tables covering:

- **Users & Authentication**: users, sessions, refresh tokens
- **Organizations**: organizations, organization_members
- **Workspaces**: workspaces, workspace_members, workspace_invitations
- **Teams**: teams, team_members
- **Sources**: sources, document_chunks, citations
- **Conversations**: conversations, messages
- **Templates**: templates
- **Billing**: subscriptions, usage_records, invoices
- **Admin**: missing_knowledge_events, admin_tasks, announcements
- **Audit**: audit_logs

See `prisma/schema.prisma` for complete schema definition.

## Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `NODE_ENV` | Environment (development/production) | Yes |
| `PORT` | Server port | Yes |
| `DATABASE_URL` | PostgreSQL connection string | Yes |
| `REDIS_URL` | Redis connection string | Yes |
| `JWT_SECRET` | JWT signing secret | Yes |
| `ANTHROPIC_API_KEY` | Claude API key | Yes |
| `PAYPAL_CLIENT_ID` | PayPal client ID | For billing |
| `PAYPAL_CLIENT_SECRET` | PayPal client secret | For billing |

## Scripts

```bash
# Development
npm run dev          # Start development server with hot reload
npm run build        # Build TypeScript
npm run start        # Start production server

# Database
npm run db:migrate   # Run database migrations
npm run db:generate  # Generate Prisma client
npm run db:studio    # Open Prisma Studio
npm run db:seed      # Seed database

# Testing
npm run test         # Run tests
npm run test:watch   # Run tests in watch mode
npm run test:coverage # Run tests with coverage

# Linting
npm run lint         # Run ESLint
npm run lint:fix     # Fix ESLint issues
npm run format       # Format code with Prettier
```

## Security

- JWT-based authentication with refresh tokens
- Role-based access control (RBAC)
- Rate limiting on all endpoints
- Helmet.js for security headers
- CORS configuration
- Input validation with Zod
- SQL injection protection via Prisma
- XSS protection
- HIPAA-compliant audit logging

## License

Proprietary - Requi Health Inc.
