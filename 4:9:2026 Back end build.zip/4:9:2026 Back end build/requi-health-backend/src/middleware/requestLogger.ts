/**
 * Request Logger Middleware
 * 
 * HTTP request/response logging with timing and metadata.
 */

import { Request, Response, NextFunction } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { logger } from '../utils/logger';

// Extend Express Request to include timing
declare global {
  namespace Express {
    interface Request {
      requestId: string;
      startTime: number;
    }
  }
}

/**
 * Request ID middleware - attaches unique ID to each request
 */
export function requestId(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  // Use existing request ID from header or generate new one
  req.requestId = req.headers['x-request-id'] as string || uuidv4();
  
  // Add request ID to response headers
  res.setHeader('x-request-id', req.requestId);
  
  next();
}

/**
 * Request timing middleware - tracks request duration
 */
export function requestTiming(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  req.startTime = Date.now();
  
  // Capture response finish
  res.on('finish', () => {
    const duration = Date.now() - req.startTime;
    const level = res.statusCode >= 400 ? 'warn' : 'info';
    
    logger[level]('HTTP Request', {
      requestId: req.requestId,
      method: req.method,
      path: req.path,
      statusCode: res.statusCode,
      duration: `${duration}ms`,
      userAgent: req.headers['user-agent'],
      ip: req.ip,
      userId: req.user?.id,
      contentLength: res.get('content-length'),
    });
  });
  
  next();
}

/**
 * Request body sanitizer - removes sensitive fields from logs
 */
export function sanitizeBody(body: any): any {
  if (!body || typeof body !== 'object') {
    return body;
  }

  const sensitiveFields = [
    'password',
    'token',
    'secret',
    'apiKey',
    'api_key',
    'creditCard',
    'credit_card',
    'ssn',
    'authorization',
  ];

  const sanitized = { ...body };

  for (const field of sensitiveFields) {
    if (field in sanitized) {
      sanitized[field] = '[REDACTED]';
    }
  }

  return sanitized;
}

/**
 * Comprehensive request logger
 */
export function requestLogger(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  // Skip logging for health checks
  if (req.path === '/health' || req.path === '/health/detailed') {
    next();
    return;
  }

  const logData: Record<string, any> = {
    requestId: req.requestId,
    method: req.method,
    path: req.path,
    query: req.query,
    headers: {
      'user-agent': req.headers['user-agent'],
      'content-type': req.headers['content-type'],
      'x-forwarded-for': req.headers['x-forwarded-for'],
    },
    ip: req.ip,
    userId: req.user?.id,
  };

  // Log body for non-GET requests (sanitized)
  if (req.method !== 'GET' && req.body) {
    logData.body = sanitizeBody(req.body);
  }

  logger.debug('Request started', logData);

  next();
}

/**
 * Security headers middleware
 */
export function securityHeaders(
  _req: Request,
  res: Response,
  next: NextFunction
): void {
  // Prevent clickjacking
  res.setHeader('X-Frame-Options', 'DENY');
  
  // Prevent MIME type sniffing
  res.setHeader('X-Content-Type-Options', 'nosniff');
  
  // XSS protection
  res.setHeader('X-XSS-Protection', '1; mode=block');
  
  // Referrer policy
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  
  // Content Security Policy (adjust as needed)
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline';"
  );
  
  next();
}

/**
 * CORS middleware configuration
 */
export function corsOptions(req: Request, callback: (err: Error | null, options?: any) => void): void {
  const allowedOrigins = process.env.ALLOWED_ORIGINS?.split(',') || [
    'http://localhost:3000',
    'http://localhost:5173',
  ];

  const origin = req.headers.origin;
  
  const options = {
    origin: allowedOrigins.includes(origin || '') ? origin : false,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: [
      'Content-Type',
      'Authorization',
      'X-Request-ID',
      'X-Workspace-ID',
    ],
    credentials: true,
    maxAge: 86400, // 24 hours
  };

  callback(null, options);
}
