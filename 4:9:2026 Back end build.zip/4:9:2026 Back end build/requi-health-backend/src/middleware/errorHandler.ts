/**
 * Error Handler Middleware
 * 
 * Centralized error handling with structured responses and logging.
 */

import { Request, Response, NextFunction } from 'express';
import { logger } from '../utils/logger';
import { auditService, AuditEventType, AuditSeverity } from '../services/auditService';

// Custom error classes
export class AppError extends Error {
  constructor(
    public statusCode: number,
    public code: string,
    message: string,
    public details?: Record<string, any>
  ) {
    super(message);
    this.name = 'AppError';
    Error.captureStackTrace(this, this.constructor);
  }
}

export class ValidationError extends AppError {
  constructor(message: string, details?: Record<string, any>) {
    super(400, 'VALIDATION_ERROR', message, details);
    this.name = 'ValidationError';
  }
}

export class AuthenticationError extends AppError {
  constructor(message: string = 'Authentication required') {
    super(401, 'AUTHENTICATION_ERROR', message);
    this.name = 'AuthenticationError';
  }
}

export class AuthorizationError extends AppError {
  constructor(message: string = 'Access denied') {
    super(403, 'AUTHORIZATION_ERROR', message);
    this.name = 'AuthorizationError';
  }
}

export class NotFoundError extends AppError {
  constructor(resource: string, id?: string) {
    super(404, 'NOT_FOUND', `${resource} not found${id ? `: ${id}` : ''}`);
    this.name = 'NotFoundError';
  }
}

export class ConflictError extends AppError {
  constructor(message: string) {
    super(409, 'CONFLICT', message);
    this.name = 'ConflictError';
  }
}

export class RateLimitError extends AppError {
  constructor(message: string = 'Rate limit exceeded') {
    super(429, 'RATE_LIMIT', message);
    this.name = 'RateLimitError';
  }
}

export class QuotaExceededError extends AppError {
  constructor(message: string = 'Monthly quota exceeded') {
    super(403, 'QUOTA_EXCEEDED', message);
    this.name = 'QuotaExceededError';
  }
}

// Error response interface
interface ErrorResponse {
  success: false;
  error: {
    code: string;
    message: string;
    details?: Record<string, any>;
    stack?: string;
  };
  requestId: string;
}

/**
 * Global error handler middleware
 */
export function errorHandler(
  err: Error,
  req: Request,
  res: Response,
  _next: NextFunction
): void {
  const requestId = req.headers['x-request-id'] as string || `req-${Date.now()}`;
  
  // Determine if it's an operational error (expected) or programming error
  const isOperationalError = err instanceof AppError;
  
  // Default error values
  let statusCode = 500;
  let errorCode = 'INTERNAL_ERROR';
  let message = 'An unexpected error occurred';
  let details: Record<string, any> | undefined;

  if (isOperationalError) {
    const appError = err as AppError;
    statusCode = appError.statusCode;
    errorCode = appError.code;
    message = appError.message;
    details = appError.details;
  } else if (err.name === 'PrismaClientKnownRequestError') {
    // Handle Prisma errors
    const prismaError = err as any;
    statusCode = 400;
    
    switch (prismaError.code) {
      case 'P2002':
        errorCode = 'UNIQUE_CONSTRAINT';
        message = 'A record with this value already exists';
        details = { field: prismaError.meta?.target };
        statusCode = 409;
        break;
      case 'P2025':
        errorCode = 'NOT_FOUND';
        message = 'Record not found';
        statusCode = 404;
        break;
      case 'P2003':
        errorCode = 'FOREIGN_KEY_CONSTRAINT';
        message = 'Referenced record does not exist';
        statusCode = 400;
        break;
      default:
        errorCode = 'DATABASE_ERROR';
        message = 'Database operation failed';
    }
  } else if (err.name === 'ZodError') {
    // Handle Zod validation errors
    statusCode = 400;
    errorCode = 'VALIDATION_ERROR';
    message = 'Validation failed';
    details = { errors: (err as any).errors };
  }

  // Log the error
  const logData = {
    requestId,
    errorCode,
    statusCode,
    message: err.message,
    stack: err.stack,
    path: req.path,
    method: req.method,
    userId: req.user?.id,
    ip: req.ip,
  };

  if (statusCode >= 500) {
    logger.error('Server error', logData);
    
    // Log critical errors to audit
    if (req.user) {
      auditService.log({
        eventType: AuditEventType.SYSTEM_ERROR,
        severity: AuditSeverity.ERROR,
        userId: req.user.id,
        metadata: {
          errorCode,
          path: req.path,
          method: req.method,
          errorMessage: err.message,
        },
        description: `Server error: ${errorCode}`,
      });
    }
  } else {
    logger.warn('Client error', logData);
  }

  // Build response
  const errorResponse: ErrorResponse = {
    success: false,
    error: {
      code: errorCode,
      message: isOperationalError ? message : 'An unexpected error occurred',
      ...(details && { details }),
      ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
    },
    requestId,
  };

  res.status(statusCode).json(errorResponse);
}

/**
 * 404 handler for undefined routes
 */
export function notFoundHandler(
  req: Request,
  res: Response,
  _next: NextFunction
): void {
  const requestId = req.headers['x-request-id'] as string || `req-${Date.now()}`;
  
  logger.warn('Route not found', {
    requestId,
    path: req.path,
    method: req.method,
  });

  res.status(404).json({
    success: false,
    error: {
      code: 'ROUTE_NOT_FOUND',
      message: `Route ${req.method} ${req.path} not found`,
    },
    requestId,
  });
}

/**
 * Async handler wrapper to catch errors in async route handlers
 */
export function asyncHandler(
  fn: (req: Request, res: Response, next: NextFunction) => Promise<any>
) {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}
