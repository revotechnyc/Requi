/**
 * Authentication & Authorization Middleware
 * 
 * JWT validation, role-based access control, and permission checks.
 */

import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { prisma } from '../config/database';
import { auditService, AuditEventType } from '../services/auditService';
import { logger } from '../utils/logger';

// Extend Express Request to include user
declare global {
  namespace Express {
    interface Request {
      user?: {
        id: string;
        email: string;
        role: string;
        organizationId?: string;
      };
    }
  }
}

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

/**
 * Verify JWT token and attach user to request
 */
export async function authenticateToken(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader?.split(' ')[1]; // Bearer TOKEN

    if (!token) {
      res.status(401).json({ error: 'Access denied. No token provided.' });
      return;
    }

    // Verify token
    const decoded = jwt.verify(token, JWT_SECRET) as {
      userId: string;
      email: string;
      role: string;
      organizationId?: string;
    };

    // Check if user still exists and is active
    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      select: {
        id: true,
        email: true,
        role: true,
        organizationId: true,
        status: true,
      },
    });

    if (!user) {
      res.status(401).json({ error: 'User not found.' });
      return;
    }

    if (user.status !== 'ACTIVE') {
      res.status(403).json({ error: 'Account is not active.' });
      return;
    }

    // Attach user to request
    req.user = {
      id: user.id,
      email: user.email,
      role: user.role,
      organizationId: user.organizationId || undefined,
    };

    next();
  } catch (error) {
    if (error instanceof jwt.TokenExpiredError) {
      res.status(401).json({ error: 'Token expired.' });
      return;
    }
    if (error instanceof jwt.JsonWebTokenError) {
      res.status(401).json({ error: 'Invalid token.' });
      return;
    }
    
    logger.error('Authentication error', { error });
    res.status(500).json({ error: 'Authentication failed.' });
  }
}

/**
 * Optional authentication - attaches user if token valid, but doesn't require it
 */
export async function optionalAuth(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader?.split(' ')[1];

    if (token) {
      const decoded = jwt.verify(token, JWT_SECRET) as {
        userId: string;
        email: string;
        role: string;
        organizationId?: string;
      };

      const user = await prisma.user.findUnique({
        where: { id: decoded.userId },
        select: {
          id: true,
          email: true,
          role: true,
          organizationId: true,
          status: true,
        },
      });

      if (user && user.status === 'ACTIVE') {
        req.user = {
          id: user.id,
          email: user.email,
          role: user.role,
          organizationId: user.organizationId || undefined,
        };
      }
    }

    next();
  } catch {
    // Ignore errors for optional auth
    next();
  }
}

/**
 * Require specific role(s)
 */
export function requireRole(...allowedRoles: string[]) {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }

    if (!allowedRoles.includes(req.user.role)) {
      // Log permission denied
      auditService.logPermissionDenied(
        req.user.id,
        req.originalUrl,
        req.method,
        req.ip || 'unknown',
        req.headers['user-agent'] || 'unknown'
      );

      res.status(403).json({ 
        error: 'Insufficient permissions.',
        required: allowedRoles,
        current: req.user.role,
      });
      return;
    }

    next();
  };
}

/**
 * Require workspace membership
 */
export function requireWorkspaceAccess(workspaceIdParam: string = 'workspaceId') {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }

    const workspaceId = req.params[workspaceIdParam] || req.body.workspaceId;

    if (!workspaceId) {
      res.status(400).json({ error: 'Workspace ID required.' });
      return;
    }

    // Super admins can access any workspace
    if (req.user.role === 'SUPER_ADMIN') {
      next();
      return;
    }

    // Check workspace membership
    const membership = await prisma.workspaceMember.findFirst({
      where: {
        workspaceId,
        userId: req.user.id,
      },
    });

    if (!membership) {
      // Check if user owns the organization
      const workspace = await prisma.workspace.findUnique({
        where: { id: workspaceId },
        select: { organizationId: true },
      });

      if (workspace) {
        const orgMember = await prisma.organizationMember.findFirst({
          where: {
            organizationId: workspace.organizationId,
            userId: req.user.id,
          },
        });

        if (orgMember) {
          next();
          return;
        }
      }

      auditService.logPermissionDenied(
        req.user.id,
        req.originalUrl,
        req.method,
        req.ip || 'unknown',
        req.headers['user-agent'] || 'unknown'
      );

      res.status(403).json({ error: 'Access denied to this workspace.' });
      return;
    }

    next();
  };
}

/**
 * Require organization membership
 */
export function requireOrganizationAccess(organizationIdParam: string = 'organizationId') {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }

    const organizationId = req.params[organizationIdParam] || req.body.organizationId;

    if (!organizationId) {
      res.status(400).json({ error: 'Organization ID required.' });
      return;
    }

    // Super admins can access any organization
    if (req.user.role === 'SUPER_ADMIN') {
      next();
      return;
    }

    // Check if user belongs to organization
    if (req.user.organizationId === organizationId) {
      next();
      return;
    }

    const membership = await prisma.organizationMember.findFirst({
      where: {
        organizationId,
        userId: req.user.id,
      },
    });

    if (!membership) {
      auditService.logPermissionDenied(
        req.user.id,
        req.originalUrl,
        req.method,
        req.ip || 'unknown',
        req.headers['user-agent'] || 'unknown'
      );

      res.status(403).json({ error: 'Access denied to this organization.' });
      return;
    }

    next();
  };
}

/**
 * Generate JWT token
 */
export function generateToken(payload: {
  userId: string;
  email: string;
  role: string;
  organizationId?: string;
}): string {
  return jwt.sign(payload, JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '24h',
  });
}

/**
 * Generate refresh token
 */
export function generateRefreshToken(userId: string): string {
  return jwt.sign({ userId, type: 'refresh' }, JWT_SECRET, {
    expiresIn: process.env.REFRESH_TOKEN_EXPIRES_IN || '7d',
  });
}
