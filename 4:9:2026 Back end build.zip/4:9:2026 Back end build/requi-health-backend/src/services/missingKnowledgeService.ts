/**
 * Missing Knowledge Service - Gap Detection and Admin Tasks
 * 
 * Handles detection of knowledge gaps, creation of admin tasks,
 * and tracking of recurrence patterns.
 */

import { prisma } from '../config/database';
import { notificationService } from './notificationService';

export interface CreateMissingKnowledgeInput {
  originalQuestion: string;
  normalizedQuestion: string;
  jurisdiction: string;
  programType?: string;
  topic?: string;
  subtopic?: string;
  missingLayer?: string | null;
  failureType: 'NO_ANSWER' | 'INCOMPLETE' | 'LOW_CONFIDENCE' | 'TOO_MUCH_INFERENCE';
  confidence: 'HIGH' | 'MEDIUM' | 'LOW' | 'UNSUPPORTED';
  workspaceId: string;
  userId: string;
}

export interface CreateAdminTaskInput {
  eventId: string;
  title: string;
  description: string;
  jurisdiction: string;
  topic?: string;
  sourceType?: string;
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  deadline?: Date;
}

export class MissingKnowledgeService {
  /**
   * Create a new missing knowledge event
   */
  async createEvent(input: CreateMissingKnowledgeInput): Promise<void> {
    // Check if similar event already exists
    const existingEvent = await this.findSimilarEvent(
      input.normalizedQuestion,
      input.jurisdiction
    );

    if (existingEvent) {
      // Update frequency and last seen
      await prisma.missingKnowledgeEvent.update({
        where: { id: existingEvent.id },
        data: {
          frequency: { increment: 1 },
          lastSeenAt: new Date(),
        },
      });

      // Create admin task if frequency threshold reached
      if (existingEvent.frequency >= 5 && existingEvent.status === 'NEW') {
        await this.createAdminTask({
          eventId: existingEvent.id,
          title: `Address recurring knowledge gap: ${input.topic || 'General'}`,
          description: `This question has been asked ${existingEvent.frequency} times. ${input.normalizedQuestion}`,
          jurisdiction: input.jurisdiction,
          topic: input.topic,
          sourceType: input.missingLayer || undefined,
          priority: existingEvent.frequency >= 10 ? 'HIGH' : 'MEDIUM',
        });
      }

      return;
    }

    // Create new event
    const event = await prisma.missingKnowledgeEvent.create({
      data: {
        originalQuestion: input.originalQuestion,
        normalizedQuestion: input.normalizedQuestion,
        jurisdiction: input.jurisdiction,
        programType: input.programType as any,
        topic: input.topic,
        subtopic: input.subtopic,
        missingLayer: input.missingLayer as any,
        failureType: input.failureType,
        confidence: input.confidence,
        frequency: 1,
        status: 'NEW',
        priority: this.calculatePriority(input),
      },
    });

    // Create initial admin task
    await this.createAdminTask({
      eventId: event.id,
      title: `Add missing ${input.missingLayer || 'source'} for ${input.jurisdiction}`,
      description: `Question: ${input.normalizedQuestion}\n\nMissing authority layer: ${input.missingLayer || 'Unknown'}`,
      jurisdiction: input.jurisdiction,
      topic: input.topic,
      sourceType: input.missingLayer || undefined,
      priority: this.calculatePriority(input),
    });

    // Notify admins
    await notificationService.notifyAdmins({
      type: 'MISSING_KNOWLEDGE',
      title: 'New Knowledge Gap Detected',
      message: `A new knowledge gap has been identified for ${input.jurisdiction}: ${input.topic || 'General'}`,
      link: `/admin/gaps/${event.id}`,
    });
  }

  /**
   * Find similar existing event
   */
  private async findSimilarEvent(
    normalizedQuestion: string,
    jurisdiction: string
  ): Promise<{ id: string; frequency: number; status: string } | null> {
    // Simple similarity check - could be improved with embeddings
    const events = await prisma.missingKnowledgeEvent.findMany({
      where: {
        jurisdiction,
        status: { not: 'CLOSED' },
      },
      select: {
        id: true,
        normalizedQuestion: true,
        frequency: true,
        status: true,
      },
    });

    for (const event of events) {
      const similarity = this.calculateSimilarity(
        normalizedQuestion,
        event.normalizedQuestion
      );
      if (similarity > 0.8) {
        return event;
      }
    }

    return null;
  }

  /**
   * Calculate string similarity (simple implementation)
   */
  private calculateSimilarity(a: string, b: string): number {
    const aWords = new Set(a.toLowerCase().split(/\s+/));
    const bWords = new Set(b.toLowerCase().split(/\s+/));
    
    const intersection = new Set([...aWords].filter(x => bWords.has(x)));
    const union = new Set([...aWords, ...bWords]);
    
    return intersection.size / union.size;
  }

  /**
   * Calculate priority based on input
   */
  private calculatePriority(input: CreateMissingKnowledgeInput): 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' {
    if (input.confidence === 'UNSUPPORTED') {
      return 'HIGH';
    }
    if (input.failureType === 'NO_ANSWER') {
      return 'HIGH';
    }
    if (input.jurisdiction === 'Federal') {
      return 'MEDIUM';
    }
    return 'LOW';
  }

  /**
   * Create admin task
   */
  async createAdminTask(input: CreateAdminTaskInput): Promise<void> {
    await prisma.adminTask.create({
      data: {
        eventId: input.eventId,
        title: input.title,
        description: input.description,
        jurisdiction: input.jurisdiction,
        topic: input.topic,
        sourceType: input.sourceType,
        priority: input.priority,
        deadline: input.deadline,
        status: 'NEW',
      },
    });
  }

  /**
   * Assign task to user
   */
  async assignTask(taskId: string, userId: string): Promise<void> {
    await prisma.adminTaskAssignment.create({
      data: {
        taskId,
        userId,
      },
    });

    await prisma.adminTask.update({
      where: { id: taskId },
      data: { status: 'UNDER_REVIEW' },
    });
  }

  /**
   * Complete task
   */
  async completeTask(
    taskId: string,
    outcome: string,
    sourceId?: string
  ): Promise<void> {
    await prisma.adminTask.update({
      where: { id: taskId },
      data: {
        status: 'CLOSED',
        outcome,
        completedAt: new Date(),
      },
    });

    // Update associated event
    const task = await prisma.adminTask.findUnique({
      where: { id: taskId },
      include: { event: true },
    });

    if (task?.event) {
      await prisma.missingKnowledgeEvent.update({
        where: { id: task.eventId },
        data: {
          status: 'CLOSED',
        },
      });
    }
  }

  /**
   * Get events for admin dashboard
   */
  async getEvents(filters: {
    status?: string;
    jurisdiction?: string;
    priority?: string;
    limit?: number;
    offset?: number;
  }): Promise<any[]> {
    const where: any = {};

    if (filters.status) {
      where.status = filters.status;
    }
    if (filters.jurisdiction) {
      where.jurisdiction = filters.jurisdiction;
    }
    if (filters.priority) {
      where.priority = filters.priority;
    }

    return prisma.missingKnowledgeEvent.findMany({
      where,
      include: {
        adminTasks: {
          include: {
            assignments: {
              include: {
                user: {
                  select: {
                    firstName: true,
                    lastName: true,
                  },
                },
              },
            },
          },
        },
      },
      orderBy: [
        { priority: 'desc' },
        { frequency: 'desc' },
        { lastSeenAt: 'desc' },
      ],
      take: filters.limit || 50,
      skip: filters.offset || 0,
    });
  }

  /**
   * Get event statistics
   */
  async getStats(): Promise<{
    totalEvents: number;
    byStatus: Record<string, number>;
    byJurisdiction: Record<string, number>;
    byPriority: Record<string, number>;
    avgResolutionTime: number | null;
  }> {
    const totalEvents = await prisma.missingKnowledgeEvent.count();

    const byStatus = await prisma.missingKnowledgeEvent.groupBy({
      by: ['status'],
      _count: { id: true },
    });

    const byJurisdiction = await prisma.missingKnowledgeEvent.groupBy({
      by: ['jurisdiction'],
      _count: { id: true },
    });

    const byPriority = await prisma.missingKnowledgeEvent.groupBy({
      by: ['priority'],
      _count: { id: true },
    });

    // Calculate average resolution time for closed events
    const closedEvents = await prisma.missingKnowledgeEvent.findMany({
      where: { status: 'CLOSED' },
      include: {
        adminTasks: {
          where: { status: 'CLOSED' },
        },
      },
    });

    let totalResolutionTime = 0;
    let resolvedCount = 0;

    for (const event of closedEvents) {
      const completedTask = event.adminTasks.find(t => t.completedAt);
      if (completedTask && completedTask.completedAt) {
        const resolutionTime = completedTask.completedAt.getTime() - event.createdAt.getTime();
        totalResolutionTime += resolutionTime;
        resolvedCount++;
      }
    }

    const avgResolutionTime = resolvedCount > 0 
      ? totalResolutionTime / resolvedCount / (1000 * 60 * 60 * 24) // Convert to days
      : null;

    return {
      totalEvents,
      byStatus: byStatus.reduce((acc, curr) => {
        acc[curr.status] = curr._count.id;
        return acc;
      }, {} as Record<string, number>),
      byJurisdiction: byJurisdiction.reduce((acc, curr) => {
        acc[curr.jurisdiction] = curr._count.id;
        return acc;
      }, {} as Record<string, number>),
      byPriority: byPriority.reduce((acc, curr) => {
        acc[curr.priority] = curr._count.id;
        return acc;
      }, {} as Record<string, number>),
      avgResolutionTime,
    };
  }
}

export const missingKnowledgeService = new MissingKnowledgeService();
