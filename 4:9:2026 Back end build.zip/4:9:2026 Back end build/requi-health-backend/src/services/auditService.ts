/**
 * Audit Service
 * 
 * Comprehensive audit logging for compliance, security, and operational visibility.
 * Tracks all user actions, AI interactions, data access, and system events.
 */

import { prisma } from '../config/database';
import { redis } from '../config/redis';
import { logger } from '../utils/logger';

export enum AuditEventType {
  // Authentication events
  USER_LOGIN = 'USER_LOGIN',
  USER_LOGIN_FAILED = 'USER_LOGIN_FAILED',
  USER_LOGOUT = 'USER_LOGOUT',
  USER_REGISTERED = 'USER_REGISTERED',
  PASSWORD_CHANGED = 'PASSWORD_CHANGED',
  MFA_ENABLED = 'MFA_ENABLED',
  MFA_DISABLED = 'MFA_DISABLED',
  TOKEN_REFRESHED = 'TOKEN_REFRESHED',
  
  // Authorization events
  PERMISSION_DENIED = 'PERMISSION_DENIED',
  ROLE_CHANGED = 'ROLE_CHANGED',
  
  // Workspace/Organization events
  WORKSPACE_CREATED = 'WORKSPACE_CREATED',
  WORKSPACE_UPDATED = 'WORKSPACE_UPDATED',
  WORKSPACE_DELETED = 'WORKSPACE_DELETED',
  WORKSPACE_ACCESS = 'WORKSPACE_ACCESS',
  TEAM_CREATED = 'TEAM_CREATED',
  TEAM_UPDATED = 'TEAM_UPDATED',
  TEAM_DELETED = 'TEAM_DELETED',
  MEMBER_INVITED = 'MEMBER_INVITED',
  MEMBER_REMOVED = 'MEMBER_REMOVED',
  
  // AI/Conversation events
  CONVERSATION_CREATED = 'CONVERSATION_CREATED',
  CONVERSATION_DELETED = 'CONVERSATION_DELETED',
  MESSAGE_SENT = 'MESSAGE_SENT',
  AI_RESPONSE_GENERATED = 'AI_RESPONSE_GENERATED',
  AI_RESPONSE_FAILED = 'AI_RESPONSE_FAILED',
  SOURCE_CITED = 'SOURCE_CITED',
  CONFIDENCE_BOUNDARY_HIT = 'CONFIDENCE_BOUNDARY_HIT',
  
  // Document/Source events
  SOURCE_UPLOADED = 'SOURCE_UPLOADED',
  SOURCE_UPDATED = 'SOURCE_UPDATED',
  SOURCE_DELETED = 'SOURCE_DELETED',
  SOURCE_ACCESSED = 'SOURCE_ACCESSED',
  DOCUMENT_INGESTED = 'DOCUMENT_INGESTED',
  DOCUMENT_INGEST_FAILED = 'DOCUMENT_INGEST_FAILED',
  
  // Template events
  TEMPLATE_CREATED = 'TEMPLATE_CREATED',
  TEMPLATE_UPDATED = 'TEMPLATE_UPDATED',
  TEMPLATE_DELETED = 'TEMPLATE_DELETED',
  TEMPLATE_USED = 'TEMPLATE_USED',
  
  // Missing knowledge events
  MISSING_KNOWLEDGE_DETECTED = 'MISSING_KNOWLEDGE_DETECTED',
  MISSING_KNOWLEDGE_REVIEWED = 'MISSING_KNOWLEDGE_REVIEWED',
  ADMIN_TASK_CREATED = 'ADMIN_TASK_CREATED',
  ADMIN_TASK_ASSIGNED = 'ADMIN_TASK_ASSIGNED',
  ADMIN_TASK_COMPLETED = 'ADMIN_TASK_COMPLETED',
  
  // Billing events
  SUBSCRIPTION_CREATED = 'SUBSCRIPTION_CREATED',
  SUBSCRIPTION_UPDATED = 'SUBSCRIPTION_UPDATED',
  SUBSCRIPTION_CANCELLED = 'SUBSCRIPTION_CANCELLED',
  PAYMENT_SUCCEEDED = 'PAYMENT_SUCCEEDED',
  PAYMENT_FAILED = 'PAYMENT_FAILED',
  QUOTA_EXCEEDED = 'QUOTA_EXCEEDED',
  
  // Admin events
  USER_SUSPENDED = 'USER_SUSPENDED',
  USER_REACTIVATED = 'USER_REACTIVATED',
  SYSTEM_CONFIG_CHANGED = 'SYSTEM_CONFIG_CHANGED',
  ANNOUNCEMENT_CREATED = 'ANNOUNCEMENT_CREATED',
}

export enum AuditSeverity {
  INFO = 'INFO',
  WARNING = 'WARNING',
  ERROR = 'ERROR',
  CRITICAL = 'CRITICAL',
}

export interface AuditLogEntry {
  eventType: AuditEventType;
  severity: AuditSeverity;
  userId?: string;
  organizationId?: string;
  workspaceId?: string;
  conversationId?: string;
  sourceId?: string;
  adminTaskId?: string;
  ipAddress?: string;
  userAgent?: string;
  metadata?: Record<string, any>;
  description?: string;
}

export interface AuditQueryFilters {
  eventTypes?: AuditEventType[];
  userId?: string;
  organizationId?: string;
  workspaceId?: string;
  severity?: AuditSeverity;
  startDate?: Date;
  endDate?: Date;
  limit?: number;
  offset?: number;
}

class AuditService {
  private readonly BATCH_SIZE = 100;
  private readonly RETENTION_DAYS = 2555; // 7 years for HIPAA compliance

  /**
   * Log an audit event
   */
  async log(entry: AuditLogEntry): Promise<void> {
    try {
      // Write to database
      await prisma.auditLog.create({
        data: {
          eventType: entry.eventType,
          severity: entry.severity,
          userId: entry.userId,
          organizationId: entry.organizationId,
          workspaceId: entry.workspaceId,
          conversationId: entry.conversationId,
          sourceId: entry.sourceId,
          adminTaskId: entry.adminTaskId,
          ipAddress: entry.ipAddress,
          userAgent: entry.userAgent,
          metadata: entry.metadata || {},
          description: entry.description,
        },
      });

      // Also log to application logs for real-time monitoring
      const logMessage = `[AUDIT] ${entry.eventType} | ${entry.severity} | User: ${entry.userId || 'system'} | ${entry.description || ''}`;
      
      switch (entry.severity) {
        case AuditSeverity.CRITICAL:
          logger.error(logMessage, entry);
          break;
        case AuditSeverity.ERROR:
          logger.error(logMessage, entry);
          break;
        case AuditSeverity.WARNING:
          logger.warn(logMessage, entry);
          break;
        default:
          logger.info(logMessage, entry);
      }

      // Cache critical events for quick admin access
      if (entry.severity === AuditSeverity.CRITICAL || entry.severity === AuditSeverity.ERROR) {
        await this.cacheCriticalEvent(entry);
      }
    } catch (error) {
      // Never throw from audit logging - failures should not break operations
      logger.error('Failed to write audit log', { error, entry });
    }
  }

  /**
   * Log authentication event
   */
  async logAuth(
    eventType: AuditEventType.USER_LOGIN | AuditEventType.USER_LOGIN_FAILED | AuditEventType.USER_LOGOUT,
    userId: string | undefined,
    ipAddress: string,
    userAgent: string,
    metadata?: Record<string, any>
  ): Promise<void> {
    await this.log({
      eventType,
      severity: eventType === AuditEventType.USER_LOGIN_FAILED ? AuditSeverity.WARNING : AuditSeverity.INFO,
      userId,
      ipAddress,
      userAgent,
      metadata,
      description: `${eventType} from ${ipAddress}`,
    });
  }

  /**
   * Log AI interaction
   */
  async logAIInteraction(
    userId: string,
    organizationId: string,
    workspaceId: string,
    conversationId: string,
    eventType: AuditEventType.AI_RESPONSE_GENERATED | AuditEventType.AI_RESPONSE_FAILED,
    metadata: {
      queryLength: number;
      responseLength: number;
      tokenCount: number;
      costCents: number;
      latencyMs: number;
      confidenceLevel?: string;
      sourcesCited?: number;
      missingKnowledge?: boolean;
    }
  ): Promise<void> {
    await this.log({
      eventType,
      severity: eventType === AuditEventType.AI_RESPONSE_FAILED ? AuditSeverity.ERROR : AuditSeverity.INFO,
      userId,
      organizationId,
      workspaceId,
      conversationId,
      metadata,
      description: `AI ${eventType === AuditEventType.AI_RESPONSE_GENERATED ? 'response' : 'failure'} - ${metadata.tokenCount} tokens`,
    });
  }

  /**
   * Log data access
   */
  async logDataAccess(
    userId: string,
    organizationId: string,
    workspaceId: string,
    sourceId: string,
    action: 'VIEW' | 'DOWNLOAD' | 'EXPORT'
  ): Promise<void> {
    await this.log({
      eventType: AuditEventType.SOURCE_ACCESSED,
      severity: AuditSeverity.INFO,
      userId,
      organizationId,
      workspaceId,
      sourceId,
      metadata: { action },
      description: `Source ${sourceId} ${action.toLowerCase()}ed`,
    });
  }

  /**
   * Log permission denial
   */
  async logPermissionDenied(
    userId: string,
    resource: string,
    action: string,
    ipAddress: string,
    userAgent: string
  ): Promise<void> {
    await this.log({
      eventType: AuditEventType.PERMISSION_DENIED,
      severity: AuditSeverity.WARNING,
      userId,
      ipAddress,
      userAgent,
      metadata: { resource, action },
      description: `Permission denied: ${action} on ${resource}`,
    });
  }

  /**
   * Query audit logs with filters
   */
  async query(filters: AuditQueryFilters): Promise<{ logs: any[]; total: number }> {
    const where: any = {};

    if (filters.eventTypes?.length) {
      where.eventType = { in: filters.eventTypes };
    }
    if (filters.userId) {
      where.userId = filters.userId;
    }
    if (filters.organizationId) {
      where.organizationId = filters.organizationId;
    }
    if (filters.workspaceId) {
      where.workspaceId = filters.workspaceId;
    }
    if (filters.severity) {
      where.severity = filters.severity;
    }
    if (filters.startDate || filters.endDate) {
      where.createdAt = {};
      if (filters.startDate) {
        where.createdAt.gte = filters.startDate;
      }
      if (filters.endDate) {
        where.createdAt.lte = filters.endDate;
      }
    }

    const [logs, total] = await Promise.all([
      prisma.auditLog.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: filters.limit || 50,
        skip: filters.offset || 0,
        include: {
          user: {
            select: { id: true, email: true, firstName: true, lastName: true },
          },
          organization: {
            select: { id: true, name: true },
          },
          workspace: {
            select: { id: true, name: true },
          },
        },
      }),
      prisma.auditLog.count({ where }),
    ]);

    return { logs, total };
  }

  /**
   * Get recent critical events
   */
  async getCriticalEvents(limit: number = 50): Promise<any[]> {
    const cacheKey = 'audit:critical:recent';
    const cached = await redis.get(cacheKey);
    
    if (cached) {
      return JSON.parse(cached);
    }

    const events = await prisma.auditLog.findMany({
      where: {
        severity: { in: [AuditSeverity.ERROR, AuditSeverity.CRITICAL] },
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
      include: {
        user: {
          select: { id: true, email: true },
        },
      },
    });

    // Cache for 5 minutes
    await redis.setex(cacheKey, 300, JSON.stringify(events));

    return events;
  }

  /**
   * Get audit statistics
   */
  async getStats(organizationId?: string, days: number = 30): Promise<{
    totalEvents: number;
    eventsByType: Record<string, number>;
    eventsBySeverity: Record<string, number>;
    topUsers: Array<{ userId: string; email: string; count: number }>;
    dailyTrend: Array<{ date: string; count: number }>;
  }> {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const where: any = {
      createdAt: { gte: startDate },
    };
    if (organizationId) {
      where.organizationId = organizationId;
    }

    const [
      totalEvents,
      eventsByType,
      eventsBySeverity,
      topUsers,
      dailyTrend,
    ] = await Promise.all([
      prisma.auditLog.count({ where }),
      prisma.auditLog.groupBy({
        by: ['eventType'],
        where,
        _count: { eventType: true },
      }),
      prisma.auditLog.groupBy({
        by: ['severity'],
        where,
        _count: { severity: true },
      }),
      prisma.auditLog.groupBy({
        by: ['userId'],
        where: { ...where, userId: { not: null } },
        _count: { userId: true },
        orderBy: { _count: { userId: 'desc' } },
        take: 10,
      }),
      prisma.$queryRaw`
        SELECT DATE(created_at) as date, COUNT(*) as count
        FROM audit_logs
        WHERE created_at >= ${startDate}
        ${organizationId ? prisma.$queryRaw`AND organization_id = ${organizationId}` : prisma.$queryRaw``}
        GROUP BY DATE(created_at)
        ORDER BY date DESC
      `,
    ]);

    // Enrich top users with email
    const userIds = topUsers.map(u => u.userId);
    const users = await prisma.user.findMany({
      where: { id: { in: userIds } },
      select: { id: true, email: true },
    });
    const userMap = new Map(users.map(u => [u.id, u.email]));

    return {
      totalEvents,
      eventsByType: eventsByType.reduce((acc, e) => ({
        ...acc,
        [e.eventType]: e._count.eventType,
      }), {}),
      eventsBySeverity: eventsBySeverity.reduce((acc, e) => ({
        ...acc,
        [e.severity]: e._count.severity,
      }), {}),
      topUsers: topUsers.map(u => ({
        userId: u.userId,
        email: userMap.get(u.userId) || 'Unknown',
        count: u._count.userId,
      })),
      dailyTrend: (dailyTrend as any[]).map(d => ({
        date: d.date.toISOString().split('T')[0],
        count: Number(d.count),
      })),
    };
  }

  /**
   * Export audit logs for compliance
   */
  async exportForCompliance(
    organizationId: string,
    startDate: Date,
    endDate: Date
  ): Promise<{
    organizationId: string;
    exportDate: string;
    dateRange: { start: string; end: string };
    events: any[];
  }> {
    const events = await prisma.auditLog.findMany({
      where: {
        organizationId,
        createdAt: { gte: startDate, lte: endDate },
      },
      orderBy: { createdAt: 'asc' },
      include: {
        user: {
          select: { id: true, email: true, firstName: true, lastName: true },
        },
      },
    });

    return {
      organizationId,
      exportDate: new Date().toISOString(),
      dateRange: {
        start: startDate.toISOString(),
        end: endDate.toISOString(),
      },
      events,
    };
  }

  /**
   * Clean up old audit logs (run as scheduled job)
   */
  async cleanupOldLogs(): Promise<{ deleted: number }> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - this.RETENTION_DAYS);

    const result = await prisma.auditLog.deleteMany({
      where: {
        createdAt: { lt: cutoffDate },
      },
    });

    logger.info(`Audit log cleanup completed`, { deleted: result.count });
    return { deleted: result.count };
  }

  /**
   * Cache critical event for quick access
   */
  private async cacheCriticalEvent(entry: AuditLogEntry): Promise<void> {
    const cacheKey = 'audit:critical:recent';
    try {
      // Invalidate cache to force refresh
      await redis.del(cacheKey);
    } catch (error) {
      // Non-critical
    }
  }
}

export const auditService = new AuditService();
