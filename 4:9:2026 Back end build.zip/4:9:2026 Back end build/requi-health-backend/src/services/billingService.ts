/**
 * Billing Service
 * 
 * Handles subscription management, payment processing, usage tracking,
 * and quota enforcement. Integrates with PayPal for payments.
 */

import { prisma } from '../config/database';
import { redis } from '../config/redis';
import { logger } from '../utils/logger';
import { notificationService, NotificationType, NotificationPriority } from './notificationService';
import { auditService, AuditEventType } from './auditService';
import { PlanType, SubscriptionStatus, UsagePeriod } from '@prisma/client';

export interface CreateSubscriptionInput {
  organizationId: string;
  planType: PlanType;
  paypalSubscriptionId?: string;
  billingEmail: string;
}

export interface UsageRecord {
  organizationId: string;
  userId: string;
  conversationId: string;
  tokenCount: number;
  costCents: number;
}

export interface QuotaCheck {
  allowed: boolean;
  currentUsage: number;
  quotaLimit: number;
  remaining: number;
  percentUsed: number;
}

// Plan definitions
export const PLANS: Record<PlanType, {
  name: string;
  monthlyTokens: number;
  monthlyCost: number; // in cents
  features: string[];
  maxWorkspaces: number;
  maxUsers: number;
  maxSources: number;
}> = {
  [PlanType.FREE]: {
    name: 'Free',
    monthlyTokens: 10000,
    monthlyCost: 0,
    features: ['Basic AI responses', '1 workspace', '3 team members', '10 sources'],
    maxWorkspaces: 1,
    maxUsers: 3,
    maxSources: 10,
  },
  [PlanType.BASIC]: {
    name: 'Basic',
    monthlyTokens: 100000,
    monthlyCost: 4900, // $49/month
    features: ['Advanced AI responses', '3 workspaces', '10 team members', '50 sources', 'Priority support'],
    maxWorkspaces: 3,
    maxUsers: 10,
    maxSources: 50,
  },
  [PlanType.PROFESSIONAL]: {
    name: 'Professional',
    monthlyTokens: 500000,
    monthlyCost: 14900, // $149/month
    features: ['Full AI capabilities', '10 workspaces', '50 team members', '200 sources', 'API access', 'Dedicated support'],
    maxWorkspaces: 10,
    maxUsers: 50,
    maxSources: 200,
  },
  [PlanType.ENTERPRISE]: {
    name: 'Enterprise',
    monthlyTokens: -1, // Unlimited
    monthlyCost: 0, // Custom pricing
    features: ['Unlimited everything', 'Custom AI training', 'SSO/SAML', 'SLA guarantee', 'Dedicated account manager'],
    maxWorkspaces: -1,
    maxUsers: -1,
    maxSources: -1,
  },
};

class BillingService {
  private readonly USAGE_CACHE_TTL = 300; // 5 minutes
  private readonly WARNING_THRESHOLD = 80;
  private readonly CRITICAL_THRESHOLD = 95;

  /**
   * Create a new subscription
   */
  async createSubscription(input: CreateSubscriptionInput): Promise<void> {
    const plan = PLANS[input.planType];
    
    await prisma.subscription.create({
      data: {
        organizationId: input.organizationId,
        planType: input.planType,
        status: input.planType === PlanType.FREE ? SubscriptionStatus.ACTIVE : SubscriptionStatus.PENDING,
        paypalSubscriptionId: input.paypalSubscriptionId,
        billingEmail: input.billingEmail,
        currentPeriodStart: new Date(),
        currentPeriodEnd: this.calculatePeriodEnd(),
        tokenQuota: plan.monthlyTokens,
        tokenUsed: 0,
      },
    });

    await auditService.log({
      eventType: AuditEventType.SUBSCRIPTION_CREATED,
      severity: 'INFO',
      organizationId: input.organizationId,
      metadata: { planType: input.planType },
      description: `Subscription created: ${plan.name}`,
    });
  }

  /**
   * Update subscription plan
   */
  async updatePlan(
    organizationId: string,
    newPlanType: PlanType,
    paypalSubscriptionId?: string
  ): Promise<void> {
    const subscription = await prisma.subscription.findUnique({
      where: { organizationId },
    });

    if (!subscription) {
      throw new Error('Subscription not found');
    }

    const plan = PLANS[newPlanType];

    await prisma.subscription.update({
      where: { organizationId },
      data: {
        planType: newPlanType,
        paypalSubscriptionId,
        tokenQuota: plan.monthlyTokens,
        status: newPlanType === PlanType.FREE ? SubscriptionStatus.ACTIVE : SubscriptionStatus.PENDING,
      },
    });

    await auditService.log({
      eventType: AuditEventType.SUBSCRIPTION_UPDATED,
      severity: 'INFO',
      organizationId,
      metadata: { 
        oldPlan: subscription.planType,
        newPlan: newPlanType,
      },
      description: `Plan changed from ${subscription.planType} to ${newPlanType}`,
    });
  }

  /**
   * Cancel subscription
   */
  async cancelSubscription(organizationId: string, reason?: string): Promise<void> {
    await prisma.subscription.update({
      where: { organizationId },
      data: {
        status: SubscriptionStatus.CANCELLED,
        cancelledAt: new Date(),
        cancellationReason: reason,
      },
    });

    await auditService.log({
      eventType: AuditEventType.SUBSCRIPTION_CANCELLED,
      severity: 'INFO',
      organizationId,
      metadata: { reason },
      description: 'Subscription cancelled',
    });
  }

  /**
   * Record usage
   */
  async recordUsage(record: UsageRecord): Promise<void> {
    const subscription = await prisma.subscription.findUnique({
      where: { organizationId: record.organizationId },
    });

    if (!subscription) {
      throw new Error('Subscription not found');
    }

    // Update subscription usage
    await prisma.subscription.update({
      where: { organizationId: record.organizationId },
      data: {
        tokenUsed: { increment: record.tokenCount },
      },
    });

    // Create usage record
    await prisma.usageRecord.create({
      data: {
        organizationId: record.organizationId,
        userId: record.userId,
        conversationId: record.conversationId,
        tokenCount: record.tokenCount,
        costCents: record.costCents,
        period: this.getCurrentPeriod(),
      },
    });

    // Invalidate cache
    await redis.del(`usage:${record.organizationId}`);

    // Check quota and send warnings
    await this.checkQuotaAndNotify(record.organizationId);
  }

  /**
   * Check if usage is within quota
   */
  async checkQuota(organizationId: string): Promise<QuotaCheck> {
    const cacheKey = `usage:${organizationId}`;
    const cached = await redis.get(cacheKey);

    if (cached) {
      return JSON.parse(cached);
    }

    const subscription = await prisma.subscription.findUnique({
      where: { organizationId },
    });

    if (!subscription) {
      throw new Error('Subscription not found');
    }

    // Enterprise has unlimited
    if (subscription.planType === PlanType.ENTERPRISE) {
      return {
        allowed: true,
        currentUsage: subscription.tokenUsed,
        quotaLimit: -1,
        remaining: -1,
        percentUsed: 0,
      };
    }

    const quotaLimit = subscription.tokenQuota;
    const currentUsage = subscription.tokenUsed;
    const remaining = quotaLimit - currentUsage;
    const percentUsed = (currentUsage / quotaLimit) * 100;

    const result: QuotaCheck = {
      allowed: remaining > 0,
      currentUsage,
      quotaLimit,
      remaining,
      percentUsed,
    };

    // Cache for 5 minutes
    await redis.setex(cacheKey, this.USAGE_CACHE_TTL, JSON.stringify(result));

    return result;
  }

  /**
   * Enforce quota - throws if exceeded
   */
  async enforceQuota(organizationId: string): Promise<void> {
    const quota = await this.checkQuota(organizationId);

    if (!quota.allowed) {
      throw new Error('QUOTA_EXCEEDED: Monthly token quota has been exceeded. Please upgrade your plan.');
    }
  }

  /**
   * Get subscription details
   */
  async getSubscription(organizationId: string): Promise<any> {
    const subscription = await prisma.subscription.findUnique({
      where: { organizationId },
      include: {
        organization: {
          select: { name: true },
        },
        invoices: {
          orderBy: { createdAt: 'desc' },
          take: 12,
        },
      },
    });

    if (!subscription) {
      return null;
    }

    const plan = PLANS[subscription.planType];
    const quota = await this.checkQuota(organizationId);

    return {
      ...subscription,
      planDetails: plan,
      usage: quota,
    };
  }

  /**
   * Get usage history
   */
  async getUsageHistory(
    organizationId: string,
    days: number = 30
  ): Promise<{ daily: any[]; byUser: any[] }> {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const [daily, byUser] = await Promise.all([
      prisma.$queryRaw`
        SELECT 
          DATE(created_at) as date,
          SUM(token_count) as tokens,
          SUM(cost_cents) as cost,
          COUNT(*) as requests
        FROM usage_records
        WHERE organization_id = ${organizationId}
          AND created_at >= ${startDate}
        GROUP BY DATE(created_at)
        ORDER BY date DESC
      `,
      prisma.usageRecord.groupBy({
        by: ['userId'],
        where: {
          organizationId,
          createdAt: { gte: startDate },
        },
        _sum: {
          tokenCount: true,
          costCents: true,
        },
        _count: {
          userId: true,
        },
        orderBy: {
          _sum: {
            tokenCount: 'desc',
          },
        },
        take: 10,
      }),
    ]);

    // Enrich user data
    const userIds = byUser.map(u => u.userId);
    const users = await prisma.user.findMany({
      where: { id: { in: userIds } },
      select: { id: true, email: true, firstName: true, lastName: true },
    });
    const userMap = new Map(users.map(u => [u.id, u]));

    return {
      daily: (daily as any[]).map(d => ({
        date: d.date.toISOString().split('T')[0],
        tokens: Number(d.tokens),
        cost: Number(d.cost) / 100,
        requests: Number(d.requests),
      })),
      byUser: byUser.map(u => ({
        userId: u.userId,
        email: userMap.get(u.userId)?.email || 'Unknown',
        name: `${userMap.get(u.userId)?.firstName || ''} ${userMap.get(u.userId)?.lastName || ''}`.trim(),
        tokens: u._sum.tokenCount,
        cost: (u._sum.costCents || 0) / 100,
        requests: u._count.userId,
      })),
    };
  }

  /**
   * Reset monthly usage (called by cron job)
   */
  async resetMonthlyUsage(): Promise<void> {
    const subscriptions = await prisma.subscription.findMany({
      where: {
        status: SubscriptionStatus.ACTIVE,
        currentPeriodEnd: { lte: new Date() },
      },
    });

    for (const sub of subscriptions) {
      await prisma.subscription.update({
        where: { id: sub.id },
        data: {
          tokenUsed: 0,
          currentPeriodStart: new Date(),
          currentPeriodEnd: this.calculatePeriodEnd(),
        },
      });

      // Clear cache
      await redis.del(`usage:${sub.organizationId}`);

      logger.info('Monthly usage reset', { 
        organizationId: sub.organizationId,
        plan: sub.planType,
      });
    }
  }

  /**
   * Create invoice (for enterprise/custom billing)
   */
  async createInvoice(
    organizationId: string,
    amount: number,
    description: string
  ): Promise<void> {
    await prisma.invoice.create({
      data: {
        organizationId,
        amount,
        description,
        status: 'PENDING',
        dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
      },
    });
  }

  /**
   * Process PayPal webhook
   */
  async processPayPalWebhook(event: any): Promise<void> {
    switch (event.event_type) {
      case 'BILLING.SUBSCRIPTION.ACTIVATED':
        await this.handleSubscriptionActivated(event.resource);
        break;
      case 'BILLING.SUBSCRIPTION.CANCELLED':
        await this.handleSubscriptionCancelled(event.resource);
        break;
      case 'BILLING.SUBSCRIPTION.PAYMENT.FAILED':
        await this.handlePaymentFailed(event.resource);
        break;
      case 'PAYMENT.SALE.COMPLETED':
        await this.handlePaymentCompleted(event.resource);
        break;
    }
  }

  // Private methods

  private calculatePeriodEnd(): Date {
    const date = new Date();
    date.setMonth(date.getMonth() + 1);
    return date;
  }

  private getCurrentPeriod(): UsagePeriod {
    const now = new Date();
    const month = now.getMonth() + 1;
    const year = now.getFullYear();
    return `${year}-${month.toString().padStart(2, '0')}` as UsagePeriod;
  }

  private async checkQuotaAndNotify(organizationId: string): Promise<void> {
    const quota = await this.checkQuota(organizationId);

    if (quota.percentUsed >= this.CRITICAL_THRESHOLD) {
      // Find org admins
      const admins = await prisma.user.findMany({
        where: {
          organizationId,
          role: { in: ['ADMIN', 'OWNER'] },
        },
        select: { id: true },
      });

      for (const admin of admins) {
        await notificationService.sendQuotaWarning(
          admin.id,
          organizationId,
          quota.percentUsed
        );
      }
    }
  }

  private async handleSubscriptionActivated(resource: any): Promise<void> {
    const subscription = await prisma.subscription.findFirst({
      where: { paypalSubscriptionId: resource.id },
    });

    if (subscription) {
      await prisma.subscription.update({
        where: { id: subscription.id },
        data: { status: SubscriptionStatus.ACTIVE },
      });
    }
  }

  private async handleSubscriptionCancelled(resource: any): Promise<void> {
    const subscription = await prisma.subscription.findFirst({
      where: { paypalSubscriptionId: resource.id },
    });

    if (subscription) {
      await prisma.subscription.update({
        where: { id: subscription.id },
        data: { 
          status: SubscriptionStatus.CANCELLED,
          cancelledAt: new Date(),
        },
      });
    }
  }

  private async handlePaymentFailed(resource: any): Promise<void> {
    const subscription = await prisma.subscription.findFirst({
      where: { paypalSubscriptionId: resource.billing_agreement_id },
    });

    if (subscription) {
      await prisma.subscription.update({
        where: { id: subscription.id },
        data: { status: SubscriptionStatus.PAST_DUE },
      });

      await auditService.log({
        eventType: AuditEventType.PAYMENT_FAILED,
        severity: 'WARNING',
        organizationId: subscription.organizationId,
        metadata: { paypalSubscriptionId: resource.billing_agreement_id },
        description: 'PayPal payment failed',
      });
    }
  }

  private async handlePaymentCompleted(resource: any): Promise<void> {
    // Record successful payment
    await auditService.log({
      eventType: AuditEventType.PAYMENT_SUCCEEDED,
      severity: 'INFO',
      metadata: { paypalPaymentId: resource.id },
      description: `Payment completed: $${resource.amount.total}`,
    });
  }
}

export const billingService = new BillingService();
