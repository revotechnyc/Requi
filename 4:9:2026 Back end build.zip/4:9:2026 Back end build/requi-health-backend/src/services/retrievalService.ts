/**
 * Retrieval Service - Source Search and Ranking
 * 
 * Handles semantic search over the document corpus,
 * source ranking by authority, and result formatting.
 */

import { prisma } from '../config/database';

export interface RetrievalQuery {
  query: string;
  jurisdiction?: string;
  programType?: string;
  authorityLayers?: string[];
  topics?: string[];
  bindingLevels?: string[];
  effectiveDate?: Date;
  limit?: number;
  workspaceId: string;
}

export interface RetrievedSource {
  id: string;
  title: string;
  jurisdiction: string;
  authorityLayer: string;
  programType: string;
  bindingLevel: string;
  effectiveDate: Date | null;
  citationText: string | null;
  relevanceScore: number;
  chunks: Array<{
    content: string;
    chunkIndex: number;
  }>;
}

export class RetrievalService {
  /**
   * Search for relevant sources
   */
  async search(query: RetrievalQuery): Promise<RetrievedSource[]> {
    // Build where clause
    const where: any = {
      workspaceId: query.workspaceId,
      status: 'ACTIVE',
      isIndexed: true,
    };

    if (query.jurisdiction) {
      where.jurisdiction = query.jurisdiction;
    }

    if (query.programType) {
      where.programType = query.programType;
    }

    if (query.authorityLayers && query.authorityLayers.length > 0) {
      where.authorityLayer = { in: query.authorityLayers };
    }

    if (query.bindingLevels && query.bindingLevels.length > 0) {
      where.bindingLevel = { in: query.bindingLevels };
    }

    if (query.topics && query.topics.length > 0) {
      where.topics = { hasSome: query.topics };
    }

    // Get sources with chunks
    const sources = await prisma.source.findMany({
      where,
      include: {
        chunks: {
          orderBy: { chunkIndex: 'asc' },
        },
      },
      take: query.limit || 10,
    });

    // Calculate relevance scores and rank
    const ranked = sources.map(source => ({
      id: source.id,
      title: source.title,
      jurisdiction: source.jurisdiction,
      authorityLayer: source.authorityLayer,
      programType: source.programType,
      bindingLevel: source.bindingLevel,
      effectiveDate: source.effectiveDate,
      citationText: source.citationText,
      relevanceScore: this.calculateRelevance(query.query, source),
      chunks: source.chunks.map(c => ({
        content: c.content,
        chunkIndex: c.chunkIndex,
      })),
    }));

    // Sort by relevance score
    ranked.sort((a, b) => b.relevanceScore - a.relevanceScore);

    // Log retrieval
    await this.logRetrieval(query, ranked);

    return ranked;
  }

  /**
   * Calculate relevance score for a source
   * Combines keyword matching with authority weighting
   */
  private calculateRelevance(query: string, source: any): number {
    const queryLower = query.toLowerCase();
    const queryTerms = queryLower.split(/\s+/);

    let score = 0;

    // Keyword matching in title
    const titleLower = source.title.toLowerCase();
    for (const term of queryTerms) {
      if (titleLower.includes(term)) {
        score += 10;
      }
    }

    // Keyword matching in chunks
    for (const chunk of source.chunks) {
      const chunkLower = chunk.content.toLowerCase();
      for (const term of queryTerms) {
        if (chunkLower.includes(term)) {
          score += 2;
        }
      }
    }

    // Authority layer weighting
    const layerWeights: Record<string, number> = {
      'FEDERAL_STATUTES': 100,
      'FEDERAL_REGULATIONS': 90,
      'FEDERAL_GUIDANCE': 80,
      'STATE_STATUTES': 85,
      'STATE_REGULATIONS': 75,
      'STATE_GUIDANCE': 65,
      'PROGRAM_DOCUMENTS': 60,
      'CONTRACTS': 70,
      'CASE_LAW': 55,
      'ACADEMIC': 30,
      'BEST_PRACTICES': 20,
    };

    score += layerWeights[source.authorityLayer] || 0;

    // Binding level weighting
    const bindingWeights: Record<string, number> = {
      'BINDING': 50,
      'PERSUASIVE': 20,
      'INFORMATIONAL': 10,
      'SCHOLARLY': 5,
    };

    score += bindingWeights[source.bindingLevel] || 0;

    // Recency bonus
    if (source.effectiveDate) {
      const age = Date.now() - source.effectiveDate.getTime();
      const ageInYears = age / (1000 * 60 * 60 * 24 * 365);
      if (ageInYears < 1) {
        score += 10;
      } else if (ageInYears < 5) {
        score += 5;
      }
    }

    return score;
  }

  /**
   * Get sources by jurisdiction
   */
  async getByJurisdiction(
    workspaceId: string,
    jurisdiction: string,
    limit: number = 50
  ): Promise<RetrievedSource[]> {
    const sources = await prisma.source.findMany({
      where: {
        workspaceId,
        jurisdiction,
        status: 'ACTIVE',
      },
      include: {
        chunks: {
          orderBy: { chunkIndex: 'asc' },
        },
      },
      take: limit,
      orderBy: [
        { bindingLevel: 'desc' },
        { effectiveDate: 'desc' },
      ],
    });

    return sources.map(source => ({
      id: source.id,
      title: source.title,
      jurisdiction: source.jurisdiction,
      authorityLayer: source.authorityLayer,
      programType: source.programType,
      bindingLevel: source.bindingLevel,
      effectiveDate: source.effectiveDate,
      citationText: source.citationText,
      relevanceScore: 0,
      chunks: source.chunks.map(c => ({
        content: c.content,
        chunkIndex: c.chunkIndex,
      })),
    }));
  }

  /**
   * Get sources by authority layer
   */
  async getByAuthorityLayer(
    workspaceId: string,
    layer: string,
    limit: number = 50
  ): Promise<RetrievedSource[]> {
    const sources = await prisma.source.findMany({
      where: {
        workspaceId,
        authorityLayer: layer as any,
        status: 'ACTIVE',
      },
      include: {
        chunks: {
          orderBy: { chunkIndex: 'asc' },
        },
      },
      take: limit,
      orderBy: { effectiveDate: 'desc' },
    });

    return sources.map(source => ({
      id: source.id,
      title: source.title,
      jurisdiction: source.jurisdiction,
      authorityLayer: source.authorityLayer,
      programType: source.programType,
      bindingLevel: source.bindingLevel,
      effectiveDate: source.effectiveDate,
      citationText: source.citationText,
      relevanceScore: 0,
      chunks: source.chunks.map(c => ({
        content: c.content,
        chunkIndex: c.chunkIndex,
      })),
    }));
  }

  /**
   * Log retrieval for analytics
   */
  private async logRetrieval(
    query: RetrievalQuery,
    results: RetrievedSource[]
  ): Promise<void> {
    // Log each source retrieval
    for (const result of results) {
      await prisma.retrievalLog.create({
        data: {
          sourceId: result.id,
          query: query.query,
          relevanceScore: result.relevanceScore,
        },
      });
    }
  }

  /**
   * Get retrieval statistics
   */
  async getStats(workspaceId: string): Promise<{
    totalSources: number;
    sourcesByLayer: Record<string, number>;
    sourcesByJurisdiction: Record<string, number>;
    recentRetrievals: number;
  }> {
    const totalSources = await prisma.source.count({
      where: { workspaceId, status: 'ACTIVE' },
    });

    const sourcesByLayer = await prisma.source.groupBy({
      by: ['authorityLayer'],
      where: { workspaceId, status: 'ACTIVE' },
      _count: { id: true },
    });

    const sourcesByJurisdiction = await prisma.source.groupBy({
      by: ['jurisdiction'],
      where: { workspaceId, status: 'ACTIVE' },
      _count: { id: true },
    });

    const recentRetrievals = await prisma.retrievalLog.count({
      where: {
        retrievedAt: {
          gte: new Date(Date.now() - 24 * 60 * 60 * 1000), // Last 24 hours
        },
      },
    });

    return {
      totalSources,
      sourcesByLayer: sourcesByLayer.reduce((acc, curr) => {
        acc[curr.authorityLayer] = curr._count.id;
        return acc;
      }, {} as Record<string, number>),
      sourcesByJurisdiction: sourcesByJurisdiction.reduce((acc, curr) => {
        acc[curr.jurisdiction] = curr._count.id;
        return acc;
      }, {} as Record<string, number>),
      recentRetrievals,
    };
  }
}

export const retrievalService = new RetrievalService();
