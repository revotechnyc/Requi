/**
 * Claude Service - Core AI Orchestration
 * 
 * Handles all interactions with the Anthropic Claude API,
 * including prompt assembly, streaming, and response parsing.
 */

import { claude, DEFAULT_MODEL, calculateCost, selectModel } from '../config/claude';
import { prisma } from '../config/database';
import {
  PERMANENT_SYSTEM_PROMPT,
  OUTPUT_CONTRACT_PROMPT,
  MISSING_KNOWLEDGE_PROMPT,
  CITATION_PROMPT,
  assembleCompletePrompt,
  buildWorkspacePrompt,
  buildRolePrompt,
} from '../prompts/system';
import { retrievalService } from './retrievalService';
import { missingKnowledgeService } from './missingKnowledgeService';
import { auditService } from './auditService';

// Types
export interface AIRequest {
  userId: string;
  workspaceId: string;
  conversationId?: string;
  query: string;
  jurisdiction?: string;
  programType?: string;
  selectedSources?: string[];
  selectedTemplate?: string;
  useStreaming?: boolean;
}

export interface AIResponse {
  answerSummary: string;
  detailedAnswer: string;
  sourcesUsed: SourceReference[];
  authorityClassification: AuthorityClassification;
  confidenceAssessment: ConfidenceAssessment;
  jurisdictionProgram: JurisdictionProgram;
  missingKnowledge: MissingKnowledgeFlag;
  templateOutput: TemplateOutput | null;
  tokenCount: { input: number; output: number };
  costCents: number;
  latencyMs: number;
}

export interface SourceReference {
  sourceId: string;
  title: string;
  layer: string;
  jurisdiction: string;
  bindingLevel: string;
  citation: string;
}

export interface AuthorityClassification {
  bindingRequirements: string[];
  guidanceRequirements: string[];
  contractualRequirements: string[];
  bestPractices: string[];
  scholarlySupport: string[];
}

export interface ConfidenceAssessment {
  level: 'HIGH' | 'MEDIUM' | 'LOW' | 'UNSUPPORTED';
  reasoning: string;
  gaps: string[];
}

export interface JurisdictionProgram {
  jurisdiction: string;
  program: string;
  crossJurisdictional: boolean;
}

export interface MissingKnowledgeFlag {
  isMissingKnowledge: boolean;
  missingConcept: string | null;
  missingLayer: string | null;
  adminTaskPayload: object | null;
}

export interface TemplateOutput {
  formattedContent: string;
  sectionsFilled: Record<string, string>;
}

export class ClaudeService {
  /**
   * Process a user query through the complete AI pipeline
   */
  async processQuery(request: AIRequest): Promise<AIResponse> {
    const startTime = Date.now();
    
    try {
      // Step 1: Retrieve relevant sources
      const retrievedSources = await this.retrieveSources(request);
      
      // Step 2: Build context
      const workspaceContext = await this.getWorkspaceContext(request.workspaceId);
      const roleContext = await this.getRoleContext(request.userId, request.workspaceId);
      
      // Step 3: Assemble prompt
      const prompt = this.assemblePrompt(request, retrievedSources, workspaceContext, roleContext);
      
      // Step 4: Call Claude API
      const model = this.selectModelForQuery(request);
      const claudeResponse = await this.callClaude(prompt, model, request.useStreaming);
      
      // Step 5: Parse and validate response
      const parsedResponse = this.parseResponse(claudeResponse.content);
      
      // Step 6: Handle missing knowledge if detected
      if (parsedResponse.missingKnowledge.isMissingKnowledge) {
        await missingKnowledgeService.createEvent({
          originalQuestion: request.query,
          normalizedQuestion: this.normalizeQuestion(request.query),
          jurisdiction: parsedResponse.jurisdictionProgram.jurisdiction,
          programType: parsedResponse.jurisdictionProgram.program,
          topic: this.extractTopic(request.query),
          missingLayer: parsedResponse.missingKnowledge.missingLayer,
          failureType: this.mapConfidenceToFailureType(parsedResponse.confidenceAssessment.level),
          confidence: parsedResponse.confidenceAssessment.level,
          workspaceId: request.workspaceId,
          userId: request.userId,
        });
      }
      
      // Step 7: Log the interaction
      const latencyMs = Date.now() - startTime;
      await this.logInteraction(request, parsedResponse, claudeResponse, latencyMs);
      
      return {
        ...parsedResponse,
        tokenCount: claudeResponse.tokenCount,
        costCents: claudeResponse.costCents,
        latencyMs,
      };
    } catch (error) {
      console.error('Claude service error:', error);
      throw error;
    }
  }

  /**
   * Retrieve relevant sources for the query
   */
  private async retrieveSources(request: AIRequest): Promise<string> {
    const sources = await retrievalService.search({
      query: request.query,
      jurisdiction: request.jurisdiction,
      programType: request.programType,
      limit: 10,
      workspaceId: request.workspaceId,
    });

    if (sources.length === 0) {
      return 'No relevant sources found in the knowledge base for this query.';
    }

    return sources.map((source, index) => `
[${index + 1}] ${source.title}
    Layer: ${source.authorityLayer}
    Jurisdiction: ${source.jurisdiction}
    Binding Level: ${source.bindingLevel}
    Effective Date: ${source.effectiveDate?.toISOString() || 'N/A'}
    
    Content:
    ${source.chunks.map(c => c.content).join('\n    ')}
    `).join('\n\n');
  }

  /**
   * Get workspace context for prompt
   */
  private async getWorkspaceContext(workspaceId: string) {
    const workspace = await prisma.workspace.findUnique({
      where: { id: workspaceId },
      include: { organization: true },
    });

    if (!workspace) {
      throw new Error('Workspace not found');
    }

    return buildWorkspacePrompt({
      companyName: workspace.organization.name,
      defaultJurisdiction: workspace.defaultJurisdiction || 'Federal',
      defaultState: workspace.defaultState || 'California',
      activeModules: ['Compliance', 'Legal', 'Operations'],
      allowedSources: ['Federal', 'State', 'Contracts', 'Guidance'],
      academicSourcesEnabled: true,
      templatePermissions: ['view', 'use'],
    });
  }

  /**
   * Get role context for prompt
   */
  private async getRoleContext(userId: string, workspaceId: string) {
    // Get user's role in the workspace
    const membership = await prisma.teamMember.findFirst({
      where: {
        userId,
        team: { workspaceId },
      },
    });

    const role = membership?.role || 'viewer';

    return buildRolePrompt({
      role: role as any,
      department: 'Compliance',
      permissions: ['read', 'search'],
    });
  }

  /**
   * Assemble the complete prompt
   */
  private assemblePrompt(
    request: AIRequest,
    retrievedSources: string,
    workspacePrompt: string,
    rolePrompt: string
  ): string {
    // Get conversation history
    const conversationHistory = ''; // TODO: Implement

    return assembleCompletePrompt({
      permanentPrompt: PERMANENT_SYSTEM_PROMPT,
      workspacePrompt,
      rolePrompt,
      outputContract: OUTPUT_CONTRACT_PROMPT,
      missingKnowledgePrompt: MISSING_KNOWLEDGE_PROMPT,
      citationPrompt: CITATION_PROMPT,
      retrievedSources,
      userQuery: request.query,
      conversationHistory,
      selectedTemplate: request.selectedTemplate,
    });
  }

  /**
   * Select appropriate model based on query complexity
   */
  private selectModelForQuery(request: AIRequest): string {
    // Use Opus for complex regulatory questions
    if (request.query.length > 500 || request.query.includes('compare')) {
      return selectModel('reasoning');
    }
    return selectModel('drafting');
  }

  /**
   * Call Claude API
   */
  private async callClaude(
    prompt: string,
    model: string,
    useStreaming?: boolean
  ): Promise<{
    content: string;
    tokenCount: { input: number; output: number };
    costCents: number;
  }> {
    if (useStreaming) {
      // TODO: Implement streaming
      throw new Error('Streaming not yet implemented');
    }

    const response = await claude.messages.create({
      model,
      max_tokens: 4096,
      temperature: 0.2, // Low temperature for factual accuracy
      messages: [
        {
          role: 'user',
          content: prompt,
        },
      ],
    });

    const content = response.content[0].type === 'text' 
      ? response.content[0].text 
      : '';

    const inputTokens = response.usage?.input_tokens || 0;
    const outputTokens = response.usage?.output_tokens || 0;

    return {
      content,
      tokenCount: { input: inputTokens, output: outputTokens },
      costCents: calculateCost(model, inputTokens, outputTokens),
    };
  }

  /**
   * Parse Claude's JSON response
   */
  private parseResponse(content: string): AIResponse {
    try {
      // Extract JSON from response (Claude may wrap in markdown)
      const jsonMatch = content.match(/```json\n([\s\S]*?)\n```/) || 
                        content.match(/\{[\s\S]*\}/);
      
      const jsonString = jsonMatch ? jsonMatch[1] || jsonMatch[0] : content;
      const parsed = JSON.parse(jsonString);

      return {
        answerSummary: parsed.answer_summary || '',
        detailedAnswer: parsed.detailed_answer || '',
        sourcesUsed: parsed.sources_used || [],
        authorityClassification: parsed.authority_classification || {
          bindingRequirements: [],
          guidanceRequirements: [],
          contractualRequirements: [],
          bestPractices: [],
          scholarlySupport: [],
        },
        confidenceAssessment: parsed.confidence_assessment || {
          level: 'UNSUPPORTED',
          reasoning: 'No confidence assessment provided',
          gaps: [],
        },
        jurisdictionProgram: parsed.jurisdiction_program || {
          jurisdiction: 'Unknown',
          program: 'Unknown',
          crossJurisdictional: false,
        },
        missingKnowledge: parsed.missing_knowledge || {
          isMissingKnowledge: false,
          missingConcept: null,
          missingLayer: null,
          adminTaskPayload: null,
        },
        templateOutput: parsed.template_output || null,
        tokenCount: { input: 0, output: 0 },
        costCents: 0,
        latencyMs: 0,
      };
    } catch (error) {
      console.error('Failed to parse Claude response:', error);
      // Return a fallback response
      return {
        answerSummary: 'Error parsing AI response',
        detailedAnswer: content,
        sourcesUsed: [],
        authorityClassification: {
          bindingRequirements: [],
          guidanceRequirements: [],
          contractualRequirements: [],
          bestPractices: [],
          scholarlySupport: [],
        },
        confidenceAssessment: {
          level: 'UNSUPPORTED',
          reasoning: 'Response parsing failed',
          gaps: ['Invalid response format'],
        },
        jurisdictionProgram: {
          jurisdiction: 'Unknown',
          program: 'Unknown',
          crossJurisdictional: false,
        },
        missingKnowledge: {
          isMissingKnowledge: true,
          missingConcept: 'Response parsing',
          missingLayer: null,
          adminTaskPayload: null,
        },
        templateOutput: null,
        tokenCount: { input: 0, output: 0 },
        costCents: 0,
        latencyMs: 0,
      };
    }
  }

  /**
   * Normalize a user question for internal use
   */
  private normalizeQuestion(query: string): string {
    // TODO: Implement proper normalization
    return query.trim().toLowerCase();
  }

  /**
   * Extract topic from query
   */
  private extractTopic(query: string): string {
    // TODO: Implement topic extraction
    return 'general';
  }

  /**
   * Map confidence level to failure type
   */
  private mapConfidenceToFailureType(
    confidence: string
  ): 'NO_ANSWER' | 'INCOMPLETE' | 'LOW_CONFIDENCE' | 'TOO_MUCH_INFERENCE' {
    switch (confidence) {
      case 'UNSUPPORTED':
        return 'NO_ANSWER';
      case 'LOW':
        return 'LOW_CONFIDENCE';
      case 'MEDIUM':
        return 'INCOMPLETE';
      default:
        return 'TOO_MUCH_INFERENCE';
    }
  }

  /**
   * Log the AI interaction
   */
  private async logInteraction(
    request: AIRequest,
    response: AIResponse,
    claudeResponse: { tokenCount: { input: number; output: number }; costCents: number },
    latencyMs: number
  ): Promise<void> {
    // Create or update conversation
    let conversationId = request.conversationId;
    
    if (!conversationId) {
      const conversation = await prisma.conversation.create({
        data: {
          workspaceId: request.workspaceId,
          userId: request.userId,
          title: request.query.slice(0, 100),
          jurisdiction: response.jurisdictionProgram.jurisdiction,
          programType: response.jurisdictionProgram.program as any,
        },
      });
      conversationId = conversation.id;
    }

    // Save user message
    await prisma.message.create({
      data: {
        conversationId,
        userId: request.userId,
        role: 'USER',
        content: request.query,
      },
    });

    // Save AI response
    await prisma.message.create({
      data: {
        conversationId,
        role: 'ASSISTANT',
        content: response.detailedAnswer,
        sourcesUsed: response.sourcesUsed as any,
        confidence: response.confidenceAssessment.level as any,
        isPartial: response.confidenceAssessment.level === 'LOW',
        tokenCount: claudeResponse.tokenCount.input + claudeResponse.tokenCount.output,
        costCents: claudeResponse.costCents,
        latencyMs,
      },
    });

    // Audit log
    await auditService.log({
      userId: request.userId,
      action: 'AI_QUERY',
      resource: 'conversation',
      resourceId: conversationId,
      metadata: {
        query: request.query,
        confidence: response.confidenceAssessment.level,
        costCents: claudeResponse.costCents,
        latencyMs,
      },
    });
  }
}

export const claudeService = new ClaudeService();
