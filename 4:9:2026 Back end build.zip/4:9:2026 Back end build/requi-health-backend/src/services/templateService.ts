/**
 * Template Service
 * 
 * Manages prompt templates for different use cases (eligibility, compliance, appeals, etc.)
 * Supports variable substitution, conditional logic, and template inheritance.
 */

import { prisma } from '../config/database';
import { redis } from '../config/redis';
import { logger } from '../utils/logger';
import { auditService, AuditEventType } from './auditService';
import { AuthorityLayer, ProgramType, Jurisdiction } from '@prisma/client';

export interface CreateTemplateInput {
  name: string;
  description?: string;
  category: TemplateCategory;
  content: string;
  variables: TemplateVariable[];
  systemPrompt?: string;
  authorityLayers?: AuthorityLayer[];
  programTypes?: ProgramType[];
  jurisdictions?: Jurisdiction[];
  isPublic: boolean;
  organizationId?: string;
  createdBy: string;
}

export interface TemplateVariable {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'date' | 'select' | 'multiselect';
  label: string;
  description?: string;
  required: boolean;
  defaultValue?: any;
  options?: string[]; // For select/multiselect
  validation?: {
    min?: number;
    max?: number;
    pattern?: string;
    message?: string;
  };
}

export enum TemplateCategory {
  ELIGIBILITY = 'ELIGIBILITY',
  COMPLIANCE = 'COMPLIANCE',
  APPEALS = 'APPEALS',
  DOCUMENTATION = 'DOCUMENTATION',
  TRAINING = 'TRAINING',
  GENERAL = 'GENERAL',
}

export interface RenderTemplateInput {
  templateId: string;
  variables: Record<string, any>;
  userId: string;
  workspaceId: string;
  conversationId?: string;
}

export interface RenderedTemplate {
  prompt: string;
  systemPrompt: string;
  metadata: {
    templateId: string;
    templateName: string;
    variablesUsed: string[];
    authorityLayers: AuthorityLayer[];
    programTypes: ProgramType[];
  };
}

class TemplateService {
  private readonly CACHE_TTL = 3600; // 1 hour
  private readonly MAX_TEMPLATE_SIZE = 10000; // characters

  /**
   * Create a new template
   */
  async create(input: CreateTemplateInput): Promise<string> {
    // Validate template size
    if (input.content.length > this.MAX_TEMPLATE_SIZE) {
      throw new Error(`Template content exceeds maximum size of ${this.MAX_TEMPLATE_SIZE} characters`);
    }

    // Validate variables
    this.validateVariables(input.content, input.variables);

    const template = await prisma.template.create({
      data: {
        name: input.name,
        description: input.description,
        category: input.category,
        content: input.content,
        variables: input.variables as any,
        systemPrompt: input.systemPrompt,
        authorityLayers: input.authorityLayers || [],
        programTypes: input.programTypes || [],
        jurisdictions: input.jurisdictions || [],
        isPublic: input.isPublic,
        organizationId: input.organizationId,
        createdBy: input.createdBy,
      },
    });

    await auditService.log({
      eventType: AuditEventType.TEMPLATE_CREATED,
      severity: 'INFO',
      userId: input.createdBy,
      organizationId: input.organizationId,
      metadata: { 
        templateId: template.id,
        category: input.category,
        isPublic: input.isPublic,
      },
      description: `Template created: ${input.name}`,
    });

    return template.id;
  }

  /**
   * Update a template
   */
  async update(
    templateId: string,
    input: Partial<CreateTemplateInput>,
    userId: string
  ): Promise<void> {
    const template = await prisma.template.findUnique({
      where: { id: templateId },
    });

    if (!template) {
      throw new Error('Template not found');
    }

    // Check permissions
    if (!template.isPublic && template.createdBy !== userId) {
      throw new Error('Permission denied: Cannot modify this template');
    }

    // Validate new content if provided
    if (input.content) {
      if (input.content.length > this.MAX_TEMPLATE_SIZE) {
        throw new Error(`Template content exceeds maximum size`);
      }
      this.validateVariables(input.content, input.variables || (template.variables as TemplateVariable[]));
    }

    await prisma.template.update({
      where: { id: templateId },
      data: {
        name: input.name,
        description: input.description,
        category: input.category,
        content: input.content,
        variables: input.variables as any,
        systemPrompt: input.systemPrompt,
        authorityLayers: input.authorityLayers,
        programTypes: input.programTypes,
        jurisdictions: input.jurisdictions,
        isPublic: input.isPublic,
        updatedAt: new Date(),
      },
    });

    // Invalidate cache
    await redis.del(`template:${templateId}`);

    await auditService.log({
      eventType: AuditEventType.TEMPLATE_UPDATED,
      severity: 'INFO',
      userId,
      organizationId: template.organizationId || undefined,
      metadata: { templateId },
      description: `Template updated: ${template.name}`,
    });
  }

  /**
   * Delete a template
   */
  async delete(templateId: string, userId: string): Promise<void> {
    const template = await prisma.template.findUnique({
      where: { id: templateId },
    });

    if (!template) {
      throw new Error('Template not found');
    }

    // Check permissions
    if (!template.isPublic && template.createdBy !== userId) {
      throw new Error('Permission denied: Cannot delete this template');
    }

    await prisma.template.delete({
      where: { id: templateId },
    });

    // Invalidate cache
    await redis.del(`template:${templateId}`);

    await auditService.log({
      eventType: AuditEventType.TEMPLATE_DELETED,
      severity: 'INFO',
      userId,
      organizationId: template.organizationId || undefined,
      metadata: { templateId },
      description: `Template deleted: ${template.name}`,
    });
  }

  /**
   * Get a template by ID
   */
  async getById(templateId: string): Promise<any> {
    const cacheKey = `template:${templateId}`;
    const cached = await redis.get(cacheKey);

    if (cached) {
      return JSON.parse(cached);
    }

    const template = await prisma.template.findUnique({
      where: { id: templateId },
      include: {
        creator: {
          select: { id: true, email: true, firstName: true, lastName: true },
        },
      },
    });

    if (!template) {
      return null;
    }

    // Cache
    await redis.setex(cacheKey, this.CACHE_TTL, JSON.stringify(template));

    return template;
  }

  /**
   * List templates with filters
   */
  async list(filters: {
    organizationId?: string;
    category?: TemplateCategory;
    isPublic?: boolean;
    search?: string;
    limit?: number;
    offset?: number;
  }): Promise<{ templates: any[]; total: number }> {
    const where: any = {};

    if (filters.organizationId) {
      where.OR = [
        { organizationId: filters.organizationId },
        { isPublic: true },
      ];
    } else if (filters.isPublic !== undefined) {
      where.isPublic = filters.isPublic;
    }

    if (filters.category) {
      where.category = filters.category;
    }

    if (filters.search) {
      where.OR = [
        { name: { contains: filters.search, mode: 'insensitive' } },
        { description: { contains: filters.search, mode: 'insensitive' } },
      ];
    }

    const [templates, total] = await Promise.all([
      prisma.template.findMany({
        where,
        orderBy: [{ isPublic: 'desc' }, { usageCount: 'desc' }],
        take: filters.limit || 20,
        skip: filters.offset || 0,
        include: {
          creator: {
            select: { id: true, email: true, firstName: true, lastName: true },
          },
        },
      }),
      prisma.template.count({ where }),
    ]);

    return { templates, total };
  }

  /**
   * Render a template with variables
   */
  async render(input: RenderTemplateInput): Promise<RenderedTemplate> {
    const template = await this.getById(input.templateId);

    if (!template) {
      throw new Error('Template not found');
    }

    // Validate required variables
    const variables = template.variables as TemplateVariable[];
    const missingRequired = variables
      .filter(v => v.required && input.variables[v.name] === undefined)
      .map(v => v.name);

    if (missingRequired.length > 0) {
      throw new Error(`Missing required variables: ${missingRequired.join(', ')}`);
    }

    // Validate variable types and values
    for (const variable of variables) {
      const value = input.variables[variable.name];
      if (value !== undefined) {
        this.validateVariableValue(variable, value);
      }
    }

    // Apply default values
    const finalVariables: Record<string, any> = {};
    for (const variable of variables) {
      finalVariables[variable.name] = input.variables[variable.name] ?? variable.defaultValue;
    }

    // Render content
    let renderedContent = template.content;
    for (const [key, value] of Object.entries(finalVariables)) {
      const regex = new RegExp(`{{\\s*${key}\\s*}}`, 'g');
      renderedContent = renderedContent.replace(regex, String(value));
    }

    // Handle conditional blocks
    renderedContent = this.processConditionals(renderedContent, finalVariables);

    // Increment usage count
    await prisma.template.update({
      where: { id: input.templateId },
      data: { usageCount: { increment: 1 } },
    });

    // Log usage
    await auditService.log({
      eventType: AuditEventType.TEMPLATE_USED,
      severity: 'INFO',
      userId: input.userId,
      workspaceId: input.workspaceId,
      metadata: { 
        templateId: input.templateId,
        conversationId: input.conversationId,
      },
      description: `Template used: ${template.name}`,
    });

    return {
      prompt: renderedContent,
      systemPrompt: template.systemPrompt || '',
      metadata: {
        templateId: template.id,
        templateName: template.name,
        variablesUsed: Object.keys(finalVariables),
        authorityLayers: template.authorityLayers as AuthorityLayer[],
        programTypes: template.programTypes as ProgramType[],
      },
    };
  }

  /**
   * Get popular templates
   */
  async getPopular(limit: number = 10): Promise<any[]> {
    const cacheKey = 'templates:popular';
    const cached = await redis.get(cacheKey);

    if (cached) {
      return JSON.parse(cached);
    }

    const templates = await prisma.template.findMany({
      where: { isPublic: true },
      orderBy: { usageCount: 'desc' },
      take: limit,
      select: {
        id: true,
        name: true,
        description: true,
        category: true,
        usageCount: true,
      },
    });

    await redis.setex(cacheKey, 3600, JSON.stringify(templates));
    return templates;
  }

  /**
   * Clone a template
   */
  async clone(
    templateId: string,
    newName: string,
    organizationId: string,
    userId: string
  ): Promise<string> {
    const template = await prisma.template.findUnique({
      where: { id: templateId },
    });

    if (!template) {
      throw new Error('Template not found');
    }

    return this.create({
      name: newName,
      description: template.description || undefined,
      category: template.category as TemplateCategory,
      content: template.content,
      variables: template.variables as TemplateVariable[],
      systemPrompt: template.systemPrompt || undefined,
      authorityLayers: template.authorityLayers as AuthorityLayer[] || undefined,
      programTypes: template.programTypes as ProgramType[] || undefined,
      jurisdictions: template.jurisdictions as Jurisdiction[] || undefined,
      isPublic: false,
      organizationId,
      createdBy: userId,
    });
  }

  // Private methods

  private validateVariables(content: string, variables: TemplateVariable[]): void {
    // Extract variable references from content
    const variableRegex = /{{\s*(\w+)\s*}}/g;
    const referencedVars = new Set<string>();
    let match;

    while ((match = variableRegex.exec(content)) !== null) {
      referencedVars.add(match[1]);
    }

    // Check that all referenced variables are defined
    const definedVars = new Set(variables.map(v => v.name));
    const undefinedVars = Array.from(referencedVars).filter(v => !definedVars.has(v));

    if (undefinedVars.length > 0) {
      throw new Error(`Template references undefined variables: ${undefinedVars.join(', ')}`);
    }
  }

  private validateVariableValue(variable: TemplateVariable, value: any): void {
    // Type validation
    switch (variable.type) {
      case 'number':
        if (typeof value !== 'number') {
          throw new Error(`Variable ${variable.name} must be a number`);
        }
        if (variable.validation?.min !== undefined && value < variable.validation.min) {
          throw new Error(`Variable ${variable.name} must be at least ${variable.validation.min}`);
        }
        if (variable.validation?.max !== undefined && value > variable.validation.max) {
          throw new Error(`Variable ${variable.name} must be at most ${variable.validation.max}`);
        }
        break;
      case 'string':
        if (typeof value !== 'string') {
          throw new Error(`Variable ${variable.name} must be a string`);
        }
        if (variable.validation?.pattern && !new RegExp(variable.validation.pattern).test(value)) {
          throw new Error(variable.validation.message || `Variable ${variable.name} has invalid format`);
        }
        break;
      case 'boolean':
        if (typeof value !== 'boolean') {
          throw new Error(`Variable ${variable.name} must be a boolean`);
        }
        break;
      case 'select':
        if (!variable.options?.includes(value)) {
          throw new Error(`Variable ${variable.name} must be one of: ${variable.options?.join(', ')}`);
        }
        break;
      case 'multiselect':
        if (!Array.isArray(value)) {
          throw new Error(`Variable ${variable.name} must be an array`);
        }
        const invalid = value.filter(v => !variable.options?.includes(v));
        if (invalid.length > 0) {
          throw new Error(`Invalid options for ${variable.name}: ${invalid.join(', ')}`);
        }
        break;
    }
  }

  private processConditionals(content: string, variables: Record<string, any>): string {
    // Handle {{#if variable}}...{{/if}} blocks
    let result = content;
    const ifRegex = /{{#if\s+(\w+)}}([\s\S]*?){{\/if}}/g;
    
    result = result.replace(ifRegex, (match, varName, innerContent) => {
      const value = variables[varName];
      // Truthy check
      if (value && (typeof value !== 'string' || value.length > 0)) {
        return innerContent;
      }
      return '';
    });

    // Handle {{#unless variable}}...{{/unless}} blocks
    const unlessRegex = /{{#unless\s+(\w+)}}([\s\S]*?){{\/unless}}/g;
    
    result = result.replace(unlessRegex, (match, varName, innerContent) => {
      const value = variables[varName];
      if (!value || (typeof value === 'string' && value.length === 0)) {
        return innerContent;
      }
      return '';
    });

    return result;
  }
}

export const templateService = new TemplateService();
