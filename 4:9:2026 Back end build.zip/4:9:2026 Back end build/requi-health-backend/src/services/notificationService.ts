/**
 * Notification Service
 * 
 * Handles all notifications including admin alerts, user notifications,
 * and system announcements. Supports email, in-app, and webhook channels.
 */

import { prisma } from '../config/database';
import { redis } from '../config/redis';
import { logger } from '../utils/logger';

export enum NotificationType {
  // Admin notifications
  MISSING_KNOWLEDGE_ALERT = 'MISSING_KNOWLEDGE_ALERT',
  ADMIN_TASK_ASSIGNED = 'ADMIN_TASK_ASSIGNED',
  ADMIN_TASK_OVERDUE = 'ADMIN_TASK_OVERDUE',
  SYSTEM_ERROR = 'SYSTEM_ERROR',
  SECURITY_ALERT = 'SECURITY_ALERT',
  
  // User notifications
  INVITATION_RECEIVED = 'INVITATION_RECEIVED',
  INVITATION_ACCEPTED = 'INVITATION_ACCEPTED',
  ROLE_CHANGED = 'ROLE_CHANGED',
  WORKSPACE_ACCESS_CHANGED = 'WORKSPACE_ACCESS_CHANGED',
  QUOTA_WARNING = 'QUOTA_WARNING',
  QUOTA_EXCEEDED = 'QUOTA_EXCEEDED',
  SUBSCRIPTION_EXPIRING = 'SUBSCRIPTION_EXPIRING',
  PAYMENT_SUCCEEDED = 'PAYMENT_SUCCEEDED',
  PAYMENT_FAILED = 'PAYMENT_FAILED',
  
  // System announcements
  MAINTENANCE_SCHEDULED = 'MAINTENANCE_SCHEDULED',
  FEATURE_ANNOUNCEMENT = 'FEATURE_ANNOUNCEMENT',
  POLICY_UPDATE = 'POLICY_UPDATE',
}

export enum NotificationChannel {
  IN_APP = 'IN_APP',
  EMAIL = 'EMAIL',
  WEBHOOK = 'WEBHOOK',
  SLACK = 'SLACK',
}

export enum NotificationPriority {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  URGENT = 'URGENT',
}

export interface CreateNotificationInput {
  type: NotificationType;
  priority: NotificationPriority;
  userId?: string;
  organizationId?: string;
  workspaceId?: string;
  title: string;
  message: string;
  metadata?: Record<string, any>;
  channels?: NotificationChannel[];
  actionUrl?: string;
  expiresAt?: Date;
}

export interface NotificationPreferences {
  userId: string;
  emailEnabled: boolean;
  channels: Record<NotificationType, NotificationChannel[]>;
}

class NotificationService {
  private readonly RATE_LIMIT_KEY = 'notifications:rate:';
  private readonly MAX_NOTIFICATIONS_PER_HOUR = 100;

  /**
   * Create and send a notification
   */
  async create(input: CreateNotificationInput): Promise<void> {
    try {
      // Check rate limiting
      const rateLimitKey = `${this.RATE_LIMIT_KEY}${input.userId || 'system'}:${input.type}`;
      const currentCount = await redis.incr(rateLimitKey);
      
      if (currentCount === 1) {
        await redis.expire(rateLimitKey, 3600); // 1 hour
      }
      
      if (currentCount > this.MAX_NOTIFICATIONS_PER_HOUR) {
        logger.warn('Notification rate limit exceeded', { input });
        return;
      }

      // Create in-app notification
      await prisma.notification.create({
        data: {
          type: input.type,
          priority: input.priority,
          userId: input.userId,
          organizationId: input.organizationId,
          workspaceId: input.workspaceId,
          title: input.title,
          message: input.message,
          metadata: input.metadata || {},
          actionUrl: input.actionUrl,
          expiresAt: input.expiresAt,
          read: false,
        },
      });

      // Send to additional channels
      const channels = input.channels || [NotificationChannel.IN_APP];
      
      for (const channel of channels) {
        switch (channel) {
          case NotificationChannel.EMAIL:
            await this.sendEmail(input);
            break;
          case NotificationChannel.SLACK:
            await this.sendSlack(input);
            break;
          case NotificationChannel.WEBHOOK:
            await this.sendWebhook(input);
            break;
        }
      }

      // Cache urgent notifications for admin dashboard
      if (input.priority === NotificationPriority.URGENT) {
        await this.cacheUrgentNotification(input);
      }
    } catch (error) {
      logger.error('Failed to create notification', { error, input });
    }
  }

  /**
   * Send missing knowledge alert to admins
   */
  async sendMissingKnowledgeAlert(
    eventId: string,
    normalizedQuestion: string,
    jurisdiction: string,
    frequency: number
  ): Promise<void> {
    // Find admins for this jurisdiction
    const admins = await prisma.user.findMany({
      where: {
        role: { in: ['ADMIN', 'SUPER_ADMIN'] },
        status: 'ACTIVE',
      },
      select: { id: true, email: true },
    });

    for (const admin of admins) {
      await this.create({
        type: NotificationType.MISSING_KNOWLEDGE_ALERT,
        priority: frequency >= 10 ? NotificationPriority.HIGH : NotificationPriority.MEDIUM,
        userId: admin.id,
        title: `Missing Knowledge Alert: ${jurisdiction}`,
        message: `The question "${normalizedQuestion.substring(0, 100)}..." has been asked ${frequency} times but cannot be answered. Review and add sources.`,
        metadata: { eventId, frequency, jurisdiction },
        channels: [NotificationChannel.IN_APP, NotificationChannel.EMAIL],
        actionUrl: `/admin/missing-knowledge/${eventId}`,
      });
    }
  }

  /**
   * Send admin task assignment notification
   */
  async sendAdminTaskAssigned(
    taskId: string,
    assigneeId: string,
    title: string,
    priority: string
  ): Promise<void> {
    await this.create({
      type: NotificationType.ADMIN_TASK_ASSIGNED,
      priority: priority === 'URGENT' ? NotificationPriority.URGENT : NotificationPriority.HIGH,
      userId: assigneeId,
      title: 'New Admin Task Assigned',
      message: `You have been assigned: "${title}"`,
      metadata: { taskId, priority },
      channels: [NotificationChannel.IN_APP, NotificationChannel.EMAIL],
      actionUrl: `/admin/tasks/${taskId}`,
    });
  }

  /**
   * Send quota warning
   */
  async sendQuotaWarning(
    userId: string,
    organizationId: string,
    usagePercent: number
  ): Promise<void> {
    await this.create({
      type: NotificationType.QUOTA_WARNING,
      priority: usagePercent >= 95 ? NotificationPriority.HIGH : NotificationPriority.MEDIUM,
      userId,
      organizationId,
      title: 'Usage Quota Warning',
      message: `You have used ${usagePercent}% of your monthly quota. Consider upgrading your plan.`,
      metadata: { usagePercent },
      channels: [NotificationChannel.IN_APP, NotificationChannel.EMAIL],
      actionUrl: '/settings/billing',
    });
  }

  /**
   * Send invitation notification
   */
  async sendInvitation(
    invitationId: string,
    email: string,
    inviterName: string,
    workspaceName: string
  ): Promise<void> {
    // Check if user exists
    const user = await prisma.user.findUnique({
      where: { email },
      select: { id: true },
    });

    if (user) {
      await this.create({
        type: NotificationType.INVITATION_RECEIVED,
        priority: NotificationPriority.MEDIUM,
        userId: user.id,
        title: 'Workspace Invitation',
        message: `${inviterName} has invited you to join "${workspaceName}"`,
        metadata: { invitationId },
        channels: [NotificationChannel.IN_APP, NotificationChannel.EMAIL],
        actionUrl: `/invitations/${invitationId}`,
      });
    }

    // Always send email for invitations
    await this.sendEmail({
      type: NotificationType.INVITATION_RECEIVED,
      priority: NotificationPriority.MEDIUM,
      title: 'Workspace Invitation',
      message: `${inviterName} has invited you to join "${workspaceName}" on Requi Health.`,
      metadata: { invitationId },
      channels: [NotificationChannel.EMAIL],
    }, email);
  }

  /**
   * Send security alert
   */
  async sendSecurityAlert(
    userId: string,
    alertType: 'SUSPICIOUS_LOGIN' | 'PASSWORD_CHANGED' | 'MFA_DISABLED',
    details: Record<string, any>
  ): Promise<void> {
    const titles: Record<string, string> = {
      SUSPICIOUS_LOGIN: 'Suspicious Login Detected',
      PASSWORD_CHANGED: 'Password Changed',
      MFA_DISABLED: 'Two-Factor Authentication Disabled',
    };

    await this.create({
      type: NotificationType.SECURITY_ALERT,
      priority: NotificationPriority.HIGH,
      userId,
      title: titles[alertType],
      message: this.getSecurityMessage(alertType, details),
      metadata: { alertType, ...details },
      channels: [NotificationChannel.IN_APP, NotificationChannel.EMAIL],
    });
  }

  /**
   * Get notifications for a user
   */
  async getForUser(
    userId: string,
    options: { unreadOnly?: boolean; limit?: number; offset?: number } = {}
  ): Promise<{ notifications: any[]; unreadCount: number }> {
    const where: any = { userId };
    
    if (options.unreadOnly) {
      where.read = false;
    }

    const [notifications, unreadCount] = await Promise.all([
      prisma.notification.findMany({
        where,
        orderBy: [{ priority: 'desc' }, { createdAt: 'desc' }],
        take: options.limit || 20,
        skip: options.offset || 0,
      }),
      prisma.notification.count({
        where: { userId, read: false },
      }),
    ]);

    return { notifications, unreadCount };
  }

  /**
   * Mark notification as read
   */
  async markAsRead(notificationId: string, userId: string): Promise<void> {
    await prisma.notification.updateMany({
      where: { id: notificationId, userId },
      data: { read: true, readAt: new Date() },
    });
  }

  /**
   * Mark all notifications as read
   */
  async markAllAsRead(userId: string): Promise<void> {
    await prisma.notification.updateMany({
      where: { userId, read: false },
      data: { read: true, readAt: new Date() },
    });
  }

  /**
   * Delete old notifications
   */
  async cleanup(days: number = 90): Promise<{ deleted: number }> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);

    const result = await prisma.notification.deleteMany({
      where: {
        createdAt: { lt: cutoffDate },
        read: true,
      },
    });

    logger.info('Notification cleanup completed', { deleted: result.count });
    return { deleted: result.count };
  }

  /**
   * Get notification preferences for a user
   */
  async getPreferences(userId: string): Promise<NotificationPreferences | null> {
    const prefs = await prisma.notificationPreference.findUnique({
      where: { userId },
    });

    if (!prefs) {
      return null;
    }

    return {
      userId: prefs.userId,
      emailEnabled: prefs.emailEnabled,
      channels: prefs.channels as Record<NotificationType, NotificationChannel[]>,
    };
  }

  /**
   * Update notification preferences
   */
  async updatePreferences(
    userId: string,
    preferences: Partial<NotificationPreferences>
  ): Promise<void> {
    await prisma.notificationPreference.upsert({
      where: { userId },
      create: {
        userId,
        emailEnabled: preferences.emailEnabled ?? true,
        channels: preferences.channels || {},
      },
      update: {
        emailEnabled: preferences.emailEnabled,
        channels: preferences.channels,
      },
    });
  }

  // Private methods

  private async sendEmail(input: CreateNotificationInput, toEmail?: string): Promise<void> {
    // TODO: Integrate with email service (SendGrid, AWS SES, etc.)
    logger.info('Email notification queued', { 
      to: toEmail || input.userId, 
      subject: input.title,
      type: input.type,
    });
  }

  private async sendSlack(input: CreateNotificationInput): Promise<void> {
    // TODO: Integrate with Slack webhook
    logger.info('Slack notification queued', { type: input.type });
  }

  private async sendWebhook(input: CreateNotificationInput): Promise<void> {
    // TODO: Send to configured webhook URL
    logger.info('Webhook notification queued', { type: input.type });
  }

  private async cacheUrgentNotification(input: CreateNotificationInput): Promise<void> {
    const cacheKey = 'notifications:urgent:recent';
    try {
      await redis.del(cacheKey); // Invalidate to force refresh
    } catch (error) {
      // Non-critical
    }
  }

  private getSecurityMessage(alertType: string, details: Record<string, any>): string {
    switch (alertType) {
      case 'SUSPICIOUS_LOGIN':
        return `We detected a login from an unusual location: ${details.location || 'Unknown'}. If this wasn't you, please secure your account.`;
      case 'PASSWORD_CHANGED':
        return 'Your password was recently changed. If you didn\'t make this change, please contact support immediately.';
      case 'MFA_DISABLED':
        return 'Two-factor authentication was disabled on your account. If you didn\'t do this, please secure your account immediately.';
      default:
        return 'A security event occurred on your account. Please review your account activity.';
    }
  }
}

export const notificationService = new NotificationService();
