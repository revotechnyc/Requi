/**
 * Document Ingestion Service
 * 
 * Handles the complete document ingestion pipeline:
 * 1. File upload and validation
 * 2. Text extraction (PDF, DOCX, etc.)
 * 3. Chunking with semantic boundaries
 * 4. Vector embedding generation
 * 5. Metadata extraction and storage
 * 6. Source registration
 */

import { prisma } from '../config/database';
import { redis } from '../config/redis';
import { logger } from '../utils/logger';
import { auditService, AuditEventType } from './auditService';
import { AuthorityLayer, BindingLevel, ProgramType, SourceStatus } from '@prisma/client';

export interface IngestionJob {
  id: string;
  sourceId: string;
  filePath: string;
  fileType: string;
  organizationId: string;
  workspaceId: string;
  uploadedBy: string;
  metadata?: Record<string, any>;
}

export interface ExtractionResult {
  text: string;
  metadata: {
    title?: string;
    author?: string;
    date?: string;
    pages?: number;
    wordCount?: number;
  };
}

export interface ChunkResult {
  chunks: Array<{
    content: string;
    startIndex: number;
    endIndex: number;
    metadata?: Record<string, any>;
  }>;
  totalChunks: number;
}

export interface IngestionResult {
  success: boolean;
  sourceId: string;
  chunksCreated: number;
  error?: string;
}

class IngestionService {
  private readonly CHUNK_SIZE = 1000; // Target chunk size in tokens (approximate)
  private readonly CHUNK_OVERLAP = 200; // Overlap between chunks
  private readonly MAX_FILE_SIZE = 100 * 1024 * 1024; // 100MB
  private readonly ALLOWED_TYPES = ['pdf', 'docx', 'doc', 'txt', 'md', 'html'];

  /**
   * Process a document ingestion job
   */
  async processJob(job: IngestionJob): Promise<IngestionResult> {
    const startTime = Date.now();
    
    try {
      logger.info('Starting document ingestion', { jobId: job.id, sourceId: job.sourceId });

      // Update source status to processing
      await this.updateSourceStatus(job.sourceId, SourceStatus.PROCESSING);

      // 1. Extract text from file
      const extraction = await this.extractText(job);
      logger.info('Text extraction completed', { 
        jobId: job.id, 
        wordCount: extraction.metadata.wordCount,
        pages: extraction.metadata.pages,
      });

      // 2. Chunk the text
      const chunking = this.chunkText(extraction.text);
      logger.info('Chunking completed', { jobId: job.id, chunks: chunking.totalChunks });

      // 3. Generate embeddings and store chunks
      await this.storeChunks(job, chunking.chunks);
      logger.info('Chunks stored', { jobId: job.id, chunks: chunking.totalChunks });

      // 4. Update source metadata
      await this.updateSourceMetadata(job.sourceId, {
        ...extraction.metadata,
        chunkCount: chunking.totalChunks,
        processedAt: new Date(),
      });

      // 5. Update source status to active
      await this.updateSourceStatus(job.sourceId, SourceStatus.ACTIVE);

      // 6. Log audit event
      await auditService.log({
        eventType: AuditEventType.DOCUMENT_INGESTED,
        severity: 'INFO',
        userId: job.uploadedBy,
        organizationId: job.organizationId,
        workspaceId: job.workspaceId,
        sourceId: job.sourceId,
        metadata: {
          chunks: chunking.totalChunks,
          wordCount: extraction.metadata.wordCount,
          processingTimeMs: Date.now() - startTime,
        },
        description: `Document ingested: ${chunking.totalChunks} chunks`,
      });

      logger.info('Document ingestion completed', { 
        jobId: job.id, 
        sourceId: job.sourceId,
        duration: Date.now() - startTime,
      });

      return {
        success: true,
        sourceId: job.sourceId,
        chunksCreated: chunking.totalChunks,
      };
    } catch (error) {
      logger.error('Document ingestion failed', { jobId: job.id, error });

      // Update source status to error
      await this.updateSourceStatus(job.sourceId, SourceStatus.ERROR, (error as Error).message);

      // Log audit event
      await auditService.log({
        eventType: AuditEventType.DOCUMENT_INGEST_FAILED,
        severity: 'ERROR',
        userId: job.uploadedBy,
        organizationId: job.organizationId,
        workspaceId: job.workspaceId,
        sourceId: job.sourceId,
        metadata: { error: (error as Error).message },
        description: `Document ingestion failed: ${(error as Error).message}`,
      });

      return {
        success: false,
        sourceId: job.sourceId,
        chunksCreated: 0,
        error: (error as Error).message,
      };
    }
  }

  /**
   * Extract text from uploaded file
   */
  private async extractText(job: IngestionJob): Promise<ExtractionResult> {
    // This would integrate with actual PDF/DOCX parsing libraries
    // For now, return a placeholder implementation
    
    const fileType = job.fileType.toLowerCase();
    
    if (!this.ALLOWED_TYPES.includes(fileType)) {
      throw new Error(`Unsupported file type: ${fileType}`);
    }

    // Placeholder: In production, use libraries like:
    // - pdf-parse for PDFs
    // - mammoth for DOCX
    // - cheerio for HTML
    
    // Simulated extraction
    const simulatedText = `This is extracted text from ${job.sourceId}. In production, this would be the actual content extracted from the ${fileType.toUpperCase()} file.`;
    
    return {
      text: simulatedText,
      metadata: {
        title: `Document ${job.sourceId}`,
        pages: 1,
        wordCount: simulatedText.split(/\s+/).length,
      },
    };
  }

  /**
   * Chunk text with semantic boundaries
   */
  private chunkText(text: string): ChunkResult {
    const chunks: ChunkResult['chunks'] = [];
    
    // Split into paragraphs first (semantic boundaries)
    const paragraphs = text.split(/\n\s*\n/);
    
    let currentChunk = '';
    let currentStart = 0;
    let currentPosition = 0;

    for (const paragraph of paragraphs) {
      const paragraphWords = paragraph.split(/\s+/).length;
      const chunkWords = currentChunk.split(/\s+/).length;

      // If adding this paragraph would exceed chunk size, save current chunk
      if (chunkWords + paragraphWords > this.CHUNK_SIZE && currentChunk.length > 0) {
        chunks.push({
          content: currentChunk.trim(),
          startIndex: currentStart,
          endIndex: currentPosition,
          metadata: { paragraphCount: currentChunk.split(/\n\s*\n/).length },
        });

        // Start new chunk with overlap
        const words = currentChunk.split(/\s+/);
        const overlapWords = words.slice(-this.CHUNK_OVERLAP);
        currentChunk = overlapWords.join(' ') + '\n\n' + paragraph;
        currentStart = currentPosition - overlapWords.join(' ').length;
      } else {
        currentChunk += (currentChunk ? '\n\n' : '') + paragraph;
      }

      currentPosition += paragraph.length + 2; // +2 for \n\n
    }

    // Don't forget the last chunk
    if (currentChunk.trim().length > 0) {
      chunks.push({
        content: currentChunk.trim(),
        startIndex: currentStart,
        endIndex: currentPosition,
        metadata: { paragraphCount: currentChunk.split(/\n\s*\n/).length },
      });
    }

    return {
      chunks,
      totalChunks: chunks.length,
    };
  }

  /**
   * Store chunks with embeddings
   */
  private async storeChunks(
    job: IngestionJob,
    chunks: ChunkResult['chunks']
  ): Promise<void> {
    // In production, this would:
    // 1. Generate embeddings using an embedding model (OpenAI, Cohere, etc.)
    // 2. Store in vector database (Pinecone, Weaviate, pgvector, etc.)
    // 3. Also store in PostgreSQL for metadata

    for (let i = 0; i < chunks.length; i++) {
      const chunk = chunks[i];
      
      // Generate placeholder embedding (384 dimensions - all-MiniLM-L6-v2 size)
      const embedding = new Array(384).fill(0).map(() => Math.random() * 2 - 1);

      await prisma.documentChunk.create({
        data: {
          sourceId: job.sourceId,
          content: chunk.content,
          embedding: embedding, // In production, use actual vector type
          chunkIndex: i,
          startIndex: chunk.startIndex,
          endIndex: chunk.endIndex,
          metadata: chunk.metadata || {},
        },
      });
    }
  }

  /**
   * Update source status
   */
  private async updateSourceStatus(
    sourceId: string,
    status: SourceStatus,
    errorMessage?: string
  ): Promise<void> {
    await prisma.source.update({
      where: { id: sourceId },
      data: {
        status,
        ...(errorMessage && { metadata: { error: errorMessage } }),
      },
    });
  }

  /**
   * Update source metadata
   */
  private async updateSourceMetadata(
    sourceId: string,
    metadata: Record<string, any>
  ): Promise<void> {
    const source = await prisma.source.findUnique({
      where: { id: sourceId },
      select: { metadata: true },
    });

    await prisma.source.update({
      where: { id: sourceId },
      data: {
        metadata: {
          ...(source?.metadata as object || {}),
          ...metadata,
        },
      },
    });
  }

  /**
   * Validate file before upload
   */
  async validateFile(
    fileName: string,
    fileSize: number,
    mimeType: string
  ): Promise<{ valid: boolean; error?: string }> {
    // Check file size
    if (fileSize > this.MAX_FILE_SIZE) {
      return {
        valid: false,
        error: `File size exceeds maximum of ${this.MAX_FILE_SIZE / 1024 / 1024}MB`,
      };
    }

    // Check file extension
    const extension = fileName.split('.').pop()?.toLowerCase();
    if (!extension || !this.ALLOWED_TYPES.includes(extension)) {
      return {
        valid: false,
        error: `Unsupported file type: ${extension}. Allowed: ${this.ALLOWED_TYPES.join(', ')}`,
      };
    }

    // Check MIME type
    const allowedMimeTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/plain',
      'text/markdown',
      'text/html',
    ];

    if (!allowedMimeTypes.includes(mimeType)) {
      return {
        valid: false,
        error: `Unsupported MIME type: ${mimeType}`,
      };
    }

    return { valid: true };
  }

  /**
   * Queue ingestion job
   */
  async queueJob(job: IngestionJob): Promise<void> {
    const queueKey = 'ingestion:queue';
    await redis.lpush(queueKey, JSON.stringify(job));
    logger.info('Ingestion job queued', { jobId: job.id, sourceId: job.sourceId });
  }

  /**
   * Process next job from queue
   */
  async processNextJob(): Promise<IngestionResult | null> {
    const queueKey = 'ingestion:queue';
    const jobData = await redis.rpop(queueKey);
    
    if (!jobData) {
      return null;
    }

    const job: IngestionJob = JSON.parse(jobData);
    return this.processJob(job);
  }

  /**
   * Get ingestion stats
   */
  async getStats(organizationId?: string): Promise<{
    totalSources: number;
    byStatus: Record<string, number>;
    totalChunks: number;
    recentIngestions: any[];
  }> {
    const where: any = {};
    if (organizationId) {
      where.organizationId = organizationId;
    }

    const [
      totalSources,
      byStatus,
      totalChunks,
      recentIngestions,
    ] = await Promise.all([
      prisma.source.count({ where }),
      prisma.source.groupBy({
        by: ['status'],
        where,
        _count: { status: true },
      }),
      prisma.documentChunk.count({
        where: {
          source: { organizationId },
        },
      }),
      prisma.source.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: 10,
        select: {
          id: true,
          title: true,
          status: true,
          createdAt: true,
          uploadedBy: {
            select: { email: true },
          },
        },
      }),
    ]);

    return {
      totalSources,
      byStatus: byStatus.reduce((acc, s) => ({
        ...acc,
        [s.status]: s._count.status,
      }), {}),
      totalChunks,
      recentIngestions,
    };
  }

  /**
   * Reprocess a source
   */
  async reprocessSource(sourceId: string, userId: string): Promise<IngestionResult> {
    const source = await prisma.source.findUnique({
      where: { id: sourceId },
    });

    if (!source) {
      throw new Error('Source not found');
    }

    // Delete existing chunks
    await prisma.documentChunk.deleteMany({
      where: { sourceId },
    });

    // Create new job
    const job: IngestionJob = {
      id: `reprocess-${Date.now()}`,
      sourceId: source.id,
      filePath: source.filePath || '',
      fileType: source.fileType || 'pdf',
      organizationId: source.organizationId,
      workspaceId: source.workspaceId,
      uploadedBy: userId,
    };

    return this.processJob(job);
  }
}

export const ingestionService = new IngestionService();
