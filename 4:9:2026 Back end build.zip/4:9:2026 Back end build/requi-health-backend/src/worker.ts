/**
 * Background Worker
 * 
 * Processes background jobs including:
 * - Document ingestion
 * - Email notifications
 * - Report generation
 * - Data cleanup tasks
 */

import { prisma } from './config/database';
import { redis } from './config/redis';
import { logger } from './utils/logger';
import { ingestionService, IngestionJob } from './services/ingestionService';
import { notificationService } from './services/notificationService';
import { auditService } from './services/auditService';
import { billingService } from './services/billingService';

// Job types
enum JobType {
  INGESTION = 'INGESTION',
  NOTIFICATION = 'NOTIFICATION',
  AUDIT_CLEANUP = 'AUDIT_CLEANUP',
  NOTIFICATION_CLEANUP = 'NOTIFICATION_CLEANUP',
  USAGE_RESET = 'USAGE_RESET',
}

interface Job {
  type: JobType;
  data: any;
}

class Worker {
  private isRunning = false;
  private readonly QUEUE_KEY = 'worker:queue';
  private readonly PROCESSING_KEY = 'worker:processing';
  private readonly POLL_INTERVAL = 1000; // 1 second

  async start(): Promise<void> {
    logger.info('Worker starting...');
    this.isRunning = true;

    // Handle graceful shutdown
    process.on('SIGTERM', () => this.stop());
    process.on('SIGINT', () => this.stop());

    // Start processing loop
    while (this.isRunning) {
      try {
        await this.processNextJob();
      } catch (error) {
        logger.error('Error processing job', { error });
      }

      // Small delay to prevent tight loop
      await this.sleep(this.POLL_INTERVAL);
    }

    logger.info('Worker stopped');
  }

  stop(): void {
    logger.info('Worker stopping...');
    this.isRunning = false;
  }

  private async processNextJob(): Promise<void> {
    // Get job from queue
    const jobData = await redis.rpop(this.QUEUE_KEY);

    if (!jobData) {
      return;
    }

    const job: Job = JSON.parse(jobData);
    const jobId = `job-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

    logger.info(`Processing job ${jobId}`, { type: job.type });

    // Mark as processing
    await redis.hset(this.PROCESSING_KEY, jobId, JSON.stringify({
      type: job.type,
      startedAt: new Date().toISOString(),
    }));

    const startTime = Date.now();

    try {
      switch (job.type) {
        case JobType.INGESTION:
          await this.processIngestion(job.data);
          break;
        case JobType.NOTIFICATION:
          await this.processNotification(job.data);
          break;
        case JobType.AUDIT_CLEANUP:
          await this.processAuditCleanup();
          break;
        case JobType.NOTIFICATION_CLEANUP:
          await this.processNotificationCleanup();
          break;
        case JobType.USAGE_RESET:
          await this.processUsageReset();
          break;
        default:
          logger.warn(`Unknown job type: ${job.type}`);
      }

      logger.info(`Job ${jobId} completed`, {
        type: job.type,
        duration: Date.now() - startTime,
      });
    } catch (error) {
      logger.error(`Job ${jobId} failed`, {
        type: job.type,
        error,
        duration: Date.now() - startTime,
      });

      // Could implement retry logic here
    } finally {
      // Remove from processing
      await redis.hdel(this.PROCESSING_KEY, jobId);
    }
  }

  private async processIngestion(data: IngestionJob): Promise<void> {
    await ingestionService.processJob(data);
  }

  private async processNotification(data: {
    userId: string;
    type: string;
    title: string;
    message: string;
  }): Promise<void> {
    await notificationService.create({
      type: data.type as any,
      priority: 'MEDIUM',
      userId: data.userId,
      title: data.title,
      message: data.message,
    });
  }

  private async processAuditCleanup(): Promise<void> {
    const result = await auditService.cleanupOldLogs();
    logger.info('Audit cleanup completed', result);
  }

  private async processNotificationCleanup(): Promise<void> {
    const result = await notificationService.cleanup();
    logger.info('Notification cleanup completed', result);
  }

  private async processUsageReset(): Promise<void> {
    await billingService.resetMonthlyUsage();
    logger.info('Monthly usage reset completed');
  }

  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Scheduled tasks
class Scheduler {
  private intervals: NodeJS.Timeout[] = [];

  start(): void {
    // Daily cleanup at 2 AM
    this.scheduleDaily('02:00', async () => {
      await this.queueJob(JobType.AUDIT_CLEANUP, {});
      await this.queueJob(JobType.NOTIFICATION_CLEANUP, {});
    });

    // Monthly usage reset (1st of month at 3 AM)
    this.scheduleMonthly(1, '03:00', async () => {
      await this.queueJob(JobType.USAGE_RESET, {});
    });

    logger.info('Scheduler started');
  }

  stop(): void {
    this.intervals.forEach(clearInterval);
    logger.info('Scheduler stopped');
  }

  private scheduleDaily(time: string, task: () => Promise<void>): void {
    const [hours, minutes] = time.split(':').map(Number);

    const checkAndRun = async () => {
      const now = new Date();
      if (now.getHours() === hours && now.getMinutes() === minutes) {
        await task();
      }
    };

    // Check every minute
    const interval = setInterval(checkAndRun, 60 * 1000);
    this.intervals.push(interval);
  }

  private scheduleMonthly(day: number, time: string, task: () => Promise<void>): void {
    const [hours, minutes] = time.split(':').map(Number);

    const checkAndRun = async () => {
      const now = new Date();
      if (now.getDate() === day && now.getHours() === hours && now.getMinutes() === minutes) {
        await task();
      }
    };

    // Check every minute
    const interval = setInterval(checkAndRun, 60 * 1000);
    this.intervals.push(interval);
  }

  private async queueJob(type: JobType, data: any): Promise<void> {
    const job: Job = { type, data };
    await redis.lpush('worker:queue', JSON.stringify(job));
    logger.info(`Scheduled job queued: ${type}`);
  }
}

// Main
async function main() {
  const worker = new Worker();
  const scheduler = new Scheduler();

  scheduler.start();
  await worker.start();

  scheduler.stop();
}

main().catch(error => {
  logger.error('Worker failed', { error });
  process.exit(1);
});
