/**
 * Requi Health Backend - Enterprise Healthcare Compliance AI Platform
 * Main Application Entry Point
 */

import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import dotenv from 'dotenv';
import rateLimit from 'express-rate-limit';

import { errorHandler, notFoundHandler } from './middleware/errorHandler';
import { requestId, requestTiming, requestLogger, securityHeaders } from './middleware/requestLogger';
import authRoutes from './routes/auth';
import workspaceRoutes from './routes/workspaces';
import teamRoutes from './routes/teams';
import templateRoutes from './routes/templates';
import sourceRoutes from './routes/sources';
import conversationRoutes from './routes/conversations';
import adminRoutes from './routes/admin';
import billingRoutes from './routes/billing';
import healthRoutes from './routes/health';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// ============================================
// SECURITY MIDDLEWARE
// ============================================

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
}));

app.use(cors({
  origin: process.env.ALLOWED_ORIGINS?.split(',') || [
    'http://localhost:3000',
    'http://localhost:5173',
  ],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Request-ID', 'X-Workspace-ID'],
}));

app.use(securityHeaders);

// ============================================
// RATE LIMITING
// ============================================

// General rate limit
const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    error: {
      code: 'RATE_LIMIT',
      message: 'Too many requests, please try again later.',
    },
  },
});
app.use(generalLimiter);

// Stricter rate limit for AI endpoints
const aiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 20, // 20 AI requests per minute
  message: {
    success: false,
    error: {
      code: 'RATE_LIMIT',
      message: 'AI request limit exceeded. Please slow down.',
    },
  },
});

// Stricter rate limit for auth endpoints
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // 10 login attempts per 15 minutes
  skipSuccessfulRequests: true,
  message: {
    success: false,
    error: {
      code: 'RATE_LIMIT',
      message: 'Too many login attempts. Please try again later.',
    },
  },
});

// ============================================
// BODY PARSING
// ============================================

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ============================================
// REQUEST LOGGING
// ============================================

app.use(requestId);
app.use(requestTiming);
app.use(morgan('combined'));
app.use(requestLogger);

// ============================================
// ROUTES
// ============================================

// Health checks (no auth required)
app.use('/health', healthRoutes);

// Authentication
app.use('/api/auth', authLimiter, authRoutes);

// Protected routes
app.use('/api/workspaces', workspaceRoutes);
app.use('/api/workspaces/:workspaceId/teams', teamRoutes);
app.use('/api/templates', templateRoutes);
app.use('/api/sources', sourceRoutes);
app.use('/api/conversations', aiLimiter, conversationRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/billing', billingRoutes);

// ============================================
// ERROR HANDLING
// ============================================

// 404 handler
app.use(notFoundHandler);

// Global error handler
app.use(errorHandler);

// ============================================
// SERVER STARTUP
// ============================================

app.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║   🔷 Requi Health Backend                                        ║
║   Enterprise Healthcare Compliance AI Platform                   ║
║                                                                  ║
║   Server running on port ${PORT}                                ║
║   Environment: ${(process.env.NODE_ENV || 'development').padEnd(20)}                        ║
║                                                                  ║
║   API Endpoints:                                                 ║
║   • Health:      http://localhost:${PORT}/health                ║
║   • API:         http://localhost:${PORT}/api                   ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
  `);
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully...');
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, shutting down gracefully...');
  process.exit(0);
});

export default app;
