/**
 * Conversation Routes
 * 
 * AI chat conversations, message handling, and streaming responses.
 */

import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/database';
import { authenticateToken, requireWorkspaceAccess } from '../middleware/auth';
import { asyncHandler, ValidationError, NotFoundError, QuotaExceededError } from '../middleware/errorHandler';
import { claudeService } from '../services/claudeService';
import { billingService } from '../services/billingService';
import { auditService, AuditEventType } from '../services/auditService';
import { logger } from '../utils/logger';

const router = Router();

// Validation schemas
const createConversationSchema = z.object({
  workspaceId: z.string().uuid('Invalid workspace ID'),
  title: z.string().optional(),
  templateId: z.string().uuid('Invalid template ID').optional(),
});

const sendMessageSchema = z.object({
  content: z.string().min(1, 'Message content is required'),
  model: z.enum(['claude-3-opus', 'claude-3-sonnet', 'claude-3-haiku']).default('claude-3-sonnet'),
  useStreaming: z.boolean().default(false),
  templateVariables: z.record(z.any()).optional(),
});

/**
 * GET /api/conversations
 * List conversations for user in workspace
 */
router.get('/', authenticateToken, asyncHandler(async (req, res) => {
  const userId = req.user!.id;
  const workspaceId = req.query.workspaceId as string | undefined;

  const where: any = { userId };
  if (workspaceId) {
    where.workspaceId = workspaceId;
  }

  const conversations = await prisma.conversation.findMany({
    where,
    orderBy: { updatedAt: 'desc' },
    include: {
      workspace: {
        select: { id: true, name: true },
      },
      _count: {
        select: { messages: true },
      },
    },
  });

  res.json({
    success: true,
    data: { conversations },
  });
}));

/**
 * GET /api/conversations/:conversationId
 * Get conversation with messages
 */
router.get(
  '/:conversationId',
  authenticateToken,
  asyncHandler(async (req, res) => {
    const { conversationId } = req.params;
    const userId = req.user!.id;

    const conversation = await prisma.conversation.findFirst({
      where: {
        id: conversationId,
        userId,
      },
      include: {
        workspace: {
          select: { id: true, name: true },
        },
        messages: {
          orderBy: { createdAt: 'asc' },
          include: {
            citations: {
              include: {
                source: {
                  select: { id: true, title: true, authorityLayer: true },
                },
              },
            },
          },
        },
      },
    });

    if (!conversation) {
      throw new NotFoundError('Conversation', conversationId);
    }

    res.json({
      success: true,
      data: { conversation },
    });
  })
);

/**
 * POST /api/conversations
 * Create a new conversation
 */
router.post('/', authenticateToken, asyncHandler(async (req, res) => {
  const data = createConversationSchema.parse(req.body);
  const userId = req.user!.id;

  // Verify workspace access
  const membership = await prisma.workspaceMember.findFirst({
    where: {
      workspaceId: data.workspaceId,
      userId,
    },
  });

  if (!membership && req.user!.role !== 'SUPER_ADMIN') {
    throw new ValidationError('You do not have access to this workspace');
  }

  const conversation = await prisma.conversation.create({
    data: {
      title: data.title || 'New Conversation',
      userId,
      workspaceId: data.workspaceId,
      templateId: data.templateId,
    },
    include: {
      workspace: {
        select: { id: true, name: true },
      },
    },
  });

  await auditService.log({
    eventType: AuditEventType.CONVERSATION_CREATED,
    severity: 'INFO',
    userId,
    workspaceId: data.workspaceId,
    conversationId: conversation.id,
    description: 'Conversation created',
  });

  res.status(201).json({
    success: true,
    data: { conversation },
  });
}));

/**
 * POST /api/conversations/:conversationId/messages
 * Send a message and get AI response
 */
router.post(
  '/:conversationId/messages',
  authenticateToken,
  asyncHandler(async (req, res) => {
    const { conversationId } = req.params;
    const data = sendMessageSchema.parse(req.body);
    const userId = req.user!.id;

    // Get conversation
    const conversation = await prisma.conversation.findFirst({
      where: {
        id: conversationId,
        userId,
      },
      include: {
        workspace: {
          include: { organization: true },
        },
        template: true,
      },
    });

    if (!conversation) {
      throw new NotFoundError('Conversation', conversationId);
    }

    const organizationId = conversation.workspace.organizationId;

    // Check quota
    const quota = await billingService.checkQuota(organizationId);
    if (!quota.allowed) {
      throw new QuotaExceededError();
    }

    // Create user message
    const userMessage = await prisma.message.create({
      data: {
        conversationId,
        role: 'USER',
        content: data.content,
      },
    });

    // Get conversation history for context
    const history = await prisma.message.findMany({
      where: { conversationId },
      orderBy: { createdAt: 'asc' },
      take: 20, // Last 20 messages for context
      select: { role: true, content: true },
    });

    try {
      // Process with Claude
      const aiResponse = await claudeService.processQuery({
        query: data.content,
        workspaceId: conversation.workspaceId,
        userId,
        conversationId,
        history: history.map(m => ({ role: m.role.toLowerCase() as any, content: m.content })),
        model: data.model,
        useStreaming: data.useStreaming,
        templateId: conversation.templateId || undefined,
        templateVariables: data.templateVariables,
      });

      // Create assistant message
      const assistantMessage = await prisma.message.create({
        data: {
          conversationId,
          role: 'ASSISTANT',
          content: aiResponse.response,
          model: data.model,
          tokenCount: aiResponse.tokenCount,
          costCents: aiResponse.costCents,
          latencyMs: aiResponse.latencyMs,
          confidenceLevel: aiResponse.confidenceLevel,
        },
      });

      // Create citations
      if (aiResponse.citations.length > 0) {
        await prisma.citation.createMany({
          data: aiResponse.citations.map(c => ({
            messageId: assistantMessage.id,
            sourceId: c.sourceId,
            chunkId: c.chunkId,
            relevanceScore: c.relevanceScore,
            excerpt: c.excerpt,
          })),
        });
      }

      // Record usage for billing
      await billingService.recordUsage({
        organizationId,
        userId,
        conversationId,
        tokenCount: aiResponse.tokenCount,
        costCents: aiResponse.costCents,
      });

      // Update conversation timestamp
      await prisma.conversation.update({
        where: { id: conversationId },
        data: { updatedAt: new Date() },
      });

      // Log AI interaction
      await auditService.logAIInteraction(
        userId,
        organizationId,
        conversation.workspaceId,
        conversationId,
        AuditEventType.AI_RESPONSE_GENERATED,
        {
          queryLength: data.content.length,
          responseLength: aiResponse.response.length,
          tokenCount: aiResponse.tokenCount,
          costCents: aiResponse.costCents,
          latencyMs: aiResponse.latencyMs,
          confidenceLevel: aiResponse.confidenceLevel,
          sourcesCited: aiResponse.citations.length,
          missingKnowledge: aiResponse.missingKnowledge.isMissingKnowledge,
        }
      );

      res.json({
        success: true,
        data: {
          userMessage,
          assistantMessage: {
            ...assistantMessage,
            citations: aiResponse.citations,
          },
          usage: {
            tokens: aiResponse.tokenCount,
            cost: aiResponse.costCents / 100,
            latency: aiResponse.latencyMs,
          },
        },
      });
    } catch (error) {
      logger.error('AI response generation failed', { error, conversationId });

      // Log failure
      await auditService.logAIInteraction(
        userId,
        organizationId,
        conversation.workspaceId,
        conversationId,
        AuditEventType.AI_RESPONSE_FAILED,
        {
          queryLength: data.content.length,
          tokenCount: 0,
          costCents: 0,
          latencyMs: 0,
        }
      );

      throw error;
    }
  })
);

/**
 * DELETE /api/conversations/:conversationId
 * Delete a conversation
 */
router.delete(
  '/:conversationId',
  authenticateToken,
  asyncHandler(async (req, res) => {
    const { conversationId } = req.params;
    const userId = req.user!.id;

    const conversation = await prisma.conversation.findFirst({
      where: {
        id: conversationId,
        userId,
      },
    });

    if (!conversation) {
      throw new NotFoundError('Conversation', conversationId);
    }

    await prisma.conversation.delete({
      where: { id: conversationId },
    });

    await auditService.log({
      eventType: AuditEventType.CONVERSATION_DELETED,
      severity: 'INFO',
      userId,
      workspaceId: conversation.workspaceId,
      conversationId,
      description: 'Conversation deleted',
    });

    res.json({
      success: true,
      message: 'Conversation deleted successfully',
    });
  })
);

/**
 * GET /api/conversations/:conversationId/export
 * Export conversation
 */
router.get(
  '/:conversationId/export',
  authenticateToken,
  asyncHandler(async (req, res) => {
    const { conversationId } = req.params;
    const userId = req.user!.id;
    const format = (req.query.format as string) || 'json';

    const conversation = await prisma.conversation.findFirst({
      where: {
        id: conversationId,
        userId,
      },
      include: {
        messages: {
          orderBy: { createdAt: 'asc' },
          include: {
            citations: {
              include: {
                source: {
                  select: { title: true, authorityLayer: true },
                },
              },
            },
          },
        },
        workspace: {
          select: { name: true },
        },
      },
    });

    if (!conversation) {
      throw new NotFoundError('Conversation', conversationId);
    }

    if (format === 'markdown') {
      let markdown = `# ${conversation.title}\n\n`;
      markdown += `**Workspace:** ${conversation.workspace.name}\n`;
      markdown += `**Created:** ${conversation.createdAt.toISOString()}\n\n`;
      markdown += `---\n\n`;

      for (const message of conversation.messages) {
        const role = message.role === 'USER' ? '**User**' : '**Assistant**';
        markdown += `${role}\n\n${message.content}\n\n`;

        if (message.citations.length > 0) {
          markdown += `*Sources cited:*\n`;
          for (const citation of message.citations) {
            markdown += `- ${citation.source.title} (${citation.source.authorityLayer})\n`;
          }
          markdown += `\n`;
        }

        markdown += `---\n\n`;
      }

      res.setHeader('Content-Type', 'text/markdown');
      res.setHeader('Content-Disposition', `attachment; filename="${conversation.title}.md"`);
      res.send(markdown);
      return;
    }

    // Default JSON export
    res.json({
      success: true,
      data: { conversation },
    });
  })
);

export default router;
