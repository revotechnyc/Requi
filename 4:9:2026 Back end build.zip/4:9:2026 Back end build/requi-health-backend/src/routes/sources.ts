/**
 * Sources Routes
 * 
 * Document source management, upload, and metadata handling.
 */

import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/database';
import { authenticateToken, requireWorkspaceAccess } from '../middleware/auth';
import { asyncHandler, ValidationError, NotFoundError } from '../middleware/errorHandler';
import { ingestionService } from '../services/ingestionService';
import { auditService, AuditEventType } from '../services/auditService';
import { AuthorityLayer, BindingLevel, ProgramType } from '@prisma/client';

const router = Router();

// Validation schemas
const createSourceSchema = z.object({
  workspaceId: z.string().uuid('Invalid workspace ID'),
  title: z.string().min(1, 'Title is required'),
  description: z.string().optional(),
  authorityLayer: z.nativeEnum(AuthorityLayer),
  bindingLevel: z.nativeEnum(BindingLevel).optional(),
  programTypes: z.array(z.nativeEnum(ProgramType)).optional(),
  jurisdictions: z.array(z.string()).optional(),
  effectiveDate: z.string().datetime().optional(),
  expirationDate: z.string().datetime().optional(),
  citation: z.string().optional(),
  url: z.string().url().optional(),
  metadata: z.record(z.any()).optional(),
});

const updateSourceSchema = z.object({
  title: z.string().min(1).optional(),
  description: z.string().optional(),
  authorityLayer: z.nativeEnum(AuthorityLayer).optional(),
  bindingLevel: z.nativeEnum(BindingLevel).optional(),
  programTypes: z.array(z.nativeEnum(ProgramType)).optional(),
  jurisdictions: z.array(z.string()).optional(),
  effectiveDate: z.string().datetime().optional(),
  expirationDate: z.string().datetime().optional(),
  citation: z.string().optional(),
  url: z.string().url().optional(),
  metadata: z.record(z.any()).optional(),
});

/**
 * GET /api/sources
 * List sources with filters
 */
router.get('/', authenticateToken, asyncHandler(async (req, res) => {
  const userId = req.user!.id;
  const {
    workspaceId,
    authorityLayer,
    programType,
    jurisdiction,
    status,
    search,
    limit = '20',
    offset = '0',
  } = req.query;

  const where: any = {};

  if (workspaceId) {
    where.workspaceId = workspaceId;
  }

  if (authorityLayer) {
    where.authorityLayer = authorityLayer;
  }

  if (programType) {
    where.programTypes = { has: programType };
  }

  if (jurisdiction) {
    where.jurisdictions = { has: jurisdiction };
  }

  if (status) {
    where.status = status;
  }

  if (search) {
    where.OR = [
      { title: { contains: search as string, mode: 'insensitive' } },
      { description: { contains: search as string, mode: 'insensitive' } },
      { citation: { contains: search as string, mode: 'insensitive' } },
    ];
  }

  // If not super admin, only show sources from accessible workspaces
  if (req.user!.role !== 'SUPER_ADMIN') {
    const accessibleWorkspaces = await prisma.workspaceMember.findMany({
      where: { userId },
      select: { workspaceId: true },
    });

    const workspaceIds = accessibleWorkspaces.map(w => w.workspaceId);

    if (workspaceId && !workspaceIds.includes(workspaceId as string)) {
      throw new ValidationError('You do not have access to this workspace');
    }

    if (!workspaceId) {
      where.workspaceId = { in: workspaceIds };
    }
  }

  const [sources, total] = await Promise.all([
    prisma.source.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: parseInt(limit as string),
      skip: parseInt(offset as string),
      include: {
        workspace: {
          select: { id: true, name: true },
        },
        uploadedBy: {
          select: { id: true, email: true, firstName: true, lastName: true },
        },
        _count: {
          select: { chunks: true },
        },
      },
    }),
    prisma.source.count({ where }),
  ]);

  res.json({
    success: true,
    data: { sources, total },
  });
}));

/**
 * GET /api/sources/:sourceId
 * Get source details
 */
router.get(
  '/:sourceId',
  authenticateToken,
  asyncHandler(async (req, res) => {
    const { sourceId } = req.params;

    const source = await prisma.source.findUnique({
      where: { id: sourceId },
      include: {
        workspace: {
          select: { id: true, name: true },
        },
        uploadedBy: {
          select: { id: true, email: true, firstName: true, lastName: true },
        },
        chunks: {
          select: {
            id: true,
            chunkIndex: true,
            content: true,
            createdAt: true,
          },
          orderBy: { chunkIndex: 'asc' },
        },
        _count: {
          select: { citations: true },
        },
      },
    });

    if (!source) {
      throw new NotFoundError('Source', sourceId);
    }

    res.json({
      success: true,
      data: { source },
    });
  })
);

/**
 * POST /api/sources
 * Create a new source (metadata only, file uploaded separately)
 */
router.post('/', authenticateToken, asyncHandler(async (req, res) => {
  const data = createSourceSchema.parse(req.body);
  const userId = req.user!.id;

  // Verify workspace access
  const membership = await prisma.workspaceMember.findFirst({
    where: {
      workspaceId: data.workspaceId,
      userId,
    },
  });

  if (!membership && req.user!.role !== 'SUPER_ADMIN') {
    throw new ValidationError('You do not have access to this workspace');
  }

  // Check source limit
  const sourceCount = await prisma.source.count({
    where: { workspaceId: data.workspaceId },
  });

  const workspace = await prisma.workspace.findUnique({
    where: { id: data.workspaceId },
    include: { organization: true },
  });

  const subscription = await prisma.subscription.findUnique({
    where: { organizationId: workspace!.organizationId },
  });

  const planLimits: Record<string, number> = {
    FREE: 10,
    BASIC: 50,
    PROFESSIONAL: 200,
    ENTERPRISE: -1,
  };

  const limit = planLimits[subscription?.planType || 'FREE'];
  if (limit !== -1 && sourceCount >= limit) {
    throw new ValidationError(`Source limit reached for your plan (${limit})`);
  }

  const source = await prisma.source.create({
    data: {
      title: data.title,
      description: data.description,
      workspaceId: data.workspaceId,
      uploadedById: userId,
      authorityLayer: data.authorityLayer,
      bindingLevel: data.bindingLevel,
      programTypes: data.programTypes || [],
      jurisdictions: data.jurisdictions || [],
      effectiveDate: data.effectiveDate ? new Date(data.effectiveDate) : null,
      expirationDate: data.expirationDate ? new Date(data.expirationDate) : null,
      citation: data.citation,
      url: data.url,
      metadata: data.metadata || {},
      status: 'PENDING',
    },
    include: {
      workspace: {
        select: { id: true, name: true },
      },
    },
  });

  await auditService.log({
    eventType: AuditEventType.SOURCE_UPLOADED,
    severity: 'INFO',
    userId,
    workspaceId: data.workspaceId,
    sourceId: source.id,
    description: `Source created: ${data.title}`,
  });

  res.status(201).json({
    success: true,
    data: { source },
  });
}));

/**
 * POST /api/sources/:sourceId/upload
 * Upload file for source
 */
router.post(
  '/:sourceId/upload',
  authenticateToken,
  requireWorkspaceAccess(),
  asyncHandler(async (req, res) => {
    const { sourceId } = req.params;
    const userId = req.user!.id;

    const source = await prisma.source.findUnique({
      where: { id: sourceId },
    });

    if (!source) {
      throw new NotFoundError('Source', sourceId);
    }

    // In production, this would handle multipart file upload
    // For now, we'll simulate with metadata from request
    const { fileName, fileSize, fileType, mimeType } = req.body;

    // Validate file
    const validation = await ingestionService.validateFile(fileName, fileSize, mimeType);
    if (!validation.valid) {
      throw new ValidationError(validation.error!);
    }

    // Update source with file info
    await prisma.source.update({
      where: { id: sourceId },
      data: {
        fileName,
        fileType,
        fileSize,
        filePath: `/uploads/${sourceId}/${fileName}`,
      },
    });

    // Queue ingestion job
    const job = {
      id: `job-${Date.now()}`,
      sourceId,
      filePath: `/uploads/${sourceId}/${fileName}`,
      fileType,
      organizationId: source.workspaceId, // Will be resolved from workspace
      workspaceId: source.workspaceId,
      uploadedBy: userId,
    };

    // Get organization from workspace
    const workspace = await prisma.workspace.findUnique({
      where: { id: source.workspaceId },
      select: { organizationId: true },
    });

    job.organizationId = workspace!.organizationId;

    await ingestionService.queueJob(job);

    res.json({
      success: true,
      message: 'File uploaded and queued for processing',
      data: {
        sourceId,
        jobId: job.id,
        status: 'PROCESSING',
      },
    });
  })
);

/**
 * PATCH /api/sources/:sourceId
 * Update source metadata
 */
router.patch(
  '/:sourceId',
  authenticateToken,
  requireWorkspaceAccess(),
  asyncHandler(async (req, res) => {
    const { sourceId } = req.params;
    const data = updateSourceSchema.parse(req.body);
    const userId = req.user!.id;

    const source = await prisma.source.findUnique({
      where: { id: sourceId },
    });

    if (!source) {
      throw new NotFoundError('Source', sourceId);
    }

    const updatedSource = await prisma.source.update({
      where: { id: sourceId },
      data: {
        ...data,
        effectiveDate: data.effectiveDate ? new Date(data.effectiveDate) : undefined,
        expirationDate: data.expirationDate ? new Date(data.expirationDate) : undefined,
        updatedAt: new Date(),
      },
      include: {
        workspace: {
          select: { id: true, name: true },
        },
      },
    });

    await auditService.log({
      eventType: AuditEventType.SOURCE_UPDATED,
      severity: 'INFO',
      userId,
      workspaceId: source.workspaceId,
      sourceId,
      description: `Source updated: ${data.title || source.title}`,
    });

    res.json({
      success: true,
      data: { source: updatedSource },
    });
  })
);

/**
 * DELETE /api/sources/:sourceId
 * Delete source
 */
router.delete(
  '/:sourceId',
  authenticateToken,
  requireWorkspaceAccess(),
  asyncHandler(async (req, res) => {
    const { sourceId } = req.params;
    const userId = req.user!.id;

    const source = await prisma.source.findUnique({
      where: { id: sourceId },
    });

    if (!source) {
      throw new NotFoundError('Source', sourceId);
    }

    await prisma.source.delete({
      where: { id: sourceId },
    });

    await auditService.log({
      eventType: AuditEventType.SOURCE_DELETED,
      severity: 'INFO',
      userId,
      workspaceId: source.workspaceId,
      sourceId,
      description: `Source deleted: ${source.title}`,
    });

    res.json({
      success: true,
      message: 'Source deleted successfully',
    });
  })
);

/**
 * POST /api/sources/:sourceId/reprocess
 * Reprocess source document
 */
router.post(
  '/:sourceId/reprocess',
  authenticateToken,
  requireWorkspaceAccess(),
  asyncHandler(async (req, res) => {
    const { sourceId } = req.params;
    const userId = req.user!.id;

    const result = await ingestionService.reprocessSource(sourceId, userId);

    res.json({
      success: result.success,
      data: {
        sourceId,
        chunksCreated: result.chunksCreated,
      },
      ...(result.error && { error: result.error }),
    });
  })
);

/**
 * GET /api/sources/stats/overview
 * Get source statistics
 */
router.get('/stats/overview', authenticateToken, asyncHandler(async (req, res) => {
  const userId = req.user!.id;
  const { workspaceId } = req.query;

  let organizationId: string | undefined;

  if (workspaceId) {
    const workspace = await prisma.workspace.findUnique({
      where: { id: workspaceId as string },
      select: { organizationId: true },
    });
    organizationId = workspace?.organizationId;
  } else if (req.user!.organizationId) {
    organizationId = req.user!.organizationId;
  }

  const stats = await ingestionService.getStats(organizationId);

  res.json({
    success: true,
    data: { stats },
  });
}));

export default router;
