/**
 * Authentication Routes
 * 
 * User registration, login, logout, password reset, and token management.
 */

import { Router } from 'express';
import bcrypt from 'bcrypt';
import { z } from 'zod';
import { prisma } from '../config/database';
import { redis } from '../config/redis';
import { 
  authenticateToken, 
  generateToken, 
  generateRefreshToken,
  optionalAuth 
} from '../middleware/auth';
import { 
  asyncHandler, 
  ValidationError, 
  AuthenticationError,
  ConflictError 
} from '../middleware/errorHandler';
import { auditService, AuditEventType } from '../services/auditService';
import { notificationService } from '../services/notificationService';
import { logger } from '../utils/logger';

const router = Router();

// Validation schemas
const registerSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  firstName: z.string().min(1, 'First name is required'),
  lastName: z.string().min(1, 'Last name is required'),
  organizationName: z.string().optional(),
});

const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(1, 'Password is required'),
});

const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, 'Current password is required'),
  newPassword: z.string().min(8, 'New password must be at least 8 characters'),
});

/**
 * POST /api/auth/register
 * Register a new user
 */
router.post('/register', asyncHandler(async (req, res) => {
  const data = registerSchema.parse(req.body);

  // Check if email already exists
  const existingUser = await prisma.user.findUnique({
    where: { email: data.email },
  });

  if (existingUser) {
    throw new ConflictError('An account with this email already exists');
  }

  // Hash password
  const hashedPassword = await bcrypt.hash(data.password, 12);

  // Create user (and organization if provided)
  const user = await prisma.$transaction(async (tx) => {
    let organizationId: string | undefined;

    // Create organization if name provided
    if (data.organizationName) {
      const org = await tx.organization.create({
        data: {
          name: data.organizationName,
          slug: data.organizationName.toLowerCase().replace(/\s+/g, '-'),
        },
      });
      organizationId = org.id;

      // Create default subscription (Free plan)
      await tx.subscription.create({
        data: {
          organizationId: org.id,
          planType: 'FREE',
          status: 'ACTIVE',
          billingEmail: data.email,
          currentPeriodStart: new Date(),
          currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
          tokenQuota: 10000,
          tokenUsed: 0,
        },
      });
    }

    // Create user
    const newUser = await tx.user.create({
      data: {
        email: data.email,
        password: hashedPassword,
        firstName: data.firstName,
        lastName: data.lastName,
        organizationId,
        role: organizationId ? 'OWNER' : 'USER',
        status: 'ACTIVE',
      },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        organizationId: true,
      },
    });

    // Add user as organization member if applicable
    if (organizationId) {
      await tx.organizationMember.create({
        data: {
          organizationId,
          userId: newUser.id,
          role: 'OWNER',
        },
      });
    }

    return newUser;
  });

  // Generate tokens
  const token = generateToken({
    userId: user.id,
    email: user.email,
    role: user.role,
    organizationId: user.organizationId || undefined,
  });

  const refreshToken = generateRefreshToken(user.id);

  // Log audit event
  await auditService.log({
    eventType: AuditEventType.USER_REGISTERED,
    severity: 'INFO',
    userId: user.id,
    organizationId: user.organizationId || undefined,
    ipAddress: req.ip,
    userAgent: req.headers['user-agent'],
    description: 'User registered',
  });

  res.status(201).json({
    success: true,
    data: {
      user,
      token,
      refreshToken,
    },
  });
}));

/**
 * POST /api/auth/login
 * Login user
 */
router.post('/login', asyncHandler(async (req, res) => {
  const data = loginSchema.parse(req.body);

  // Find user
  const user = await prisma.user.findUnique({
    where: { email: data.email },
  });

  if (!user) {
    await auditService.logAuth(
      AuditEventType.USER_LOGIN_FAILED,
      undefined,
      req.ip || 'unknown',
      req.headers['user-agent'] || 'unknown',
      { reason: 'User not found', email: data.email }
    );
    throw new AuthenticationError('Invalid email or password');
  }

  // Check if user is active
  if (user.status !== 'ACTIVE') {
    await auditService.logAuth(
      AuditEventType.USER_LOGIN_FAILED,
      user.id,
      req.ip || 'unknown',
      req.headers['user-agent'] || 'unknown',
      { reason: 'Account not active', status: user.status }
    );
    throw new AuthenticationError('Account is not active');
  }

  // Verify password
  const isValidPassword = await bcrypt.compare(data.password, user.password);

  if (!isValidPassword) {
    await auditService.logAuth(
      AuditEventType.USER_LOGIN_FAILED,
      user.id,
      req.ip || 'unknown',
      req.headers['user-agent'] || 'unknown',
      { reason: 'Invalid password' }
    );
    throw new AuthenticationError('Invalid email or password');
  }

  // Update last login
  await prisma.user.update({
    where: { id: user.id },
    data: { lastLoginAt: new Date() },
  });

  // Generate tokens
  const token = generateToken({
    userId: user.id,
    email: user.email,
    role: user.role,
    organizationId: user.organizationId || undefined,
  });

  const refreshToken = generateRefreshToken(user.id);

  // Log successful login
  await auditService.logAuth(
    AuditEventType.USER_LOGIN,
    user.id,
    req.ip || 'unknown',
    req.headers['user-agent'] || 'unknown'
  );

  res.json({
    success: true,
    data: {
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        organizationId: user.organizationId,
      },
      token,
      refreshToken,
    },
  });
}));

/**
 * POST /api/auth/logout
 * Logout user
 */
router.post('/logout', authenticateToken, asyncHandler(async (req, res) => {
  // In a stateless JWT setup, we can't truly invalidate the token
  // But we can add it to a blacklist or just let it expire
  // For now, we'll just log the logout event

  await auditService.logAuth(
    AuditEventType.USER_LOGOUT,
    req.user!.id,
    req.ip || 'unknown',
    req.headers['user-agent'] || 'unknown'
  );

  res.json({
    success: true,
    message: 'Logged out successfully',
  });
}));

/**
 * POST /api/auth/refresh
 * Refresh access token
 */
router.post('/refresh', asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;

  if (!refreshToken) {
    throw new ValidationError('Refresh token is required');
  }

  // Verify refresh token
  try {
    const jwt = require('jsonwebtoken');
    const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
    
    const decoded = jwt.verify(refreshToken, JWT_SECRET) as {
      userId: string;
      type: string;
    };

    if (decoded.type !== 'refresh') {
      throw new AuthenticationError('Invalid refresh token');
    }

    // Get user
    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      select: {
        id: true,
        email: true,
        role: true,
        organizationId: true,
        status: true,
      },
    });

    if (!user || user.status !== 'ACTIVE') {
      throw new AuthenticationError('User not found or inactive');
    }

    // Generate new tokens
    const newToken = generateToken({
      userId: user.id,
      email: user.email,
      role: user.role,
      organizationId: user.organizationId || undefined,
    });

    const newRefreshToken = generateRefreshToken(user.id);

    await auditService.log({
      eventType: AuditEventType.TOKEN_REFRESHED,
      severity: 'INFO',
      userId: user.id,
      description: 'Token refreshed',
    });

    res.json({
      success: true,
      data: {
        token: newToken,
        refreshToken: newRefreshToken,
      },
    });
  } catch (error) {
    throw new AuthenticationError('Invalid or expired refresh token');
  }
}));

/**
 * POST /api/auth/change-password
 * Change user password
 */
router.post('/change-password', authenticateToken, asyncHandler(async (req, res) => {
  const data = changePasswordSchema.parse(req.body);
  const userId = req.user!.id;

  // Get current user with password
  const user = await prisma.user.findUnique({
    where: { id: userId },
  });

  if (!user) {
    throw new AuthenticationError('User not found');
  }

  // Verify current password
  const isValidPassword = await bcrypt.compare(data.currentPassword, user.password);

  if (!isValidPassword) {
    throw new ValidationError('Current password is incorrect');
  }

  // Hash new password
  const hashedPassword = await bcrypt.hash(data.newPassword, 12);

  // Update password
  await prisma.user.update({
    where: { id: userId },
    data: {
      password: hashedPassword,
      passwordChangedAt: new Date(),
    },
  });

  await auditService.log({
    eventType: AuditEventType.PASSWORD_CHANGED,
    severity: 'INFO',
    userId,
    description: 'Password changed',
  });

  res.json({
    success: true,
    message: 'Password changed successfully',
  });
}));

/**
 * GET /api/auth/me
 * Get current user
 */
router.get('/me', authenticateToken, asyncHandler(async (req, res) => {
  const user = await prisma.user.findUnique({
    where: { id: req.user!.id },
    select: {
      id: true,
      email: true,
      firstName: true,
      lastName: true,
      role: true,
      status: true,
      organizationId: true,
      lastLoginAt: true,
      createdAt: true,
      organization: {
        select: {
          id: true,
          name: true,
          slug: true,
        },
      },
    },
  });

  if (!user) {
    throw new AuthenticationError('User not found');
  }

  res.json({
    success: true,
    data: { user },
  });
}));

export default router;
