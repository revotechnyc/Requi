/**
 * Template Routes
 * 
 * Prompt template management and rendering.
 */

import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/database';
import { authenticateToken } from '../middleware/auth';
import { asyncHandler, ValidationError, NotFoundError } from '../middleware/errorHandler';
import { templateService, TemplateCategory, CreateTemplateInput } from '../services/templateService';
import { AuthorityLayer, ProgramType } from '@prisma/client';

const router = Router();

// Validation schemas
const createTemplateSchema = z.object({
  name: z.string().min(1, 'Template name is required'),
  description: z.string().optional(),
  category: z.nativeEnum(TemplateCategory),
  content: z.string().min(1, 'Template content is required'),
  variables: z.array(z.object({
    name: z.string(),
    type: z.enum(['string', 'number', 'boolean', 'date', 'select', 'multiselect']),
    label: z.string(),
    description: z.string().optional(),
    required: z.boolean(),
    defaultValue: z.any().optional(),
    options: z.array(z.string()).optional(),
  })).default([]),
  systemPrompt: z.string().optional(),
  authorityLayers: z.array(z.nativeEnum(AuthorityLayer)).optional(),
  programTypes: z.array(z.nativeEnum(ProgramType)).optional(),
  jurisdictions: z.array(z.string()).optional(),
  isPublic: z.boolean().default(false),
  organizationId: z.string().uuid().optional(),
});

const renderTemplateSchema = z.object({
  variables: z.record(z.any()),
});

/**
 * GET /api/templates
 * List templates
 */
router.get('/', authenticateToken, asyncHandler(async (req, res) => {
  const {
    category,
    isPublic,
    search,
    limit = '20',
    offset = '0',
  } = req.query;

  const filters: any = {};

  if (category) filters.category = category as TemplateCategory;
  if (isPublic !== undefined) filters.isPublic = isPublic === 'true';
  if (search) filters.search = search as string;
  if (req.user!.organizationId) filters.organizationId = req.user!.organizationId;

  filters.limit = parseInt(limit as string);
  filters.offset = parseInt(offset as string);

  const result = await templateService.list(filters);

  res.json({
    success: true,
    data: result,
  });
}));

/**
 * GET /api/templates/popular
 * Get popular templates
 */
router.get('/popular', asyncHandler(async (req, res) => {
  const limit = parseInt(req.query.limit as string) || 10;
  const templates = await templateService.getPopular(limit);

  res.json({
    success: true,
    data: { templates },
  });
}));

/**
 * GET /api/templates/categories
 * Get template categories
 */
router.get('/categories', (_req, res) => {
  res.json({
    success: true,
    data: {
      categories: Object.values(TemplateCategory),
    },
  });
});

/**
 * GET /api/templates/:templateId
 * Get template details
 */
router.get(
  '/:templateId',
  authenticateToken,
  asyncHandler(async (req, res) => {
    const { templateId } = req.params;

    const template = await templateService.getById(templateId);

    if (!template) {
      throw new NotFoundError('Template', templateId);
    }

    res.json({
      success: true,
      data: { template },
    });
  })
);

/**
 * POST /api/templates
 * Create a new template
 */
router.post('/', authenticateToken, asyncHandler(async (req, res) => {
  const data = createTemplateSchema.parse(req.body);

  // If organizationId provided, verify membership
  if (data.organizationId) {
    const membership = await prisma.organizationMember.findFirst({
      where: {
        organizationId: data.organizationId,
        userId: req.user!.id,
      },
    });

    if (!membership && req.user!.role !== 'SUPER_ADMIN') {
      throw new ValidationError('You do not have access to this organization');
    }
  }

  const input: CreateTemplateInput = {
    name: data.name,
    description: data.description,
    category: data.category,
    content: data.content,
    variables: data.variables,
    systemPrompt: data.systemPrompt,
    authorityLayers: data.authorityLayers,
    programTypes: data.programTypes,
    jurisdictions: data.jurisdictions,
    isPublic: data.isPublic,
    organizationId: data.organizationId,
    createdBy: req.user!.id,
  };

  const templateId = await templateService.create(input);

  res.status(201).json({
    success: true,
    data: { templateId },
  });
}));

/**
 * PATCH /api/templates/:templateId
 * Update template
 */
router.patch(
  '/:templateId',
  authenticateToken,
  asyncHandler(async (req, res) => {
    const { templateId } = req.params;
    const data = createTemplateSchema.partial().parse(req.body);

    await templateService.update(templateId, data, req.user!.id);

    res.json({
      success: true,
      message: 'Template updated successfully',
    });
  })
);

/**
 * DELETE /api/templates/:templateId
 * Delete template
 */
router.delete(
  '/:templateId',
  authenticateToken,
  asyncHandler(async (req, res) => {
    const { templateId } = req.params;

    await templateService.delete(templateId, req.user!.id);

    res.json({
      success: true,
      message: 'Template deleted successfully',
    });
  })
);

/**
 * POST /api/templates/:templateId/render
 * Render template with variables
 */
router.post(
  '/:templateId/render',
  authenticateToken,
  asyncHandler(async (req, res) => {
    const { templateId } = req.params;
    const data = renderTemplateSchema.parse(req.body);

    const rendered = await templateService.render({
      templateId,
      variables: data.variables,
      userId: req.user!.id,
      workspaceId: req.body.workspaceId,
    });

    res.json({
      success: true,
      data: { rendered },
    });
  })
);

/**
 * POST /api/templates/:templateId/clone
 * Clone a template
 */
router.post(
  '/:templateId/clone',
  authenticateToken,
  asyncHandler(async (req, res) => {
    const { templateId } = req.params;
    const { name, organizationId } = req.body;

    if (!name) {
      throw new ValidationError('New template name is required');
    }

    if (!organizationId && !req.user!.organizationId) {
      throw new ValidationError('Organization ID is required');
    }

    const newTemplateId = await templateService.clone(
      templateId,
      name,
      organizationId || req.user!.organizationId!,
      req.user!.id
    );

    res.status(201).json({
      success: true,
      data: { templateId: newTemplateId },
    });
  })
);

export default router;
