/**
 * Workspace Routes
 * 
 * Workspace CRUD, member management, and access control.
 */

import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/database';
import { authenticateToken, requireWorkspaceAccess, requireOrganizationAccess } from '../middleware/auth';
import { asyncHandler, ValidationError, NotFoundError, AuthorizationError } from '../middleware/errorHandler';
import { auditService, AuditEventType } from '../services/auditService';
import { notificationService } from '../services/notificationService';

const router = Router();

// Validation schemas
const createWorkspaceSchema = z.object({
  name: z.string().min(1, 'Workspace name is required'),
  description: z.string().optional(),
  organizationId: z.string().uuid('Invalid organization ID'),
  jurisdictions: z.array(z.string()).optional(),
  programTypes: z.array(z.string()).optional(),
});

const updateWorkspaceSchema = z.object({
  name: z.string().min(1).optional(),
  description: z.string().optional(),
  jurisdictions: z.array(z.string()).optional(),
  programTypes: z.array(z.string()).optional(),
});

const inviteMemberSchema = z.object({
  email: z.string().email('Invalid email address'),
  role: z.enum(['MEMBER', 'ADMIN']).default('MEMBER'),
});

/**
 * GET /api/workspaces
 * List workspaces for current user
 */
router.get('/', authenticateToken, asyncHandler(async (req, res) => {
  const userId = req.user!.id;
  const organizationId = req.query.organizationId as string | undefined;

  const where: any = {
    OR: [
      { createdBy: userId },
      {
        members: {
          some: { userId },
        },
      },
    ],
  };

  if (organizationId) {
    where.organizationId = organizationId;
  }

  const workspaces = await prisma.workspace.findMany({
    where,
    include: {
      organization: {
        select: { id: true, name: true },
      },
      _count: {
        select: { members: true, sources: true },
      },
    },
    orderBy: { updatedAt: 'desc' },
  });

  res.json({
    success: true,
    data: { workspaces },
  });
}));

/**
 * GET /api/workspaces/:workspaceId
 * Get workspace details
 */
router.get(
  '/:workspaceId',
  authenticateToken,
  requireWorkspaceAccess(),
  asyncHandler(async (req, res) => {
    const { workspaceId } = req.params;

    const workspace = await prisma.workspace.findUnique({
      where: { id: workspaceId },
      include: {
        organization: {
          select: { id: true, name: true, slug: true },
        },
        members: {
          include: {
            user: {
              select: { id: true, email: true, firstName: true, lastName: true },
            },
          },
        },
        sources: {
          where: { status: 'ACTIVE' },
          select: { id: true, title: true, authorityLayer: true },
        },
        _count: {
          select: { conversations: true },
        },
      },
    });

    if (!workspace) {
      throw new NotFoundError('Workspace', workspaceId);
    }

    res.json({
      success: true,
      data: { workspace },
    });
  })
);

/**
 * POST /api/workspaces
 * Create a new workspace
 */
router.post('/', authenticateToken, asyncHandler(async (req, res) => {
  const data = createWorkspaceSchema.parse(req.body);
  const userId = req.user!.id;

  // Check organization membership
  const orgMember = await prisma.organizationMember.findFirst({
    where: {
      organizationId: data.organizationId,
      userId,
    },
  });

  if (!orgMember && req.user!.role !== 'SUPER_ADMIN') {
    throw new AuthorizationError('You do not have access to this organization');
  }

  // Check workspace limit for organization
  const workspaceCount = await prisma.workspace.count({
    where: { organizationId: data.organizationId },
  });

  const subscription = await prisma.subscription.findUnique({
    where: { organizationId: data.organizationId },
  });

  const planLimits: Record<string, number> = {
    FREE: 1,
    BASIC: 3,
    PROFESSIONAL: 10,
    ENTERPRISE: -1,
  };

  const limit = planLimits[subscription?.planType || 'FREE'];
  if (limit !== -1 && workspaceCount >= limit) {
    throw new ValidationError(`Workspace limit reached for your plan (${limit})`);
  }

  const workspace = await prisma.workspace.create({
    data: {
      name: data.name,
      description: data.description,
      organizationId: data.organizationId,
      createdBy: userId,
      jurisdictions: data.jurisdictions || [],
      programTypes: data.programTypes || [],
      members: {
        create: {
          userId,
          role: 'ADMIN',
        },
      },
    },
    include: {
      organization: {
        select: { id: true, name: true },
      },
    },
  });

  await auditService.log({
    eventType: AuditEventType.WORKSPACE_CREATED,
    severity: 'INFO',
    userId,
    organizationId: data.organizationId,
    workspaceId: workspace.id,
    description: `Workspace created: ${data.name}`,
  });

  res.status(201).json({
    success: true,
    data: { workspace },
  });
}));

/**
 * PATCH /api/workspaces/:workspaceId
 * Update workspace
 */
router.patch(
  '/:workspaceId',
  authenticateToken,
  requireWorkspaceAccess(),
  asyncHandler(async (req, res) => {
    const { workspaceId } = req.params;
    const data = updateWorkspaceSchema.parse(req.body);
    const userId = req.user!.id;

    const workspace = await prisma.workspace.update({
      where: { id: workspaceId },
      data: {
        ...data,
        updatedAt: new Date(),
      },
      include: {
        organization: {
          select: { id: true, name: true },
        },
      },
    });

    await auditService.log({
      eventType: AuditEventType.WORKSPACE_UPDATED,
      severity: 'INFO',
      userId,
      organizationId: workspace.organizationId,
      workspaceId,
      description: `Workspace updated: ${workspace.name}`,
    });

    res.json({
      success: true,
      data: { workspace },
    });
  })
);

/**
 * DELETE /api/workspaces/:workspaceId
 * Delete workspace
 */
router.delete(
  '/:workspaceId',
  authenticateToken,
  requireWorkspaceAccess(),
  asyncHandler(async (req, res) => {
    const { workspaceId } = req.params;
    const userId = req.user!.id;

    const workspace = await prisma.workspace.findUnique({
      where: { id: workspaceId },
    });

    if (!workspace) {
      throw new NotFoundError('Workspace', workspaceId);
    }

    // Only workspace creator or org admin can delete
    const isCreator = workspace.createdBy === userId;
    const isOrgAdmin = await prisma.organizationMember.findFirst({
      where: {
        organizationId: workspace.organizationId,
        userId,
        role: { in: ['OWNER', 'ADMIN'] },
      },
    });

    if (!isCreator && !isOrgAdmin && req.user!.role !== 'SUPER_ADMIN') {
      throw new AuthorizationError('Only workspace creator or organization admin can delete');
    }

    await prisma.workspace.delete({
      where: { id: workspaceId },
    });

    await auditService.log({
      eventType: AuditEventType.WORKSPACE_DELETED,
      severity: 'INFO',
      userId,
      organizationId: workspace.organizationId,
      description: `Workspace deleted: ${workspace.name}`,
    });

    res.json({
      success: true,
      message: 'Workspace deleted successfully',
    });
  })
);

/**
 * POST /api/workspaces/:workspaceId/invite
 * Invite member to workspace
 */
router.post(
  '/:workspaceId/invite',
  authenticateToken,
  requireWorkspaceAccess(),
  asyncHandler(async (req, res) => {
    const { workspaceId } = req.params;
    const data = inviteMemberSchema.parse(req.body);
    const userId = req.user!.id;

    // Check user limit
    const memberCount = await prisma.workspaceMember.count({
      where: { workspaceId },
    });

    const workspace = await prisma.workspace.findUnique({
      where: { id: workspaceId },
      include: { organization: true },
    });

    const subscription = await prisma.subscription.findUnique({
      where: { organizationId: workspace!.organizationId },
    });

    const planLimits: Record<string, number> = {
      FREE: 3,
      BASIC: 10,
      PROFESSIONAL: 50,
      ENTERPRISE: -1,
    };

    const limit = planLimits[subscription?.planType || 'FREE'];
    if (limit !== -1 && memberCount >= limit) {
      throw new ValidationError(`Member limit reached for your plan (${limit})`);
    }

    // Check if user already invited or member
    const existingMember = await prisma.workspaceMember.findFirst({
      where: {
        workspaceId,
        user: { email: data.email },
      },
    });

    if (existingMember) {
      throw new ValidationError('User is already a member of this workspace');
    }

    const existingInvite = await prisma.workspaceInvitation.findFirst({
      where: {
        workspaceId,
        email: data.email,
        status: 'PENDING',
      },
    });

    if (existingInvite) {
      throw new ValidationError('An invitation is already pending for this email');
    }

    // Create invitation
    const invitation = await prisma.workspaceInvitation.create({
      data: {
        workspaceId,
        email: data.email,
        role: data.role,
        invitedBy: userId,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
      },
    });

    // Send notification
    const inviter = await prisma.user.findUnique({
      where: { id: userId },
      select: { firstName: true, lastName: true },
    });

    await notificationService.sendInvitation(
      invitation.id,
      data.email,
      `${inviter?.firstName} ${inviter?.lastName}`,
      workspace!.name
    );

    await auditService.log({
      eventType: AuditEventType.MEMBER_INVITED,
      severity: 'INFO',
      userId,
      workspaceId,
      description: `Invited ${data.email} to workspace`,
    });

    res.status(201).json({
      success: true,
      data: { invitation },
    });
  })
);

/**
 * GET /api/workspaces/:workspaceId/members
 * List workspace members
 */
router.get(
  '/:workspaceId/members',
  authenticateToken,
  requireWorkspaceAccess(),
  asyncHandler(async (req, res) => {
    const { workspaceId } = req.params;

    const members = await prisma.workspaceMember.findMany({
      where: { workspaceId },
      include: {
        user: {
          select: { id: true, email: true, firstName: true, lastName: true },
        },
      },
    });

    res.json({
      success: true,
      data: { members },
    });
  })
);

/**
 * DELETE /api/workspaces/:workspaceId/members/:memberId
 * Remove member from workspace
 */
router.delete(
  '/:workspaceId/members/:memberId',
  authenticateToken,
  requireWorkspaceAccess(),
  asyncHandler(async (req, res) => {
    const { workspaceId, memberId } = req.params;
    const userId = req.user!.id;

    const member = await prisma.workspaceMember.findFirst({
      where: {
        workspaceId,
        userId: memberId,
      },
    });

    if (!member) {
      throw new NotFoundError('Member');
    }

    // Can't remove yourself if you're the only admin
    if (member.userId === userId) {
      const adminCount = await prisma.workspaceMember.count({
        where: {
          workspaceId,
          role: 'ADMIN',
        },
      });

      if (adminCount <= 1) {
        throw new ValidationError('Cannot remove the only admin from workspace');
      }
    }

    await prisma.workspaceMember.delete({
      where: { id: member.id },
    });

    await auditService.log({
      eventType: AuditEventType.MEMBER_REMOVED,
      severity: 'INFO',
      userId,
      workspaceId,
      description: `Removed member ${memberId} from workspace`,
    });

    res.json({
      success: true,
      message: 'Member removed successfully',
    });
  })
);

export default router;
