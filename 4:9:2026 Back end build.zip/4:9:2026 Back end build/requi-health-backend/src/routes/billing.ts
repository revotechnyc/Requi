/**
 * Billing Routes
 * 
 * Subscription management, payment processing, and usage tracking.
 */

import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/database';
import { authenticateToken, requireOrganizationAccess } from '../middleware/auth';
import { asyncHandler, ValidationError, NotFoundError } from '../middleware/errorHandler';
import { billingService, PLANS } from '../services/billingService';
import { auditService, AuditEventType } from '../services/auditService';

const router = Router();

// Validation schemas
const updateSubscriptionSchema = z.object({
  planType: z.enum(['FREE', 'BASIC', 'PROFESSIONAL', 'ENTERPRISE']),
  paypalSubscriptionId: z.string().optional(),
});

/**
 * GET /api/billing/subscription
 * Get current subscription
 */
router.get(
  '/subscription',
  authenticateToken,
  asyncHandler(async (req, res) => {
    const organizationId = req.user!.organizationId;

    if (!organizationId) {
      throw new ValidationError('User is not associated with an organization');
    }

    const subscription = await billingService.getSubscription(organizationId);

    if (!subscription) {
      throw new NotFoundError('Subscription');
    }

    res.json({
      success: true,
      data: { subscription },
    });
  })
);

/**
 * GET /api/billing/plans
 * List available plans
 */
router.get('/plans', asyncHandler(async (_req, res) => {
  res.json({
    success: true,
    data: {
      plans: PLANS,
    },
  });
}));

/**
 * PATCH /api/billing/subscription
 * Update subscription plan
 */
router.patch(
  '/subscription',
  authenticateToken,
  asyncHandler(async (req, res) => {
    const organizationId = req.user!.organizationId;

    if (!organizationId) {
      throw new ValidationError('User is not associated with an organization');
    }

    // Check if user is org admin
    const membership = await prisma.organizationMember.findFirst({
      where: {
        organizationId,
        userId: req.user!.id,
        role: { in: ['OWNER', 'ADMIN'] },
      },
    });

    if (!membership && req.user!.role !== 'SUPER_ADMIN') {
      throw new ValidationError('Only organization admins can change the subscription');
    }

    const data = updateSubscriptionSchema.parse(req.body);

    await billingService.updatePlan(
      organizationId,
      data.planType,
      data.paypalSubscriptionId
    );

    res.json({
      success: true,
      message: 'Subscription updated successfully',
    });
  })
);

/**
 * GET /api/billing/usage
 * Get usage history
 */
router.get(
  '/usage',
  authenticateToken,
  asyncHandler(async (req, res) => {
    const organizationId = req.user!.organizationId;

    if (!organizationId) {
      throw new ValidationError('User is not associated with an organization');
    }

    const days = parseInt(req.query.days as string) || 30;
    const history = await billingService.getUsageHistory(organizationId, days);

    res.json({
      success: true,
      data: { usage: history },
    });
  })
);

/**
 * GET /api/billing/quota
 * Check current quota
 */
router.get(
  '/quota',
  authenticateToken,
  asyncHandler(async (req, res) => {
    const organizationId = req.user!.organizationId;

    if (!organizationId) {
      throw new ValidationError('User is not associated with an organization');
    }

    const quota = await billingService.checkQuota(organizationId);

    res.json({
      success: true,
      data: { quota },
    });
  })
);

/**
 * GET /api/billing/invoices
 * List invoices
 */
router.get(
  '/invoices',
  authenticateToken,
  asyncHandler(async (req, res) => {
    const organizationId = req.user!.organizationId;

    if (!organizationId) {
      throw new ValidationError('User is not associated with an organization');
    }

    const invoices = await prisma.invoice.findMany({
      where: { organizationId },
      orderBy: { createdAt: 'desc' },
    });

    res.json({
      success: true,
      data: { invoices },
    });
  })
);

/**
 * POST /api/billing/paypal/webhook
 * PayPal webhook handler
 */
router.post('/paypal/webhook', asyncHandler(async (req, res) => {
  // Verify webhook signature in production
  // const isValid = verifyPayPalWebhook(req);
  
  await billingService.processPayPalWebhook(req.body);

  res.json({ success: true });
}));

export default router;
