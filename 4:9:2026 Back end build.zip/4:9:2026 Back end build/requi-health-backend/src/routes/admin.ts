/**
 * Admin Routes
 * 
 * Back office functionality for super admins and system administrators.
 */

import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/database';
import { authenticateToken, requireRole } from '../middleware/auth';
import { asyncHandler, ValidationError, NotFoundError } from '../middleware/errorHandler';
import { missingKnowledgeService } from '../services/missingKnowledgeService';
import { auditService, AuditEventType, AuditSeverity } from '../services/auditService';
import { notificationService } from '../services/notificationService';
import { billingService } from '../services/billingService';

const router = Router();

// Validation schemas
const createAnnouncementSchema = z.object({
  title: z.string().min(1, 'Title is required'),
  content: z.string().min(1, 'Content is required'),
  type: z.enum(['INFO', 'WARNING', 'MAINTENANCE', 'FEATURE']),
  targetAudience: z.enum(['ALL', 'ADMINS', 'USERS']).default('ALL'),
  startDate: z.string().datetime().optional(),
  endDate: z.string().datetime().optional(),
});

const updateTaskSchema = z.object({
  status: z.enum(['PENDING', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED']).optional(),
  priority: z.enum(['LOW', 'MEDIUM', 'HIGH', 'URGENT']).optional(),
  assignedToId: z.string().uuid().optional().nullable(),
  notes: z.string().optional(),
});

/**
 * GET /api/admin/dashboard
 * Get admin dashboard stats
 */
router.get(
  '/dashboard',
  authenticateToken,
  requireRole('ADMIN', 'SUPER_ADMIN'),
  asyncHandler(async (req, res) => {
    const [
      userStats,
      organizationStats,
      conversationStats,
      sourceStats,
      missingKnowledgeStats,
      recentAuditEvents,
      criticalEvents,
    ] = await Promise.all([
      // User stats
      prisma.user.groupBy({
        by: ['status'],
        _count: { status: true },
      }),
      // Organization stats
      prisma.organization.count(),
      // Conversation stats
      prisma.conversation.count(),
      // Source stats
      prisma.source.groupBy({
        by: ['status'],
        _count: { status: true },
      }),
      // Missing knowledge stats
      prisma.missingKnowledgeEvent.groupBy({
        by: ['status'],
        _count: { status: true },
      }),
      // Recent audit events
      auditService.query({ limit: 10 }),
      // Critical events
      auditService.getCriticalEvents(10),
    ]);

    // Get today's usage
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const todayUsage = await prisma.usageRecord.aggregate({
      where: {
        createdAt: { gte: today },
      },
      _sum: {
        tokenCount: true,
        costCents: true,
      },
      _count: true,
    });

    res.json({
      success: true,
      data: {
        users: {
          total: userStats.reduce((acc, s) => acc + s._count.status, 0),
          byStatus: userStats.reduce((acc, s) => ({ ...acc, [s.status]: s._count.status }), {}),
        },
        organizations: organizationStats,
        conversations: conversationStats,
        sources: {
          total: sourceStats.reduce((acc, s) => acc + s._count.status, 0),
          byStatus: sourceStats.reduce((acc, s) => ({ ...acc, [s.status]: s._count.status }), {}),
        },
        missingKnowledge: {
          total: missingKnowledgeStats.reduce((acc, s) => acc + s._count.status, 0),
          byStatus: missingKnowledgeStats.reduce((acc, s) => ({ ...acc, [s.status]: s._count.status }), {}),
        },
        todayUsage: {
          requests: todayUsage._count,
          tokens: todayUsage._sum.tokenCount || 0,
          cost: (todayUsage._sum.costCents || 0) / 100,
        },
        recentEvents: recentAuditEvents.logs,
        criticalEvents,
      },
    });
  })
);

/**
 * GET /api/admin/users
 * List all users (admin only)
 */
router.get(
  '/users',
  authenticateToken,
  requireRole('ADMIN', 'SUPER_ADMIN'),
  asyncHandler(async (req, res) => {
    const {
      search,
      status,
      role,
      limit = '20',
      offset = '0',
    } = req.query;

    const where: any = {};

    if (search) {
      where.OR = [
        { email: { contains: search as string, mode: 'insensitive' } },
        { firstName: { contains: search as string, mode: 'insensitive' } },
        { lastName: { contains: search as string, mode: 'insensitive' } },
      ];
    }

    if (status) {
      where.status = status;
    }

    if (role) {
      where.role = role;
    }

    const [users, total] = await Promise.all([
      prisma.user.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: parseInt(limit as string),
        skip: parseInt(offset as string),
        include: {
          organization: {
            select: { id: true, name: true },
          },
          _count: {
            select: { conversations: true },
          },
        },
      }),
      prisma.user.count({ where }),
    ]);

    res.json({
      success: true,
      data: { users, total },
    });
  })
);

/**
 * PATCH /api/admin/users/:userId
 * Update user (suspend, change role, etc.)
 */
router.patch(
  '/users/:userId',
  authenticateToken,
  requireRole('SUPER_ADMIN'),
  asyncHandler(async (req, res) => {
    const { userId } = req.params;
    const { status, role } = req.body;

    const user = await prisma.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      throw new NotFoundError('User', userId);
    }

    const updatedUser = await prisma.user.update({
      where: { id: userId },
      data: {
        ...(status && { status }),
        ...(role && { role }),
        updatedAt: new Date(),
      },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        status: true,
      },
    });

    // Log event
    if (status === 'SUSPENDED') {
      await auditService.log({
        eventType: AuditEventType.USER_SUSPENDED,
        severity: AuditSeverity.WARNING,
        userId,
        description: 'User suspended by admin',
      });
    } else if (status === 'ACTIVE' && user.status === 'SUSPENDED') {
      await auditService.log({
        eventType: AuditEventType.USER_REACTIVATED,
        severity: 'INFO',
        userId,
        description: 'User reactivated by admin',
      });
    }

    res.json({
      success: true,
      data: { user: updatedUser },
    });
  })
);

/**
 * GET /api/admin/missing-knowledge
 * List missing knowledge events
 */
router.get(
  '/missing-knowledge',
  authenticateToken,
  requireRole('ADMIN', 'SUPER_ADMIN'),
  asyncHandler(async (req, res) => {
    const {
      status,
      priority,
      jurisdiction,
      limit = '20',
      offset = '0',
    } = req.query;

    const filters: any = {};
    if (status) filters.status = status;
    if (priority) filters.priority = priority;
    if (jurisdiction) filters.jurisdiction = jurisdiction;

    const events = await missingKnowledgeService.getEvents(filters, {
      limit: parseInt(limit as string),
      offset: parseInt(offset as string),
    });

    res.json({
      success: true,
      data: events,
    });
  })
);

/**
 * GET /api/admin/missing-knowledge/stats
 * Get missing knowledge statistics
 */
router.get(
  '/missing-knowledge/stats',
  authenticateToken,
  requireRole('ADMIN', 'SUPER_ADMIN'),
  asyncHandler(async (req, res) => {
    const stats = await missingKnowledgeService.getStats();

    res.json({
      success: true,
      data: { stats },
    });
  })
);

/**
 * POST /api/admin/missing-knowledge/:eventId/resolve
 * Resolve a missing knowledge event
 */
router.post(
  '/missing-knowledge/:eventId/resolve',
  authenticateToken,
  requireRole('ADMIN', 'SUPER_ADMIN'),
  asyncHandler(async (req, res) => {
    const { eventId } = req.params;
    const { resolution, sourceId } = req.body;

    await prisma.missingKnowledgeEvent.update({
      where: { id: eventId },
      data: {
        status: 'RESOLVED',
        resolution,
        resolvedById: req.user!.id,
        resolvedAt: new Date(),
        sourceId,
      },
    });

    await auditService.log({
      eventType: AuditEventType.MISSING_KNOWLEDGE_REVIEWED,
      severity: 'INFO',
      userId: req.user!.id,
      metadata: { eventId, resolution },
      description: 'Missing knowledge event resolved',
    });

    res.json({
      success: true,
      message: 'Event resolved successfully',
    });
  })
);

/**
 * GET /api/admin/tasks
 * List admin tasks
 */
router.get(
  '/tasks',
  authenticateToken,
  requireRole('ADMIN', 'SUPER_ADMIN'),
  asyncHandler(async (req, res) => {
    const {
      status,
      priority,
      assignedTo,
      limit = '20',
      offset = '0',
    } = req.query;

    const where: any = {};

    if (status) where.status = status;
    if (priority) where.priority = priority;
    if (assignedTo) where.assignedToId = assignedTo;

    const [tasks, total] = await Promise.all([
      prisma.adminTask.findMany({
        where,
        orderBy: [{ priority: 'desc' }, { createdAt: 'desc' }],
        take: parseInt(limit as string),
        skip: parseInt(offset as string),
        include: {
          assignedTo: {
            select: { id: true, email: true, firstName: true, lastName: true },
          },
          createdBy: {
            select: { id: true, email: true, firstName: true, lastName: true },
          },
          missingKnowledgeEvent: true,
        },
      }),
      prisma.adminTask.count({ where }),
    ]);

    res.json({
      success: true,
      data: { tasks, total },
    });
  })
);

/**
 * PATCH /api/admin/tasks/:taskId
 * Update admin task
 */
router.patch(
  '/tasks/:taskId',
  authenticateToken,
  requireRole('ADMIN', 'SUPER_ADMIN'),
  asyncHandler(async (req, res) => {
    const { taskId } = req.params;
    const data = updateTaskSchema.parse(req.body);

    const task = await prisma.adminTask.findUnique({
      where: { id: taskId },
    });

    if (!task) {
      throw new NotFoundError('Task', taskId);
    }

    const updatedTask = await prisma.adminTask.update({
      where: { id: taskId },
      data: {
        ...data,
        completedAt: data.status === 'COMPLETED' ? new Date() : undefined,
      },
      include: {
        assignedTo: {
          select: { id: true, email: true },
        },
      },
    });

    // Send notification if assigned
    if (data.assignedToId && data.assignedToId !== task.assignedToId) {
      await notificationService.sendAdminTaskAssigned(
        taskId,
        data.assignedToId,
        task.title,
        data.priority || task.priority
      );
    }

    res.json({
      success: true,
      data: { task: updatedTask },
    });
  })
);

/**
 * GET /api/admin/audit-logs
 * Query audit logs
 */
router.get(
  '/audit-logs',
  authenticateToken,
  requireRole('ADMIN', 'SUPER_ADMIN'),
  asyncHandler(async (req, res) => {
    const {
      eventTypes,
      userId,
      severity,
      startDate,
      endDate,
      limit = '50',
      offset = '0',
    } = req.query;

    const filters: any = {
      limit: parseInt(limit as string),
      offset: parseInt(offset as string),
    };

    if (eventTypes) filters.eventTypes = (eventTypes as string).split(',');
    if (userId) filters.userId = userId as string;
    if (severity) filters.severity = severity as string;
    if (startDate) filters.startDate = new Date(startDate as string);
    if (endDate) filters.endDate = new Date(endDate as string);

    const result = await auditService.query(filters);

    res.json({
      success: true,
      data: result,
    });
  })
);

/**
 * GET /api/admin/audit-logs/stats
 * Get audit statistics
 */
router.get(
  '/audit-logs/stats',
  authenticateToken,
  requireRole('ADMIN', 'SUPER_ADMIN'),
  asyncHandler(async (req, res) => {
    const { days } = req.query;
    const stats = await auditService.getStats(undefined, parseInt(days as string) || 30);

    res.json({
      success: true,
      data: { stats },
    });
  })
);

/**
 * POST /api/admin/announcements
 * Create system announcement
 */
router.post(
  '/announcements',
  authenticateToken,
  requireRole('SUPER_ADMIN'),
  asyncHandler(async (req, res) => {
    const data = createAnnouncementSchema.parse(req.body);

    const announcement = await prisma.announcement.create({
      data: {
        title: data.title,
        content: data.content,
        type: data.type,
        targetAudience: data.targetAudience,
        createdById: req.user!.id,
        startDate: data.startDate ? new Date(data.startDate) : new Date(),
        endDate: data.endDate ? new Date(data.endDate) : null,
      },
    });

    await auditService.log({
      eventType: AuditEventType.ANNOUNCEMENT_CREATED,
      severity: 'INFO',
      userId: req.user!.id,
      metadata: { announcementId: announcement.id },
      description: `Announcement created: ${data.title}`,
    });

    res.status(201).json({
      success: true,
      data: { announcement },
    });
  })
);

/**
 * GET /api/admin/subscriptions
 * List all subscriptions
 */
router.get(
  '/subscriptions',
  authenticateToken,
  requireRole('ADMIN', 'SUPER_ADMIN'),
  asyncHandler(async (req, res) => {
    const { status, planType, limit = '20', offset = '0' } = req.query;

    const where: any = {};
    if (status) where.status = status;
    if (planType) where.planType = planType;

    const [subscriptions, total] = await Promise.all([
      prisma.subscription.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: parseInt(limit as string),
        skip: parseInt(offset as string),
        include: {
          organization: {
            select: { id: true, name: true },
          },
        },
      }),
      prisma.subscription.count({ where }),
    ]);

    res.json({
      success: true,
      data: { subscriptions, total },
    });
  })
);

export default router;
