/**
 * Team Routes
 * 
 * Team management within workspaces.
 */

import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/database';
import { authenticateToken, requireWorkspaceAccess } from '../middleware/auth';
import { asyncHandler, ValidationError, NotFoundError } from '../middleware/errorHandler';
import { auditService, AuditEventType } from '../services/auditService';

const router = Router({ mergeParams: true });

// Validation schemas
const createTeamSchema = z.object({
  name: z.string().min(1, 'Team name is required'),
  description: z.string().optional(),
  memberIds: z.array(z.string().uuid()).optional(),
});

const updateTeamSchema = z.object({
  name: z.string().min(1).optional(),
  description: z.string().optional(),
});

/**
 * GET /api/workspaces/:workspaceId/teams
 * List teams in workspace
 */
router.get(
  '/',
  authenticateToken,
  requireWorkspaceAccess(),
  asyncHandler(async (req, res) => {
    const { workspaceId } = req.params;

    const teams = await prisma.team.findMany({
      where: { workspaceId },
      include: {
        members: {
          include: {
            user: {
              select: { id: true, email: true, firstName: true, lastName: true },
            },
          },
        },
        _count: {
          select: { members: true },
        },
      },
    });

    res.json({
      success: true,
      data: { teams },
    });
  })
);

/**
 * GET /api/workspaces/:workspaceId/teams/:teamId
 * Get team details
 */
router.get(
  '/:teamId',
  authenticateToken,
  requireWorkspaceAccess(),
  asyncHandler(async (req, res) => {
    const { workspaceId, teamId } = req.params;

    const team = await prisma.team.findFirst({
      where: {
        id: teamId,
        workspaceId,
      },
      include: {
        members: {
          include: {
            user: {
              select: { id: true, email: true, firstName: true, lastName: true },
            },
          },
        },
      },
    });

    if (!team) {
      throw new NotFoundError('Team', teamId);
    }

    res.json({
      success: true,
      data: { team },
    });
  })
);

/**
 * POST /api/workspaces/:workspaceId/teams
 * Create a new team
 */
router.post(
  '/',
  authenticateToken,
  requireWorkspaceAccess(),
  asyncHandler(async (req, res) => {
    const { workspaceId } = req.params;
    const data = createTeamSchema.parse(req.body);
    const userId = req.user!.id;

    const team = await prisma.team.create({
      data: {
        name: data.name,
        description: data.description,
        workspaceId,
        createdBy: userId,
        members: data.memberIds ? {
          create: data.memberIds.map(memberId => ({
            userId: memberId,
          })),
        } : undefined,
      },
      include: {
        members: {
          include: {
            user: {
              select: { id: true, email: true, firstName: true, lastName: true },
            },
          },
        },
      },
    });

    await auditService.log({
      eventType: AuditEventType.TEAM_CREATED,
      severity: 'INFO',
      userId,
      workspaceId,
      description: `Team created: ${data.name}`,
    });

    res.status(201).json({
      success: true,
      data: { team },
    });
  })
);

/**
 * PATCH /api/workspaces/:workspaceId/teams/:teamId
 * Update team
 */
router.patch(
  '/:teamId',
  authenticateToken,
  requireWorkspaceAccess(),
  asyncHandler(async (req, res) => {
    const { workspaceId, teamId } = req.params;
    const data = updateTeamSchema.parse(req.body);
    const userId = req.user!.id;

    const team = await prisma.team.findFirst({
      where: {
        id: teamId,
        workspaceId,
      },
    });

    if (!team) {
      throw new NotFoundError('Team', teamId);
    }

    const updatedTeam = await prisma.team.update({
      where: { id: teamId },
      data: {
        ...data,
        updatedAt: new Date(),
      },
      include: {
        members: {
          include: {
            user: {
              select: { id: true, email: true, firstName: true, lastName: true },
            },
          },
        },
      },
    });

    await auditService.log({
      eventType: AuditEventType.TEAM_UPDATED,
      severity: 'INFO',
      userId,
      workspaceId,
      description: `Team updated: ${data.name || team.name}`,
    });

    res.json({
      success: true,
      data: { team: updatedTeam },
    });
  })
);

/**
 * DELETE /api/workspaces/:workspaceId/teams/:teamId
 * Delete team
 */
router.delete(
  '/:teamId',
  authenticateToken,
  requireWorkspaceAccess(),
  asyncHandler(async (req, res) => {
    const { workspaceId, teamId } = req.params;
    const userId = req.user!.id;

    const team = await prisma.team.findFirst({
      where: {
        id: teamId,
        workspaceId,
      },
    });

    if (!team) {
      throw new NotFoundError('Team', teamId);
    }

    await prisma.team.delete({
      where: { id: teamId },
    });

    await auditService.log({
      eventType: AuditEventType.TEAM_DELETED,
      severity: 'INFO',
      userId,
      workspaceId,
      description: `Team deleted: ${team.name}`,
    });

    res.json({
      success: true,
      message: 'Team deleted successfully',
    });
  })
);

/**
 * POST /api/workspaces/:workspaceId/teams/:teamId/members
 * Add member to team
 */
router.post(
  '/:teamId/members',
  authenticateToken,
  requireWorkspaceAccess(),
  asyncHandler(async (req, res) => {
    const { workspaceId, teamId } = req.params;
    const { userId: memberId } = req.body;
    const userId = req.user!.id;

    if (!memberId) {
      throw new ValidationError('User ID is required');
    }

    const team = await prisma.team.findFirst({
      where: {
        id: teamId,
        workspaceId,
      },
    });

    if (!team) {
      throw new NotFoundError('Team', teamId);
    }

    // Check if user is already in team
    const existingMember = await prisma.teamMember.findFirst({
      where: {
        teamId,
        userId: memberId,
      },
    });

    if (existingMember) {
      throw new ValidationError('User is already a member of this team');
    }

    // Verify user is a workspace member
    const workspaceMember = await prisma.workspaceMember.findFirst({
      where: {
        workspaceId,
        userId: memberId,
      },
    });

    if (!workspaceMember) {
      throw new ValidationError('User must be a workspace member before joining a team');
    }

    const teamMember = await prisma.teamMember.create({
      data: {
        teamId,
        userId: memberId,
      },
      include: {
        user: {
          select: { id: true, email: true, firstName: true, lastName: true },
        },
      },
    });

    res.status(201).json({
      success: true,
      data: { member: teamMember },
    });
  })
);

/**
 * DELETE /api/workspaces/:workspaceId/teams/:teamId/members/:memberId
 * Remove member from team
 */
router.delete(
  '/:teamId/members/:memberId',
  authenticateToken,
  requireWorkspaceAccess(),
  asyncHandler(async (req, res) => {
    const { workspaceId, teamId, memberId } = req.params;

    const team = await prisma.team.findFirst({
      where: {
        id: teamId,
        workspaceId,
      },
    });

    if (!team) {
      throw new NotFoundError('Team', teamId);
    }

    const teamMember = await prisma.teamMember.findFirst({
      where: {
        teamId,
        userId: memberId,
      },
    });

    if (!teamMember) {
      throw new NotFoundError('Team member');
    }

    await prisma.teamMember.delete({
      where: { id: teamMember.id },
    });

    res.json({
      success: true,
      message: 'Member removed from team',
    });
  })
);

export default router;
