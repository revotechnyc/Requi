/**
 * Health Check Routes
 * 
 * System health monitoring and status endpoints.
 */

import { Router } from 'express';
import { prisma } from '../config/database';
import { redis } from '../config/redis';
import { logger } from '../utils/logger';

const router = Router();

/**
 * GET /health
 * Basic health check
 */
router.get('/', async (_req, res) => {
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    service: 'requi-health-api',
    version: process.env.npm_package_version || '1.0.0',
  });
});

/**
 * GET /health/detailed
 * Detailed health check with dependency status
 */
router.get('/detailed', async (_req, res) => {
  const checks: Record<string, { status: string; responseTime: number; error?: string }> = {};
  let overallStatus = 'healthy';

  // Check database
  const dbStart = Date.now();
  try {
    await prisma.$queryRaw`SELECT 1`;
    checks.database = {
      status: 'healthy',
      responseTime: Date.now() - dbStart,
    };
  } catch (error) {
    checks.database = {
      status: 'unhealthy',
      responseTime: Date.now() - dbStart,
      error: (error as Error).message,
    };
    overallStatus = 'unhealthy';
  }

  // Check Redis
  const redisStart = Date.now();
  try {
    await redis.ping();
    checks.redis = {
      status: 'healthy',
      responseTime: Date.now() - redisStart,
    };
  } catch (error) {
    checks.redis = {
      status: 'unhealthy',
      responseTime: Date.now() - redisStart,
      error: (error as Error).message,
    };
    overallStatus = 'unhealthy';
  }

  // Check memory usage
  const memoryUsage = process.memoryUsage();
  const memoryThreshold = 1024 * 1024 * 1024; // 1GB
  const memoryStatus = memoryUsage.heapUsed < memoryThreshold ? 'healthy' : 'warning';
  
  checks.memory = {
    status: memoryStatus,
    responseTime: 0,
  };

  if (memoryStatus === 'warning') {
    overallStatus = overallStatus === 'healthy' ? 'degraded' : overallStatus;
  }

  // Check uptime
  const uptime = process.uptime();

  const statusCode = overallStatus === 'healthy' ? 200 : overallStatus === 'degraded' ? 200 : 503;

  res.status(statusCode).json({
    status: overallStatus,
    timestamp: new Date().toISOString(),
    service: 'requi-health-api',
    version: process.env.npm_package_version || '1.0.0',
    uptime: Math.floor(uptime),
    memory: {
      used: Math.round(memoryUsage.heapUsed / 1024 / 1024),
      total: Math.round(memoryUsage.heapTotal / 1024 / 1024),
      rss: Math.round(memoryUsage.rss / 1024 / 1024),
    },
    checks,
  });
});

/**
 * GET /health/ready
 * Kubernetes readiness probe
 */
router.get('/ready', async (_req, res) => {
  try {
    // Check critical dependencies
    await Promise.all([
      prisma.$queryRaw`SELECT 1`,
      redis.ping(),
    ]);

    res.status(200).json({ ready: true });
  } catch (error) {
    logger.error('Readiness check failed', { error });
    res.status(503).json({ ready: false });
  }
});

/**
 * GET /health/live
 * Kubernetes liveness probe
 */
router.get('/live', (_req, res) => {
  // Simple liveness check - if the server is responding, it's alive
  res.status(200).json({ alive: true });
});

export default router;
