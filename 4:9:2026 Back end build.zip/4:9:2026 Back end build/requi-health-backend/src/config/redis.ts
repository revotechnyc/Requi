import Redis from 'ioredis';

// Redis client configuration
const redisConfig = {
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT || '6379'),
  password: process.env.REDIS_PASSWORD,
  db: parseInt(process.env.REDIS_DB || '0'),
  retryStrategy: (times: number) => {
    const delay = Math.min(times * 50, 2000);
    return delay;
  },
  maxRetriesPerRequest: 3,
};

// Redis client singleton
const globalForRedis = globalThis as unknown as {
  redis: Redis | undefined;
};

export const redis = globalForRedis.redis ?? new Redis(redisConfig);

if (process.env.NODE_ENV !== 'production') {
  globalForRedis.redis = redis;
}

// Cache key prefixes
export const CACHE_KEYS = {
  USER_SESSION: 'session:user:',
  WORKSPACE: 'workspace:',
  SOURCE: 'source:',
  RETRIEVAL: 'retrieval:',
  RATE_LIMIT: 'ratelimit:',
} as const;

// Cache TTLs (in seconds)
export const CACHE_TTL = {
  USER_SESSION: 60 * 60 * 24, // 24 hours
  WORKSPACE: 60 * 5, // 5 minutes
  SOURCE: 60 * 60, // 1 hour
  RETRIEVAL: 60 * 60 * 24, // 24 hours
  RATE_LIMIT: 60 * 15, // 15 minutes
} as const;

// Cache helper functions
export async function getCache<T>(key: string): Promise<T | null> {
  try {
    const value = await redis.get(key);
    return value ? JSON.parse(value) : null;
  } catch (error) {
    console.error('Cache get error:', error);
    return null;
  }
}

export async function setCache<T>(
  key: string,
  value: T,
  ttlSeconds: number = CACHE_TTL.WORKSPACE
): Promise<void> {
  try {
    await redis.setex(key, ttlSeconds, JSON.stringify(value));
  } catch (error) {
    console.error('Cache set error:', error);
  }
}

export async function deleteCache(key: string): Promise<void> {
  try {
    await redis.del(key);
  } catch (error) {
    console.error('Cache delete error:', error);
  }
}

// Connection health check
export async function checkRedisConnection(): Promise<boolean> {
  try {
    await redis.ping();
    return true;
  } catch (error) {
    console.error('Redis connection failed:', error);
    return false;
  }
}
