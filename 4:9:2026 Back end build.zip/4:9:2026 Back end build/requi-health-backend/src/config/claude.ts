import Anthropic from '@anthropic-ai/sdk';

// Claude client singleton
const globalForClaude = globalThis as unknown as {
  claude: Anthropic | undefined;
};

export const claude = globalForClaude.claude ?? new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

if (process.env.NODE_ENV !== 'production') {
  globalForClaude.claude = claude;
}

// Model configuration
export const CLAUDE_MODELS = {
  // Best for complex reasoning, regulatory analysis
  CLAUDE_3_OPUS: 'claude-3-opus-20240229',
  // Balanced performance and cost
  CLAUDE_3_SONNET: 'claude-3-sonnet-20240229',
  // Fast, cost-effective for simple tasks
  CLAUDE_3_HAIKU: 'claude-3-haiku-20240307',
} as const;

// Default model for compliance reasoning
export const DEFAULT_MODEL = CLAUDE_MODELS.CLAUDE_3_SONNET;

// Model selection based on use case
export function selectModel(useCase: 'reasoning' | 'drafting' | 'extraction' | 'simple'): string {
  switch (useCase) {
    case 'reasoning':
      return CLAUDE_MODELS.CLAUDE_3_OPUS;
    case 'drafting':
      return CLAUDE_MODELS.CLAUDE_3_SONNET;
    case 'extraction':
      return CLAUDE_MODELS.CLAUDE_3_HAIKU;
    case 'simple':
      return CLAUDE_MODELS.CLAUDE_3_HAIKU;
    default:
      return DEFAULT_MODEL;
  }
}

// Token limits by model
export const MODEL_TOKEN_LIMITS = {
  [CLAUDE_MODELS.CLAUDE_3_OPUS]: 200000,
  [CLAUDE_MODELS.CLAUDE_3_SONNET]: 200000,
  [CLAUDE_MODELS.CLAUDE_3_HAIKU]: 200000,
} as const;

// Cost per 1K tokens (input/output) - approximate
export const MODEL_COSTS = {
  [CLAUDE_MODELS.CLAUDE_3_OPUS]: { input: 0.015, output: 0.075 },
  [CLAUDE_MODELS.CLAUDE_3_SONNET]: { input: 0.003, output: 0.015 },
  [CLAUDE_MODELS.CLAUDE_3_HAIKU]: { input: 0.00025, output: 0.00125 },
} as const;

// Calculate estimated cost
export function calculateCost(
  model: string,
  inputTokens: number,
  outputTokens: number
): number {
  const costs = MODEL_COSTS[model as keyof typeof MODEL_COSTS];
  if (!costs) return 0;
  
  const inputCost = (inputTokens / 1000) * costs.input;
  const outputCost = (outputTokens / 1000) * costs.output;
  return Math.round((inputCost + outputCost) * 100); // Return in cents
}
