/**
 * Database Seed
 * 
 * Initial data for development and testing.
 */

import { PrismaClient, AuthorityLayer, BindingLevel, ProgramType, PlanType } from '@prisma/client';
import bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  // Create admin user
  const adminPassword = await bcrypt.hash('admin123', 12);
  const admin = await prisma.user.upsert({
    where: { email: 'admin@requi.health' },
    update: {},
    create: {
      email: 'admin@requi.health',
      password: adminPassword,
      firstName: 'Super',
      lastName: 'Admin',
      role: 'SUPER_ADMIN',
      status: 'ACTIVE',
    },
  });
  console.log('✅ Admin user created:', admin.email);

  // Create demo organization
  const org = await prisma.organization.upsert({
    where: { slug: 'demo-healthcare' },
    update: {},
    create: {
      name: 'Demo Healthcare Organization',
      slug: 'demo-healthcare',
    },
  });
  console.log('✅ Organization created:', org.name);

  // Create subscription for organization
  await prisma.subscription.upsert({
    where: { organizationId: org.id },
    update: {},
    create: {
      organizationId: org.id,
      planType: PlanType.PROFESSIONAL,
      status: 'ACTIVE',
      billingEmail: 'billing@demo-healthcare.com',
      currentPeriodStart: new Date(),
      currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      tokenQuota: 500000,
      tokenUsed: 0,
    },
  });
  console.log('✅ Subscription created');

  // Create demo user
  const userPassword = await bcrypt.hash('demo123', 12);
  const user = await prisma.user.upsert({
    where: { email: 'demo@requi.health' },
    update: {},
    create: {
      email: 'demo@requi.health',
      password: userPassword,
      firstName: 'Demo',
      lastName: 'User',
      role: 'ADMIN',
      status: 'ACTIVE',
      organizationId: org.id,
    },
  });
  console.log('✅ Demo user created:', user.email);

  // Add user as organization member
  await prisma.organizationMember.upsert({
    where: {
      organizationId_userId: {
        organizationId: org.id,
        userId: user.id,
      },
    },
    update: {},
    create: {
      organizationId: org.id,
      userId: user.id,
      role: 'ADMIN',
    },
  });

  // Create demo workspace
  const workspace = await prisma.workspace.upsert({
    where: { id: 'demo-workspace-001' },
    update: {},
    create: {
      id: 'demo-workspace-001',
      name: 'Compliance Workspace',
      description: 'Main workspace for compliance questions',
      organizationId: org.id,
      createdBy: user.id,
      jurisdictions: ['CA', 'NY', 'TX'],
      programTypes: [ProgramType.MEDICAID, ProgramType.MEDICARE],
      members: {
        create: {
          userId: user.id,
          role: 'ADMIN',
        },
      },
    },
  });
  console.log('✅ Workspace created:', workspace.name);

  // Create sample sources
  const sources = [
    {
      title: '42 CFR Part 2 - Confidentiality of Substance Use Disorder Patient Records',
      description: 'Federal regulations protecting the confidentiality of substance use disorder patient records.',
      authorityLayer: AuthorityLayer.FEDERAL_REGULATIONS,
      bindingLevel: BindingLevel.FEDERAL_MANDATE,
      programTypes: [ProgramType.MEDICAID, ProgramType.MEDICARE],
      jurisdictions: ['FEDERAL'],
      citation: '42 CFR Part 2',
      url: 'https://www.ecfr.gov/current/title-42/chapter-I/subchapter-A/part-2',
    },
    {
      title: 'HIPAA Privacy Rule',
      description: 'Standards for protecting individuals medical records and other personal health information.',
      authorityLayer: AuthorityLayer.FEDERAL_REGULATIONS,
      bindingLevel: BindingLevel.FEDERAL_MANDATE,
      programTypes: [ProgramType.MEDICAID, ProgramType.MEDICARE, ProgramType.COMMERCIAL],
      jurisdictions: ['FEDERAL'],
      citation: '45 CFR 160, 164',
      url: 'https://www.hhs.gov/hipaa/for-professionals/privacy/index.html',
    },
    {
      title: 'CMS Medicaid Managed Care Final Rule',
      description: 'Final rule establishing requirements for Medicaid managed care programs.',
      authorityLayer: AuthorityLayer.FEDERAL_REGULATIONS,
      bindingLevel: BindingLevel.FEDERAL_MANDATE,
      programTypes: [ProgramType.MEDICAID],
      jurisdictions: ['FEDERAL'],
      citation: '42 CFR Part 438',
      url: 'https://www.medicaid.gov/medicaid/managed-care/guidance/final-rule/index.html',
    },
    {
      title: 'California Medicaid (Medi-Cal) Provider Manual',
      description: 'Official provider manual for California Medicaid program.',
      authorityLayer: AuthorityLayer.STATE_GUIDANCE,
      bindingLevel: BindingLevel.STATE_MANDATE,
      programTypes: [ProgramType.MEDICAID],
      jurisdictions: ['CA'],
      citation: 'Medi-Cal Provider Manual',
      url: 'https://www.medi-cal.ca.gov/',
    },
  ];

  for (const sourceData of sources) {
    await prisma.source.upsert({
      where: { id: `source-${sourceData.title.slice(0, 20).replace(/\s+/g, '-').toLowerCase()}` },
      update: {},
      create: {
        id: `source-${sourceData.title.slice(0, 20).replace(/\s+/g, '-').toLowerCase()}`,
        ...sourceData,
        workspaceId: workspace.id,
        uploadedById: user.id,
        status: 'ACTIVE',
      },
    });
  }
  console.log('✅ Sample sources created');

  // Create sample templates
  const templates = [
    {
      name: 'Eligibility Verification',
      description: 'Template for verifying patient eligibility for Medicaid/Medicare programs.',
      category: 'ELIGIBILITY',
      content: `Please verify eligibility for the following patient:

Patient Name: {{patientName}}
Date of Birth: {{dateOfBirth}}
Medicaid ID: {{medicaidId}}
State: {{state}}

What are the eligibility requirements and verification procedures for {{program}} in {{state}}?`,
      variables: [
        { name: 'patientName', type: 'string', label: 'Patient Name', required: true },
        { name: 'dateOfBirth', type: 'date', label: 'Date of Birth', required: true },
        { name: 'medicaidId', type: 'string', label: 'Medicaid ID', required: false },
        { name: 'state', type: 'string', label: 'State', required: true },
        { name: 'program', type: 'select', label: 'Program', required: true, options: ['Medicaid', 'Medicare', 'Both'] },
      ],
      authorityLayers: [AuthorityLayer.FEDERAL_REGULATIONS, AuthorityLayer.STATE_GUIDANCE],
      programTypes: [ProgramType.MEDICAID, ProgramType.MEDICARE],
      isPublic: true,
    },
    {
      name: 'Prior Authorization Request',
      description: 'Template for prior authorization requirements.',
      category: 'COMPLIANCE',
      content: `What are the prior authorization requirements for {{serviceType}} under {{program}} in {{state}}?

Service Details:
- Service Type: {{serviceType}}
- Diagnosis Code: {{diagnosisCode}}
- Provider Type: {{providerType}}

Please include:
1. Required documentation
2. Timeframes for approval
3. Appeal procedures if denied`,
      variables: [
        { name: 'serviceType', type: 'string', label: 'Service Type', required: true },
        { name: 'program', type: 'select', label: 'Program', required: true, options: ['Medicaid', 'Medicare', 'Commercial'] },
        { name: 'state', type: 'string', label: 'State', required: true },
        { name: 'diagnosisCode', type: 'string', label: 'Diagnosis Code (ICD-10)', required: false },
        { name: 'providerType', type: 'string', label: 'Provider Type', required: true },
      ],
      authorityLayers: [AuthorityLayer.FEDERAL_REGULATIONS, AuthorityLayer.STATE_REGULATIONS],
      programTypes: [ProgramType.MEDICAID, ProgramType.MEDICARE, ProgramType.COMMERCIAL],
      isPublic: true,
    },
    {
      name: 'Appeals Process',
      description: 'Template for understanding appeals and grievances procedures.',
      category: 'APPEALS',
      content: `What is the appeals process for {{program}} in {{state}}?

Appeal Type: {{appealType}}
Denial Reason: {{denialReason}}

Please provide:
1. Timeframes for filing an appeal
2. Required documentation
3. Levels of appeal available
4. Expedited appeal procedures (if applicable)`,
      variables: [
        { name: 'program', type: 'select', label: 'Program', required: true, options: ['Medicaid', 'Medicare', 'Commercial'] },
        { name: 'state', type: 'string', label: 'State', required: true },
        { name: 'appealType', type: 'select', label: 'Appeal Type', required: true, options: ['Claim Denial', 'Service Denial', 'Eligibility Denial'] },
        { name: 'denialReason', type: 'string', label: 'Denial Reason', required: false },
      ],
      authorityLayers: [AuthorityLayer.FEDERAL_REGULATIONS, AuthorityLayer.STATE_REGULATIONS],
      programTypes: [ProgramType.MEDICAID, ProgramType.MEDICARE, ProgramType.COMMERCIAL],
      isPublic: true,
    },
  ];

  for (const templateData of templates) {
    await prisma.template.upsert({
      where: { id: `template-${templateData.name.toLowerCase().replace(/\s+/g, '-')}` },
      update: {},
      create: {
        id: `template-${templateData.name.toLowerCase().replace(/\s+/g, '-')}`,
        ...templateData,
        createdBy: user.id,
        variables: templateData.variables as any,
      },
    });
  }
  console.log('✅ Sample templates created');

  console.log('\n🎉 Database seeding completed!');
  console.log('\nLogin credentials:');
  console.log('  Admin: admin@requi.health / admin123');
  console.log('  Demo:  demo@requi.health / demo123');
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
