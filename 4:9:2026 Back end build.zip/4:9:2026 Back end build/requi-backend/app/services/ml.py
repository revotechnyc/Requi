"""
ML service for gap detection, confidence scoring, and Claude integration
"""

import json
from typing import List, Optional, Tuple
from uuid import UUID

import anthropic
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.models import GapTask, GapTaskStatus, KnowledgeRecord, KnowledgeStatus
from app.services.retrieval import RetrievalService

# Initialize Anthropic client
claude_client = anthropic.AsyncAnthropic(api_key=settings.anthropic_api_key)


class ConfidenceScorer:
    """Score confidence of retrieved knowledge"""
    
    @staticmethod
    def calculate_relevance_score(retrieval_score: float) -> float:
        """Calculate relevance score from retrieval similarity"""
        return min(max(retrieval_score, 0.0), 1.0)
    
    @staticmethod
    def calculate_recency_score(document_date: Optional[str]) -> float:
        """Calculate recency score from document date"""
        if not document_date:
            return 0.5  # Unknown date = neutral score
        
        # TODO: Implement actual date comparison
        return 1.0
    
    @staticmethod
    def calculate_trust_score(authority_score: float, is_official: bool) -> float:
        """Calculate trust score from source authority"""
        base_score = authority_score
        if is_official:
            base_score = min(base_score + 0.2, 1.0)
        return base_score
    
    @staticmethod
    def calculate_agreement_score(sources: List[dict]) -> float:
        """Calculate agreement score across multiple sources"""
        if len(sources) <= 1:
            return 1.0  # Single source = perfect agreement
        
        # TODO: Implement semantic agreement checking
        return 0.8
    
    @staticmethod
    def calculate_overall_confidence(
        relevance: float,
        recency: float,
        trust: float,
        agreement: float,
    ) -> float:
        """Calculate overall confidence score"""
        # Weighted average
        weights = {
            "relevance": 0.35,
            "recency": 0.20,
            "trust": 0.30,
            "agreement": 0.15,
        }
        
        confidence = (
            relevance * weights["relevance"] +
            recency * weights["recency"] +
            trust * weights["trust"] +
            agreement * weights["agreement"]
        )
        
        return round(confidence, 3)


class GapDetectionService:
    """Knowledge gap detection service"""
    
    def __init__(self):
        self.confidence_scorer = ConfidenceScorer()
        self.retrieval_service = RetrievalService()
    
    async def detect_gap(
        self,
        db: AsyncSession,
        organization_id: UUID,
        query: str,
        context: str,
        citations: List[dict],
    ) -> Tuple[bool, float, str]:
        """
        Detect if there's a knowledge gap
        Returns: (is_gap, confidence, description)
        """
        # Calculate confidence scores
        if not citations:
            return True, 1.0, "No relevant sources found for this query"
        
        # Get average retrieval score
        avg_retrieval_score = sum(c["relevance_score"] for c in citations) / len(citations)
        
        # Calculate individual scores
        relevance = self.confidence_scorer.calculate_relevance_score(avg_retrieval_score)
        recency = 1.0  # Assume recent for now
        trust = 0.8    # Assume trusted sources
        agreement = self.confidence_scorer.calculate_agreement_score(citations)
        
        overall_confidence = self.confidence_scorer.calculate_overall_confidence(
            relevance, recency, trust, agreement
        )
        
        # Check against threshold
        if overall_confidence < settings.gap_detection_threshold:
            gap_description = self._generate_gap_description(
                query, overall_confidence, relevance, recency, trust, agreement
            )
            return True, overall_confidence, gap_description
        
        return False, overall_confidence, ""
    
    def _generate_gap_description(
        self,
        query: str,
        confidence: float,
        relevance: float,
        recency: float,
        trust: float,
        agreement: float,
    ) -> str:
        """Generate human-readable gap description"""
        issues = []
        
        if relevance < 0.5:
            issues.append("low relevance of available sources")
        if recency < 0.5:
            issues.append("outdated information")
        if trust < 0.5:
            issues.append("low trust in source authority")
        if agreement < 0.5:
            issues.append("conflicting information across sources")
        
        if issues:
            return f"Knowledge gap detected due to {', '.join(issues)}"
        
        return f"Knowledge gap detected (confidence: {confidence:.2f})"
    
    async def create_gap_task(
        self,
        db: AsyncSession,
        organization_id: UUID,
        original_query: str,
        gap_description: str,
        confidence_score: float,
    ) -> GapTask:
        """Create a gap resolution task"""
        task = GapTask(
            organization_id=organization_id,
            original_query=original_query,
            gap_description=gap_description,
            confidence_score=confidence_score,
            status=GapTaskStatus.DETECTED,
        )
        
        db.add(task)
        await db.commit()
        await db.refresh(task)
        
        return task


class ClaudeService:
    """Claude LLM service for answer generation"""
    
    SYSTEM_PROMPT = """You are a healthcare compliance expert AI assistant. 

Your role is to provide accurate, well-sourced compliance guidance based on the provided context.

Rules:
1. Only use information from the provided context
2. If the context doesn't contain enough information, say so clearly
3. Always cite your sources using [Source X] format
4. Structure your answers clearly with headings and bullet points
5. Include confidence level (High/Medium/Low) based on source quality
6. Never make up information or hallucinate

Response format:
- Brief summary (1-2 sentences)
- Detailed answer with citations
- Key takeaways
- Confidence level"""
    
    async def generate_answer(
        self,
        query: str,
        context: str,
        conversation_history: Optional[List[dict]] = None,
    ) -> dict:
        """Generate answer using Claude"""
        # Build messages
        messages = []
        
        # Add conversation history if provided
        if conversation_history:
            for msg in conversation_history[-5:]:  # Last 5 messages
                messages.append({
                    "role": msg["role"],
                    "content": msg["content"],
                })
        
        # Add current query with context
        user_message = f"""Context:
{context}

---

Question: {query}

Please provide a comprehensive answer based on the context above."""
        
        messages.append({
            "role": "user",
            "content": user_message,
        })
        
        # Call Claude
        try:
            response = await claude_client.messages.create(
                model=settings.claude_model,
                max_tokens=settings.claude_max_tokens,
                system=self.SYSTEM_PROMPT,
                messages=messages,
            )
            
            answer = response.content[0].text
            
            # Extract confidence level
            confidence = self._extract_confidence(answer)
            
            return {
                "answer": answer,
                "confidence": confidence,
                "model": settings.claude_model,
                "tokens_used": response.usage.input_tokens + response.usage.output_tokens,
            }
        
        except Exception as e:
            return {
                "answer": f"Error generating answer: {str(e)}",
                "confidence": "low",
                "model": settings.claude_model,
                "tokens_used": 0,
            }
    
    def _extract_confidence(self, answer: str) -> str:
        """Extract confidence level from answer"""
        answer_lower = answer.lower()
        
        if "confidence: high" in answer_lower or "high confidence" in answer_lower:
            return "high"
        elif "confidence: low" in answer_lower or "low confidence" in answer_lower:
            return "low"
        
        return "medium"
    
    async def rewrite_query(
        self,
        query: str,
        conversation_history: Optional[List[dict]] = None,
    ) -> str:
        """Rewrite query for better retrieval"""
        prompt = f"""Rewrite the following healthcare compliance query to be more specific and searchable:

Original query: {query}

Rewritten query:"""
        
        try:
            response = await claude_client.messages.create(
                model=settings.claude_model,
                max_tokens=200,
                messages=[{"role": "user", "content": prompt}],
            )
            
            return response.content[0].text.strip()
        
        except Exception:
            return query  # Return original on error
    
    async def summarize_conflict(
        self,
        sources: List[dict],
    ) -> str:
        """Summarize conflicting information from sources"""
        sources_text = "\n\n".join([
            f"Source {i+1}: {s.get('excerpt', '')}"
            for i, s in enumerate(sources)
        ])
        
        prompt = f"""Summarize the key points of agreement and disagreement across these sources:

{sources_text}

Summary:"""
        
        try:
            response = await claude_client.messages.create(
                model=settings.claude_model,
                max_tokens=500,
                messages=[{"role": "user", "content": prompt}],
            )
            
            return response.content[0].text.strip()
        
        except Exception as e:
            return f"Error summarizing: {str(e)}"
    
    async def generate_proposed_knowledge(
        self,
        query: str,
        context: str,
        citations: List[dict],
    ) -> dict:
        """Generate proposed knowledge record from gap resolution"""
        prompt = f"""Based on the following context, create a structured knowledge record:

Query: {query}

Context:
{context}

Generate:
1. A clear topic/title
2. The core question being answered
3. A comprehensive answer with citations
4. Key takeaways

Format as JSON:
{{
    "topic": "...",
    "question": "...",
    "answer": "...",
    "takeaways": ["..."]
}}"""
        
        try:
            response = await claude_client.messages.create(
                model=settings.claude_model,
                max_tokens=2000,
                messages=[{"role": "user", "content": prompt}],
            )
            
            # Parse JSON response
            content = response.content[0].text
            
            # Extract JSON from response
            json_start = content.find("{")
            json_end = content.rfind("}") + 1
            
            if json_start >= 0 and json_end > json_start:
                json_str = content[json_start:json_end]
                parsed = json.loads(json_str)
                return parsed
            
            return {
                "topic": query[:100],
                "question": query,
                "answer": content,
                "takeaways": [],
            }
        
        except Exception as e:
            return {
                "topic": query[:100],
                "question": query,
                "answer": f"Error generating knowledge: {str(e)}",
                "takeaways": [],
            }


class MLService:
    """Main ML service combining all components"""
    
    def __init__(self):
        self.claude = ClaudeService()
        self.gap_detection = GapDetectionService()
        self.retrieval = RetrievalService()
    
    async def answer_query(
        self,
        db: AsyncSession,
        organization_id: UUID,
        query: str,
        conversation_history: Optional[List[dict]] = None,
    ) -> dict:
        """Full pipeline: retrieve context, generate answer, detect gaps"""
        # Step 1: Rewrite query for better retrieval
        rewritten_query = await self.claude.rewrite_query(query, conversation_history)
        
        # Step 2: Retrieve relevant context
        context, citations = await self.retrieval.get_context_for_query(
            db, organization_id, rewritten_query
        )
        
        # Step 3: Detect knowledge gap
        is_gap, confidence, gap_description = await self.gap_detection.detect_gap(
            db, organization_id, query, context, citations
        )
        
        # Step 4: Generate answer
        answer_result = await self.claude.generate_answer(
            query, context, conversation_history
        )
        
        # Step 5: Create gap task if needed (for TEAM+ plans)
        gap_task_id = None
        if is_gap:
            gap_task = await self.gap_detection.create_gap_task(
                db, organization_id, query, gap_description, confidence
            )
            gap_task_id = str(gap_task.id)
        
        return {
            "query": query,
            "rewritten_query": rewritten_query,
            "answer": answer_result["answer"],
            "confidence": answer_result["confidence"],
            "citations": citations,
            "knowledge_gap_detected": is_gap,
            "gap_confidence": confidence,
            "gap_description": gap_description if is_gap else None,
            "gap_task_id": gap_task_id,
            "tokens_used": answer_result["tokens_used"],
        }
