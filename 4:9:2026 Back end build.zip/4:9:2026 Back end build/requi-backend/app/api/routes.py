"""
API routes registration
"""

from fastapi import APIRouter

from app.api.endpoints import (
    admin,
    ai,
    auth,
    billing,
    knowledge,
    organizations,
    sources,
    users,
)

api_router = APIRouter()

# Auth routes (no auth required)
api_router.include_router(auth.router, prefix="/auth", tags=["auth"])

# Protected routes
api_router.include_router(
    users.router,
    prefix="/users",
    tags=["users"],
    dependencies=[],  # Add auth dependency
)

api_router.include_router(
    organizations.router,
    prefix="/organizations",
    tags=["organizations"],
)

api_router.include_router(
    billing.router,
    prefix="/billing",
    tags=["billing"],
)

api_router.include_router(
    sources.router,
    prefix="/sources",
    tags=["sources"],
)

api_router.include_router(
    knowledge.router,
    prefix="/knowledge",
    tags=["knowledge"],
)

api_router.include_router(
    ai.router,
    prefix="/ai",
    tags=["ai"],
)

api_router.include_router(
    admin.router,
    prefix="/admin",
    tags=["admin"],
)
