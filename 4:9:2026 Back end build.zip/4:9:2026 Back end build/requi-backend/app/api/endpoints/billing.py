"""
Billing endpoints with Stripe integration
"""

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.endpoints.auth import get_current_active_user
from app.core.config import settings
from app.core.permissions import Feature, check_feature_access, require_feature_dependency
from app.db.database import get_db
from app.db.models import Organization, PlanType, Seat, Subscription, SubscriptionStatus, User
from app.services.billing import BillingService

router = APIRouter()


# Pydantic models
class SubscriptionCreate(BaseModel):
    plan_type: str  # core, team, enterprise
    seat_quantity: int
    payment_method_id: Optional[str] = None


class SubscriptionUpdate(BaseModel):
    plan_type: Optional[str] = None
    seat_quantity: Optional[int] = None


class CheckoutSessionCreate(BaseModel):
    plan_type: str
    seat_quantity: int
    success_url: str
    cancel_url: str


@router.post("/subscriptions")
async def create_subscription(
    data: SubscriptionCreate,
    organization_id: str,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Create new subscription"""
    # Get organization
    result = await db.execute(
        select(Organization).where(Organization.id == organization_id)
    )
    org = result.scalar_one_or_none()
    
    if not org:
        raise HTTPException(status_code=404, detail="Organization not found")
    
    # Check if user is owner/admin
    seat_result = await db.execute(
        select(Seat).where(
            Seat.organization_id == organization_id,
            Seat.user_id == current_user.id,
        )
    )
    seat = seat_result.scalar_one_or_none()
    
    if not seat or seat.role.value not in ["owner", "admin"]:
        raise HTTPException(status_code=403, detail="Only owners and admins can manage billing")
    
    # Check if subscription already exists
    if org.subscription and org.subscription.is_active():
        raise HTTPException(status_code=400, detail="Active subscription already exists")
    
    # Parse plan type
    try:
        plan_type = PlanType(data.plan_type.lower())
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid plan type")
    
    # Create subscription
    subscription = await BillingService.create_subscription(
        db, org, plan_type, data.seat_quantity, data.payment_method_id
    )
    
    return {
        "subscription_id": str(subscription.id),
        "stripe_subscription_id": subscription.stripe_subscription_id,
        "status": subscription.status.value,
        "client_secret": None,  # Would be populated from Stripe
    }


@router.patch("/subscriptions/{subscription_id}")
async def update_subscription(
    subscription_id: str,
    data: SubscriptionUpdate,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Update subscription (change plan or seats)"""
    # Get subscription
    result = await db.execute(
        select(Subscription).where(Subscription.id == subscription_id)
    )
    subscription = result.scalar_one_or_none()
    
    if not subscription:
        raise HTTPException(status_code=404, detail="Subscription not found")
    
    # Check permissions
    org_result = await db.execute(
        select(Organization).where(Organization.id == subscription.organization_id)
    )
    org = org_result.scalar_one()
    
    seat_result = await db.execute(
        select(Seat).where(
            Seat.organization_id == org.id,
            Seat.user_id == current_user.id,
        )
    )
    seat = seat_result.scalar_one_or_none()
    
    if not seat or seat.role.value not in ["owner", "admin"]:
        raise HTTPException(status_code=403, detail="Only owners and admins can manage billing")
    
    # Parse plan type if provided
    plan_type = None
    if data.plan_type:
        try:
            plan_type = PlanType(data.plan_type.lower())
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid plan type")
    
    # Update subscription
    updated = await BillingService.update_subscription(
        db, subscription, plan_type, data.seat_quantity
    )
    
    return {
        "subscription_id": str(updated.id),
        "plan_type": updated.plan_type.value,
        "seat_quantity": updated.seat_quantity,
        "status": updated.status.value,
    }


@router.delete("/subscriptions/{subscription_id}")
async def cancel_subscription(
    subscription_id: str,
    immediately: bool = False,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Cancel subscription"""
    result = await db.execute(
        select(Subscription).where(Subscription.id == subscription_id)
    )
    subscription = result.scalar_one_or_none()
    
    if not subscription:
        raise HTTPException(status_code=404, detail="Subscription not found")
    
    # Check permissions
    org_result = await db.execute(
        select(Organization).where(Organization.id == subscription.organization_id)
    )
    org = org_result.scalar_one()
    
    seat_result = await db.execute(
        select(Seat).where(
            Seat.organization_id == org.id,
            Seat.user_id == current_user.id,
        )
    )
    seat = seat_result.scalar_one_or_none()
    
    if not seat or seat.role.value not in ["owner", "admin"]:
        raise HTTPException(status_code=403, detail="Only owners and admins can manage billing")
    
    cancelled = await BillingService.cancel_subscription(db, subscription, immediately)
    
    return {
        "subscription_id": str(cancelled.id),
        "status": cancelled.status.value,
        "cancel_at_period_end": cancelled.cancel_at_period_end,
    }


@router.post("/checkout-session")
async def create_checkout_session(
    data: CheckoutSessionCreate,
    organization_id: str,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Create Stripe checkout session"""
    result = await db.execute(
        select(Organization).where(Organization.id == organization_id)
    )
    org = result.scalar_one_or_none()
    
    if not org:
        raise HTTPException(status_code=404, detail="Organization not found")
    
    # Ensure customer exists
    if not org.owner.stripe_customer_id:
        customer_id = await BillingService.create_customer(org.owner, org)
        org.owner.stripe_customer_id = customer_id
        await db.commit()
    
    try:
        plan_type = PlanType(data.plan_type.lower())
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid plan type")
    
    session = await BillingService.get_checkout_session(
        org, plan_type, data.seat_quantity, data.success_url, data.cancel_url
    )
    
    return session


@router.post("/portal-session")
async def create_portal_session(
    organization_id: str,
    return_url: str,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Create Stripe customer portal session"""
    result = await db.execute(
        select(Organization).where(Organization.id == organization_id)
    )
    org = result.scalar_one_or_none()
    
    if not org:
        raise HTTPException(status_code=404, detail="Organization not found")
    
    session = await BillingService.get_portal_session(org, return_url)
    return session


@router.post("/webhook")
async def stripe_webhook(
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """Handle Stripe webhook events"""
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature")
    
    try:
        import stripe
        event = stripe.Webhook.construct_event(
            payload, sig_header, settings.stripe_webhook_secret
        )
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid payload")
    except stripe.error.SignatureVerificationError:
        raise HTTPException(status_code=400, detail="Invalid signature")
    
    # Handle event
    await BillingService.handle_webhook(db, event["type"], event["data"]["object"])
    
    return {"status": "success"}


@router.get("/plans")
async def get_plans():
    """Get available pricing plans"""
    return {
        "core": {
            "name": "Core",
            "price_per_seat": settings.core_plan_price,
            "min_seats": settings.core_plan_min_seats,
            "max_seats": settings.core_plan_max_seats,
            "features": [
                "AI compliance Q&A",
                "Limited query volume",
            ],
        },
        "team": {
            "name": "Team",
            "price_per_seat": settings.team_plan_price,
            "min_seats": settings.team_plan_min_seats,
            "max_seats": settings.team_plan_max_seats,
            "features": [
                "AI compliance Q&A",
                "Knowledge gap detection",
                "Shared team knowledge base",
                "Basic analytics",
            ],
        },
        "enterprise": {
            "name": "Enterprise",
            "price_per_seat": settings.enterprise_plan_price,
            "min_seats": settings.enterprise_plan_min_seats,
            "max_seats": settings.enterprise_plan_max_seats,
            "features": [
                "Full AI + ML system",
                "Automated knowledge validation",
                "Daily self-update jobs",
                "Admin dashboards",
                "Full audit logs",
                "Priority processing",
            ],
        },
    }
