"""
AI Q&A endpoints
"""

from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.endpoints.auth import get_current_active_user
from app.core.permissions import Feature, check_feature_access, require_feature_dependency
from app.db.database import get_db
from app.db.models import Conversation, Message, Organization, User
from app.services.ml import MLService

router = APIRouter()
ml_service = MLService()


# Pydantic models
class AskRequest(BaseModel):
    question: str
    conversation_id: Optional[str] = None


class AskResponse(BaseModel):
    answer: str
    confidence: str
    citations: List[dict]
    knowledge_gap_detected: bool
    gap_description: Optional[str] = None
    gap_task_id: Optional[str] = None
    tokens_used: int


class ConversationCreate(BaseModel):
    title: Optional[str] = None


class MessageResponse(BaseModel):
    id: str
    role: str
    content: str
    citations: Optional[List[dict]] = None
    created_at: str


class ConversationResponse(BaseModel):
    id: str
    title: Optional[str]
    messages: List[MessageResponse]
    created_at: str
    updated_at: str


@router.post("/ask", response_model=AskResponse)
async def ask_question(
    request: AskRequest,
    organization: Organization = Depends(lambda: require_feature_dependency(Feature.AI_QA)),
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Ask a compliance question"""
    # Get or create conversation
    conversation = None
    conversation_history = []
    
    if request.conversation_id:
        result = await db.execute(
            select(Conversation).where(
                Conversation.id == request.conversation_id,
                Conversation.user_id == current_user.id,
            )
        )
        conversation = result.scalar_one_or_none()
        
        if conversation:
            # Build conversation history
            for msg in conversation.messages:
                conversation_history.append({
                    "role": msg.role,
                    "content": msg.content,
                })
    
    # Get answer from ML service
    result = await ml_service.answer_query(
        db,
        organization.id,
        request.question,
        conversation_history if conversation_history else None,
    )
    
    # Save to conversation
    if conversation:
        # Add user message
        user_msg = Message(
            conversation_id=conversation.id,
            role="user",
            content=request.question,
        )
        db.add(user_msg)
        
        # Add assistant message
        assistant_msg = Message(
            conversation_id=conversation.id,
            role="assistant",
            content=result["answer"],
            citations=result["citations"],
            confidence_score=0.8 if result["confidence"] == "high" else 0.5 if result["confidence"] == "medium" else 0.3,
        )
        db.add(assistant_msg)
        await db.commit()
    
    return AskResponse(
        answer=result["answer"],
        confidence=result["confidence"],
        citations=result["citations"],
        knowledge_gap_detected=result["knowledge_gap_detected"],
        gap_description=result.get("gap_description"),
        gap_task_id=result.get("gap_task_id"),
        tokens_used=result["tokens_used"],
    )


@router.post("/conversations", response_model=dict)
async def create_conversation(
    data: ConversationCreate,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Create new conversation"""
    # Get user's organization
    from app.db.models import Seat
    
    result = await db.execute(
        select(Seat).where(
            Seat.user_id == current_user.id,
            Seat.is_active == True,
        )
    )
    seat = result.scalar_one_or_none()
    
    if not seat:
        raise HTTPException(status_code=400, detail="No active organization")
    
    conversation = Conversation(
        organization_id=seat.organization_id,
        user_id=current_user.id,
        title=data.title or "New Conversation",
    )
    db.add(conversation)
    await db.commit()
    await db.refresh(conversation)
    
    return {
        "id": str(conversation.id),
        "title": conversation.title,
        "created_at": conversation.created_at.isoformat(),
    }


@router.get("/conversations", response_model=List[dict])
async def list_conversations(
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """List user's conversations"""
    result = await db.execute(
        select(Conversation)
        .where(Conversation.user_id == current_user.id)
        .order_by(Conversation.updated_at.desc())
    )
    conversations = result.scalars().all()
    
    return [
        {
            "id": str(c.id),
            "title": c.title,
            "message_count": len(c.messages),
            "created_at": c.created_at.isoformat(),
            "updated_at": c.updated_at.isoformat(),
        }
        for c in conversations
    ]


@router.get("/conversations/{conversation_id}", response_model=ConversationResponse)
async def get_conversation(
    conversation_id: str,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Get conversation with messages"""
    result = await db.execute(
        select(Conversation).where(
            Conversation.id == conversation_id,
            Conversation.user_id == current_user.id,
        )
    )
    conversation = result.scalar_one_or_none()
    
    if not conversation:
        raise HTTPException(status_code=404, detail="Conversation not found")
    
    return ConversationResponse(
        id=str(conversation.id),
        title=conversation.title,
        messages=[
            MessageResponse(
                id=str(m.id),
                role=m.role,
                content=m.content,
                citations=m.citations,
                created_at=m.created_at.isoformat(),
            )
            for m in conversation.messages
        ],
        created_at=conversation.created_at.isoformat(),
        updated_at=conversation.updated_at.isoformat(),
    )


@router.delete("/conversations/{conversation_id}")
async def delete_conversation(
    conversation_id: str,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete conversation"""
    result = await db.execute(
        select(Conversation).where(
            Conversation.id == conversation_id,
            Conversation.user_id == current_user.id,
        )
    )
    conversation = result.scalar_one_or_none()
    
    if not conversation:
        raise HTTPException(status_code=404, detail="Conversation not found")
    
    await db.delete(conversation)
    await db.commit()
    
    return {"status": "deleted"}
