"""
Feature gating and permission system
Controls access based on subscription plan and user role
"""

from enum import Enum
from functools import wraps
from typing import Callable, Optional

from fastapi import Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.database import get_db
from app.db.models import (
    Organization,
    PlanType,
    Seat,
    Subscription,
    SubscriptionStatus,
    User,
    UserRole,
)


class Feature(str, Enum):
    """Feature flags for gating"""
    AI_QA = "ai_qa"
    KNOWLEDGE_STORAGE = "knowledge_storage"
    GAP_DETECTION = "gap_detection"
    GAP_RESOLUTION = "gap_resolution"
    TEAM_COLLABORATION = "team_collaboration"
    DAILY_AUTO_UPDATE = "daily_auto_update"
    ADMIN_DASHBOARD = "admin_dashboard"
    CUSTOM_SOURCES = "custom_sources"
    AUDIT_LOGS = "audit_logs"
    PRIORITY_PROCESSING = "priority_processing"
    MULTI_STATE = "multi_state"
    ENTERPRISE_INTEGRATIONS = "enterprise_integrations"


# Feature gating matrix
FEATURE_MATRIX = {
    PlanType.CORE: {
        Feature.AI_QA: True,
        Feature.KNOWLEDGE_STORAGE: False,
        Feature.GAP_DETECTION: False,
        Feature.GAP_RESOLUTION: False,
        Feature.TEAM_COLLABORATION: False,
        Feature.DAILY_AUTO_UPDATE: False,
        Feature.ADMIN_DASHBOARD: False,
        Feature.CUSTOM_SOURCES: False,
        Feature.AUDIT_LOGS: False,
        Feature.PRIORITY_PROCESSING: False,
        Feature.MULTI_STATE: False,
        Feature.ENTERPRISE_INTEGRATIONS: False,
    },
    PlanType.TEAM: {
        Feature.AI_QA: True,
        Feature.KNOWLEDGE_STORAGE: True,
        Feature.GAP_DETECTION: True,
        Feature.GAP_RESOLUTION: True,
        Feature.TEAM_COLLABORATION: True,
        Feature.DAILY_AUTO_UPDATE: False,
        Feature.ADMIN_DASHBOARD: False,
        Feature.CUSTOM_SOURCES: False,
        Feature.AUDIT_LOGS: False,
        Feature.PRIORITY_PROCESSING: False,
        Feature.MULTI_STATE: False,
        Feature.ENTERPRISE_INTEGRATIONS: False,
    },
    PlanType.ENTERPRISE: {
        Feature.AI_QA: True,
        Feature.KNOWLEDGE_STORAGE: True,
        Feature.GAP_DETECTION: True,
        Feature.GAP_RESOLUTION: True,
        Feature.TEAM_COLLABORATION: True,
        Feature.DAILY_AUTO_UPDATE: True,
        Feature.ADMIN_DASHBOARD: True,
        Feature.CUSTOM_SOURCES: True,
        Feature.AUDIT_LOGS: True,
        Feature.PRIORITY_PROCESSING: True,
        Feature.MULTI_STATE: True,
        Feature.ENTERPRISE_INTEGRATIONS: True,
    },
}


# Role permissions
ROLE_PERMISSIONS = {
    UserRole.OWNER: [
        "org:read", "org:write", "org:delete",
        "billing:read", "billing:write",
        "users:read", "users:write", "users:delete",
        "sources:read", "sources:write", "sources:delete",
        "knowledge:read", "knowledge:write", "knowledge:approve",
        "admin:full",
    ],
    UserRole.ADMIN: [
        "org:read",
        "billing:read",
        "users:read", "users:write",
        "sources:read", "sources:write",
        "knowledge:read", "knowledge:write", "knowledge:approve",
        "admin:read",
    ],
    UserRole.MANAGER: [
        "org:read",
        "users:read",
        "sources:read", "sources:write",
        "knowledge:read", "knowledge:write",
    ],
    UserRole.ANALYST: [
        "org:read",
        "sources:read",
        "knowledge:read",
        "ai:use",
    ],
    UserRole.VIEWER: [
        "org:read",
        "knowledge:read",
    ],
}


class FeatureGate:
    """Feature gating service"""
    
    @staticmethod
    def has_feature(plan_type: PlanType, feature: Feature) -> bool:
        """Check if a plan has access to a feature"""
        return FEATURE_MATRIX.get(plan_type, {}).get(feature, False)
    
    @staticmethod
    def require_feature(feature: Feature):
        """Decorator to require a feature for an endpoint"""
        def decorator(func: Callable):
            @wraps(func)
            async def wrapper(*args, **kwargs):
                # Get organization from kwargs or dependency
                org = kwargs.get('organization')
                if not org:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Organization context required"
                    )
                
                # Get subscription
                subscription = getattr(org, 'subscription', None)
                if not subscription or not subscription.is_active():
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Active subscription required"
                    )
                
                # Check feature
                if not FeatureGate.has_feature(subscription.plan_type, feature):
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail=f"Feature '{feature.value}' not available on your plan"
                    )
                
                return await func(*args, **kwargs)
            return wrapper
        return decorator


class PermissionChecker:
    """Permission checking service"""
    
    @staticmethod
    def has_permission(user_role: UserRole, permission: str) -> bool:
        """Check if a role has a specific permission"""
        permissions = ROLE_PERMISSIONS.get(user_role, [])
        return permission in permissions or "admin:full" in permissions
    
    @staticmethod
    def require_permission(permission: str):
        """Dependency to require a permission"""
        async def checker(
            current_user: User = Depends(get_current_user),
            db: AsyncSession = Depends(get_db),
        ) -> User:
            # Get user's seat/role in organization
            seat = await db.execute(
                select(Seat).where(
                    Seat.user_id == current_user.id,
                    Seat.is_active == True
                )
            )
            seat = seat.scalar_one_or_none()
            
            if not seat:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Not a member of this organization"
                )
            
            if not PermissionChecker.has_permission(seat.role, permission):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Permission '{permission}' required"
                )
            
            return current_user
        return checker


# Import here to avoid circular dependency
from app.services.auth import get_current_user
from sqlalchemy import select


async def check_organization_access(
    user: User,
    organization_id: str,
    db: AsyncSession,
    require_active_subscription: bool = True,
) -> Organization:
    """Check if user has access to organization"""
    from sqlalchemy import select
    
    # Get organization with subscription
    result = await db.execute(
        select(Organization)
        .where(Organization.id == organization_id)
        .options(
            selectinload(Organization.subscription),
            selectinload(Organization.seats),
        )
    )
    org = result.scalar_one_or_none()
    
    if not org:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Organization not found"
        )
    
    # Check if user is member
    is_member = any(
        seat.user_id == user.id and seat.is_active
        for seat in org.seats
    )
    
    if not is_member and not user.is_superuser:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    # Check subscription if required
    if require_active_subscription:
        if not org.subscription or not org.subscription.is_active():
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Active subscription required"
            )
    
    return org


async def check_feature_access(
    organization: Organization,
    feature: Feature,
) -> bool:
    """Check if organization has access to a feature"""
    if not organization.subscription:
        return False
    
    if not organization.subscription.is_active():
        return False
    
    return FeatureGate.has_feature(
        organization.subscription.plan_type,
        feature
    )


# Dependencies for FastAPI
async def require_feature_dependency(
    feature: Feature,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> Organization:
    """Dependency that requires a specific feature"""
    # Get user's active organization
    result = await db.execute(
        select(Seat)
        .where(
            Seat.user_id == current_user.id,
            Seat.is_active == True
        )
        .options(selectinload(Seat.organization).selectinload(Organization.subscription))
    )
    seat = result.scalar_one_or_none()
    
    if not seat:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No active organization membership"
        )
    
    org = seat.organization
    
    if not await check_feature_access(org, feature):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Feature '{feature.value}' not available on your plan"
        )
    
    return org
