"""
Application configuration using Pydantic Settings
"""

from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings loaded from environment variables"""
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
    )
    
    # Application
    app_name: str = "Requi Health API"
    app_env: str = "development"
    debug: bool = False
    secret_key: str = Field(..., description="Secret key for JWT signing")
    api_v1_prefix: str = "/api/v1"
    
    # Server
    host: str = "0.0.0.0"
    port: int = 8000
    
    # Database
    database_url: str = Field(..., description="PostgreSQL connection URL")
    database_pool_size: int = 20
    database_max_overflow: int = 30
    
    # Redis
    redis_url: str = "redis://localhost:6379/0"
    redis_pool_size: int = 50
    
    # Celery
    celery_broker_url: str = "redis://localhost:6379/1"
    celery_result_backend: str = "redis://localhost:6379/2"
    celery_worker_concurrency: int = 4
    
    # Authentication
    jwt_secret_key: str = Field(..., description="Secret key for JWT tokens")
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7
    
    # Anthropic Claude
    anthropic_api_key: str = Field(..., description="Anthropic API key")
    claude_model: str = "claude-3-sonnet-20240229"
    claude_max_tokens: int = 4096
    
    # OpenAI (embeddings)
    openai_api_key: str = Field(..., description="OpenAI API key")
    embedding_model: str = "text-embedding-3-small"
    
    # Stripe
    stripe_secret_key: str = Field(..., description="Stripe secret key")
    stripe_publishable_key: str = Field(..., description="Stripe publishable key")
    stripe_webhook_secret: str = Field(..., description="Stripe webhook secret")
    
    # Stripe Price IDs
    stripe_price_core: str = Field(..., description="Stripe price ID for CORE plan")
    stripe_price_team: str = Field(..., description="Stripe price ID for TEAM plan")
    stripe_price_enterprise: str = Field(..., description="Stripe price ID for ENTERPRISE plan")
    
    # Plan Configuration (in cents)
    core_plan_price: int = 20400  # $204
    core_plan_min_seats: int = 1
    core_plan_max_seats: int = 1
    
    team_plan_price: int = 75000  # $750
    team_plan_min_seats: int = 2
    team_plan_max_seats: int = 50
    
    enterprise_plan_price: int = 200400  # $2,004
    enterprise_plan_min_seats: int = 5
    enterprise_plan_max_seats: int = 1000
    
    # Knowledge Pipeline
    chunk_size: int = 1000
    chunk_overlap: int = 200
    max_sources_per_query: int = 5
    min_confidence_threshold: float = 0.7
    gap_detection_threshold: float = 0.5
    
    # Daily Update Job
    daily_update_hour: int = 2
    daily_update_minute: int = 0
    knowledge_stale_days: int = 30
    
    # Document Storage
    document_storage_type: str = "local"  # local, s3
    s3_bucket_name: Optional[str] = None
    s3_region: str = "us-east-1"
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    
    # Logging
    log_level: str = "INFO"
    log_format: str = "json"
    
    # Rate Limiting
    rate_limit_requests_per_minute: int = 60
    
    @property
    def is_production(self) -> bool:
        return self.app_env == "production"
    
    @property
    def is_development(self) -> bool:
        return self.app_env == "development"
    
    def get_plan_price(self, plan_type: str) -> int:
        """Get price in cents for a plan type"""
        prices = {
            "core": self.core_plan_price,
            "team": self.team_plan_price,
            "enterprise": self.enterprise_plan_price,
        }
        return prices.get(plan_type.lower(), 0)
    
    def get_plan_limits(self, plan_type: str) -> dict:
        """Get seat limits for a plan type"""
        limits = {
            "core": {"min": self.core_plan_min_seats, "max": self.core_plan_max_seats},
            "team": {"min": self.team_plan_min_seats, "max": self.team_plan_max_seats},
            "enterprise": {"min": self.enterprise_plan_min_seats, "max": self.enterprise_plan_max_seats},
        }
        return limits.get(plan_type.lower(), {"min": 1, "max": 1})


# Global settings instance
settings = Settings()
