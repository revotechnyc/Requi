# Requi Health — Product Architecture & Design Specification

## Executive Summary

Requi Health is an enterprise healthcare compliance operating system designed as two distinct but interconnected platforms:

1. **Admin Console (Version A)** — Internal intelligence and governance platform
2. **Enterprise User Dashboard (Version B)** — Customer-facing compliance command center

Both platforms share a unified backend intelligence engine while maintaining separate UI/UX identities, navigation logic, and branding directions.

---

## Part 1 — Product Architecture Overview

### 1.1 System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           REQUI HEALTH PLATFORM                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────┐      ┌─────────────────────────┐               │
│  │    ADMIN CONSOLE        │      │   USER DASHBOARD        │               │
│  │    (Internal Ops)       │      │   (Customer-Facing)     │               │
│  │                         │      │                         │               │
│  │  • AI Training          │      │  • Compliance Overview  │               │
│  │  • Source Management    │      │  • Gap Analysis         │               │
│  │  • Rule Engine          │      │  • Risk Scoring         │               │
│  │  • Organization Mgmt    │      │  • Task Management      │               │
│  │  • Billing Oversight    │      │  • Calendar/Deadlines   │               │
│  │  • Audit Logs           │      │  • News Feed            │               │
│  │                         │      │  • Integrations         │               │
│  └───────────┬─────────────┘      └───────────┬─────────────┘               │
│              │                                │                              │
│              └────────────────┬───────────────┘                              │
│                               │                                              │
│              ┌────────────────▼───────────────┐                              │
│              │   UNIFIED BACKEND ENGINE        │                              │
│              │                                 │                              │
│              │  • Auth Service                 │                              │
│              │  • Compliance Engine            │                              │
│              │  • Scoring Engine               │                              │
│              │  • AI/LLM Service               │                              │
│              │  • Integration Hub              │                              │
│              │  • Billing Service              │                              │
│              │  • Notification Service         │                              │
│              │  • Audit Logger                 │                              │
│              └────────────────┬───────────────┘                              │
│                               │                                              │
│              ┌────────────────▼───────────────┐                              │
│              │      DATA LAYER                 │                              │
│              │                                 │                              │
│              │  • PostgreSQL (Primary)         │                              │
│              │  • Redis (Cache/Queue)          │                              │
│              │  • Pinecone (Vector Search)     │                              │
│              │  • S3 (Document Storage)        │                              │
│              └─────────────────────────────────┘                              │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 1.2 Platform Split Rationale

| Aspect | Admin Console | User Dashboard |
|--------|---------------|----------------|
| **User** | Internal ops, engineers, compliance trainers | Enterprise customers, compliance officers |
| **Mental Model** | Control center, intelligence hub | Command center, action-oriented |
| **Visual Identity** | Dark, dense, operational | Light, spacious, executive |
| **Information Density** | High (data-rich) | Moderate (action-focused) |
| **Primary Actions** | Train, configure, monitor | Review, act, delegate |
| **Brand Feel** | Palantir + Notion + Apple | Linear + Apple + Enterprise SaaS |

### 1.3 Shared Backend Services

| Service | Admin Usage | User Usage |
|---------|-------------|------------|
| **Auth Service** | Full RBAC, super-admin roles | Org-scoped, role-based |
| **Compliance Engine** | Rule configuration, gap mapping | Gap viewing, action tracking |
| **Scoring Engine** | Score calibration, weight tuning | Score display, trend analysis |
| **AI/LLM Service** | Training, prompt governance | Query, recommendations |
| **Integration Hub** | Connector management | Sync status, configuration |
| **Billing Service** | Oversight, adjustments | Self-service, invoices |
| **Notification Service** | System alerts, customer comms | User alerts, reminders |
| **Audit Logger** | Full system audit | Org-scoped audit trail |

### 1.4 Data Flow Architecture

```
┌────────────────────────────────────────────────────────────────┐
│                        DATA FLOW                                │
├────────────────────────────────────────────────────────────────┤
│                                                                 │
│  EXTERNAL SOURCES              ADMIN CONSOLE                    │
│  ┌─────────────┐               ┌─────────────┐                  │
│  │ Regulations │──────────────▶│ AI Training │                  │
│  │ CMS/OCR/OIG │               │ Sources     │                  │
│  │ State Laws  │               │ Rules       │                  │
│  └─────────────┘               │ Templates   │                  │
│                                └──────┬──────┘                  │
│                                       │                         │
│                                       ▼                         │
│                         ┌─────────────────────┐                 │
│                         │  KNOWLEDGE GRAPH    │                 │
│                         │  (Vector DB + SQL)  │                 │
│                         └──────────┬──────────┘                 │
│                                    │                            │
│                                    ▼                            │
│  USER DASHBOARD         ┌─────────────────────┐                 │
│  ┌─────────────┐        │  SCORING ENGINE     │                 │
│  │ Compliance  │◀───────│  • Gap Detection    │                 │
│  │ Score       │        │  • Risk Calculation │                 │
│  │ Risk Score  │        │  • Audit Readiness  │                 │
│  │ Deadlines   │        │  • Deadline Engine  │                 │
│  │ Tasks       │        └─────────────────────┘                 │
│  │ News Feed   │                                               │
│  └─────────────┘                                               │
│                                                                 │
└────────────────────────────────────────────────────────────────┘
```

### 1.5 Technology Stack

| Layer | Technology |
|-------|------------|
| **Frontend** | Next.js 14 (App Router), React 18, TypeScript |
| **Styling** | Tailwind CSS, CSS Variables for theming |
| **State Management** | Zustand (global), React Query (server state) |
| **UI Components** | Radix UI primitives, custom component library |
| **Charts** | Recharts, D3 for custom visualizations |
| **Backend** | NestJS, Node.js, TypeScript |
| **Database** | PostgreSQL 15, Prisma ORM |
| **Cache/Queue** | Redis (BullMQ for jobs) |
| **Vector DB** | Pinecone (document embeddings) |
| **AI/LLM** | Anthropic Claude, OpenAI GPT-4 |
| **Search** | Algolia or Elasticsearch |
| **File Storage** | AWS S3 or Cloudflare R2 |
| **Auth** | Auth0, Clerk, or custom JWT |
| **Billing** | Stripe |
| **Monitoring** | Datadog, Sentry |

---

## Part 2 — UI/UX Redesign for Admin Console

### 2.1 Brand Identity: Admin Console

**Codename:** "Command"

**Brand Essence:** Precision, Intelligence, Control

**Logo Concept:** 
- Geometric mark suggesting a neural network or command node
- Monogram "R" with circuit-like connections
- Dark background, subtle gradient

**Color System:**

```css
/* Primary Palette */
--command-bg-primary: #0A0A0F;        /* Deep void */
--command-bg-secondary: #12121A;      /* Elevated surface */
--command-bg-tertiary: #1A1A25;       /* Card surface */

/* Accent Colors */
--command-accent-cyan: #00D4AA;       /* Primary action */
--command-accent-blue: #3B82F6;       /* Information */
--command-accent-purple: #8B5CF6;     /* AI/Intelligence */
--command-accent-amber: #F59E0B;      /* Warning */
--command-accent-rose: #F43F5E;       /* Critical */

/* Text Colors */
--command-text-primary: #FAFAFA;
--command-text-secondary: #A1A1AA;
--command-text-tertiary: #71717A;

/* Border Colors */
--command-border-subtle: rgba(255,255,255,0.06);
--command-border-default: rgba(255,255,255,0.1);
--command-border-strong: rgba(255,255,255,0.15);
```

**Typography:**
- **Primary:** Inter (clean, technical)
- **Monospace:** JetBrains Mono (code, IDs, timestamps)
- **Scale:** 12px base for dense UI, 14px for readable content

**Icon Direction:**
- Lucide icons (consistent, minimal)
- Custom icons for domain concepts
- 16px standard, 20px for emphasis

### 2.2 Information Architecture

```
Admin Console Navigation
│
├── Dashboard (Overview)
│   ├── System Health
│   ├── Customer Activity
│   ├── AI Performance
│   └── Recent Alerts
│
├── Intelligence
│   ├── Sources
│   │   ├── All Sources
│   │   ├── Pending Review
│   │   ├── Approved
│   │   └── Rejected
│   ├── Knowledge Graph
│   │   ├── Entities
│   │   ├── Relationships
│   │   └── Gaps
│   └── Training
│       ├── Prompts
│       ├── Examples
│       └── Model Settings
│
├── Compliance Engine
│   ├── Rules
│   │   ├── Active Rules
│   │   ├── Draft Rules
│   │   └── Rule Templates
│   ├── Requirements
│   │   ├── Federal
│   │   ├── State
│   │   └── Custom
│   └── Scoring
│       ├── Algorithms
│       ├── Weights
│       └── Calibration
│
├── Organizations
│   ├── All Organizations
│   ├── Active Trials
│   ├── Subscriptions
│   └── Health Scores
│
├── Users
│   ├── All Users
│   ├── Admins
│   └── Activity Log
│
├── Billing
│   ├── Overview
│   ├── Invoices
│   ├── Plans
│   └── Revenue
│
├── Integrations
│   ├── Connectors
│   ├── Sync Status
│   └── API Keys
│
├── Audit
│   ├── System Logs
│   ├── User Actions
│   └── Security Events
│
└── Settings
    ├── Platform
    ├── Notifications
    └── Security
```

### 2.3 Screen Map

#### Dashboard (Home)
```
┌─────────────────────────────────────────────────────────────────┐
│  [Logo]  Dashboard  Intelligence  Compliance  Orgs  [Search] [Profile]
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  SYSTEM HEALTH                    [View Details →]      │   │
│  │  ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐           │   │
│  │  │ API    │ │ AI     │ │ DB     │ │ Queue  │           │   │
│  │  │ ✓ 99%  │ │ ✓ 98%  │ │ ✓ 100% │ │ ✓ 100% │           │   │
│  │  └────────┘ └────────┘ └────────┘ └────────┘           │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────┐  ┌─────────────────────────────┐  │
│  │ CUSTOMER ACTIVITY       │  │ AI PERFORMANCE              │  │
│  │                         │  │                             │  │
│  │ Active Orgs: 47    ↑12% │  │ Queries Today: 12,847       │  │
│  │ New Today: 3            │  │ Avg Response: 1.2s          │  │
│  │ Trials Ending: 5   ⚠️   │  │ Accuracy: 94.2%             │  │
│  │                         │  │                             │  │
│  │ [Sparkline Chart]       │  │ [Accuracy Trend]            │  │
│  └─────────────────────────┘  └─────────────────────────────┘  │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ RECENT ALERTS                                           │   │
│  │ ⚠️ Source "CMS-2024-001" failed ingestion              │   │
│  │ ℹ️ New regulation detected: Texas Medicaid Update      │   │
│  │ ✓ AI model v2.4.1 deployed successfully                │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

#### Sources Management
```
┌─────────────────────────────────────────────────────────────────┐
│  [Logo]  ...  Intelligence  >  Sources              [+ Add Source]
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  [All ▼]  [Search sources...    ]  [Filter ▼] [View ▼] │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  STATUS    SOURCE              TYPE      DATE    ACTIONS │   │
│  │  ─────────────────────────────────────────────────────── │   │
│  │  🟡        CMS Final Rule 2024  Federal   2h ago  [Review]│   │
│  │  🟢        HIPAA Security Upd   Federal   1d ago  [View]  │   │
│  │  🟢        Texas Medicaid HB21  State     2d ago  [View]  │   │
│  │  🔴        OIG Work Plan Q2     Federal   3d ago  [Retry] │   │
│  │  ...                                                     │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  [◀ Previous]  Page 1 of 12  [Next ▶]                          │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

#### Organization Detail
```
┌─────────────────────────────────────────────────────────────────┐
│  [Logo]  ...  Organizations  >  Acme Health System    [Actions ▼]
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  Acme Health System                    [Trial] [Active] │   │
│  │  Enterprise Plan • 75 users • $75,000/mo                │   │
│  │  Trial ends: 12 days                                    │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐              │
│  │ COMPLIANCE  │ │ RISK        │ │ AUDIT       │              │
│  │ SCORE       │ │ SCORE       │ │ READINESS   │              │
│  │             │ │             │ │             │              │
│  │    78       │ │    42       │ │    65       │              │
│  │   /100      │ │   /100      │ │   /100      │              │
│  │             │ │             │ │             │              │
│  │ [Gauge]     │ │ [Gauge]     │ │ [Gauge]     │              │
│  └─────────────┘ └─────────────┘ └─────────────┘              │
│                                                                 │
│  TABS: [Overview] [Users] [Activity] [Billing] [Settings]      │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  RECENT ACTIVITY                                        │   │
│  │  ─────────────────────────────────────────────────────  │   │
│  │  Today, 2:34 PM  User uploaded policy document          │   │
│  │  Today, 11:20 AM Compliance query: "HIPAA breach..."   │   │
│  │  Yesterday         Gap identified: Missing FWA training │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 2.4 Component System

#### Cards
```css
/* Command Card */
.command-card {
  background: var(--command-bg-tertiary);
  border: 1px solid var(--command-border-subtle);
  border-radius: 8px;
  padding: 16px;
}

.command-card:hover {
  border-color: var(--command-border-default);
}

.command-card-elevated {
  box-shadow: 0 4px 24px rgba(0,0,0,0.4);
}
```

#### Tables
```css
/* Data Table */
.command-table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
}

.command-table th {
  color: var(--command-text-secondary);
  font-size: 11px;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  padding: 12px 16px;
  border-bottom: 1px solid var(--command-border-default);
}

.command-table td {
  padding: 12px 16px;
  border-bottom: 1px solid var(--command-border-subtle);
}

.command-table tr:hover td {
  background: rgba(255,255,255,0.02);
}
```

#### Badges
```css
/* Status Badges */
.badge-pending { background: rgba(245,158,11,0.15); color: #F59E0B; }
.badge-approved { background: rgba(0,212,170,0.15); color: #00D4AA; }
.badge-rejected { background: rgba(244,63,94,0.15); color: #F43F5E; }
.badge-processing { background: rgba(59,130,246,0.15); color: #3B82F6; }
```

#### Score Gauges
- Circular progress indicator
- Color-coded: Green (80-100), Yellow (60-79), Orange (40-59), Red (0-39)
- Animated on load
- Tooltip on hover showing breakdown

### 2.5 Motion & Interaction

| Interaction | Behavior | Duration |
|-------------|----------|----------|
| Card hover | Border brighten, subtle lift | 150ms |
| Table row hover | Background highlight | 100ms |
| Modal open | Fade + scale from 0.95 | 200ms |
| Page transition | Fade + slide | 250ms |
| Score animation | Count up from 0 | 800ms |
| Toast notification | Slide in from right | 300ms |

---

## Part 3 — UI/UX Redesign for User Dashboard

### 3.1 Brand Identity: User Dashboard

**Codename:** "Clarity"

**Brand Essence:** Confidence, Simplicity, Action

**Logo Concept:**
- Clean geometric mark suggesting a shield or checkmark
- Monogram "R" with subtle gradient
- Light background, premium feel

**Color System:**

```css
/* Primary Palette */
--clarity-bg-primary: #FFFFFF;
--clarity-bg-secondary: #F8FAFC;      /* Subtle gray */
--clarity-bg-tertiary: #F1F5F9;       /* Card background */

/* Accent Colors */
--clarity-accent-blue: #0EA5E9;       /* Primary action */
--clarity-accent-teal: #14B8A6;       /* Success/Compliance */
--clarity-accent-indigo: #6366F1;     /* Intelligence */
--clarity-accent-amber: #F59E0B;      /* Warning */
--clarity-accent-rose: #EF4444;       /* Critical */

/* Text Colors */
--clarity-text-primary: #0F172A;
--clarity-text-secondary: #475569;
--clarity-text-tertiary: #94A3B8;

/* Border Colors */
--clarity-border-subtle: #E2E8F0;
--clarity-border-default: #CBD5E1;
--clarity-border-strong: #94A3B8;
```

**Typography:**
- **Primary:** Inter (modern, readable)
- **Headings:** Plus Jakarta Sans (friendly, professional)
- **Scale:** 14px base, generous line-height

**Icon Direction:**
- Lucide icons (consistent)
- 20px standard, rounded strokes

### 3.2 Information Architecture

```
User Dashboard Navigation
│
├── Home (Dashboard)
│   ├── Executive Summary
│   ├── Compliance Score
│   ├── Risk Overview
│   ├── Upcoming Deadlines
│   └── Quick Actions
│
├── Compliance
│   ├── Overview
│   ├── Gap Analysis
│   │   ├── All Gaps
│   │   ├── By Category
│   │   └── Action Plan
│   ├── Requirements
│   │   ├── Federal
│   │   ├── State
│   │   └── Internal
│   └── Documents
│       ├── Policies
│       ├── Evidence
│       └── Templates
│
├── Tasks
│   ├── My Tasks
│   ├── Team Tasks
│   ├── Projects
│   └── Calendar
│
├── Intelligence
│   ├── Regulatory Feed
│   ├── News & Updates
│   ├── Bookmarks
│   └── Alerts
│
├── Integrations
│   ├── Connected Apps
│   ├── Sync Status
│   └── Settings
│
├── Organization
│   ├── Profile
│   ├── Team
│   ├── Settings
│   └── Billing (Admin only)
│
└── Support
    ├── Help Center
    ├── Contact
    └── Feedback
```

### 3.3 Screen Map

#### Dashboard (Home)
```
┌─────────────────────────────────────────────────────────────────┐
│  [Logo]  Home  Compliance  Tasks  Intelligence  [Search] [Bell] [Profile]
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  Good morning, Sarah 👋                                 │   │
│  │  You have 3 tasks due this week and 2 new alerts       │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐              │
│  │ COMPLIANCE  │ │ RISK        │ │ AUDIT       │              │
│  │ SCORE       │ │ SCORE       │ │ READINESS   │              │
│  │             │ │             │ │             │              │
│  │    78       │ │    42       │ │    65       │              │
│  │   /100      │ │   /100      │ │   /100      │              │
│  │             │ │             │ │             │              │
│  │ [Gauge]     │ │ [Gauge]     │ │ [Gauge]     │              │
│  └─────────────┘ └─────────────┘ └─────────────┘              │
│                                                                 │
│  ┌─────────────────────────┐  ┌─────────────────────────────┐  │
│  │ UPCOMING DEADLINES      │  │ RECENT INTELLIGENCE         │  │
│  │                         │  │                             │  │
│  │ 🗓️  Jan 15  Annual      │  │ 📰 CMS Final Rule 2024      │  │
│  │     HIPAA Risk Assess   │  │    New requirements for...  │  │
│  │                         │  │                             │  │
│  │ 🗓️  Jan 22  Quarterly   │  │ 📰 Texas Medicaid Update    │  │
│  │     FWA Report          │  │    HB 21 provisions...      │  │
│  │                         │  │                             │  │
│  │ [View Calendar →]       │  │ [View All →]                │  │
│  └─────────────────────────┘  └─────────────────────────────┘  │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  PRIORITY ACTIONS                    [View All Tasks →] │   │
│  │  ─────────────────────────────────────────────────────  │   │
│  │  ☐ Review updated HIPAA Security Rule requirements      │   │
│  │  ☐ Complete Q4 FWA training attestation                 │   │
│  │  ☐ Upload evidence for network adequacy audit           │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

#### Gap Analysis
```
┌─────────────────────────────────────────────────────────────────┐
│  [Logo]  ...  Compliance  >  Gap Analysis           [Export] [Help]
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  12 Gaps Identified                    [Filter ▼] [Sort ▼]│   │
│  │  3 Critical • 5 High • 4 Medium                         │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  TABS: [All Gaps] [By Category] [Action Plan]                  │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  🔴 CRITICAL                                            │   │
│  │  ─────────────────────────────────────────────────────  │   │
│  │                                                         │   │
│  │  Missing FWA Training Program                           │   │
│  │  Category: Program Integrity  •  Due: 15 days           │   │
│  │  ─────────────────────────────────────────────────────  │   │
│  │  Your organization lacks a documented fraud, waste,     │   │
│  │  and abuse training program as required by 42 CFR...    │   │
│  │                                                         │   │
│  │  [View Details]  [Create Action Plan]                   │   │
│  │                                                         │   │
│  │  ─────────────────────────────────────────────────────  │   │
│  │                                                         │   │
│  │  Incomplete Breach Response Documentation               │   │
│  │  Category: HIPAA  •  Due: 22 days                       │   │
│  │  ...                                                    │   │
│  │                                                         │   │
│  │  [View Details]  [Create Action Plan]                   │   │
│  │                                                         │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

#### Regulatory Feed
```
┌─────────────────────────────────────────────────────────────────┐
│  [Logo]  ...  Intelligence  >  Regulatory Feed      [Filter ▼]
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  [🔍 Search updates...          ]  [Federal ▼] [Date ▼] │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  📰 CMS Final Rule: Medicare Advantage and Part D       │   │
│  │  ─────────────────────────────────────────────────────  │   │
│  │  Source: CMS  •  Published: Jan 5, 2024  •  Federal     │   │
│  │                                                         │   │
│  │  CMS issued a final rule updating requirements for...   │   │
│  │                                                         │   │
│  │  [Read More]  [Bookmark]  [Create Task]  [Share]        │   │
│  │                                                         │   │
│  │  Tags: Medicare Advantage, Part D, Marketing            │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  📰 Texas Medicaid: HB 21 Implementation Guidance       │   │
│  │  ─────────────────────────────────────────────────────  │   │
│  │  Source: Texas HHS  •  Published: Jan 3, 2024  •  State │   │
│  │  ...                                                    │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 3.4 Component System

#### Cards
```css
/* Clarity Card */
.clarity-card {
  background: var(--clarity-bg-primary);
  border: 1px solid var(--clarity-border-subtle);
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.clarity-card:hover {
  box-shadow: 0 4px 12px rgba(0,0,0,0.08);
  border-color: var(--clarity-border-default);
}
```

#### Score Display
- Large circular gauge with gradient fill
- Score prominently displayed in center
- Color-coded ring
- Subtle shadow for depth

#### Task Items
- Checkbox for completion
- Clear title and due date
- Priority indicator (dot)
- Category tag
- Hover reveals actions

### 3.5 Motion & Interaction

| Interaction | Behavior | Duration |
|-------------|----------|----------|
| Card hover | Subtle lift, shadow increase | 200ms |
| Score animation | Smooth count-up | 1000ms |
| Tab switch | Fade content | 150ms |
| Task check | Strike-through + fade | 300ms |
| Modal open | Slide up + fade | 250ms |
| Toast | Slide in from top-right | 300ms |

---

## Part 4 — Updated Onboarding and Assessment Engine

### 4.1 Onboarding Flow (8 Steps)

```
┌─────────────────────────────────────────────────────────────────┐
│                    ONBOARDING PROGRESS                           │
│  [●────●────●────○────○────○────○────○]  Step 3 of 8           │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                                                         │   │
│  │  [Step Content]                                         │   │
│  │                                                         │   │
│  │  [Back]                    [Continue]                   │   │
│  │                                                         │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 4.2 Step Details

#### Step 1 — Company Setup
**Fields:**
- Company Name (text, required)
- Primary Admin Email (email, required)
- Number of Users (select: 25, 50, 75, 100, 150, 200, 250, 500+)
- Business Domain (select: Healthcare Provider, Health Plan, MSO, Other)

**Validation:**
- Minimum 25 users enforced
- Email domain validation

#### Step 2 — Organization Type
**Single Select:**
- ○ Medicaid MCO Compliance
- ○ Provider Group Compliance
- ○ MSO / Multi-location Operations
- ○ Other Healthcare Enterprise

**Backend Impact:**
- Maps to requirement template
- Determines default scoring weights

#### Step 3 — Operating Footprint
**Fields:**
- States of Operation (multi-select, all 50 states + DC)
- Number of Locations (number)
- Lines of Business (multi-select):
  - ○ Medicaid
  - ○ Medicare
  - ○ Commercial
  - ○ Exchange
  - ○ Managed Long-term Care

**Backend Impact:**
- Determines applicable regulations
- Calculates compliance complexity score

#### Step 4 — Health Plan / Payer Relationships
**Fields:**
- Plans Worked With (multi-select + other)
- Subsidiaries / State Plans (text area)
- Managed Care Relationships (text area)

**Backend Impact:**
- Maps network adequacy requirements
- Determines reporting obligations

#### Step 5 — Compliance Maturity Assessment
**Question Library (Yes/No/Partial + Evidence):**

| Category | Question | Impact |
|----------|----------|--------|
| Governance | Do you have a designated Compliance Officer? | Compliance +10 |
| Governance | Are compliance policies documented and approved? | Compliance +15 |
| FWA | Do you have a Fraud, Waste & Abuse program? | Compliance +10, Risk -10 |
| FWA | Is FWA training conducted annually? | Compliance +5 |
| HIPAA | Do you have documented breach response procedures? | Compliance +10, Risk -15 |
| HIPAA | Is HIPAA training provided to all workforce? | Compliance +5 |
| Reporting | Do you track and report overpayments? | Compliance +10, Risk -10 |
| Reporting | Do you have incident reporting procedures? | Compliance +10 |
| Data | Do you submit encounter data? | Compliance +5 |
| Data | Do you have provider directory accuracy controls? | Compliance +10 |
| Access | Do you have cultural and linguistic services? | Compliance +5 |
| Screening | Do you conduct exclusion screening? | Compliance +10, Risk -15 |
| Retention | Do you have document retention policies? | Compliance +5 |
| Training | Is compliance training conducted regularly? | Compliance +10 |

**Scoring:**
- Each "Yes" adds to compliance score
- Each "No" adds to risk score
- "Partial" adds half points

#### Step 6 — Integrations
**Toggle Selection:**
- ☑ Microsoft 365
  - ☑ Outlook
  - ☑ Teams
  - ☑ OneDrive
- ☑ Google Workspace
  - ☑ Gmail
  - ☑ Google Drive
  - ☑ Google Calendar
- ☑ Monday.com

**Backend Impact:**
- Creates integration records
- Sets up sync jobs
- Stores OAuth tokens

#### Step 7 — Trial and Billing
**Summary Display:**
- Selected Plan: [X] users
- Monthly Cost: $[X]
- Trial Period: 30 days

**Fields:**
- Billing Contact Name
- Billing Email
- Billing Address
- [Start Trial] button

**Stripe Integration:**
- Create customer
- Create subscription (trial)
- Store payment method (optional during trial)

#### Step 8 — Initial Readiness Snapshot
**Generated Report:**

```
┌─────────────────────────────────────────────────────────────────┐
│  Your Initial Compliance Snapshot                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐              │
│  │ COMPLIANCE  │ │ RISK        │ │ AUDIT       │              │
│  │ SCORE       │ │ SCORE       │ │ READINESS   │              │
│  │             │ │             │ │             │              │
│  │    65       │ │    45       │ │    58       │              │
│  │   /100      │ │   /100      │ │   /100      │              │
│  └─────────────┘ └─────────────┘ └─────────────┘              │
│                                                                 │
│  TOP PRIORITIES                                                 │
│  ─────────────────────────────────────────────────────────────  │
│  1. Implement FWA training program                              │
│  2. Document breach response procedures                         │
│  3. Set up exclusion screening process                          │
│                                                                 │
│  [Go to Dashboard]  [View Detailed Report]                      │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 4.3 Assessment Engine Schema

```typescript
interface AssessmentQuestion {
  id: string;
  category: 'GOVERNANCE' | 'FWA' | 'HIPAA' | 'REPORTING' | 'DATA' | 'ACCESS' | 'SCREENING' | 'RETENTION' | 'TRAINING';
  questionText: string;
  answerType: 'BOOLEAN' | 'SCALE' | 'TEXT' | 'SELECT';
  options?: string[];
  complianceImpact: number; // Points added to compliance score
  riskImpact: number; // Points reduced from risk score
  auditReadinessImpact: number; // Points added to audit readiness
  evidenceRequired: boolean;
  evidenceDescription?: string;
  requirementMapping: string[]; // IDs of related requirements
  deadlineTrigger?: {
    condition: 'NO' | 'PARTIAL';
    deadlineType: string;
    daysFromNow: number;
  };
}

interface AssessmentResponse {
  questionId: string;
  answer: boolean | string | number;
  evidence?: string[]; // File URLs
  notes?: string;
  answeredAt: Date;
  answeredBy: string;
}

interface ComplianceScore {
  organizationId: string;
  overallScore: number; // 0-100
  categoryScores: Record<string, number>;
  calculatedAt: Date;
  responses: AssessmentResponse[];
}
```

---

## Part 5 — React Frontend Architecture

### 5.1 Project Structure

```
apps/
├── admin/                          # Admin Console (Next.js)
│   ├── src/
│   │   ├── app/                    # Next.js App Router
│   │   │   ├── (auth)/             # Auth routes (login, etc.)
│   │   │   ├── (dashboard)/        # Main dashboard
│   │   │   │   ├── page.tsx
│   │   │   │   ├── layout.tsx
│   │   │   │   └── loading.tsx
│   │   │   ├── intelligence/
│   │   │   ├── compliance/
│   │   │   ├── organizations/
│   │   │   ├── billing/
│   │   │   └── settings/
│   │   ├── components/
│   │   │   ├── ui/                 # Base UI components
│   │   │   ├── layout/             # Layout components
│   │   │   ├── charts/             # Data visualization
│   │   │   └── forms/              # Form components
│   │   ├── hooks/                  # Custom React hooks
│   │   ├── lib/
│   │   │   ├── api.ts              # API client
│   │   │   ├── utils.ts            # Utilities
│   │   │   └── constants.ts        # Constants
│   │   ├── stores/                 # Zustand stores
│   │   ├── types/                  # TypeScript types
│   │   └── styles/
│   │       └── globals.css
│   ├── public/
│   └── package.json
│
├── dashboard/                      # User Dashboard (Next.js)
│   ├── src/
│   │   ├── app/
│   │   │   ├── (auth)/
│   │   │   ├── (dashboard)/
│   │   │   ├── compliance/
│   │   │   ├── tasks/
│   │   │   ├── intelligence/
│   │   │   └── organization/
│   │   ├── components/
│   │   ├── hooks/
│   │   ├── lib/
│   │   ├── stores/
│   │   ├── types/
│   │   └── styles/
│   ├── public/
│   └── package.json
│
└── shared/                         # Shared packages
    ├── ui/                         # Shared UI components
    ├── types/                      # Shared TypeScript types
    ├── utils/                      # Shared utilities
    └── api-client/                 # Shared API client
```

### 5.2 Route Structure

#### Admin Console Routes
```
/login                    # Admin login
/dashboard                # System overview
/intelligence
  /sources                # Source management
  /knowledge-graph        # Entity relationships
  /training               # AI training
/compliance
  /rules                  # Rule engine
  /requirements           # Requirement library
  /scoring                # Scoring configuration
/organizations            # Customer orgs
  /[orgId]                # Org detail
/users                     # User management
/billing                   # Billing oversight
/integrations              # Connector management
/audit                     # System audit logs
/settings                  # Platform settings
```

#### User Dashboard Routes
```
/login                     # User login
/onboarding                # 8-step onboarding
/dashboard                 # Executive overview
/compliance
  /overview                # Compliance summary
  /gaps                    # Gap analysis
  /requirements            # Requirements list
  /documents               # Document center
/tasks                     # Task management
  /calendar                # Deadline calendar
/intelligence
  /feed                    # Regulatory news
  /bookmarks               # Saved items
/integrations              # Connected apps
/organization
  /profile                 # Company profile
  /team                    # Team members
  /billing                 # Subscription (admin only)
/support                   # Help center
```

### 5.3 State Management

#### Zustand Stores

```typescript
// stores/auth.ts
interface AuthState {
  user: User | null;
  organization: Organization | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  refreshToken: () => Promise<void>;
}

// stores/compliance.ts
interface ComplianceState {
  score: ComplianceScore | null;
  gaps: ComplianceGap[];
  requirements: Requirement[];
  isLoading: boolean;
  fetchScore: () => Promise<void>;
  fetchGaps: () => Promise<void>;
  updateGap: (id: string, data: Partial<ComplianceGap>) => Promise<void>;
}

// stores/tasks.ts
interface TasksState {
  tasks: Task[];
  projects: Project[];
  filters: TaskFilters;
  fetchTasks: () => Promise<void>;
  createTask: (task: CreateTaskInput) => Promise<void>;
  completeTask: (id: string) => Promise<void>;
}
```

### 5.4 API Integration

```typescript
// lib/api.ts
import axios from 'axios';

const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Response interceptor
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// React Query hooks
export function useComplianceScore() {
  return useQuery({
    queryKey: ['compliance', 'score'],
    queryFn: () => api.get('/compliance/score').then(r => r.data),
  });
}

export function useGaps() {
  return useQuery({
    queryKey: ['compliance', 'gaps'],
    queryFn: () => api.get('/compliance/gaps').then(r => r.data),
  });
}
```

### 5.5 Protected Routes

```typescript
// components/auth/ProtectedRoute.tsx
'use client';

import { useAuth } from '@/hooks/useAuth';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRole?: string;
}

export function ProtectedRoute({ children, requiredRole }: ProtectedRouteProps) {
  const { user, isLoading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!isLoading && !user) {
      router.push('/login');
    }
    if (!isLoading && requiredRole && user?.role !== requiredRole) {
      router.push('/unauthorized');
    }
  }, [user, isLoading, router, requiredRole]);

  if (isLoading) {
    return <LoadingSpinner />;
  }

  return <>{children}</>;
}
```

---

## Part 6 — Backend/API Integration Map

### 6.1 Service Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      API GATEWAY                                │
│              (Rate Limiting, Auth, Routing)                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐             │
│  │ Auth        │  │ Compliance  │  │ AI/LLM      │             │
│  │ Service     │  │ Service     │  │ Service     │             │
│  │             │  │             │  │             │             │
│  │ • Login     │  │ • Scoring   │  │ • Query     │             │
│  │ • Register  │  │ • Gaps      │  │ • Training  │             │
│  │ • RBAC      │  │ • Rules     │  │ • Embed     │             │
│  │ • SSO       │  │ • Deadlines │  │ • Generate  │             │
│  └─────────────┘  └─────────────┘  └─────────────┘             │
│                                                                 │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐             │
│  │ Billing     │  │ Integration │  │ Notification│             │
│  │ Service     │  │ Service     │  │ Service     │             │
│  │             │  │             │  │             │             │
│  │ • Stripe    │  │ • Microsoft │  │ • Email     │             │
│  │ • Seats     │  │ • Google    │  │ • In-app    │             │
│  │ • Invoices  │  │ • Monday    │  │ • Push      │             │
│  │ • Trials    │  │ • Webhooks  │  │ • Digest    │             │
│  └─────────────┘  └─────────────┘  └─────────────┘             │
│                                                                 │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐             │
│  │ Organization│  │ Document    │  │ Audit       │             │
│  │ Service     │  │ Service     │  │ Service     │             │
│  │             │  │             │  │             │             │
│  │ • CRUD      │  │ • Upload    │  │ • Log       │             │
│  │ • Settings  │  │ • Parse     │  │ • Search    │             │
│  │ • Members   │  │ • Search    │  │ • Export    │             │
│  │ • Profile   │  │ • Version   │  │ • Alert     │             │
│  └─────────────┘  └─────────────┘  └─────────────┘             │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 6.2 API Endpoints

#### Auth Service
```
POST   /auth/login
POST   /auth/register
POST   /auth/logout
POST   /auth/refresh
POST   /auth/forgot-password
POST   /auth/reset-password
POST   /auth/sso/microsoft
POST   /auth/sso/google
GET    /auth/me
PUT    /auth/me
```

#### Compliance Service
```
GET    /compliance/score
POST   /compliance/assessment/submit
GET    /compliance/gaps
GET    /compliance/gaps/:id
PUT    /compliance/gaps/:id
GET    /compliance/requirements
GET    /compliance/requirements/:id
GET    /compliance/deadlines
POST   /compliance/deadlines
GET    /compliance/documents
POST   /compliance/documents
GET    /compliance/documents/:id
```

#### AI Service
```
POST   /ai/query              # Ask compliance question
POST   /ai/train              # Add training example
GET    /ai/sources            # List knowledge sources
POST   /ai/sources            # Add source
DELETE /ai/sources/:id
POST   /ai/embed              # Generate embeddings
GET    /ai/suggestions        # Get recommendations
```

#### Billing Service
```
GET    /billing/tiers
GET    /billing/subscription
POST   /billing/trial/start
POST   /billing/subscribe
POST   /billing/upgrade
POST   /billing/cancel
GET    /billing/invoices
GET    /billing/invoices/:id
POST   /billing/payment-methods
DELETE /billing/payment-methods/:id
POST   /billing/webhook       # Stripe webhook
```

#### Integration Service
```
GET    /integrations
POST   /integrations/connect
DELETE /integrations/:id
GET    /integrations/:id/status
POST   /integrations/:id/sync
GET    /integrations/:id/logs
```

#### Organization Service
```
GET    /organizations
POST   /organizations
GET    /organizations/:id
PUT    /organizations/:id
DELETE /organizations/:id
GET    /organizations/:id/members
POST   /organizations/:id/members
DELETE /organizations/:id/members/:userId
GET    /organizations/:id/settings
PUT    /organizations/:id/settings
```

### 6.3 Data Models

```typescript
// Core Models

interface Organization {
  id: string;
  name: string;
  slug: string;
  type: 'PROVIDER' | 'MCO' | 'MSO' | 'OTHER';
  status: 'TRIAL' | 'ACTIVE' | 'SUSPENDED' | 'CANCELED';
  subscription: Subscription;
  profile: OrganizationProfile;
  settings: OrganizationSettings;
  members: OrganizationMember[];
  createdAt: Date;
  updatedAt: Date;
}

interface OrganizationProfile {
  states: string[];
  locationCount: number;
  linesOfBusiness: string[];
  payerRelationships: string[];
  complianceMaturity: ComplianceMaturity;
}

interface ComplianceMaturity {
  hasComplianceOfficer: boolean;
  hasDocumentedPolicies: boolean;
  hasFWAProgram: boolean;
  hasBreachResponse: boolean;
  hasExclusionScreening: boolean;
  trainingCadence: 'NONE' | 'ANNUAL' | 'QUARTERLY' | 'MONTHLY';
}

interface ComplianceScore {
  id: string;
  organizationId: string;
  overallScore: number;
  complianceScore: number;
  riskScore: number;
  auditReadinessScore: number;
  categoryScores: Record<string, number>;
  calculatedAt: Date;
  nextCalculation: Date;
}

interface ComplianceGap {
  id: string;
  organizationId: string;
  title: string;
  description: string;
  category: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  status: 'OPEN' | 'IN_PROGRESS' | 'RESOLVED' | 'ACCEPTED';
  requirementId: string;
  dueDate?: Date;
  assignedTo?: string;
  evidence: string[];
  createdAt: Date;
  updatedAt: Date;
}

interface Requirement {
  id: string;
  code: string;
  title: string;
  description: string;
  category: string;
  jurisdiction: 'FEDERAL' | 'STATE';
  states?: string[];
  applicableTo: string[];
  frequency?: string;
  deadlinePattern?: string;
  evidenceRequired: boolean;
  sourceId: string;
}

interface Deadline {
  id: string;
  organizationId: string;
  title: string;
  description: string;
  dueDate: Date;
  category: string;
  requirementId?: string;
  status: 'UPCOMING' | 'DUE_SOON' | 'OVERDUE' | 'COMPLETED';
  assignedTo?: string;
  reminderDays: number[];
}

interface Subscription {
  id: string;
  organizationId: string;
  tier: SubscriptionTier;
  status: 'TRIAL' | 'ACTIVE' | 'PAST_DUE' | 'CANCELED';
  trialEndsAt?: Date;
  currentPeriodStart: Date;
  currentPeriodEnd: Date;
  seatsUsed: number;
  seatsTotal: number;
  stripeCustomerId?: string;
  stripeSubscriptionId?: string;
}

interface Integration {
  id: string;
  organizationId: string;
  provider: 'MICROSOFT' | 'GOOGLE' | 'MONDAY';
  status: 'CONNECTED' | 'DISCONNECTED' | 'ERROR';
  scopes: string[];
  lastSyncAt?: Date;
  settings: Record<string, any>;
}
```

### 6.4 Scoring Engine Logic

```typescript
// Compliance Score Calculation
function calculateComplianceScore(responses: AssessmentResponse[]): number {
  const maxPossibleScore = responses.length * 10;
  const actualScore = responses.reduce((sum, r) => {
    if (r.answer === true) return sum + 10;
    if (r.answer === 'partial') return sum + 5;
    return sum;
  }, 0);
  
  return Math.round((actualScore / maxPossibleScore) * 100);
}

// Risk Score Calculation
function calculateRiskScore(gaps: ComplianceGap[], responses: AssessmentResponse[]): number {
  let riskPoints = 0;
  
  // Gap-based risk
  gaps.forEach(gap => {
    if (gap.severity === 'CRITICAL') riskPoints += 25;
    if (gap.severity === 'HIGH') riskPoints += 15;
    if (gap.severity === 'MEDIUM') riskPoints += 5;
  });
  
  // Response-based risk
  responses.forEach(r => {
    if (r.answer === false && r.question.riskImpact) {
      riskPoints += r.question.riskImpact;
    }
  });
  
  return Math.min(100, riskPoints);
}

// Audit Readiness Score
function calculateAuditReadinessScore(
  complianceScore: number,
  documentCount: number,
  policyCount: number,
  trainingCompletion: number
): number {
  const weights = {
    compliance: 0.4,
    documentation: 0.3,
    policies: 0.15,
    training: 0.15,
  };
  
  const docScore = Math.min(100, documentCount * 5);
  const policyScore = Math.min(100, policyCount * 10);
  
  return Math.round(
    complianceScore * weights.compliance +
    docScore * weights.documentation +
    policyScore * weights.policies +
    trainingCompletion * weights.training
  );
}
```

---

## Part 7 — Billing Integration Logic

### 7.1 Pricing Model

```
┌─────────────────────────────────────────────────────────────────┐
│                    ENTERPRISE PRICING                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Base Price: $1,000 per user per month                          │
│  Minimum: 25 users                                              │
│  Increments: 25 users                                           │
│                                                                 │
│  ┌──────────┬─────────────┬──────────────┐                     │
│  │ Users    │ Monthly     │ Annual       │                     │
│  ├──────────┼─────────────┼──────────────┤                     │
│  │ 25       │ $25,000     │ $300,000     │                     │
│  │ 50       │ $50,000     │ $600,000     │                     │
│  │ 75       │ $75,000     │ $900,000     │                     │
│  │ 100      │ $100,000    │ $1,200,000   │                     │
│  │ 150      │ $150,000    │ $1,800,000   │                     │
│  │ 200      │ $200,000    │ $2,400,000   │                     │
│  │ 250      │ $250,000    │ $3,000,000   │                     │
│  │ 500      │ $500,000    │ $6,000,000   │                     │
│  └──────────┴─────────────┴──────────────┘                     │
│                                                                 │
│  Trial: 30 days free, full access                               │
│  Post-trial: Read-only mode until payment                       │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 7.2 Billing States

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   TRIAL     │────▶│   ACTIVE    │────▶│  CANCELED   │
│  (30 days)  │     │  (paid)     │     │  (end of    │
└─────────────┘     └─────────────┘     │   period)   │
       │                                └─────────────┘
       │
       ▼
┌─────────────┐
│TRIAL_EXPIRED│────▶ Read-only mode
│             │
└─────────────┘
```

### 7.3 Stripe Integration Flow

```typescript
// Billing Service

class BillingService {
  async startTrial(organizationId: string, seatCount: number, billingEmail: string) {
    // Validate minimum seats
    if (seatCount < 25) throw new Error('Minimum 25 seats required');
    
    // Create Stripe customer
    const customer = await stripe.customers.create({
      email: billingEmail,
      metadata: { organizationId },
    });
    
    // Create subscription with trial
    const subscription = await stripe.subscriptions.create({
      customer: customer.id,
      items: [{ price: getPriceId(seatCount) }],
      trial_period_days: 30,
      metadata: { organizationId, seatCount },
    });
    
    // Store in database
    await db.subscriptions.create({
      organizationId,
      stripeCustomerId: customer.id,
      stripeSubscriptionId: subscription.id,
      seatCount,
      status: 'TRIAL',
      trialEndsAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
    });
  }
  
  async upgradeSeats(organizationId: string, newSeatCount: number) {
    const sub = await db.subscriptions.findOne({ organizationId });
    
    // Calculate prorated charge
    const proration = await stripe.subscriptions.update(
      sub.stripeSubscriptionId,
      {
        items: [{
          id: sub.stripeItemId,
          price: getPriceId(newSeatCount),
        }],
        proration_behavior: 'create_prorations',
      }
    );
    
    // Update database
    await db.subscriptions.update(
      { organizationId },
      { seatCount: newSeatCount }
    );
  }
  
  async handleWebhook(event: Stripe.Event) {
    switch (event.type) {
      case 'invoice.paid':
        await this.handleInvoicePaid(event.data.object);
        break;
      case 'invoice.payment_failed':
        await this.handlePaymentFailed(event.data.object);
        break;
      case 'customer.subscription.deleted':
        await this.handleSubscriptionCanceled(event.data.object);
        break;
    }
  }
}
```

### 7.4 Seat Management

```typescript
// Seat Assignment Logic

async function assignSeat(organizationId: string, userId: string) {
  const subscription = await db.subscriptions.findOne({ organizationId });
  
  // Check available seats
  if (subscription.seatsUsed >= subscription.seatsTotal) {
    throw new Error('No seats available. Please upgrade your plan.');
  }
  
  // Assign seat
  await db.seatAssignments.create({
    organizationId,
    userId,
    assignedAt: new Date(),
  });
  
  // Update count
  await db.subscriptions.update(
    { organizationId },
    { $inc: { seatsUsed: 1 } }
  );
}

async function unassignSeat(organizationId: string, userId: string) {
  // Remove assignment
  await db.seatAssignments.deleteOne({ organizationId, userId });
  
  // Update count
  await db.subscriptions.update(
    { organizationId },
    { $inc: { seatsUsed: -1 } }
  );
  
  // Note: No refund - prorated credit applied to next invoice
}
```

---

## Part 8 — Deployment Action Checklist

### 8.1 Frontend Deployment

#### Admin Console
- [ ] Build configuration (next.config.js)
- [ ] Environment variables setup
- [ ] Domain: admin.requi.health
- [ ] SSL certificate
- [ ] CDN configuration (Cloudflare)
- [ ] Analytics (Segment/Amplitude)
- [ ] Error tracking (Sentry)

#### User Dashboard
- [ ] Build configuration
- [ ] Environment variables setup
- [ ] Domain: app.requi.health
- [ ] SSL certificate
- [ ] CDN configuration
- [ ] Analytics
- [ ] Error tracking

### 8.2 Backend Deployment

#### Infrastructure
- [ ] API server (AWS ECS / Railway / Render)
- [ ] PostgreSQL database (AWS RDS / Supabase)
- [ ] Redis cache (AWS ElastiCache / Upstash)
- [ ] Pinecone vector DB
- [ ] S3-compatible storage (AWS S3 / Cloudflare R2)
- [ ] Load balancer
- [ ] Auto-scaling configuration

#### Services
- [ ] Auth service deployment
- [ ] Compliance service deployment
- [ ] AI service deployment
- [ ] Billing service deployment
- [ ] Integration service deployment
- [ ] Notification service deployment
- [ ] Worker processes (BullMQ)

#### Background Jobs
- [ ] Trial expiration checker (daily)
- [ ] Scoring recalculation (daily)
- [ ] Deadline reminder notifications (daily)
- [ ] Integration sync jobs (hourly)
- [ ] Audit log cleanup (weekly)
- [ ] Usage report generation (monthly)

### 8.3 Security Checklist

- [ ] Secrets management (AWS Secrets Manager / Doppler)
- [ ] Database encryption at rest
- [ ] TLS 1.3 for all connections
- [ ] API rate limiting
- [ ] Webhook signature validation
- [ ] CORS configuration
- [ ] Content Security Policy headers
- [ ] SQL injection prevention (Prisma)
- [ ] XSS protection
- [ ] CSRF tokens
- [ ] Password policies
- [ ] MFA support
- [ ] Audit logging enabled
- [ ] Data retention policies
- [ ] Backup strategy (daily backups, 30-day retention)
- [ ] Disaster recovery plan

### 8.4 Pre-Launch QA

#### Onboarding
- [ ] All 8 steps tested
- [ ] Score calculation verified
- [ ] Trial activation works
- [ ] Billing integration tested

#### Scoring
- [ ] Compliance score accuracy
- [ ] Risk score accuracy
- [ ] Audit readiness score accuracy
- [ ] Gap detection working
- [ ] Deadline generation working

#### Billing
- [ ] Trial flow tested
- [ ] Upgrade flow tested
- [ ] Seat assignment tested
- [ ] Invoice generation tested
- [ ] Webhook handling tested

#### Integrations
- [ ] Microsoft OAuth flow
- [ ] Google OAuth flow
- [ ] Monday.com OAuth flow
- [ ] Sync jobs working
- [ ] Error handling tested

#### Admin
- [ ] Source upload working
- [ ] AI training flow tested
- [ ] Organization management working
- [ ] Billing oversight working
- [ ] Audit logs accessible

#### User Dashboard
- [ ] Dashboard loads correctly
- [ ] Scores display accurately
- [ ] Tasks can be created/completed
- [ ] Calendar shows deadlines
- [ ] News feed populated
- [ ] Integrations configurable

---

## Part 9 — Required API Keys and Credentials

### 9.1 AI / Model Layer

| Service | Key Name | Purpose | Environment |
|---------|----------|---------|-------------|
| Anthropic | `ANTHROPIC_API_KEY` | Claude API for compliance queries | Production |
| OpenAI | `OPENAI_API_KEY` | GPT-4 fallback / embeddings | Optional |

### 9.2 Billing

| Service | Key Name | Purpose | Environment |
|---------|----------|---------|-------------|
| Stripe | `STRIPE_SECRET_KEY` | Payment processing | Production |
| Stripe | `STRIPE_PUBLISHABLE_KEY` | Frontend payments | Production |
| Stripe | `STRIPE_WEBHOOK_SECRET` | Webhook validation | Production |

### 9.3 Auth

| Service | Key Name | Purpose | Environment |
|---------|----------|---------|-------------|
| Auth0/Clerk | `AUTH_SECRET` | JWT signing | Production |
| Auth0/Clerk | `AUTH_CLIENT_ID` | OAuth client | Production |
| Auth0/Clerk | `AUTH_CLIENT_SECRET` | OAuth secret | Production |

### 9.4 Microsoft Integrations

| Service | Key Name | Purpose | Environment |
|---------|----------|---------|-------------|
| Azure AD | `MICROSOFT_CLIENT_ID` | App registration | Production |
| Azure AD | `MICROSOFT_CLIENT_SECRET` | App secret | Production |
| Azure AD | `MICROSOFT_TENANT_ID` | Tenant ID | Production |
| Graph API | `MICROSOFT_GRAPH_TOKEN` | API access | Runtime |

### 9.5 Google Integrations

| Service | Key Name | Purpose | Environment |
|---------|----------|---------|-------------|
| Google Cloud | `GOOGLE_CLIENT_ID` | OAuth client | Production |
| Google Cloud | `GOOGLE_CLIENT_SECRET` | OAuth secret | Production |
| Google APIs | `GOOGLE_API_KEY` | API access | Production |

### 9.6 Monday.com

| Service | Key Name | Purpose | Environment |
|---------|----------|---------|-------------|
| Monday.com | `MONDAY_API_TOKEN` | API access | Production |
| Monday.com | `MONDAY_CLIENT_ID` | OAuth | Production |
| Monday.com | `MONDAY_CLIENT_SECRET` | OAuth secret | Production |

### 9.7 Storage / Infrastructure

| Service | Key Name | Purpose | Environment |
|---------|----------|---------|-------------|
| AWS/Cloudflare | `S3_ACCESS_KEY_ID` | Object storage | Production |
| AWS/Cloudflare | `S3_SECRET_ACCESS_KEY` | Object storage | Production |
| AWS/Cloudflare | `S3_BUCKET_NAME` | Bucket name | Production |
| AWS/Cloudflare | `S3_ENDPOINT` | S3-compatible endpoint | Production |
| Pinecone | `PINECONE_API_KEY` | Vector search | Production |
| Pinecone | `PINECONE_ENVIRONMENT` | Pinecone env | Production |
| Pinecone | `PINECONE_INDEX` | Index name | Production |

### 9.8 Database / Cache

| Service | Key Name | Purpose | Environment |
|---------|----------|---------|-------------|
| PostgreSQL | `DATABASE_URL` | Database connection | Production |
| Redis | `REDIS_URL` | Cache/queue | Production |

### 9.9 Email / Notifications

| Service | Key Name | Purpose | Environment |
|---------|----------|---------|-------------|
| SendGrid/AWS SES | `EMAIL_API_KEY` | Transactional email | Production |
| SendGrid/AWS SES | `FROM_EMAIL` | Sender address | Production |

### 9.10 Monitoring

| Service | Key Name | Purpose | Environment |
|---------|----------|---------|-------------|
| Sentry | `SENTRY_DSN` | Error tracking | Production |
| Datadog | `DATADOG_API_KEY` | Monitoring | Optional |
| Segment | `SEGMENT_WRITE_KEY` | Analytics | Optional |

---

## Part 10 — Recommended Launch Sequence

### Phase 1: Foundation (Weeks 1-2)
1. Set up infrastructure (AWS/Railway accounts)
2. Configure databases (PostgreSQL, Redis, Pinecone)
3. Set up CI/CD pipelines
4. Configure domains and SSL
5. Set up monitoring (Sentry, analytics)

### Phase 2: Backend (Weeks 3-4)
1. Deploy auth service
2. Deploy organization service
3. Deploy compliance service (basic)
4. Deploy billing service with Stripe
5. Set up background job workers

### Phase 3: Admin Console (Weeks 5-6)
1. Build and deploy admin authentication
2. Implement organization management
3. Build source upload and management
4. Implement AI training interface
5. Build billing oversight

### Phase 4: User Dashboard (Weeks 7-8)
1. Build and deploy user authentication
2. Implement onboarding flow (8 steps)
3. Build dashboard with scores
4. Implement gap analysis
5. Build task management
6. Create regulatory feed

### Phase 5: Integrations (Weeks 9-10)
1. Implement Microsoft OAuth
2. Implement Google OAuth
3. Implement Monday.com OAuth
4. Build sync jobs
5. Test integration flows

### Phase 6: Testing & QA (Weeks 11-12)
1. End-to-end testing
2. Security audit
3. Performance testing
4. Load testing
5. Bug fixes

### Phase 7: Soft Launch (Week 13)
1. Invite beta customers
2. Monitor closely
3. Gather feedback
4. Iterate quickly

### Phase 8: Public Launch (Week 14+)
1. Remove beta restrictions
2. Launch marketing
3. Scale infrastructure
4. Monitor metrics

---

## Appendix: Design Tokens

### Admin Console (Command)

```css
:root {
  /* Background */
  --cmd-bg-void: #0A0A0F;
  --cmd-bg-surface: #12121A;
  --cmd-bg-elevated: #1A1A25;
  --cmd-bg-hover: rgba(255,255,255,0.03);
  
  /* Accent */
  --cmd-cyan: #00D4AA;
  --cmd-blue: #3B82F6;
  --cmd-purple: #8B5CF6;
  --cmd-amber: #F59E0B;
  --cmd-rose: #F43F5E;
  
  /* Text */
  --cmd-text-primary: #FAFAFA;
  --cmd-text-secondary: #A1A1AA;
  --cmd-text-tertiary: #71717A;
  
  /* Border */
  --cmd-border-subtle: rgba(255,255,255,0.06);
  --cmd-border-default: rgba(255,255,255,0.1);
  
  /* Shadow */
  --cmd-shadow-sm: 0 1px 2px rgba(0,0,0,0.3);
  --cmd-shadow-md: 0 4px 12px rgba(0,0,0,0.4);
  --cmd-shadow-lg: 0 8px 24px rgba(0,0,0,0.5);
  
  /* Radius */
  --cmd-radius-sm: 4px;
  --cmd-radius-md: 8px;
  --cmd-radius-lg: 12px;
  
  /* Spacing */
  --cmd-space-1: 4px;
  --cmd-space-2: 8px;
  --cmd-space-3: 12px;
  --cmd-space-4: 16px;
  --cmd-space-5: 24px;
  --cmd-space-6: 32px;
}
```

### User Dashboard (Clarity)

```css
:root {
  /* Background */
  --cl-bg-primary: #FFFFFF;
  --cl-bg-secondary: #F8FAFC;
  --cl-bg-tertiary: #F1F5F9;
  --cl-bg-hover: rgba(0,0,0,0.02);
  
  /* Accent */
  --cl-blue: #0EA5E9;
  --cl-teal: #14B8A6;
  --cl-indigo: #6366F1;
  --cl-amber: #F59E0B;
  --cl-rose: #EF4444;
  
  /* Text */
  --cl-text-primary: #0F172A;
  --cl-text-secondary: #475569;
  --cl-text-tertiary: #94A3B8;
  
  /* Border */
  --cl-border-subtle: #E2E8F0;
  --cl-border-default: #CBD5E1;
  
  /* Shadow */
  --cl-shadow-sm: 0 1px 2px rgba(0,0,0,0.05);
  --cl-shadow-md: 0 4px 12px rgba(0,0,0,0.08);
  --cl-shadow-lg: 0 8px 24px rgba(0,0,0,0.12);
  
  /* Radius */
  --cl-radius-sm: 6px;
  --cl-radius-md: 10px;
  --cl-radius-lg: 16px;
  
  /* Spacing */
  --cl-space-1: 4px;
  --cl-space-2: 8px;
  --cl-space-3: 12px;
  --cl-space-4: 16px;
  --cl-space-5: 24px;
  --cl-space-6: 32px;
  --cl-space-7: 48px;
}
```

---

*Document Version: 1.0*
*Last Updated: 2024*
*Author: Product Architecture Team*
