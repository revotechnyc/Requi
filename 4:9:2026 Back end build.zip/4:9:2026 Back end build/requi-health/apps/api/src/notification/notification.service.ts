import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { RedisService } from '../redis/redis.service';

export interface NotificationPayload {
  userId: string;
  type: string;
  title: string;
  message: string;
  data?: Record<string, any>;
}

@Injectable()
export class NotificationService {
  private readonly logger = new Logger(NotificationService.name);
  private readonly notificationChannel = 'requi:notifications';

  constructor(
    private readonly prisma: PrismaService,
    private readonly redisService: RedisService,
  ) {}

  /**
   * Send a notification to a user
   */
  async sendNotification(payload: NotificationPayload): Promise<void> {
    try {
      // Store notification in database
      const notification = await this.prisma.notification.create({
        data: {
          userId: payload.userId,
          type: payload.type,
          title: payload.title,
          message: payload.message,
          data: payload.data || {},
          isRead: false,
        },
      });

      // Publish to Redis for real-time delivery
      await this.redisService.publish(
        `${this.notificationChannel}:${payload.userId}`,
        JSON.stringify({
          id: notification.id,
          ...payload,
          createdAt: notification.createdAt,
        }),
      );

      this.logger.debug(`Notification sent to user ${payload.userId}`);
    } catch (error) {
      this.logger.error('Error sending notification:', error);
    }
  }

  /**
   * Send notification to multiple users
   */
  async sendBulkNotifications(
    userIds: string[],
    payload: Omit<NotificationPayload, 'userId'>,
  ): Promise<void> {
    await Promise.all(
      userIds.map((userId) =>
        this.sendNotification({
          userId,
          ...payload,
        }),
      ),
    );
  }

  /**
   * Send notification to workspace members
   */
  async sendWorkspaceNotification(
    workspaceId: string,
    payload: Omit<NotificationPayload, 'userId'>,
    excludeUserIds?: string[],
  ): Promise<void> {
    try {
      const members = await this.prisma.workspaceMember.findMany({
        where: {
          workspaceId,
          userId: excludeUserIds ? { notIn: excludeUserIds } : undefined,
        },
        select: { userId: true },
      });

      await this.sendBulkNotifications(
        members.map((m) => m.userId),
        payload,
      );
    } catch (error) {
      this.logger.error('Error sending workspace notification:', error);
    }
  }

  /**
   * Get user notifications
   */
  async getUserNotifications(
    userId: string,
    options?: {
      isRead?: boolean;
      page?: number;
      limit?: number;
    },
  ) {
    const { isRead, page = 1, limit = 20 } = options || {};
    const skip = (page - 1) * limit;

    const where: any = { userId };
    if (isRead !== undefined) {
      where.isRead = isRead;
    }

    const [notifications, total, unreadCount] = await Promise.all([
      this.prisma.notification.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      this.prisma.notification.count({ where }),
      this.prisma.notification.count({
        where: { userId, isRead: false },
      }),
    ]);

    return {
      data: notifications,
      unreadCount,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  /**
   * Mark notification as read
   */
  async markAsRead(userId: string, notificationId: string) {
    const notification = await this.prisma.notification.findFirst({
      where: {
        id: notificationId,
        userId,
      },
    });

    if (!notification) {
      throw new Error('Notification not found');
    }

    return this.prisma.notification.update({
      where: { id: notificationId },
      data: { isRead: true, readAt: new Date() },
    });
  }

  /**
   * Mark all notifications as read
   */
  async markAllAsRead(userId: string) {
    return this.prisma.notification.updateMany({
      where: {
        userId,
        isRead: false,
      },
      data: {
        isRead: true,
        readAt: new Date(),
      },
    });
  }

  /**
   * Delete a notification
   */
  async deleteNotification(userId: string, notificationId: string) {
    const notification = await this.prisma.notification.findFirst({
      where: {
        id: notificationId,
        userId,
      },
    });

    if (!notification) {
      throw new Error('Notification not found');
    }

    return this.prisma.notification.delete({
      where: { id: notificationId },
    });
  }

  /**
   * Clean up old notifications
   */
  async cleanup(maxAge: number = 30 * 24 * 60 * 60 * 1000): Promise<void> {
    try {
      const cutoff = new Date(Date.now() - maxAge);

      await this.prisma.notification.deleteMany({
        where: {
          createdAt: { lt: cutoff },
          isRead: true,
        },
      });

      this.logger.debug('Cleaned up old notifications');
    } catch (error) {
      this.logger.error('Error cleaning up notifications:', error);
    }
  }

  /**
   * Subscribe to notifications for a user (for WebSocket/SSE)
   */
  subscribeToNotifications(userId: string, callback: (notification: any) => void): void {
    this.redisService.subscribe(
      `${this.notificationChannel}:${userId}`,
      (message) => {
        try {
          const notification = JSON.parse(message);
          callback(notification);
        } catch (error) {
          this.logger.error('Error parsing notification:', error);
        }
      },
    );
  }
}
