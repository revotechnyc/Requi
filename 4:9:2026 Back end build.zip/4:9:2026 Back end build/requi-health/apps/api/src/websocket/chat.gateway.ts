import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
  OnGatewayConnection,
  OnGatewayDisconnect,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { Logger, UseGuards } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma/prisma.service';
import { ConversationsService } from '../conversations/conversations.service';

interface AuthenticatedSocket extends Socket {
  user?: {
    id: string;
    email: string;
    role: string;
  };
}

@WebSocketGateway({
  namespace: '/chat',
  cors: {
    origin: '*',
    credentials: true,
  },
})
export class ChatGateway implements OnGatewayConnection, OnGatewayDisconnect {
  private readonly logger = new Logger(ChatGateway.name);

  @WebSocketServer()
  server: Server;

  constructor(
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
    private readonly prisma: PrismaService,
    private readonly conversationsService: ConversationsService,
  ) {}

  async handleConnection(client: AuthenticatedSocket) {
    try {
      const token = this.extractToken(client);
      if (!token) {
        client.disconnect();
        return;
      }

      const payload = this.jwtService.verify(token, {
        secret: this.configService.get('JWT_SECRET'),
      });

      client.user = {
        id: payload.sub,
        email: payload.email,
        role: payload.role,
      };

      this.logger.log(`Client connected: ${client.user.id}`);
    } catch (error) {
      this.logger.error('Connection error:', error);
      client.disconnect();
    }
  }

  handleDisconnect(client: AuthenticatedSocket) {
    this.logger.log(`Client disconnected: ${client.user?.id || 'unknown'}`);
  }

  @SubscribeMessage('join_conversation')
  async handleJoinConversation(
    @MessageBody() data: { conversationId: string; workspaceId: string },
    @ConnectedSocket() client: AuthenticatedSocket,
  ) {
    if (!client.user) {
      client.emit('error', { message: 'Not authenticated' });
      return;
    }

    try {
      // Verify access
      await this.conversationsService.getConversation(
        client.user.id,
        data.conversationId,
      );

      const roomId = `conversation:${data.conversationId}`;
      await client.join(roomId);

      client.emit('joined_conversation', {
        conversationId: data.conversationId,
        roomId,
      });

      this.logger.debug(`User ${client.user.id} joined room ${roomId}`);
    } catch (error) {
      client.emit('error', { message: error.message });
    }
  }

  @SubscribeMessage('leave_conversation')
  async handleLeaveConversation(
    @MessageBody() data: { conversationId: string },
    @ConnectedSocket() client: AuthenticatedSocket,
  ) {
    const roomId = `conversation:${data.conversationId}`;
    await client.leave(roomId);

    client.emit('left_conversation', {
      conversationId: data.conversationId,
    });
  }

  @SubscribeMessage('send_message')
  async handleSendMessage(
    @MessageBody()
    data: {
      conversationId: string;
      workspaceId: string;
      content: string;
      filters?: any;
    },
    @ConnectedSocket() client: AuthenticatedSocket,
  ) {
    if (!client.user) {
      client.emit('error', { message: 'Not authenticated' });
      return;
    }

    const roomId = `conversation:${data.conversationId}`;

    try {
      // Save user message
      const userMessage = await this.prisma.message.create({
        data: {
          conversationId: data.conversationId,
          role: 'USER',
          content: data.content,
          status: 'COMPLETE',
        },
      });

      // Broadcast user message to room
      this.server.to(roomId).emit('new_message', {
        id: userMessage.id,
        role: 'USER',
        content: data.content,
        createdAt: userMessage.createdAt,
        userId: client.user.id,
      });

      // Start streaming AI response
      const stream = this.conversationsService.streamMessage(
        client.user.id,
        data.conversationId,
        { content: data.content, filters: data.filters },
      );

      let aiMessageId: string;
      let fullContent = '';

      for await (const chunk of stream) {
        if (chunk.type === 'text') {
          fullContent += chunk.content;

          this.server.to(roomId).emit('stream_chunk', {
            conversationId: data.conversationId,
            content: chunk.content,
            isComplete: false,
          });
        } else if (chunk.type === 'citation') {
          this.server.to(roomId).emit('citation', {
            conversationId: data.conversationId,
            citation: chunk.citation,
          });
        } else if (chunk.type === 'confidence') {
          this.server.to(roomId).emit('confidence', {
            conversationId: data.conversationId,
            confidence: chunk.confidence,
          });
        } else if (chunk.type === 'complete') {
          this.server.to(roomId).emit('stream_complete', {
            conversationId: data.conversationId,
            content: fullContent,
          });
        } else if (chunk.type === 'error') {
          this.server.to(roomId).emit('stream_error', {
            conversationId: data.conversationId,
            error: chunk.error,
          });
        }
      }
    } catch (error) {
      this.logger.error('Error handling message:', error);
      client.emit('error', { message: error.message });
    }
  }

  @SubscribeMessage('typing')
  async handleTyping(
    @MessageBody()
    data: { conversationId: string; isTyping: boolean },
    @ConnectedSocket() client: AuthenticatedSocket,
  ) {
    if (!client.user) return;

    const roomId = `conversation:${data.conversationId}`;

    // Broadcast typing status to other users in room
    client.to(roomId).emit('user_typing', {
      conversationId: data.conversationId,
      userId: client.user.id,
      isTyping: data.isTyping,
    });
  }

  private extractToken(client: Socket): string | null {
    const auth = client.handshake.auth;
    if (auth && auth.token) {
      return auth.token.replace('Bearer ', '');
    }

    const token = client.handshake.query.token as string;
    if (token) {
      return token.replace('Bearer ', '');
    }

    return null;
  }
}
