import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { QueueService } from '../queue/queue.service';
import { NotificationService } from '../notification/notification.service';
import {
  MissingKnowledgeStatus,
  MissingKnowledgePriority,
  ConfidenceLevel,
  TaskType,
  TaskStatus,
} from '@requi/shared-types';

export interface DetectMissingKnowledgeDto {
  query: string;
  workspaceId: string;
  conversationId: string;
  userId: string;
  confidenceLevel: ConfidenceLevel;
  detectedGaps?: string[];
}

export interface CreateMissingKnowledgeEntryDto {
  query: string;
  workspaceId: string;
  detectedGaps: string[];
  suggestedSources?: string[];
  priority?: MissingKnowledgePriority;
  conversationId?: string;
  createdBy: string;
}

@Injectable()
export class MissingKnowledgeService {
  private readonly logger = new Logger(MissingKnowledgeService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly queueService: QueueService,
    private readonly notificationService: NotificationService,
  ) {}

  /**
   * Detect missing knowledge from a query and create entry if needed
   */
  async detectMissingKnowledge(dto: DetectMissingKnowledgeDto): Promise<void> {
    try {
      this.logger.debug(`Detecting missing knowledge for query: ${dto.query}`);

      // Only create entry if confidence is low or unsupported
      if (
        dto.confidenceLevel !== ConfidenceLevel.LOW &&
        dto.confidenceLevel !== ConfidenceLevel.UNSUPPORTED
      ) {
        return;
      }

      // Check if similar entry already exists
      const existingEntry = await this.prisma.missingKnowledge.findFirst({
        where: {
          workspaceId: dto.workspaceId,
          query: {
            contains: dto.query.slice(0, 50),
            mode: 'insensitive',
          },
          status: {
            in: [
              MissingKnowledgeStatus.PENDING,
              MissingKnowledgeStatus.UNDER_REVIEW,
              MissingKnowledgeStatus.SOURCING,
            ],
          },
        },
      });

      if (existingEntry) {
        this.logger.debug(`Similar missing knowledge entry already exists: ${existingEntry.id}`);
        return;
      }

      // Determine priority based on confidence level
      const priority =
        dto.confidenceLevel === ConfidenceLevel.UNSUPPORTED
          ? MissingKnowledgePriority.HIGH
          : MissingKnowledgePriority.MEDIUM;

      // Create missing knowledge entry
      const entry = await this.prisma.missingKnowledge.create({
        data: {
          workspaceId: dto.workspaceId,
          query: dto.query,
          detectedGaps: dto.detectedGaps || ['Insufficient sources to answer query'],
          suggestedSources: dto.suggestedSources || [],
          priority,
          status: MissingKnowledgeStatus.PENDING,
          conversationId: dto.conversationId,
          createdBy: dto.userId,
        },
      });

      this.logger.debug(`Created missing knowledge entry: ${entry.id}`);

      // Create admin task for review
      await this.createAdminTask(entry.id, dto.workspaceId, dto.userId);

      // Queue notification to workspace admins
      await this.queueService.addJob('missing-knowledge-notification', {
        entryId: entry.id,
        workspaceId: dto.workspaceId,
        query: dto.query,
        priority,
      });
    } catch (error) {
      this.logger.error('Error detecting missing knowledge:', error);
    }
  }

  /**
   * Create a missing knowledge entry manually
   */
  async createEntry(dto: CreateMissingKnowledgeEntryDto) {
    const entry = await this.prisma.missingKnowledge.create({
      data: {
        workspaceId: dto.workspaceId,
        query: dto.query,
        detectedGaps: dto.detectedGaps,
        suggestedSources: dto.suggestedSources || [],
        priority: dto.priority || MissingKnowledgePriority.MEDIUM,
        status: MissingKnowledgeStatus.PENDING,
        conversationId: dto.conversationId,
        createdBy: dto.createdBy,
      },
    });

    // Create admin task
    await this.createAdminTask(entry.id, dto.workspaceId, dto.createdBy);

    return entry;
  }

  /**
   * List missing knowledge entries for a workspace
   */
  async listEntries(
    workspaceId: string,
    options?: {
      status?: MissingKnowledgeStatus;
      priority?: MissingKnowledgePriority;
      page?: number;
      limit?: number;
    },
  ) {
    const { status, priority, page = 1, limit = 20 } = options || {};
    const skip = (page - 1) * limit;

    const where: any = { workspaceId };
    if (status) where.status = status;
    if (priority) where.priority = priority;

    const [entries, total] = await Promise.all([
      this.prisma.missingKnowledge.findMany({
        where,
        orderBy: [
          { priority: 'desc' },
          { createdAt: 'desc' },
        ],
        skip,
        take: limit,
        include: {
          resolvedByUser: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              email: true,
            },
          },
          _count: {
            select: { tasks: true },
          },
        },
      }),
      this.prisma.missingKnowledge.count({ where }),
    ]);

    return {
      data: entries,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  /**
   * Get a missing knowledge entry by ID
   */
  async getEntry(id: string) {
    return this.prisma.missingKnowledge.findUnique({
      where: { id },
      include: {
        resolvedByUser: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            email: true,
          },
        },
        tasks: {
          include: {
            assignedToUser: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                email: true,
              },
            },
          },
        },
      },
    });
  }

  /**
   * Update a missing knowledge entry
   */
  async updateEntry(
    id: string,
    dto: {
      status?: MissingKnowledgeStatus;
      priority?: MissingKnowledgePriority;
      detectedGaps?: string[];
      suggestedSources?: string[];
      resolutionNotes?: string;
      resolvedBy?: string;
    },
  ) {
    const updateData: any = { ...dto };

    // If resolving, set resolvedAt timestamp
    if (dto.status === MissingKnowledgeStatus.RESOLVED) {
      updateData.resolvedAt = new Date();
    }

    return this.prisma.missingKnowledge.update({
      where: { id },
      data: updateData,
    });
  }

  /**
   * Resolve a missing knowledge entry
   */
  async resolveEntry(
    id: string,
    resolvedBy: string,
    resolutionNotes: string,
    addedSourceIds?: string[],
  ) {
    const entry = await this.prisma.missingKnowledge.update({
      where: { id },
      data: {
        status: MissingKnowledgeStatus.RESOLVED,
        resolutionNotes,
        resolvedBy,
        resolvedAt: new Date(),
        addedSourceIds: addedSourceIds || [],
      },
    });

    // Update related tasks
    await this.prisma.task.updateMany({
      where: {
        missingKnowledgeId: id,
        status: { not: TaskStatus.COMPLETED },
      },
      data: {
        status: TaskStatus.COMPLETED,
        completedAt: new Date(),
      },
    });

    // Notify the original user if this was from a conversation
    if (entry.conversationId && entry.createdBy) {
      await this.notificationService.sendNotification({
        userId: entry.createdBy,
        type: 'missing_knowledge_resolved',
        title: 'Knowledge Gap Addressed',
        message: `The knowledge gap you reported has been addressed with new sources.`,
        data: {
          entryId: entry.id,
          conversationId: entry.conversationId,
        },
      });
    }

    return entry;
  }

  /**
   * Get statistics for missing knowledge
   */
  async getStats(workspaceId: string) {
    const [
      total,
      byStatus,
      byPriority,
      avgResolutionTime,
      recentTrend,
    ] = await Promise.all([
      this.prisma.missingKnowledge.count({ where: { workspaceId } }),

      this.prisma.missingKnowledge.groupBy({
        by: ['status'],
        where: { workspaceId },
        _count: { id: true },
      }),

      this.prisma.missingKnowledge.groupBy({
        by: ['priority'],
        where: { workspaceId },
        _count: { id: true },
      }),

      this.prisma.missingKnowledge.aggregate({
        where: {
          workspaceId,
          status: MissingKnowledgeStatus.RESOLVED,
          resolvedAt: { not: null },
        },
        _avg: {
          // Calculate average time to resolution
        },
      }),

      this.prisma.missingKnowledge.findMany({
        where: { workspaceId },
        orderBy: { createdAt: 'desc' },
        take: 10,
        select: {
          id: true,
          status: true,
          priority: true,
          createdAt: true,
        },
      }),
    ]);

    return {
      total,
      byStatus: byStatus.reduce(
        (acc, curr) => ({ ...acc, [curr.status]: curr._count.id }),
        {},
      ),
      byPriority: byPriority.reduce(
        (acc, curr) => ({ ...acc, [curr.priority]: curr._count.id }),
        {},
      ),
      recentTrend,
    };
  }

  /**
   * Create admin task for missing knowledge review
   */
  private async createAdminTask(
    missingKnowledgeId: string,
    workspaceId: string,
    createdBy: string,
  ) {
    try {
      // Find workspace admins
      const admins = await this.prisma.workspaceMember.findMany({
        where: {
          workspaceId,
          role: { in: ['OWNER', 'ADMIN'] },
        },
        include: {
          user: true,
        },
      });

      // Create task for each admin
      for (const admin of admins) {
        await this.prisma.task.create({
          data: {
            workspaceId,
            type: TaskType.MISSING_KNOWLEDGE_REVIEW,
            title: 'Review Missing Knowledge Entry',
            description: 'A knowledge gap has been detected that requires review and sourcing.',
            status: TaskStatus.PENDING,
            priority: 'HIGH',
            assignedTo: admin.userId,
            missingKnowledgeId,
            createdBy,
          },
        });

        // Send notification
        await this.notificationService.sendNotification({
          userId: admin.userId,
          type: 'missing_knowledge_task',
          title: 'New Missing Knowledge Entry',
          message: 'A knowledge gap has been detected that requires your attention.',
          data: {
            missingKnowledgeId,
            workspaceId,
          },
        });
      }
    } catch (error) {
      this.logger.error('Error creating admin task:', error);
    }
  }

  /**
   * Bulk update missing knowledge entries
   */
  async bulkUpdate(
    ids: string[],
    dto: {
      status?: MissingKnowledgeStatus;
      priority?: MissingKnowledgePriority;
    },
  ) {
    return this.prisma.missingKnowledge.updateMany({
      where: {
        id: { in: ids },
      },
      data: dto,
    });
  }

  /**
   * Delete a missing knowledge entry
   */
  async deleteEntry(id: string) {
    // Delete related tasks first
    await this.prisma.task.deleteMany({
      where: { missingKnowledgeId: id },
    });

    return this.prisma.missingKnowledge.delete({
      where: { id },
    });
  }
}
