import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Query,
  Req,
  UseGuards,
  HttpStatus,
  ParseUUIDPipe,
  DefaultValuePipe,
  ParseIntPipe,
} from '@nestjs/common';
import { Request } from 'express';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';
import { MissingKnowledgeService } from './missing-knowledge.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { WorkspaceRolesGuard } from '../auth/guards/workspace-roles.guard';
import { WorkspaceRoles } from '../auth/decorators/workspace-roles.decorator';
import { UserRole, MissingKnowledgeStatus, MissingKnowledgePriority } from '@requi/shared-types';

@ApiTags('Missing Knowledge')
@Controller('missing-knowledge')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class MissingKnowledgeController {
  constructor(private readonly missingKnowledgeService: MissingKnowledgeService) {}

  @Get()
  @ApiOperation({ summary: 'List missing knowledge entries' })
  @ApiQuery({ name: 'workspaceId', required: true })
  @ApiQuery({ name: 'status', required: false })
  @ApiQuery({ name: 'priority', required: false })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  @ApiResponse({ status: HttpStatus.OK, description: 'Entries retrieved' })
  async listEntries(
    @Req() req: Request,
    @Query('workspaceId', new ParseUUIDPipe()) workspaceId: string,
    @Query('status') status?: MissingKnowledgeStatus,
    @Query('priority') priority?: MissingKnowledgePriority,
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page?: number,
    @Query('limit', new DefaultValuePipe(20), ParseIntPipe) limit?: number,
  ) {
    return this.missingKnowledgeService.listEntries(workspaceId, {
      status,
      priority,
      page,
      limit,
    });
  }

  @Get('stats')
  @ApiOperation({ summary: 'Get missing knowledge statistics' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Stats retrieved' })
  async getStats(
    @Query('workspaceId', new ParseUUIDPipe()) workspaceId: string,
  ) {
    return this.missingKnowledgeService.getStats(workspaceId);
  }

  @Post()
  @ApiOperation({ summary: 'Create missing knowledge entry' })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Entry created' })
  async createEntry(
    @Req() req: Request,
    @Body() body: {
      workspaceId: string;
      query: string;
      detectedGaps: string[];
      suggestedSources?: string[];
      priority?: MissingKnowledgePriority;
      conversationId?: string;
    },
  ) {
    const userId = req.user?.['id'];
    return this.missingKnowledgeService.createEntry({
      ...body,
      createdBy: userId,
    });
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get missing knowledge entry' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Entry retrieved' })
  async getEntry(@Param('id', ParseUUIDPipe) id: string) {
    return this.missingKnowledgeService.getEntry(id);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Update missing knowledge entry' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Entry updated' })
  async updateEntry(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() body: {
      status?: MissingKnowledgeStatus;
      priority?: MissingKnowledgePriority;
      detectedGaps?: string[];
      suggestedSources?: string[];
      resolutionNotes?: string;
    },
  ) {
    return this.missingKnowledgeService.updateEntry(id, body);
  }

  @Post(':id/resolve')
  @ApiOperation({ summary: 'Resolve missing knowledge entry' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Entry resolved' })
  async resolveEntry(
    @Req() req: Request,
    @Param('id', ParseUUIDPipe) id: string,
    @Body() body: {
      resolutionNotes: string;
      addedSourceIds?: string[];
    },
  ) {
    const userId = req.user?.['id'];
    return this.missingKnowledgeService.resolveEntry(
      id,
      userId,
      body.resolutionNotes,
      body.addedSourceIds,
    );
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete missing knowledge entry' })
  @ApiResponse({ status: HttpStatus.NO_CONTENT, description: 'Entry deleted' })
  async deleteEntry(@Param('id', ParseUUIDPipe) id: string) {
    await this.missingKnowledgeService.deleteEntry(id);
    return { success: true };
  }

  @Post('bulk-update')
  @ApiOperation({ summary: 'Bulk update missing knowledge entries' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Entries updated' })
  async bulkUpdate(
    @Body() body: {
      ids: string[];
      status?: MissingKnowledgeStatus;
      priority?: MissingKnowledgePriority;
    },
  ) {
    return this.missingKnowledgeService.bulkUpdate(body.ids, {
      status: body.status,
      priority: body.priority,
    });
  }
}
