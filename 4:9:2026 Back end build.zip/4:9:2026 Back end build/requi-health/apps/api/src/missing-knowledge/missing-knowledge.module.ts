import { Module } from '@nestjs/common';
import { MissingKnowledgeService } from './missing-knowledge.service';
import { MissingKnowledgeController } from './missing-knowledge.controller';
import { QueueModule } from '../queue/queue.module';
import { NotificationModule } from '../notification/notification.module';

@Module({
  imports: [QueueModule, NotificationModule],
  controllers: [MissingKnowledgeController],
  providers: [MissingKnowledgeService],
  exports: [MissingKnowledgeService],
})
export class MissingKnowledgeModule {}
