import {
  Injectable,
  Logger,
  NotFoundException,
  ForbiddenException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
  ClaudeService,
  ChatMessage,
  StreamChunk,
} from '../ai/services/claude.service';
import { MissingKnowledgeService } from '../missing-knowledge/missing-knowledge.service';
import {
  MessageRole,
  MessageStatus,
  ConfidenceLevel,
  ConversationStatus,
} from '@requi/shared-types';

export interface CreateConversationDto {
  workspaceId: string;
  title?: string;
  initialMessage?: string;
  filters?: {
    jurisdictions?: string[];
    authorityTiers?: string[];
    sourceTypes?: string[];
    dateRange?: { from?: Date; to?: Date };
  };
}

export interface SendMessageDto {
  content: string;
  filters?: {
    jurisdictions?: string[];
    authorityTiers?: string[];
    sourceTypes?: string[];
    dateRange?: { from?: Date; to?: Date };
  };
}

@Injectable()
export class ConversationsService {
  private readonly logger = new Logger(ConversationsService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly claudeService: ClaudeService,
    private readonly missingKnowledgeService: MissingKnowledgeService,
  ) {}

  /**
   * List conversations for a workspace
   */
  async listConversations(
    userId: string,
    workspaceId: string,
    page: number = 1,
    limit: number = 20,
  ) {
    // Verify user has access to workspace
    await this.verifyWorkspaceAccess(userId, workspaceId);

    const skip = (page - 1) * limit;

    const [conversations, total] = await Promise.all([
      this.prisma.conversation.findMany({
        where: { workspaceId },
        orderBy: { updatedAt: 'desc' },
        skip,
        take: limit,
        include: {
          _count: {
            select: { messages: true },
          },
        },
      }),
      this.prisma.conversation.count({
        where: { workspaceId },
      }),
    ]);

    return {
      data: conversations,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  /**
   * Create a new conversation
   */
  async createConversation(userId: string, dto: CreateConversationDto) {
    const { workspaceId, title, initialMessage, filters } = dto;

    // Verify user has access to workspace
    await this.verifyWorkspaceAccess(userId, workspaceId);

    // Create conversation
    const conversation = await this.prisma.conversation.create({
      data: {
        workspaceId,
        title: title || 'New Conversation',
        status: ConversationStatus.ACTIVE,
        filters: filters || {},
      },
    });

    // If initial message provided, send it
    if (initialMessage) {
      await this.sendMessage(userId, conversation.id, {
        content: initialMessage,
        filters,
      });
    }

    return conversation;
  }

  /**
   * Get a conversation by ID
   */
  async getConversation(userId: string, conversationId: string) {
    const conversation = await this.prisma.conversation.findUnique({
      where: { id: conversationId },
      include: {
        _count: {
          select: { messages: true },
        },
      },
    });

    if (!conversation) {
      throw new NotFoundException('Conversation not found');
    }

    // Verify user has access to workspace
    await this.verifyWorkspaceAccess(userId, conversation.workspaceId);

    return conversation;
  }

  /**
   * Update a conversation
   */
  async updateConversation(
    userId: string,
    conversationId: string,
    dto: { title?: string; filters?: any },
  ) {
    const conversation = await this.prisma.conversation.findUnique({
      where: { id: conversationId },
    });

    if (!conversation) {
      throw new NotFoundException('Conversation not found');
    }

    await this.verifyWorkspaceAccess(userId, conversation.workspaceId);

    return this.prisma.conversation.update({
      where: { id: conversationId },
      data: {
        title: dto.title,
        filters: dto.filters
          ? { ...conversation.filters, ...dto.filters }
          : conversation.filters,
      },
    });
  }

  /**
   * Delete a conversation
   */
  async deleteConversation(userId: string, conversationId: string) {
    const conversation = await this.prisma.conversation.findUnique({
      where: { id: conversationId },
    });

    if (!conversation) {
      throw new NotFoundException('Conversation not found');
    }

    await this.verifyWorkspaceAccess(userId, conversation.workspaceId);

    // Soft delete by updating status
    await this.prisma.conversation.update({
      where: { id: conversationId },
      data: { status: ConversationStatus.ARCHIVED },
    });
  }

  /**
   * Send a message and get AI response
   */
  async sendMessage(
    userId: string,
    conversationId: string,
    dto: SendMessageDto,
  ) {
    const conversation = await this.prisma.conversation.findUnique({
      where: { id: conversationId },
      include: {
        workspace: true,
      },
    });

    if (!conversation) {
      throw new NotFoundException('Conversation not found');
    }

    await this.verifyWorkspaceAccess(userId, conversation.workspaceId);

    // Save user message
    const userMessage = await this.prisma.message.create({
      data: {
        conversationId,
        role: MessageRole.USER,
        content: dto.content,
        status: MessageStatus.COMPLETE,
      },
    });

    // Get message history for context
    const messageHistory = await this.getMessageHistory(conversationId);

    // Merge filters (conversation filters + message filters)
    const filters = {
      ...(conversation.filters || {}),
      ...(dto.filters || {}),
    };

    try {
      // Call Claude API
      const response = await this.claudeService.chat({
        workspaceId: conversation.workspaceId,
        conversationId,
        userId,
        messageHistory,
        jurisdictionFilter: filters.jurisdictions,
        authorityTierFilter: filters.authorityTiers,
        sourceTypeFilter: filters.sourceTypes,
        dateRangeFilter: filters.dateRange,
      });

      // Save AI response
      const aiMessage = await this.prisma.message.create({
        data: {
          conversationId,
          role: MessageRole.ASSISTANT,
          content: response.content,
          status: MessageStatus.COMPLETE,
          confidence: response.confidence,
          sources: response.sources.map((s) => ({
            id: s.id,
            title: s.title,
            sourceType: s.sourceType,
            authorityTier: s.authorityTier,
            citation: s.citation,
          })),
          citations: response.citations,
        },
      });

      // Update conversation title if this is the first exchange
      const messageCount = await this.prisma.message.count({
        where: { conversationId },
      });
      if (messageCount <= 2 && conversation.title === 'New Conversation') {
        await this.prisma.conversation.update({
          where: { id: conversationId },
          data: {
            title: dto.content.slice(0, 50) + (dto.content.length > 50 ? '...' : ''),
          },
        });
      }

      // Check for missing knowledge if confidence is low
      if (response.confidence === ConfidenceLevel.LOW ||
          response.confidence === ConfidenceLevel.UNSUPPORTED) {
        await this.missingKnowledgeService.detectMissingKnowledge({
          query: dto.content,
          workspaceId: conversation.workspaceId,
          conversationId,
          userId,
          confidenceLevel: response.confidence,
        });
      }

      return {
        userMessage,
        aiMessage: {
          ...aiMessage,
          sources: response.sources,
        },
      };
    } catch (error) {
      this.logger.error('Error sending message:', error);

      // Save error message
      await this.prisma.message.create({
        data: {
          conversationId,
          role: MessageRole.ASSISTANT,
          content: 'I apologize, but I encountered an error processing your request. Please try again.',
          status: MessageStatus.ERROR,
        },
      });

      throw error;
    }
  }

  /**
   * Stream a message response
   */
  async *streamMessage(
    userId: string,
    conversationId: string,
    dto: SendMessageDto,
  ): AsyncGenerator<StreamChunk> {
    const conversation = await this.prisma.conversation.findUnique({
      where: { id: conversationId },
      include: {
        workspace: true,
      },
    });

    if (!conversation) {
      throw new NotFoundException('Conversation not found');
    }

    await this.verifyWorkspaceAccess(userId, conversation.workspaceId);

    // Save user message
    await this.prisma.message.create({
      data: {
        conversationId,
        role: MessageRole.USER,
        content: dto.content,
        status: MessageStatus.COMPLETE,
      },
    });

    // Get message history
    const messageHistory = await this.getMessageHistory(conversationId);

    // Merge filters
    const filters = {
      ...(conversation.filters || {}),
      ...(dto.filters || {}),
    };

    // Create placeholder AI message
    const aiMessage = await this.prisma.message.create({
      data: {
        conversationId,
        role: MessageRole.ASSISTANT,
        content: '',
        status: MessageStatus.PENDING,
      },
    });

    let fullContent = '';
    let confidence: ConfidenceLevel = ConfidenceLevel.LOW;
    const sources: any[] = [];

    try {
      const stream = this.claudeService.streamChat({
        workspaceId: conversation.workspaceId,
        conversationId,
        userId,
        messageHistory,
        jurisdictionFilter: filters.jurisdictions,
        authorityTierFilter: filters.authorityTiers,
        sourceTypeFilter: filters.sourceTypes,
        dateRangeFilter: filters.dateRange,
      });

      for await (const chunk of stream) {
        if (chunk.type === 'text') {
          fullContent += chunk.content;
        } else if (chunk.type === 'confidence') {
          confidence = chunk.confidence!;
        } else if (chunk.type === 'citation') {
          // Track citations
        }

        yield chunk;
      }

      // Update AI message with complete content
      await this.prisma.message.update({
        where: { id: aiMessage.id },
        data: {
          content: fullContent,
          status: MessageStatus.COMPLETE,
          confidence,
        },
      });

      // Check for missing knowledge
      if (confidence === ConfidenceLevel.LOW ||
          confidence === ConfidenceLevel.UNSUPPORTED) {
        await this.missingKnowledgeService.detectMissingKnowledge({
          query: dto.content,
          workspaceId: conversation.workspaceId,
          conversationId,
          userId,
          confidenceLevel: confidence,
        });
      }
    } catch (error) {
      this.logger.error('Error in stream:', error);

      await this.prisma.message.update({
        where: { id: aiMessage.id },
        data: {
          content: 'I apologize, but I encountered an error processing your request.',
          status: MessageStatus.ERROR,
        },
      });

      yield {
        type: 'error',
        error: error.message,
      };
    }
  }

  /**
   * Get messages in a conversation
   */
  async getMessages(
    userId: string,
    conversationId: string,
    page: number = 1,
    limit: number = 50,
  ) {
    const conversation = await this.prisma.conversation.findUnique({
      where: { id: conversationId },
    });

    if (!conversation) {
      throw new NotFoundException('Conversation not found');
    }

    await this.verifyWorkspaceAccess(userId, conversation.workspaceId);

    const skip = (page - 1) * limit;

    const [messages, total] = await Promise.all([
      this.prisma.message.findMany({
        where: { conversationId },
        orderBy: { createdAt: 'asc' },
        skip,
        take: limit,
      }),
      this.prisma.message.count({
        where: { conversationId },
      }),
    ]);

    return {
      data: messages,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  /**
   * Regenerate the last AI response
   */
  async regenerateResponse(userId: string, conversationId: string) {
    const conversation = await this.prisma.conversation.findUnique({
      where: { id: conversationId },
    });

    if (!conversation) {
      throw new NotFoundException('Conversation not found');
    }

    await this.verifyWorkspaceAccess(userId, conversation.workspaceId);

    // Get the last user message
    const lastUserMessage = await this.prisma.message.findFirst({
      where: {
        conversationId,
        role: MessageRole.USER,
      },
      orderBy: { createdAt: 'desc' },
    });

    if (!lastUserMessage) {
      throw new NotFoundException('No user message found to regenerate response');
    }

    // Delete the last AI message if it exists
    const lastAiMessage = await this.prisma.message.findFirst({
      where: {
        conversationId,
        role: MessageRole.ASSISTANT,
      },
      orderBy: { createdAt: 'desc' },
    });

    if (lastAiMessage) {
      await this.prisma.message.delete({
        where: { id: lastAiMessage.id },
      });
    }

    // Send message again
    return this.sendMessage(userId, conversationId, {
      content: lastUserMessage.content,
    });
  }

  /**
   * Submit feedback for a message
   */
  async submitFeedback(
    userId: string,
    conversationId: string,
    messageId: string,
    isHelpful: boolean,
    comment?: string,
  ) {
    const conversation = await this.prisma.conversation.findUnique({
      where: { id: conversationId },
    });

    if (!conversation) {
      throw new NotFoundException('Conversation not found');
    }

    await this.verifyWorkspaceAccess(userId, conversation.workspaceId);

    const message = await this.prisma.message.findUnique({
      where: { id: messageId },
    });

    if (!message || message.conversationId !== conversationId) {
      throw new NotFoundException('Message not found');
    }

    return this.prisma.messageFeedback.create({
      data: {
        messageId,
        userId,
        isHelpful,
        comment,
      },
    });
  }

  /**
   * Verify user has access to workspace
   */
  private async verifyWorkspaceAccess(userId: string, workspaceId: string) {
    const membership = await this.prisma.workspaceMember.findUnique({
      where: {
        workspaceId_userId: {
          workspaceId,
          userId,
        },
      },
    });

    if (!membership) {
      throw new ForbiddenException('You do not have access to this workspace');
    }

    return membership;
  }

  /**
   * Get message history for context
   */
  private async getMessageHistory(conversationId: string): Promise<ChatMessage[]> {
    const messages = await this.prisma.message.findMany({
      where: {
        conversationId,
        status: { in: [MessageStatus.COMPLETE, MessageStatus.PARTIAL] },
      },
      orderBy: { createdAt: 'asc' },
      take: 20, // Last 20 messages for context
    });

    return messages.map((msg) => ({
      role: msg.role as MessageRole,
      content: msg.content,
    }));
  }
}
