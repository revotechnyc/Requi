import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Query,
  Req,
  Res,
  UseGuards,
  HttpStatus,
  ParseUUIDPipe,
  DefaultValuePipe,
  ParseIntPipe,
} from '@nestjs/common';
import { Request, Response } from 'express';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';
import { ConversationsService } from './conversations.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { WorkspaceRolesGuard } from '../auth/guards/workspace-roles.guard';
import { WorkspaceRoles } from '../auth/decorators/workspace-roles.decorator';
import { UserRole } from '@requi/shared-types';
import { ZodValidationPipe } from '../pipes/zod-validation.pipe';
import {
  createConversationSchema,
  sendMessageSchema,
  updateConversationSchema,
} from '@requi/validation';

@ApiTags('Conversations')
@Controller('conversations')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class ConversationsController {
  constructor(private readonly conversationsService: ConversationsService) {}

  @Get()
  @ApiOperation({ summary: 'List conversations for a workspace' })
  @ApiQuery({ name: 'workspaceId', required: true, description: 'Workspace ID' })
  @ApiQuery({ name: 'page', required: false, description: 'Page number' })
  @ApiQuery({ name: 'limit', required: false, description: 'Items per page' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Conversations retrieved successfully' })
  async listConversations(
    @Req() req: Request,
    @Query('workspaceId', new ParseUUIDPipe()) workspaceId: string,
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('limit', new DefaultValuePipe(20), ParseIntPipe) limit: number,
  ) {
    const userId = req.user?.['id'];
    return this.conversationsService.listConversations(userId, workspaceId, page, limit);
  }

  @Post()
  @ApiOperation({ summary: 'Create a new conversation' })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Conversation created successfully' })
  async createConversation(
    @Req() req: Request,
    @Body(new ZodValidationPipe(createConversationSchema)) body: any,
  ) {
    const userId = req.user?.['id'];
    return this.conversationsService.createConversation(userId, body);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get a conversation by ID' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Conversation retrieved successfully' })
  @ApiResponse({ status: HttpStatus.NOT_FOUND, description: 'Conversation not found' })
  async getConversation(
    @Req() req: Request,
    @Param('id', ParseUUIDPipe) id: string,
  ) {
    const userId = req.user?.['id'];
    return this.conversationsService.getConversation(userId, id);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Update a conversation' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Conversation updated successfully' })
  async updateConversation(
    @Req() req: Request,
    @Param('id', ParseUUIDPipe) id: string,
    @Body(new ZodValidationPipe(updateConversationSchema)) body: any,
  ) {
    const userId = req.user?.['id'];
    return this.conversationsService.updateConversation(userId, id, body);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete a conversation' })
  @ApiResponse({ status: HttpStatus.NO_CONTENT, description: 'Conversation deleted successfully' })
  async deleteConversation(
    @Req() req: Request,
    @Param('id', ParseUUIDPipe) id: string,
  ) {
    const userId = req.user?.['id'];
    await this.conversationsService.deleteConversation(userId, id);
    return { success: true };
  }

  @Post(':id/messages')
  @ApiOperation({ summary: 'Send a message and get AI response' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Message sent successfully' })
  async sendMessage(
    @Req() req: Request,
    @Param('id', ParseUUIDPipe) conversationId: string,
    @Body(new ZodValidationPipe(sendMessageSchema)) body: any,
  ) {
    const userId = req.user?.['id'];
    return this.conversationsService.sendMessage(userId, conversationId, body);
  }

  @Post(':id/messages/stream')
  @ApiOperation({ summary: 'Send a message and stream AI response' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Streaming response' })
  async streamMessage(
    @Req() req: Request,
    @Res() res: Response,
    @Param('id', ParseUUIDPipe) conversationId: string,
    @Body(new ZodValidationPipe(sendMessageSchema)) body: any,
  ) {
    const userId = req.user?.['id'];

    // Set headers for SSE
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    try {
      const stream = this.conversationsService.streamMessage(
        userId,
        conversationId,
        body,
      );

      for await (const chunk of stream) {
        res.write(`data: ${JSON.stringify(chunk)}\n\n`);
      }

      res.write('data: [DONE]\n\n');
      res.end();
    } catch (error) {
      res.write(`data: ${JSON.stringify({ type: 'error', error: error.message })}\n\n`);
      res.end();
    }
  }

  @Get(':id/messages')
  @ApiOperation({ summary: 'Get messages in a conversation' })
  @ApiQuery({ name: 'page', required: false, description: 'Page number' })
  @ApiQuery({ name: 'limit', required: false, description: 'Items per page' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Messages retrieved successfully' })
  async getMessages(
    @Req() req: Request,
    @Param('id', ParseUUIDPipe) conversationId: string,
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('limit', new DefaultValuePipe(50), ParseIntPipe) limit: number,
  ) {
    const userId = req.user?.['id'];
    return this.conversationsService.getMessages(userId, conversationId, page, limit);
  }

  @Post(':id/regenerate')
  @ApiOperation({ summary: 'Regenerate the last AI response' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Response regenerated successfully' })
  async regenerateResponse(
    @Req() req: Request,
    @Param('id', ParseUUIDPipe) conversationId: string,
  ) {
    const userId = req.user?.['id'];
    return this.conversationsService.regenerateResponse(userId, conversationId);
  }

  @Post(':id/feedback')
  @ApiOperation({ summary: 'Submit feedback for a message' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Feedback submitted successfully' })
  async submitFeedback(
    @Req() req: Request,
    @Param('id', ParseUUIDPipe) conversationId: string,
    @Body() body: { messageId: string; isHelpful: boolean; comment?: string },
  ) {
    const userId = req.user?.['id'];
    return this.conversationsService.submitFeedback(
      userId,
      conversationId,
      body.messageId,
      body.isHelpful,
      body.comment,
    );
  }
}
