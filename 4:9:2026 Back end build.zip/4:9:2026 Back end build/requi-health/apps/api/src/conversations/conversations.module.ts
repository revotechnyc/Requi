import { Module } from '@nestjs/common';
import { ConversationsController } from './conversations.controller';
import { ConversationsService } from './conversations.service';
import { AiModule } from '../ai/ai.module';
import { MissingKnowledgeModule } from '../missing-knowledge/missing-knowledge.module';

@Module({
  imports: [AiModule, MissingKnowledgeModule],
  controllers: [ConversationsController],
  providers: [ConversationsService],
  exports: [ConversationsService],
})
export class ConversationsModule {}
