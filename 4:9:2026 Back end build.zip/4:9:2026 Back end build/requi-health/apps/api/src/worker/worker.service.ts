import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { Interval } from '@nestjs/schedule';
import { QueueService } from '../queue/queue.service';
import { DocumentProcessor } from './processors/document.processor';
import { SourceProcessor } from './processors/source.processor';
import { NotificationProcessor } from './processors/notification.processor';

@Injectable()
export class WorkerService implements OnModuleInit {
  private readonly logger = new Logger(WorkerService.name);
  private isProcessing = false;

  constructor(
    private readonly queueService: QueueService,
    private readonly documentProcessor: DocumentProcessor,
    private readonly sourceProcessor: SourceProcessor,
    private readonly notificationProcessor: NotificationProcessor,
  ) {}

  onModuleInit() {
    this.logger.log('Worker service initialized');
    this.startProcessing();
  }

  @Interval(1000)
  async processQueues() {
    if (this.isProcessing) {
      return;
    }

    this.isProcessing = true;

    try {
      await this.processDocumentQueue();
      await this.processSourceQueue();
      await this.processNotificationQueue();
    } catch (error) {
      this.logger.error('Error processing queues:', error);
    } finally {
      this.isProcessing = false;
    }
  }

  private async startProcessing() {
    this.logger.log('Starting queue processing');
  }

  private async processDocumentQueue() {
    const job = await this.queueService.getNextJob('process-document');
    if (!job) return;

    try {
      this.logger.debug(`Processing document job: ${job.id}`);
      await this.documentProcessor.process(job);
      await this.queueService.completeJob('process-document', job.id);
    } catch (error) {
      this.logger.error(`Error processing document job ${job.id}:`, error);
      await this.queueService.failJob(
        'process-document',
        job.id,
        error.message,
        true,
      );
    }
  }

  private async processSourceQueue() {
    const job = await this.queueService.getNextJob('process-source');
    if (!job) return;

    try {
      this.logger.debug(`Processing source job: ${job.id}`);
      await this.sourceProcessor.process(job);
      await this.queueService.completeJob('process-source', job.id);
    } catch (error) {
      this.logger.error(`Error processing source job ${job.id}:`, error);
      await this.queueService.failJob(
        'process-source',
        job.id,
        error.message,
        true,
      );
    }
  }

  private async processNotificationQueue() {
    const job = await this.queueService.getNextJob('missing-knowledge-notification');
    if (!job) return;

    try {
      this.logger.debug(`Processing notification job: ${job.id}`);
      await this.notificationProcessor.processMissingKnowledgeNotification(job);
      await this.queueService.completeJob(
        'missing-knowledge-notification',
        job.id,
      );
    } catch (error) {
      this.logger.error(`Error processing notification job ${job.id}:`, error);
      await this.queueService.failJob(
        'missing-knowledge-notification',
        job.id,
        error.message,
        true,
      );
    }
  }

  /**
   * Get worker statistics
   */
  async getStats() {
    const [documentStats, sourceStats, notificationStats] = await Promise.all([
      this.queueService.getQueueStats('process-document'),
      this.queueService.getQueueStats('process-source'),
      this.queueService.getQueueStats('missing-knowledge-notification'),
    ]);

    return {
      documentQueue: documentStats,
      sourceQueue: sourceStats,
      notificationQueue: notificationStats,
    };
  }
}
