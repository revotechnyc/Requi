import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ScheduleModule } from '@nestjs/schedule';
import { WorkerService } from './worker.service';
import { DocumentProcessor } from './processors/document.processor';
import { SourceProcessor } from './processors/source.processor';
import { NotificationProcessor } from './processors/notification.processor';
import { PrismaModule } from '../prisma/prisma.module';
import { RedisModule } from '../redis/redis.module';
import { QueueModule } from '../queue/queue.module';
import { VectorStoreModule } from '../vector-store/vector-store.module';
import { NotificationModule } from '../notification/notification.module';
import { AiModule } from '../ai/ai.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: ['.env', '../../.env'],
    }),
    ScheduleModule.forRoot(),
    PrismaModule,
    RedisModule,
    QueueModule,
    VectorStoreModule,
    NotificationModule,
    AiModule,
  ],
  providers: [
    WorkerService,
    DocumentProcessor,
    SourceProcessor,
    NotificationProcessor,
  ],
})
export class WorkerModule {}
