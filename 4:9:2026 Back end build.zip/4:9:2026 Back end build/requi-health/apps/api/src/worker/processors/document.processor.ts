import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { VectorStoreService } from '../../vector-store/vector-store.service';
import { SourcesService } from '../../sources/sources.service';

interface DocumentJob {
  id: string;
  sourceId: string;
  fileBuffer: string;
  fileType: string;
  userId: string;
}

@Injectable()
export class DocumentProcessor {
  private readonly logger = new Logger(DocumentProcessor.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly vectorStore: VectorStoreService,
    private readonly sourcesService: SourcesService,
  ) {}

  async process(job: DocumentJob): Promise<void> {
    this.logger.log(`Processing document for source: ${job.sourceId}`);

    try {
      // Update status to processing
      await this.prisma.sourceDocument.update({
        where: { id: job.sourceId },
        data: { processingStatus: 'PROCESSING' },
      });

      // Extract text from document
      const content = await this.extractText(
        Buffer.from(job.fileBuffer, 'base64'),
        job.fileType,
      );

      if (!content || content.trim().length === 0) {
        throw new Error('No text content extracted from document');
      }

      // Process the extracted content
      await this.sourcesService.processSourceContent(job.sourceId, content);

      this.logger.log(`Document processed successfully: ${job.sourceId}`);
    } catch (error) {
      this.logger.error(`Error processing document ${job.sourceId}:`, error);

      // Update status to failed
      await this.prisma.sourceDocument.update({
        where: { id: job.sourceId },
        data: {
          processingStatus: 'FAILED',
          processingError: error.message,
        },
      });

      throw error;
    }
  }

  /**
   * Extract text from document buffer
   */
  private async extractText(
    buffer: Buffer,
    fileType: string,
  ): Promise<string> {
    switch (fileType) {
      case 'text/plain':
        return buffer.toString('utf-8');

      case 'application/pdf':
        return this.extractPdfText(buffer);

      case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
      case 'application/msword':
        return this.extractWordText(buffer);

      case 'text/html':
        return this.extractHtmlText(buffer);

      case 'text/markdown':
        return buffer.toString('utf-8');

      default:
        // Try to extract as plain text
        return buffer.toString('utf-8');
    }
  }

  /**
   * Extract text from PDF
   * Note: In production, use a proper PDF parsing library like pdf-parse
   */
  private async extractPdfText(buffer: Buffer): Promise<string> {
    try {
      // Placeholder for PDF extraction
      // In production: const pdfParse = require('pdf-parse');
      // const data = await pdfParse(buffer);
      // return data.text;

      this.logger.warn('PDF extraction not fully implemented, using placeholder');
      return 'PDF content placeholder - implement with pdf-parse library';
    } catch (error) {
      this.logger.error('Error extracting PDF text:', error);
      throw new Error('Failed to extract text from PDF');
    }
  }

  /**
   * Extract text from Word document
   * Note: In production, use a library like mammoth
   */
  private async extractWordText(buffer: Buffer): Promise<string> {
    try {
      // Placeholder for Word extraction
      // In production: const mammoth = require('mammoth');
      // const result = await mammoth.extractRawText({ buffer });
      // return result.value;

      this.logger.warn('Word extraction not fully implemented, using placeholder');
      return 'Word document content placeholder - implement with mammoth library';
    } catch (error) {
      this.logger.error('Error extracting Word text:', error);
      throw new Error('Failed to extract text from Word document');
    }
  }

  /**
   * Extract text from HTML
   */
  private async extractHtmlText(buffer: Buffer): Promise<string> {
    try {
      const html = buffer.toString('utf-8');
      // Simple HTML tag removal
      return html
        .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
        .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
        .replace(/<[^>]+>/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
    } catch (error) {
      this.logger.error('Error extracting HTML text:', error);
      throw new Error('Failed to extract text from HTML');
    }
  }
}
