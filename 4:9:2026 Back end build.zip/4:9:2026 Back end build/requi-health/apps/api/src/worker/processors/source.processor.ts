import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { SourcesService } from '../../sources/sources.service';

interface SourceJob {
  id: string;
  sourceId: string;
  content: string;
  userId: string;
}

@Injectable()
export class SourceProcessor {
  private readonly logger = new Logger(SourceProcessor.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly sourcesService: SourcesService,
  ) {}

  async process(job: SourceJob): Promise<void> {
    this.logger.log(`Processing source: ${job.sourceId}`);

    try {
      await this.sourcesService.processSourceContent(
        job.sourceId,
        job.content,
      );

      this.logger.log(`Source processed successfully: ${job.sourceId}`);
    } catch (error) {
      this.logger.error(`Error processing source ${job.sourceId}:`, error);
      throw error;
    }
  }
}
