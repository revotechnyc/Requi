import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { NotificationService } from '../../notification/notification.service';

interface NotificationJob {
  id: string;
  entryId: string;
  workspaceId: string;
  query: string;
  priority: string;
}

@Injectable()
export class NotificationProcessor {
  private readonly logger = new Logger(NotificationProcessor.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly notificationService: NotificationService,
  ) {}

  async processMissingKnowledgeNotification(job: NotificationJob): Promise<void> {
    this.logger.log(
      `Processing missing knowledge notification: ${job.entryId}`,
    );

    try {
      // Get workspace admins
      const admins = await this.prisma.workspaceMember.findMany({
        where: {
          workspaceId: job.workspaceId,
          role: { in: ['OWNER', 'ADMIN'] },
        },
        include: {
          user: true,
        },
      });

      // Send notifications to all admins
      for (const admin of admins) {
        await this.notificationService.sendNotification({
          userId: admin.userId,
          type: 'missing_knowledge',
          title: 'New Missing Knowledge Entry',
          message: `A knowledge gap has been detected: "${job.query.slice(0, 100)}${job.query.length > 100 ? '...' : ''}"`,
          data: {
            entryId: job.entryId,
            workspaceId: job.workspaceId,
            priority: job.priority,
          },
        });
      }

      this.logger.log(
        `Missing knowledge notification sent to ${admins.length} admins`,
      );
    } catch (error) {
      this.logger.error(
        `Error processing notification for entry ${job.entryId}:`,
        error,
      );
      throw error;
    }
  }

  async processSourceProcessedNotification(data: {
    sourceId: string;
    userId: string;
    success: boolean;
    error?: string;
  }): Promise<void> {
    try {
      const source = await this.prisma.sourceDocument.findUnique({
        where: { id: data.sourceId },
      });

      if (!source) return;

      await this.notificationService.sendNotification({
        userId: data.userId,
        type: data.success ? 'source_processed' : 'source_processing_failed',
        title: data.success
          ? 'Source Processed Successfully'
          : 'Source Processing Failed',
        message: data.success
          ? `"${source.title}" has been processed and indexed.`
          : `"${source.title}" could not be processed: ${data.error || 'Unknown error'}`,
        data: {
          sourceId: data.sourceId,
        },
      });
    } catch (error) {
      this.logger.error('Error sending source processed notification:', error);
    }
  }
}
