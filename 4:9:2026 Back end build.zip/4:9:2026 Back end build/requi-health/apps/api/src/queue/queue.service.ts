import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { RedisService } from '../redis/redis.service';

export interface JobData {
  [key: string]: any;
}

export interface JobOptions {
  delay?: number;
  priority?: number;
  attempts?: number;
  backoff?: {
    type: 'fixed' | 'exponential';
    delay: number;
  };
}

@Injectable()
export class QueueService implements OnModuleInit {
  private readonly logger = new Logger(QueueService.name);
  private readonly queuePrefix = 'requi:queue';

  constructor(
    private readonly configService: ConfigService,
    private readonly redisService: RedisService,
  ) {}

  async onModuleInit() {
    this.logger.log('Queue service initialized');
  }

  /**
   * Add a job to the queue
   */
  async addJob(
    queueName: string,
    data: JobData,
    options: JobOptions = {},
  ): Promise<string> {
    try {
      const jobId = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      const job = {
        id: jobId,
        data,
        options,
        createdAt: new Date().toISOString(),
        attempts: 0,
      };

      const queueKey = `${this.queuePrefix}:${queueName}`;

      // If delay is specified, add to delayed queue
      if (options.delay && options.delay > 0) {
        const executeAt = Date.now() + options.delay;
        await this.redisService.zadd(`${queueKey}:delayed`, executeAt, JSON.stringify(job));
        this.logger.debug(`Added delayed job ${jobId} to queue ${queueName}`);
      } else {
        // Add to regular queue
        await this.redisService.lpush(`${queueKey}:pending`, JSON.stringify(job));
        this.logger.debug(`Added job ${jobId} to queue ${queueName}`);
      }

      return jobId;
    } catch (error) {
      this.logger.error('Error adding job to queue:', error);
      throw error;
    }
  }

  /**
   * Get the next job from the queue
   */
  async getNextJob(queueName: string): Promise<(JobData & { id: string }) | null> {
    try {
      const queueKey = `${this.queuePrefix}:${queueName}`;

      // First, check for delayed jobs that are ready
      const now = Date.now();
      const delayedJobs = await this.redisService.zrangebyscore(
        `${queueKey}:delayed`,
        0,
        now,
      );

      for (const delayedJob of delayedJobs) {
        const job = JSON.parse(delayedJob);
        // Remove from delayed and add to pending
        await this.redisService.zrem(`${queueKey}:delayed`, delayedJob);
        await this.redisService.lpush(`${queueKey}:pending`, delayedJob);
      }

      // Get next job from pending queue
      const jobData = await this.redisService.brpop(`${queueKey}:pending`, 1);
      if (!jobData) {
        return null;
      }

      const job = JSON.parse(jobData[1]);
      job.attempts += 1;

      // Move to processing
      await this.redisService.hset(
        `${queueKey}:processing`,
        job.id,
        JSON.stringify(job),
      );

      return {
        id: job.id,
        ...job.data,
      };
    } catch (error) {
      this.logger.error('Error getting next job:', error);
      return null;
    }
  }

  /**
   * Mark a job as completed
   */
  async completeJob(queueName: string, jobId: string, result?: any): Promise<void> {
    try {
      const queueKey = `${this.queuePrefix}:${queueName}`;

      // Remove from processing
      await this.redisService.hdel(`${queueKey}:processing`, jobId);

      // Add to completed
      await this.redisService.lpush(
        `${queueKey}:completed`,
        JSON.stringify({
          id: jobId,
          result,
          completedAt: new Date().toISOString(),
        }),
      );

      this.logger.debug(`Job ${jobId} completed in queue ${queueName}`);
    } catch (error) {
      this.logger.error('Error completing job:', error);
    }
  }

  /**
   * Mark a job as failed
   */
  async failJob(
    queueName: string,
    jobId: string,
    error: string,
    retry: boolean = false,
  ): Promise<void> {
    try {
      const queueKey = `${this.queuePrefix}:${queueName}`;

      // Get job from processing
      const jobData = await this.redisService.hget(`${queueKey}:processing`, jobId);
      if (!jobData) {
        return;
      }

      const job = JSON.parse(jobData);
      await this.redisService.hdel(`${queueKey}:processing`, jobId);

      if (retry && job.attempts < (job.options.attempts || 3)) {
        // Retry with backoff
        const backoffDelay = job.options.backoff
          ? job.options.backoff.type === 'exponential'
            ? job.options.backoff.delay * Math.pow(2, job.attempts - 1)
            : job.options.backoff.delay
          : 5000;

        await this.redisService.zadd(
          `${queueKey}:delayed`,
          Date.now() + backoffDelay,
          JSON.stringify(job),
        );

        this.logger.debug(`Job ${jobId} scheduled for retry in ${backoffDelay}ms`);
      } else {
        // Add to failed
        await this.redisService.lpush(
          `${queueKey}:failed`,
          JSON.stringify({
            id: jobId,
            error,
            attempts: job.attempts,
            failedAt: new Date().toISOString(),
          }),
        );

        this.logger.debug(`Job ${jobId} failed in queue ${queueName}`);
      }
    } catch (err) {
      this.logger.error('Error failing job:', err);
    }
  }

  /**
   * Get queue statistics
   */
  async getQueueStats(queueName: string): Promise<{
    pending: number;
    processing: number;
    delayed: number;
    completed: number;
    failed: number;
  }> {
    try {
      const queueKey = `${this.queuePrefix}:${queueName}`;

      const [pending, processing, delayed, completed, failed] = await Promise.all([
        this.redisService.llen(`${queueKey}:pending`),
        this.redisService.hlen(`${queueKey}:processing`),
        this.redisService.zcard(`${queueKey}:delayed`),
        this.redisService.llen(`${queueKey}:completed`),
        this.redisService.llen(`${queueKey}:failed`),
      ]);

      return {
        pending,
        processing,
        delayed,
        completed,
        failed,
      };
    } catch (error) {
      this.logger.error('Error getting queue stats:', error);
      return {
        pending: 0,
        processing: 0,
        delayed: 0,
        completed: 0,
        failed: 0,
      };
    }
  }

  /**
   * Clean up old completed/failed jobs
   */
  async cleanup(queueName: string, maxAge: number = 7 * 24 * 60 * 60 * 1000): Promise<void> {
    try {
      const queueKey = `${this.queuePrefix}:${queueName}`;
      const cutoff = Date.now() - maxAge;

      // Clean completed jobs
      const completedJobs = await this.redisService.lrange(`${queueKey}:completed`, 0, -1);
      for (const jobData of completedJobs) {
        const job = JSON.parse(jobData);
        if (new Date(job.completedAt).getTime() < cutoff) {
          await this.redisService.lrem(`${queueKey}:completed`, 0, jobData);
        }
      }

      // Clean failed jobs
      const failedJobs = await this.redisService.lrange(`${queueKey}:failed`, 0, -1);
      for (const jobData of failedJobs) {
        const job = JSON.parse(jobData);
        if (new Date(job.failedAt).getTime() < cutoff) {
          await this.redisService.lrem(`${queueKey}:failed`, 0, jobData);
        }
      }

      this.logger.debug(`Cleaned up old jobs in queue ${queueName}`);
    } catch (error) {
      this.logger.error('Error cleaning up queue:', error);
    }
  }
}
