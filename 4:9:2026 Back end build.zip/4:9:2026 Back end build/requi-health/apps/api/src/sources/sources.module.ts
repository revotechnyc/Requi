import { Module } from '@nestjs/common';
import { SourcesController } from './sources.controller';
import { SourcesService } from './sources.service';
import { VectorStoreModule } from '../vector-store/vector-store.module';
import { QueueModule } from '../queue/queue.module';

@Module({
  imports: [VectorStoreModule, QueueModule],
  controllers: [SourcesController],
  providers: [SourcesService],
  exports: [SourcesService],
})
export class SourcesModule {}
