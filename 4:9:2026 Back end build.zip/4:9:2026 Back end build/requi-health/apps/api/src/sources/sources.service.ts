import {
  Injectable,
  Logger,
  NotFoundException,
  ForbiddenException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { VectorStoreService } from '../vector-store/vector-store.service';
import { QueueService } from '../queue/queue.service';
import {
  SourceType,
  AuthorityTier,
  SourceStatus,
  ProcessingStatus,
} from '@requi/shared-types';

export interface ListSourcesOptions {
  type?: SourceType;
  authorityTier?: AuthorityTier;
  jurisdiction?: string;
  status?: SourceStatus;
  search?: string;
  page?: number;
  limit?: number;
}

export interface CreateSourceDto {
  workspaceId: string;
  title: string;
  sourceType: SourceType;
  authorityTier: AuthorityTier;
  jurisdiction: string;
  citation?: string;
  url?: string;
  effectiveDate?: Date;
  content?: string;
  metadata?: Record<string, any>;
}

@Injectable()
export class SourcesService {
  private readonly logger = new Logger(SourcesService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly vectorStore: VectorStoreService,
    private readonly queueService: QueueService,
  ) {}

  /**
   * List sources for a workspace
   */
  async listSources(workspaceId: string, options: ListSourcesOptions = {}) {
    const {
      type,
      authorityTier,
      jurisdiction,
      status,
      search,
      page = 1,
      limit = 20,
    } = options;

    const skip = (page - 1) * limit;

    const where: any = { workspaceId };
    if (type) where.sourceType = type;
    if (authorityTier) where.authorityTier = authorityTier;
    if (jurisdiction) where.jurisdiction = jurisdiction;
    if (status) where.status = status;
    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { citation: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [sources, total] = await Promise.all([
      this.prisma.sourceDocument.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
        include: {
          _count: {
            select: { chunks: true },
          },
        },
      }),
      this.prisma.sourceDocument.count({ where }),
    ]);

    return {
      data: sources,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  /**
   * Get source statistics
   */
  async getStats(workspaceId: string) {
    const [
      total,
      byType,
      byAuthorityTier,
      byJurisdiction,
      byStatus,
      processingStats,
    ] = await Promise.all([
      this.prisma.sourceDocument.count({ where: { workspaceId } }),

      this.prisma.sourceDocument.groupBy({
        by: ['sourceType'],
        where: { workspaceId },
        _count: { id: true },
      }),

      this.prisma.sourceDocument.groupBy({
        by: ['authorityTier'],
        where: { workspaceId },
        _count: { id: true },
      }),

      this.prisma.sourceDocument.groupBy({
        by: ['jurisdiction'],
        where: { workspaceId },
        _count: { id: true },
      }),

      this.prisma.sourceDocument.groupBy({
        by: ['status'],
        where: { workspaceId },
        _count: { id: true },
      }),

      this.prisma.sourceDocument.groupBy({
        by: ['processingStatus'],
        where: { workspaceId },
        _count: { id: true },
      }),
    ]);

    return {
      total,
      byType: byType.reduce((acc, curr) => ({ ...acc, [curr.sourceType]: curr._count.id }), {}),
      byAuthorityTier: byAuthorityTier.reduce(
        (acc, curr) => ({ ...acc, [curr.authorityTier]: curr._count.id }),
        {},
      ),
      byJurisdiction: byJurisdiction.reduce(
        (acc, curr) => ({ ...acc, [curr.jurisdiction]: curr._count.id }),
        {},
      ),
      byStatus: byStatus.reduce((acc, curr) => ({ ...acc, [curr.status]: curr._count.id }), {}),
      processingStats: processingStats.reduce(
        (acc, curr) => ({ ...acc, [curr.processingStatus]: curr._count.id }),
        {},
      ),
    };
  }

  /**
   * Create a new source
   */
  async createSource(userId: string, dto: CreateSourceDto) {
    // Verify workspace access
    await this.verifyWorkspaceAccess(userId, dto.workspaceId);

    // Create source document
    const source = await this.prisma.sourceDocument.create({
      data: {
        workspaceId: dto.workspaceId,
        title: dto.title,
        sourceType: dto.sourceType,
        authorityTier: dto.authorityTier,
        jurisdiction: dto.jurisdiction,
        citation: dto.citation,
        url: dto.url,
        effectiveDate: dto.effectiveDate,
        status: SourceStatus.ACTIVE,
        processingStatus: dto.content
          ? ProcessingStatus.PENDING
          : ProcessingStatus.COMPLETED,
        metadata: dto.metadata || {},
        uploadedBy: userId,
      },
    });

    // If content is provided, process it
    if (dto.content) {
      await this.queueService.addJob('process-source', {
        sourceId: source.id,
        content: dto.content,
        userId,
      });
    }

    return source;
  }

  /**
   * Upload a document
   */
  async uploadDocument(
    userId: string,
    file: Express.Multer.File,
    dto: {
      workspaceId: string;
      title: string;
      sourceType: SourceType;
      authorityTier: AuthorityTier;
      jurisdiction: string;
      citation?: string;
      effectiveDate?: string;
    },
  ) {
    // Verify workspace access
    await this.verifyWorkspaceAccess(userId, dto.workspaceId);

    // Create source document
    const source = await this.prisma.sourceDocument.create({
      data: {
        workspaceId: dto.workspaceId,
        title: dto.title,
        sourceType: dto.sourceType,
        authorityTier: dto.authorityTier,
        jurisdiction: dto.jurisdiction,
        citation: dto.citation,
        effectiveDate: dto.effectiveDate ? new Date(dto.effectiveDate) : null,
        status: SourceStatus.ACTIVE,
        processingStatus: ProcessingStatus.PENDING,
        fileName: file.originalname,
        fileType: file.mimetype,
        fileSize: file.size,
        uploadedBy: userId,
      },
    });

    // Queue document processing
    await this.queueService.addJob('process-document', {
      sourceId: source.id,
      fileBuffer: file.buffer.toString('base64'),
      fileType: file.mimetype,
      userId,
    });

    return {
      ...source,
      message: 'Document uploaded and queued for processing',
    };
  }

  /**
   * Get source by ID
   */
  async getSource(id: string) {
    const source = await this.prisma.sourceDocument.findUnique({
      where: { id },
      include: {
        _count: {
          select: { chunks: true },
        },
      },
    });

    if (!source) {
      throw new NotFoundException('Source not found');
    }

    return source;
  }

  /**
   * Get source chunks
   */
  async getSourceChunks(sourceId: string, page: number = 1, limit: number = 50) {
    const skip = (page - 1) * limit;

    const [chunks, total] = await Promise.all([
      this.prisma.sourceChunk.findMany({
        where: { sourceDocumentId: sourceId },
        orderBy: { chunkIndex: 'asc' },
        skip,
        take: limit,
      }),
      this.prisma.sourceChunk.count({
        where: { sourceDocumentId: sourceId },
      }),
    ]);

    return {
      data: chunks,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  /**
   * Update source
   */
  async updateSource(
    userId: string,
    id: string,
    dto: {
      title?: string;
      citation?: string;
      url?: string;
      effectiveDate?: Date;
      status?: SourceStatus;
      metadata?: Record<string, any>;
    },
  ) {
    const source = await this.prisma.sourceDocument.findUnique({
      where: { id },
    });

    if (!source) {
      throw new NotFoundException('Source not found');
    }

    await this.verifyWorkspaceAccess(userId, source.workspaceId);

    return this.prisma.sourceDocument.update({
      where: { id },
      data: {
        ...dto,
        metadata: dto.metadata
          ? { ...source.metadata, ...dto.metadata }
          : source.metadata,
      },
    });
  }

  /**
   * Delete source
   */
  async deleteSource(userId: string, id: string) {
    const source = await this.prisma.sourceDocument.findUnique({
      where: { id },
    });

    if (!source) {
      throw new NotFoundException('Source not found');
    }

    await this.verifyWorkspaceAccess(userId, source.workspaceId);

    // Delete vectors first
    await this.vectorStore.deleteVectorsByDocument(id);

    // Delete source (cascades to chunks)
    await this.prisma.sourceDocument.delete({
      where: { id },
    });
  }

  /**
   * Reindex source
   */
  async reindexSource(userId: string, id: string) {
    const source = await this.prisma.sourceDocument.findUnique({
      where: { id },
    });

    if (!source) {
      throw new NotFoundException('Source not found');
    }

    await this.verifyWorkspaceAccess(userId, source.workspaceId);

    // Update processing status
    await this.prisma.sourceDocument.update({
      where: { id },
      data: {
        processingStatus: ProcessingStatus.PENDING,
      },
    });

    // Delete existing vectors
    await this.vectorStore.deleteVectorsByDocument(id);

    // Queue reprocessing
    await this.queueService.addJob('reindex-source', {
      sourceId: id,
      userId,
    });

    return { message: 'Source queued for reindexing' };
  }

  /**
   * Get source versions
   */
  async getSourceVersions(id: string) {
    const versions = await this.prisma.sourceVersion.findMany({
      where: { sourceDocumentId: id },
      orderBy: { versionNumber: 'desc' },
      include: {
        createdByUser: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
          },
        },
      },
    });

    return versions;
  }

  /**
   * Process source content (called by worker)
   */
  async processSourceContent(sourceId: string, content: string): Promise<void> {
    try {
      this.logger.debug(`Processing source ${sourceId}`);

      // Update processing status
      await this.prisma.sourceDocument.update({
        where: { id: sourceId },
        data: { processingStatus: ProcessingStatus.PROCESSING },
      });

      // Chunk the content
      const chunks = this.chunkContent(content);

      // Process each chunk
      for (let i = 0; i < chunks.length; i++) {
        const chunk = chunks[i];

        // Create chunk record
        const chunkRecord = await this.prisma.sourceChunk.create({
          data: {
            sourceDocumentId: sourceId,
            content: chunk,
            chunkIndex: i,
            tokenCount: this.estimateTokenCount(chunk),
          },
        });

        // Generate embedding and store
        const embedding = await this.vectorStore.generateEmbedding(chunk);
        await this.vectorStore.storeVector(chunkRecord.id, embedding, {
          sourceId,
          chunkIndex: i,
        });
      }

      // Update processing status
      await this.prisma.sourceDocument.update({
        where: { id: sourceId },
        data: {
          processingStatus: ProcessingStatus.COMPLETED,
          processedAt: new Date(),
        },
      });

      this.logger.debug(`Source ${sourceId} processed successfully`);
    } catch (error) {
      this.logger.error(`Error processing source ${sourceId}:`, error);

      await this.prisma.sourceDocument.update({
        where: { id: sourceId },
        data: {
          processingStatus: ProcessingStatus.FAILED,
          processingError: error.message,
        },
      });

      throw error;
    }
  }

  /**
   * Verify workspace access
   */
  private async verifyWorkspaceAccess(userId: string, workspaceId: string) {
    const membership = await this.prisma.workspaceMember.findUnique({
      where: {
        workspaceId_userId: {
          workspaceId,
          userId,
        },
      },
    });

    if (!membership) {
      throw new ForbiddenException('You do not have access to this workspace');
    }

    return membership;
  }

  /**
   * Chunk content into smaller pieces
   */
  private chunkContent(content: string, maxChunkSize: number = 1000): string[] {
    const chunks: string[] = [];
    const sentences = content.match(/[^.!?]+[.!?]+/g) || [content];

    let currentChunk = '';
    for (const sentence of sentences) {
      if (currentChunk.length + sentence.length > maxChunkSize) {
        if (currentChunk) {
          chunks.push(currentChunk.trim());
        }
        currentChunk = sentence;
      } else {
        currentChunk += sentence;
      }
    }

    if (currentChunk) {
      chunks.push(currentChunk.trim());
    }

    return chunks;
  }

  /**
   * Estimate token count (rough approximation)
   */
  private estimateTokenCount(text: string): number {
    // Rough estimate: 1 token ≈ 4 characters for English text
    return Math.ceil(text.length / 4);
  }
}
