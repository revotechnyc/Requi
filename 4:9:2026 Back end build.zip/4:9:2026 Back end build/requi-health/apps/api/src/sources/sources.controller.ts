import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Query,
  Req,
  UseGuards,
  HttpStatus,
  ParseUUIDPipe,
  DefaultValuePipe,
  ParseIntPipe,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { Request } from 'express';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiQuery, ApiConsumes } from '@nestjs/swagger';
import { SourcesService } from './sources.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { WorkspaceRolesGuard } from '../auth/guards/workspace-roles.guard';
import { WorkspaceRoles } from '../auth/decorators/workspace-roles.decorator';
import { UserRole, SourceType, AuthorityTier, SourceStatus } from '@requi/shared-types';

@ApiTags('Sources')
@Controller('sources')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class SourcesController {
  constructor(private readonly sourcesService: SourcesService) {}

  @Get()
  @ApiOperation({ summary: 'List sources for a workspace' })
  @ApiQuery({ name: 'workspaceId', required: true })
  @ApiQuery({ name: 'type', required: false })
  @ApiQuery({ name: 'authorityTier', required: false })
  @ApiQuery({ name: 'jurisdiction', required: false })
  @ApiQuery({ name: 'status', required: false })
  @ApiQuery({ name: 'search', required: false })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  @ApiResponse({ status: HttpStatus.OK, description: 'Sources retrieved' })
  async listSources(
    @Req() req: Request,
    @Query('workspaceId', new ParseUUIDPipe()) workspaceId: string,
    @Query('type') type?: SourceType,
    @Query('authorityTier') authorityTier?: AuthorityTier,
    @Query('jurisdiction') jurisdiction?: string,
    @Query('status') status?: SourceStatus,
    @Query('search') search?: string,
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page?: number,
    @Query('limit', new DefaultValuePipe(20), ParseIntPipe) limit?: number,
  ) {
    return this.sourcesService.listSources(workspaceId, {
      type,
      authorityTier,
      jurisdiction,
      status,
      search,
      page,
      limit,
    });
  }

  @Get('stats')
  @ApiOperation({ summary: 'Get source statistics' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Stats retrieved' })
  async getStats(
    @Query('workspaceId', new ParseUUIDPipe()) workspaceId: string,
  ) {
    return this.sourcesService.getStats(workspaceId);
  }

  @Post()
  @ApiOperation({ summary: 'Create a new source' })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Source created' })
  async createSource(
    @Req() req: Request,
    @Body() body: {
      workspaceId: string;
      title: string;
      sourceType: SourceType;
      authorityTier: AuthorityTier;
      jurisdiction: string;
      citation?: string;
      url?: string;
      effectiveDate?: Date;
      content?: string;
      metadata?: Record<string, any>;
    },
  ) {
    const userId = req.user?.['id'];
    return this.sourcesService.createSource(userId, body);
  }

  @Post('upload')
  @ApiOperation({ summary: 'Upload a document' })
  @ApiConsumes('multipart/form-data')
  @UseInterceptors(FileInterceptor('file'))
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Document uploaded' })
  async uploadDocument(
    @Req() req: Request,
    @UploadedFile() file: Express.Multer.File,
    @Body() body: {
      workspaceId: string;
      title: string;
      sourceType: SourceType;
      authorityTier: AuthorityTier;
      jurisdiction: string;
      citation?: string;
      effectiveDate?: string;
    },
  ) {
    const userId = req.user?.['id'];
    return this.sourcesService.uploadDocument(userId, file, body);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get source by ID' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Source retrieved' })
  async getSource(@Param('id', ParseUUIDPipe) id: string) {
    return this.sourcesService.getSource(id);
  }

  @Get(':id/chunks')
  @ApiOperation({ summary: 'Get source chunks' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Chunks retrieved' })
  async getSourceChunks(
    @Param('id', ParseUUIDPipe) id: string,
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page?: number,
    @Query('limit', new DefaultValuePipe(50), ParseIntPipe) limit?: number,
  ) {
    return this.sourcesService.getSourceChunks(id, page, limit);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Update source' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Source updated' })
  async updateSource(
    @Req() req: Request,
    @Param('id', ParseUUIDPipe) id: string,
    @Body() body: {
      title?: string;
      citation?: string;
      url?: string;
      effectiveDate?: Date;
      status?: SourceStatus;
      metadata?: Record<string, any>;
    },
  ) {
    const userId = req.user?.['id'];
    return this.sourcesService.updateSource(userId, id, body);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete source' })
  @ApiResponse({ status: HttpStatus.NO_CONTENT, description: 'Source deleted' })
  async deleteSource(
    @Req() req: Request,
    @Param('id', ParseUUIDPipe) id: string,
  ) {
    const userId = req.user?.['id'];
    await this.sourcesService.deleteSource(userId, id);
    return { success: true };
  }

  @Post(':id/reindex')
  @ApiOperation({ summary: 'Reindex source' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Source reindexed' })
  async reindexSource(
    @Req() req: Request,
    @Param('id', ParseUUIDPipe) id: string,
  ) {
    const userId = req.user?.['id'];
    return this.sourcesService.reindexSource(userId, id);
  }

  @Get(':id/versions')
  @ApiOperation({ summary: 'Get source versions' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Versions retrieved' })
  async getSourceVersions(
    @Param('id', ParseUUIDPipe) id: string,
  ) {
    return this.sourcesService.getSourceVersions(id);
  }
}
