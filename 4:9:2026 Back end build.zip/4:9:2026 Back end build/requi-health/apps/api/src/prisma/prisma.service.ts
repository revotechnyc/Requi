import { Injectable, OnModuleInit, OnModuleDestroy, Logger } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

@Injectable()
export class PrismaService
  extends PrismaClient
  implements OnModuleInit, OnModuleDestroy
{
  private readonly logger = new Logger(PrismaService.name);

  async onModuleInit() {
    await this.$connect();
    this.logger.log('Connected to database');
  }

  async onModuleDestroy() {
    await this.$disconnect();
    this.logger.log('Disconnected from database');
  }

  /**
   * Execute a raw query
   */
  async $queryRawUnsafe<T = any>(query: string, ...values: any[]): Promise<T> {
    return super.$queryRawUnsafe<T>(query, ...values);
  }

  /**
   * Execute a raw command
   */
  async $executeRawUnsafe(query: string, ...values: any[]): Promise<number> {
    return super.$executeRawUnsafe(query, ...values);
  }
}
