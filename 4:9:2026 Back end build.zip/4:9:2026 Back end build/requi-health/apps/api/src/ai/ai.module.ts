import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ClaudeService } from './services/claude.service';
import { RetrievalService } from './services/retrieval.service';
import { PromptBuilderService } from './services/prompt-builder.service';
import { ResponseParserService } from './services/response-parser.service';
import { VectorStoreModule } from '../vector-store/vector-store.module';

@Module({
  imports: [ConfigModule, VectorStoreModule],
  providers: [
    ClaudeService,
    RetrievalService,
    PromptBuilderService,
    ResponseParserService,
  ],
  exports: [ClaudeService, RetrievalService, PromptBuilderService],
})
export class AiModule {}
