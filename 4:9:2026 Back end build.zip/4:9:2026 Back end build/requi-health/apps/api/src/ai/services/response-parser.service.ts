import { Injectable, Logger } from '@nestjs/common';
import { RetrievedSource } from './retrieval.service';
import { ConfidenceLevel } from '@requi/shared-types';

export interface ParsedResponse {
  content: string;
  confidence: ConfidenceLevel;
  citations: Array<{
    sourceId: string;
    text: string;
    startIndex: number;
    endIndex: number;
  }>;
  cleanContent: string;
}

export interface ParsedDocumentResponse {
  title: string;
  content: string;
  metadata: Record<string, any>;
}

export interface GapAnalysisResult {
  summary: string;
  gaps: Array<{
    description: string;
    severity: 'high' | 'medium' | 'low';
    recommendation: string;
  }>;
}

@Injectable()
export class ResponseParserService {
  private readonly logger = new Logger(ResponseParserService.name);

  /**
   * Parse Claude's response into structured format
   */
  parseResponse(content: string, sources: RetrievedSource[]): ParsedResponse {
    try {
      // Extract confidence level
      const confidence = this.extractConfidence(content);

      // Extract citations
      const citations = this.extractCitations(content, sources);

      // Clean content (remove confidence markers)
      const cleanContent = this.cleanResponseContent(content);

      return {
        content,
        confidence,
        citations,
        cleanContent,
      };
    } catch (error) {
      this.logger.error('Error parsing response:', error);
      return {
        content,
        confidence: ConfidenceLevel.LOW,
        citations: [],
        cleanContent: content,
      };
    }
  }

  /**
   * Parse document generation response
   */
  parseDocumentResponse(content: string): ParsedDocumentResponse {
    try {
      // Try to parse as JSON
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        return {
          title: parsed.title || 'Untitled Document',
          content: parsed.content || content,
          metadata: parsed.metadata || {},
        };
      }

      // Fallback: treat entire content as document
      return {
        title: 'Generated Document',
        content,
        metadata: { raw: true },
      };
    } catch (error) {
      this.logger.error('Error parsing document response:', error);
      return {
        title: 'Generated Document',
        content,
        metadata: { parseError: true },
      };
    }
  }

  /**
   * Parse gap analysis response
   */
  parseGapAnalysis(content: string): GapAnalysisResult {
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        return {
          summary: parsed.summary || 'No summary provided',
          gaps: parsed.gaps || [],
        };
      }

      return {
        summary: 'Unable to parse analysis',
        gaps: [],
      };
    } catch (error) {
      this.logger.error('Error parsing gap analysis:', error);
      return {
        summary: 'Error parsing analysis results',
        gaps: [],
      };
    }
  }

  /**
   * Extract confidence level from response
   */
  private extractConfidence(content: string): ConfidenceLevel {
    const confidenceMatch = content.match(/\[CONFIDENCE:\s*(HIGH|MEDIUM|LOW|UNSUPPORTED)\]/i);
    if (confidenceMatch) {
      const confidence = confidenceMatch[1].toUpperCase();
      if (Object.values(ConfidenceLevel).includes(confidence as ConfidenceLevel)) {
        return confidence as ConfidenceLevel;
      }
    }

    // Default to LOW if no confidence marker found
    return ConfidenceLevel.LOW;
  }

  /**
   * Extract citations from response
   */
  private extractCitations(
    content: string,
    sources: RetrievedSource[],
  ): Array<{
    sourceId: string;
    text: string;
    startIndex: number;
    endIndex: number;
  }> {
    const citations: Array<{
      sourceId: string;
      text: string;
      startIndex: number;
      endIndex: number;
    }> = [];

    // Find citation markers like [1], [2], etc.
    const citationRegex = /\[(\d+)\]/g;
    let match;

    while ((match = citationRegex.exec(content)) !== null) {
      const sourceIndex = parseInt(match[1], 10) - 1;
      if (sourceIndex >= 0 && sourceIndex < sources.length) {
        const source = sources[sourceIndex];

        // Find the surrounding text (sentence containing the citation)
        const sentenceStart = this.findSentenceStart(content, match.index);
        const sentenceEnd = this.findSentenceEnd(content, match.index + match[0].length);
        const sentence = content.substring(sentenceStart, sentenceEnd);

        citations.push({
          sourceId: source.id,
          text: sentence,
          startIndex: sentenceStart,
          endIndex: sentenceEnd,
        });
      }
    }

    return citations;
  }

  /**
   * Clean response content (remove confidence markers, etc.)
   */
  private cleanResponseContent(content: string): string {
    // Remove confidence markers
    let cleaned = content.replace(/\[CONFIDENCE:\s*(HIGH|MEDIUM|LOW|UNSUPPORTED)\]/gi, '');

    // Remove extra whitespace
    cleaned = cleaned.replace(/\n{3,}/g, '\n\n');

    // Trim
    cleaned = cleaned.trim();

    return cleaned;
  }

  /**
   * Find the start of a sentence
   */
  private findSentenceStart(content: string, index: number): number {
    // Look backwards for sentence boundaries
    const sentenceEnders = /[.!?]\s+/g;
    let lastMatch = 0;
    let match;

    sentenceEnders.lastIndex = 0;
    while ((match = sentenceEnders.exec(content)) !== null) {
      if (match.index >= index) {
        break;
      }
      lastMatch = match.index + match[0].length;
    }

    return lastMatch;
  }

  /**
   * Find the end of a sentence
   */
  private findSentenceEnd(content: string, index: number): number {
    // Look forwards for sentence boundaries
    const sentenceEnders = /[.!?](\s+|$)/;
    const remaining = content.substring(index);
    const match = remaining.match(sentenceEnders);

    if (match) {
      return index + match.index + 1;
    }

    return content.length;
  }

  /**
   * Parse missing knowledge assessment
   */
  parseMissingKnowledgeAssessment(content: string): {
    canAnswer: boolean;
    confidence: ConfidenceLevel;
    reasoning: string;
    missingKnowledge: string[];
    suggestedSources: string[];
  } {
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        return {
          canAnswer: parsed.canAnswer ?? false,
          confidence: parsed.confidence || ConfidenceLevel.UNSUPPORTED,
          reasoning: parsed.reasoning || '',
          missingKnowledge: parsed.missingKnowledge || [],
          suggestedSources: parsed.suggestedSources || [],
        };
      }

      return {
        canAnswer: false,
        confidence: ConfidenceLevel.UNSUPPORTED,
        reasoning: 'Unable to parse assessment',
        missingKnowledge: [],
        suggestedSources: [],
      };
    } catch (error) {
      this.logger.error('Error parsing missing knowledge assessment:', error);
      return {
        canAnswer: false,
        confidence: ConfidenceLevel.UNSUPPORTED,
        reasoning: 'Error parsing assessment',
        missingKnowledge: [],
        suggestedSources: [],
      };
    }
  }
}
