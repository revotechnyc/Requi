import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Anthropic from '@anthropic-ai/sdk';
import {
  MessageParam,
  ContentBlock,
  TextBlock,
} from '@anthropic-ai/sdk/resources/messages';
import {
  ConfidenceLevel,
  MessageRole,
  SourceType,
} from '@requi/shared-types';
import { PromptBuilderService } from './prompt-builder.service';
import { ResponseParserService } from './response-parser.service';
import { RetrievalService, RetrievedSource } from './retrieval.service';

export interface ChatMessage {
  role: MessageRole;
  content: string;
  sources?: RetrievedSource[];
  confidence?: ConfidenceLevel;
  metadata?: Record<string, any>;
}

export interface StreamChunk {
  type: 'text' | 'citation' | 'confidence' | 'complete' | 'error';
  content?: string;
  citation?: {
    sourceId: string;
    text: string;
    startIndex: number;
    endIndex: number;
  };
  confidence?: ConfidenceLevel;
  error?: string;
}

export interface ChatOptions {
  workspaceId: string;
  conversationId: string;
  userId: string;
  messageHistory: ChatMessage[];
  jurisdictionFilter?: string[];
  authorityTierFilter?: string[];
  sourceTypeFilter?: string[];
  dateRangeFilter?: { from?: Date; to?: Date };
  enableStreaming?: boolean;
}

@Injectable()
export class ClaudeService {
  private readonly logger = new Logger(ClaudeService.name);
  private anthropic: Anthropic;
  private readonly model: string;
  private readonly maxTokens: number;
  private readonly temperature: number;

  constructor(
    private readonly configService: ConfigService,
    private readonly promptBuilder: PromptBuilderService,
    private readonly responseParser: ResponseParserService,
    private readonly retrievalService: RetrievalService,
  ) {
    const apiKey = this.configService.get<string>('ANTHROPIC_API_KEY');
    if (!apiKey) {
      throw new Error('ANTHROPIC_API_KEY is not configured');
    }

    this.anthropic = new Anthropic({ apiKey });
    this.model = this.configService.get<string>('CLAUDE_MODEL', 'claude-3-5-sonnet-20241022');
    this.maxTokens = this.configService.get<number>('CLAUDE_MAX_TOKENS', 4096);
    this.temperature = this.configService.get<number>('CLAUDE_TEMPERATURE', 0.3);
  }

  /**
   * Send a chat message and get a complete response
   */
  async chat(options: ChatOptions): Promise<{
    content: string;
    sources: RetrievedSource[];
    confidence: ConfidenceLevel;
    citations: Array<{
      sourceId: string;
      text: string;
      startIndex: number;
      endIndex: number;
    }>;
  }> {
    try {
      // Retrieve relevant sources
      const lastMessage = options.messageHistory[options.messageHistory.length - 1];
      const retrievedSources = await this.retrievalService.retrieve({
        query: lastMessage.content,
        workspaceId: options.workspaceId,
        jurisdictionFilter: options.jurisdictionFilter,
        authorityTierFilter: options.authorityTierFilter,
        sourceTypeFilter: options.sourceTypeFilter,
        dateRangeFilter: options.dateRangeFilter,
        topK: 10,
      });

      // Build the prompt with context
      const systemPrompt = this.promptBuilder.buildRagPrompt({
        sources: retrievedSources,
        userContext: {
          jurisdiction: options.jurisdictionFilter?.[0],
          workspaceType: 'healthcare_compliance',
        },
      });

      // Convert message history to Claude format
      const messages: MessageParam[] = this.convertToClaudeMessages(
        options.messageHistory.slice(0, -1), // Exclude the last message (we'll add it separately)
      );

      // Add the current user message with retrieved context
      const userMessageWithContext = this.buildUserMessageWithContext(
        lastMessage.content,
        retrievedSources,
      );
      messages.push({
        role: 'user',
        content: userMessageWithContext,
      });

      // Call Claude API
      const response = await this.anthropic.messages.create({
        model: this.model,
        max_tokens: this.maxTokens,
        temperature: this.temperature,
        system: systemPrompt,
        messages,
      });

      // Parse the response
      const parsedResponse = this.responseParser.parseResponse(
        this.extractTextContent(response.content),
        retrievedSources,
      );

      return {
        content: parsedResponse.content,
        sources: retrievedSources,
        confidence: parsedResponse.confidence,
        citations: parsedResponse.citations,
      };
    } catch (error) {
      this.logger.error('Error in Claude chat:', error);
      throw error;
    }
  }

  /**
   * Stream a chat response
   */
  async *streamChat(options: ChatOptions): AsyncGenerator<StreamChunk> {
    try {
      // Retrieve relevant sources
      const lastMessage = options.messageHistory[options.messageHistory.length - 1];
      const retrievedSources = await this.retrievalService.retrieve({
        query: lastMessage.content,
        workspaceId: options.workspaceId,
        jurisdictionFilter: options.jurisdictionFilter,
        authorityTierFilter: options.authorityTierFilter,
        sourceTypeFilter: options.sourceTypeFilter,
        dateRangeFilter: options.dateRangeFilter,
        topK: 10,
      });

      // Yield sources first
      yield {
        type: 'text',
        content: '',
      };

      // Build the prompt
      const systemPrompt = this.promptBuilder.buildRagPrompt({
        sources: retrievedSources,
        userContext: {
          jurisdiction: options.jurisdictionFilter?.[0],
          workspaceType: 'healthcare_compliance',
        },
      });

      // Convert message history
      const messages: MessageParam[] = this.convertToClaudeMessages(
        options.messageHistory.slice(0, -1),
      );

      const userMessageWithContext = this.buildUserMessageWithContext(
        lastMessage.content,
        retrievedSources,
      );
      messages.push({
        role: 'user',
        content: userMessageWithContext,
      });

      // Stream the response
      const stream = await this.anthropic.messages.create({
        model: this.model,
        max_tokens: this.maxTokens,
        temperature: this.temperature,
        system: systemPrompt,
        messages,
        stream: true,
      });

      let fullContent = '';
      let confidenceEmitted = false;

      for await (const chunk of stream) {
        if (chunk.type === 'content_block_delta') {
          const delta = chunk.delta;
          if (delta.type === 'text_delta') {
            const text = delta.text;
            fullContent += text;

            // Check for confidence marker
            if (!confidenceEmitted && fullContent.includes('[CONFIDENCE:')) {
              const confidence = this.extractConfidenceFromText(fullContent);
              if (confidence) {
                yield {
                  type: 'confidence',
                  confidence,
                };
                confidenceEmitted = true;
              }
            }

            yield {
              type: 'text',
              content: text,
            };
          }
        }
      }

      // Parse final response for citations
      const parsedResponse = this.responseParser.parseResponse(fullContent, retrievedSources);

      // Yield citations
      for (const citation of parsedResponse.citations) {
        yield {
          type: 'citation',
          citation,
        };
      }

      yield {
        type: 'complete',
      };
    } catch (error) {
      this.logger.error('Error in Claude stream:', error);
      yield {
        type: 'error',
        error: error.message,
      };
    }
  }

  /**
   * Generate a document from a template
   */
  async generateDocument(options: {
    templateId: string;
    variables: Record<string, any>;
    workspaceId: string;
    userId: string;
  }): Promise<{
    content: string;
    title: string;
    metadata: Record<string, any>;
  }> {
    try {
      const systemPrompt = this.promptBuilder.buildDocumentGenerationPrompt({
        templateVariables: options.variables,
      });

      const response = await this.anthropic.messages.create({
        model: this.model,
        max_tokens: this.maxTokens,
        temperature: 0.2,
        system: systemPrompt,
        messages: [
          {
            role: 'user',
            content: `Generate a document using the provided template variables. Template ID: ${options.templateId}`,
          },
        ],
      });

      const content = this.extractTextContent(response.content);
      const parsed = this.responseParser.parseDocumentResponse(content);

      return {
        content: parsed.content,
        title: parsed.title,
        metadata: parsed.metadata,
      };
    } catch (error) {
      this.logger.error('Error generating document:', error);
      throw error;
    }
  }

  /**
   * Analyze a document for compliance gaps
   */
  async analyzeDocument(options: {
    documentContent: string;
    documentType: string;
    workspaceId: string;
  }): Promise<{
    gaps: Array<{
      description: string;
      severity: 'high' | 'medium' | 'low';
      recommendation: string;
    }>;
    summary: string;
  }> {
    try {
      const systemPrompt = this.promptBuilder.buildDocumentAnalysisPrompt({
        documentType: options.documentType,
      });

      const response = await this.anthropic.messages.create({
        model: this.model,
        max_tokens: this.maxTokens,
        temperature: 0.2,
        system: systemPrompt,
        messages: [
          {
            role: 'user',
            content: `Analyze the following document for compliance gaps:\n\n${options.documentContent}`,
          },
        ],
      });

      const content = this.extractTextContent(response.content);
      return this.responseParser.parseGapAnalysis(content);
    } catch (error) {
      this.logger.error('Error analyzing document:', error);
      throw error;
    }
  }

  /**
   * Convert internal message format to Claude's format
   */
  private convertToClaudeMessages(messages: ChatMessage[]): MessageParam[] {
    return messages.map((msg) => ({
      role: msg.role === MessageRole.USER ? 'user' : 'assistant',
      content: msg.content,
    }));
  }

  /**
   * Build user message with retrieved context
   */
  private buildUserMessageWithContext(
    query: string,
    sources: RetrievedSource[],
  ): string {
    let contextSection = '';

    if (sources.length > 0) {
      contextSection = '\n\n<retrieved_sources>\n';
      sources.forEach((source, index) => {
        contextSection += `[${index + 1}] ${source.title}\n`;
        contextSection += `Source Type: ${source.sourceType}\n`;
        contextSection += `Authority Tier: ${source.authorityTier}\n`;
        contextSection += `Jurisdiction: ${source.jurisdiction}\n`;
        contextSection += `Content: ${source.content}\n\n`;
      });
      contextSection += '</retrieved_sources>\n\n';
    }

    return `${contextSection}Question: ${query}\n\nPlease provide a response with citations to the sources above where applicable. Include a confidence assessment at the end of your response.`;
  }

  /**
   * Extract text content from Claude response
   */
  private extractTextContent(contentBlocks: ContentBlock[]): string {
    return contentBlocks
      .filter((block): block is TextBlock => block.type === 'text')
      .map((block) => block.text)
      .join('');
  }

  /**
   * Extract confidence level from text
   */
  private extractConfidenceFromText(text: string): ConfidenceLevel | null {
    const match = text.match(/\[CONFIDENCE:\s*(HIGH|MEDIUM|LOW|UNSUPPORTED)\]/i);
    if (match) {
      const confidence = match[1].toUpperCase();
      if (Object.values(ConfidenceLevel).includes(confidence as ConfidenceLevel)) {
        return confidence as ConfidenceLevel;
      }
    }
    return null;
  }
}
