import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { VectorStoreService } from '../../vector-store/vector-store.service';
import {
  SourceType,
  AuthorityTier,
  ConfidenceLevel,
} from '@requi/shared-types';

export interface RetrievedSource {
  id: string;
  title: string;
  content: string;
  sourceType: SourceType;
  authorityTier: AuthorityTier;
  jurisdiction: string;
  citation: string;
  url?: string;
  effectiveDate?: Date;
  sourceDocumentId: string;
  relevanceScore: number;
}

export interface RetrievalOptions {
  query: string;
  workspaceId: string;
  jurisdictionFilter?: string[];
  authorityTierFilter?: string[];
  sourceTypeFilter?: string[];
  dateRangeFilter?: { from?: Date; to?: Date };
  topK?: number;
  minRelevanceScore?: number;
}

@Injectable()
export class RetrievalService {
  private readonly logger = new Logger(RetrievalService.name);

  // Authority tier weights for ranking
  private readonly authorityWeights: Record<AuthorityTier, number> = {
    [AuthorityTier.TIER_1_BINDING_PRIMARY]: 1.0,
    [AuthorityTier.TIER_2_BINDING_SECONDARY]: 0.9,
    [AuthorityTier.TIER_3_OFFICIAL_GUIDANCE]: 0.8,
    [AuthorityTier.TIER_4_INTERPRETIVE]: 0.7,
    [AuthorityTier.TIER_5_INFORMATIVE]: 0.6,
    [AuthorityTier.TIER_6_GENERAL]: 0.5,
  };

  constructor(
    private readonly prisma: PrismaService,
    private readonly vectorStore: VectorStoreService,
  ) {}

  /**
   * Retrieve relevant sources for a query
   */
  async retrieve(options: RetrievalOptions): Promise<RetrievedSource[]> {
    try {
      this.logger.debug(`Retrieving sources for query: ${options.query}`);

      // Generate embedding for the query
      const queryEmbedding = await this.vectorStore.generateEmbedding(options.query);

      // Build filter conditions
      const filters: any = {
        workspaceId: options.workspaceId,
      };

      if (options.jurisdictionFilter?.length) {
        filters.jurisdiction = { in: options.jurisdictionFilter };
      }

      if (options.authorityTierFilter?.length) {
        filters.authorityTier = { in: options.authorityTierFilter };
      }

      if (options.sourceTypeFilter?.length) {
        filters.sourceType = { in: options.sourceTypeFilter };
      }

      if (options.dateRangeFilter) {
        filters.effectiveDate = {};
        if (options.dateRangeFilter.from) {
          filters.effectiveDate.gte = options.dateRangeFilter.from;
        }
        if (options.dateRangeFilter.to) {
          filters.effectiveDate.lte = options.dateRangeFilter.to;
        }
      }

      // Perform vector search
      const vectorResults = await this.vectorStore.search({
        embedding: queryEmbedding,
        filters,
        topK: options.topK || 10,
        minScore: options.minRelevanceScore || 0.7,
      });

      // Fetch full source details from database
      const sourceIds = vectorResults.map((r) => r.sourceChunkId);
      const sources = await this.prisma.sourceChunk.findMany({
        where: {
          id: { in: sourceIds },
        },
        include: {
          sourceDocument: {
            select: {
              id: true,
              title: true,
              sourceType: true,
              authorityTier: true,
              jurisdiction: true,
              citation: true,
              url: true,
              effectiveDate: true,
            },
          },
        },
      });

      // Map and rank results
      const retrievedSources: RetrievedSource[] = sources.map((chunk) => {
        const vectorResult = vectorResults.find((r) => r.sourceChunkId === chunk.id);
        const baseScore = vectorResult?.score || 0;
        const authorityWeight =
          this.authorityWeights[chunk.sourceDocument.authorityTier as AuthorityTier] || 0.5;
        const weightedScore = baseScore * authorityWeight;

        return {
          id: chunk.id,
          title: chunk.sourceDocument.title,
          content: chunk.content,
          sourceType: chunk.sourceDocument.sourceType as SourceType,
          authorityTier: chunk.sourceDocument.authorityTier as AuthorityTier,
          jurisdiction: chunk.sourceDocument.jurisdiction,
          citation: chunk.sourceDocument.citation,
          url: chunk.sourceDocument.url || undefined,
          effectiveDate: chunk.sourceDocument.effectiveDate || undefined,
          sourceDocumentId: chunk.sourceDocument.id,
          relevanceScore: weightedScore,
        };
      });

      // Sort by weighted relevance score
      retrievedSources.sort((a, b) => b.relevanceScore - a.relevanceScore);

      this.logger.debug(`Retrieved ${retrievedSources.length} sources`);
      return retrievedSources;
    } catch (error) {
      this.logger.error('Error retrieving sources:', error);
      throw error;
    }
  }

  /**
   * Retrieve sources by ID
   */
  async getSourcesByIds(sourceIds: string[]): Promise<RetrievedSource[]> {
    try {
      const sources = await this.prisma.sourceChunk.findMany({
        where: {
          id: { in: sourceIds },
        },
        include: {
          sourceDocument: {
            select: {
              id: true,
              title: true,
              sourceType: true,
              authorityTier: true,
              jurisdiction: true,
              citation: true,
              url: true,
              effectiveDate: true,
            },
          },
        },
      });

      return sources.map((chunk) => ({
        id: chunk.id,
        title: chunk.sourceDocument.title,
        content: chunk.content,
        sourceType: chunk.sourceDocument.sourceType as SourceType,
        authorityTier: chunk.sourceDocument.authorityTier as AuthorityTier,
        jurisdiction: chunk.sourceDocument.jurisdiction,
        citation: chunk.sourceDocument.citation,
        url: chunk.sourceDocument.url || undefined,
        effectiveDate: chunk.sourceDocument.effectiveDate || undefined,
        sourceDocumentId: chunk.sourceDocument.id,
        relevanceScore: 1.0, // Direct retrieval has perfect score
      }));
    } catch (error) {
      this.logger.error('Error getting sources by IDs:', error);
      throw error;
    }
  }

  /**
   * Check if query can be answered with available sources
   */
  async assessAnswerability(
    query: string,
    workspaceId: string,
  ): Promise<{
    canAnswer: boolean;
    confidence: ConfidenceLevel;
    relevantSources: RetrievedSource[];
    missingKnowledge?: string[];
  }> {
    try {
      const sources = await this.retrieve({
        query,
        workspaceId,
        topK: 5,
        minRelevanceScore: 0.6,
      });

      if (sources.length === 0) {
        return {
          canAnswer: false,
          confidence: ConfidenceLevel.UNSUPPORTED,
          relevantSources: [],
          missingKnowledge: ['No relevant sources found for this query'],
        };
      }

      // Calculate average relevance score
      const avgScore = sources.reduce((sum, s) => sum + s.relevanceScore, 0) / sources.length;

      let confidence: ConfidenceLevel;
      if (avgScore >= 0.85) {
        confidence = ConfidenceLevel.HIGH;
      } else if (avgScore >= 0.7) {
        confidence = ConfidenceLevel.MEDIUM;
      } else if (avgScore >= 0.5) {
        confidence = ConfidenceLevel.LOW;
      } else {
        confidence = ConfidenceLevel.UNSUPPORTED;
      }

      return {
        canAnswer: confidence !== ConfidenceLevel.UNSUPPORTED,
        confidence,
        relevantSources: sources,
      };
    } catch (error) {
      this.logger.error('Error assessing answerability:', error);
      throw error;
    }
  }

  /**
   * Get source statistics for a workspace
   */
  async getWorkspaceSourceStats(workspaceId: string): Promise<{
    totalSources: number;
    byAuthorityTier: Record<AuthorityTier, number>;
    bySourceType: Record<SourceType, number>;
    byJurisdiction: Record<string, number>;
    lastUpdated: Date | null;
  }> {
    try {
      const stats = await this.prisma.sourceDocument.groupBy({
        by: ['authorityTier', 'sourceType', 'jurisdiction'],
        where: { workspaceId },
        _count: { id: true },
      });

      const totalSources = await this.prisma.sourceDocument.count({
        where: { workspaceId },
      });

      const lastSource = await this.prisma.sourceDocument.findFirst({
        where: { workspaceId },
        orderBy: { updatedAt: 'desc' },
        select: { updatedAt: true },
      });

      // Aggregate by authority tier
      const byAuthorityTier: Record<AuthorityTier, number> = {
        [AuthorityTier.TIER_1_BINDING_PRIMARY]: 0,
        [AuthorityTier.TIER_2_BINDING_SECONDARY]: 0,
        [AuthorityTier.TIER_3_OFFICIAL_GUIDANCE]: 0,
        [AuthorityTier.TIER_4_INTERPRETIVE]: 0,
        [AuthorityTier.TIER_5_INFORMATIVE]: 0,
        [AuthorityTier.TIER_6_GENERAL]: 0,
      };

      // Aggregate by source type
      const bySourceType: Record<SourceType, number> = {
        [SourceType.FEDERAL_STATUTE]: 0,
        [SourceType.FEDERAL_REGULATION]: 0,
        [SourceType.FEDERAL_GUIDANCE]: 0,
        [SourceType.STATE_STATUTE]: 0,
        [SourceType.STATE_REGULATION]: 0,
        [SourceType.STATE_GUIDANCE]: 0,
        [SourceType.PROGRAM_DOCUMENT]: 0,
        [SourceType.CONTRACT]: 0,
        [SourceType.CASE_LAW]: 0,
        [SourceType.ACADEMIC]: 0,
        [SourceType.BEST_PRACTICE]: 0,
        [SourceType.INTERNAL_DOCUMENT]: 0,
      };

      const byJurisdiction: Record<string, number> = {};

      for (const stat of stats) {
        const tier = stat.authorityTier as AuthorityTier;
        const type = stat.sourceType as SourceType;

        if (byAuthorityTier[tier] !== undefined) {
          byAuthorityTier[tier] += stat._count.id;
        }

        if (bySourceType[type] !== undefined) {
          bySourceType[type] += stat._count.id;
        }

        byJurisdiction[stat.jurisdiction] =
          (byJurisdiction[stat.jurisdiction] || 0) + stat._count.id;
      }

      return {
        totalSources,
        byAuthorityTier,
        bySourceType,
        byJurisdiction,
        lastUpdated: lastSource?.updatedAt || null,
      };
    } catch (error) {
      this.logger.error('Error getting source stats:', error);
      throw error;
    }
  }
}
