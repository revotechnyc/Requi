import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma/prisma.service';

export interface VectorSearchResult {
  sourceChunkId: string;
  score: number;
}

export interface VectorSearchOptions {
  embedding: number[];
  filters?: Record<string, any>;
  topK?: number;
  minScore?: number;
}

@Injectable()
export class VectorStoreService {
  private readonly logger = new Logger(VectorStoreService.name);
  private readonly embeddingDimension: number;

  constructor(
    private readonly configService: ConfigService,
    private readonly prisma: PrismaService,
  ) {
    this.embeddingDimension = this.configService.get<number>('EMBEDDING_DIMENSION', 1536);
  }

  /**
   * Generate embedding for text using external service
   * In production, this would call OpenAI, Cohere, or another embedding service
   */
  async generateEmbedding(text: string): Promise<number[]> {
    try {
      // For now, we'll use a mock embedding
      // In production, this should call an embedding API like OpenAI's text-embedding-ada-002
      // Example:
      // const response = await openai.embeddings.create({
      //   model: 'text-embedding-ada-002',
      //   input: text,
      // });
      // return response.data[0].embedding;

      // Mock implementation - generate deterministic pseudo-random embedding
      return this.generateMockEmbedding(text);
    } catch (error) {
      this.logger.error('Error generating embedding:', error);
      throw error;
    }
  }

  /**
   * Store a vector embedding for a source chunk
   */
  async storeVector(
    sourceChunkId: string,
    embedding: number[],
    metadata?: Record<string, any>,
  ): Promise<void> {
    try {
      // Convert embedding array to string for storage
      const embeddingString = `[${embedding.join(',')}]`;

      await this.prisma.$executeRaw`
        INSERT INTO source_embeddings (id, "sourceChunkId", embedding, metadata, "createdAt", "updatedAt")
        VALUES (
          gen_random_uuid(),
          ${sourceChunkId},
          ${embeddingString}::vector,
          ${metadata ? JSON.stringify(metadata) : null}::jsonb,
          NOW(),
          NOW()
        )
        ON CONFLICT ("sourceChunkId") 
        DO UPDATE SET 
          embedding = ${embeddingString}::vector,
          metadata = ${metadata ? JSON.stringify(metadata) : null}::jsonb,
          "updatedAt" = NOW()
      `;

      this.logger.debug(`Stored vector for chunk ${sourceChunkId}`);
    } catch (error) {
      this.logger.error('Error storing vector:', error);
      throw error;
    }
  }

  /**
   * Search for similar vectors
   */
  async search(options: VectorSearchOptions): Promise<VectorSearchResult[]> {
    try {
      const { embedding, filters, topK = 10, minScore = 0.7 } = options;

      // Convert embedding to string
      const embeddingString = `[${embedding.join(',')}]`;

      // Build the query with filters
      let whereClause = '';
      const params: any[] = [embeddingString, minScore, topK];
      let paramIndex = 4;

      if (filters) {
        const conditions: string[] = [];

        if (filters.workspaceId) {
          conditions.push(`sc."workspaceId" = $${paramIndex}`);
          params.push(filters.workspaceId);
          paramIndex++;
        }

        if (filters.jurisdiction?.in) {
          conditions.push(`sd.jurisdiction = ANY($${paramIndex})`);
          params.push(filters.jurisdiction.in);
          paramIndex++;
        }

        if (filters.authorityTier?.in) {
          conditions.push(`sd."authorityTier" = ANY($${paramIndex})`);
          params.push(filters.authorityTier.in);
          paramIndex++;
        }

        if (filters.sourceType?.in) {
          conditions.push(`sd."sourceType" = ANY($${paramIndex})`);
          params.push(filters.sourceType.in);
          paramIndex++;
        }

        if (conditions.length > 0) {
          whereClause = 'WHERE ' + conditions.join(' AND ');
        }
      }

      // Execute similarity search using cosine similarity
      const results = await this.prisma.$queryRawUnsafe<
        Array<{
          source_chunk_id: string;
          similarity: number;
        }>
      >(
        `
        SELECT 
          se."sourceChunkId" as source_chunk_id,
          1 - (se.embedding <=> $1::vector) as similarity
        FROM source_embeddings se
        JOIN source_chunks sc ON se."sourceChunkId" = sc.id
        JOIN source_documents sd ON sc."sourceDocumentId" = sd.id
        ${whereClause}
        AND 1 - (se.embedding <=> $1::vector) >= $2
        ORDER BY se.embedding <=> $1::vector
        LIMIT $3
        `,
        ...params,
      );

      return results.map((r) => ({
        sourceChunkId: r.source_chunk_id,
        score: r.similarity,
      }));
    } catch (error) {
      this.logger.error('Error searching vectors:', error);
      throw error;
    }
  }

  /**
   * Delete a vector by source chunk ID
   */
  async deleteVector(sourceChunkId: string): Promise<void> {
    try {
      await this.prisma.$executeRaw`
        DELETE FROM source_embeddings 
        WHERE "sourceChunkId" = ${sourceChunkId}
      `;

      this.logger.debug(`Deleted vector for chunk ${sourceChunkId}`);
    } catch (error) {
      this.logger.error('Error deleting vector:', error);
      throw error;
    }
  }

  /**
   * Delete vectors by source document ID
   */
  async deleteVectorsByDocument(sourceDocumentId: string): Promise<void> {
    try {
      await this.prisma.$executeRaw`
        DELETE FROM source_embeddings se
        USING source_chunks sc
        WHERE se."sourceChunkId" = sc.id
        AND sc."sourceDocumentId" = ${sourceDocumentId}
      `;

      this.logger.debug(`Deleted vectors for document ${sourceDocumentId}`);
    } catch (error) {
      this.logger.error('Error deleting vectors by document:', error);
      throw error;
    }
  }

  /**
   * Generate a mock embedding for development/testing
   * This creates a deterministic pseudo-random embedding based on text content
   */
  private generateMockEmbedding(text: string): number[] {
    // Simple hash function to seed random numbers
    const hash = this.hashString(text);
    const embedding: number[] = [];

    // Use hash as seed for pseudo-random numbers
    let seed = hash;
    for (let i = 0; i < this.embeddingDimension; i++) {
      seed = (seed * 9301 + 49297) % 233280;
      const random = seed / 233280;
      // Normalize to range [-1, 1]
      embedding.push(random * 2 - 1);
    }

    // Normalize the vector to unit length
    const magnitude = Math.sqrt(embedding.reduce((sum, val) => sum + val * val, 0));
    return embedding.map((val) => val / magnitude);
  }

  /**
   * Simple string hash function
   */
  private hashString(str: string): number {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return Math.abs(hash);
  }
}
