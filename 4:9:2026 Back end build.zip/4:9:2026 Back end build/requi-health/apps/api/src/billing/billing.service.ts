import {
  Injectable,
  Logger,
  BadRequestException,
  NotFoundException,
  ForbiddenException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma/prisma.service';
import { StripeService } from './stripe.service';
import { NotificationService } from '../notification/notification.service';
import {
  SubscriptionStatus,
  AccessMode,
  InvoiceStatus,
} from '@prisma/client';

// Enterprise Pricing: $1,000/user/month, min 25 users
const PRICE_PER_SEAT_CENTS = 100000; // $1,000
const MIN_SEATS = 25;
const SEAT_INCREMENTS = 25;
const TRIAL_DAYS = 30;

export interface CreateSubscriptionDto {
  organizationId: string;
  seatCount: number;
  billingEmail: string;
  billingName?: string;
  billingAddress?: any;
  paymentMethodId?: string;
}

export interface UpgradeSeatsDto {
  organizationId: string;
  newSeatCount: number;
}

export interface BillingInfo {
  subscription: {
    id: string;
    status: SubscriptionStatus;
    tier: {
      name: string;
      seatCount: number;
      totalPriceCents: number;
    };
    seatsUsed: number;
    seatsAvailable: number;
  };
  trial: {
    isActive: boolean;
    daysRemaining: number;
    endsAt: Date | null;
  };
  billing: {
    nextBillingDate: Date;
    amountDueCents: number;
    paymentMethod: any | null;
  };
  invoices: any[];
}

@Injectable()
export class BillingService {
  private readonly logger = new Logger(BillingService.name);

  constructor(
    private readonly configService: ConfigService,
    private readonly prisma: PrismaService,
    private readonly stripeService: StripeService,
    private readonly notificationService: NotificationService,
  ) {}

  /**
   * Initialize subscription tiers (run once at setup)
   */
  async initializeTiers(): Promise<void> {
    const tiers = [
      { name: '25_SEATS', displayName: '25 Users', seatCount: 25 },
      { name: '50_SEATS', displayName: '50 Users', seatCount: 50 },
      { name: '75_SEATS', displayName: '75 Users', seatCount: 75 },
      { name: '100_SEATS', displayName: '100 Users', seatCount: 100 },
      { name: '150_SEATS', displayName: '150 Users', seatCount: 150 },
      { name: '200_SEATS', displayName: '200 Users', seatCount: 200 },
      { name: '250_SEATS', displayName: '250 Users', seatCount: 250 },
      { name: '500_SEATS', displayName: '500 Users', seatCount: 500 },
    ];

    for (const tier of tiers) {
      const totalPriceCents = tier.seatCount * PRICE_PER_SEAT_CENTS;
      
      await this.prisma.subscriptionTier.upsert({
        where: { name: tier.name },
        update: {},
        create: {
          name: tier.name,
          displayName: tier.displayName,
          seatCount: tier.seatCount,
          pricePerSeatCents: PRICE_PER_SEAT_CENTS,
          totalPriceCents,
        },
      });
    }

    this.logger.log('Subscription tiers initialized');
  }

  /**
   * Start trial for new organization
   */
  async startTrial(
    organizationId: string,
    seatCount: number,
    billingEmail: string,
  ): Promise<any> {
    // Validate seat count
    if (seatCount < MIN_SEATS) {
      throw new BadRequestException(
        `Minimum ${MIN_SEATS} seats required for enterprise plan`,
      );
    }

    if (seatCount % SEAT_INCREMENTS !== 0) {
      throw new BadRequestException(
        `Seat count must be in increments of ${SEAT_INCREMENTS}`,
      );
    }

    // Get tier
    const tier = await this.prisma.subscriptionTier.findFirst({
      where: { seatCount },
    });

    if (!tier) {
      throw new BadRequestException('Invalid seat count');
    }

    const trialEndsAt = new Date();
    trialEndsAt.setDate(trialEndsAt.getDate() + TRIAL_DAYS);

    const subscription = await this.prisma.subscription.create({
      data: {
        organizationId,
        tierId: tier.id,
        status: SubscriptionStatus.TRIAL,
        trialStartedAt: new Date(),
        trialEndsAt,
        currentPeriodStart: new Date(),
        currentPeriodEnd: trialEndsAt,
        billingEmail,
        seatsAvailable: seatCount,
        seatsUsed: 0,
      },
      include: {
        tier: true,
      },
    });

    // Log event
    await this.logBillingEvent(
      subscription.id,
      'TRIAL_STARTED',
      null,
      `Trial started for ${seatCount} seats`,
    );

    // Send notification
    await this.notificationService.sendNotification({
      userId: organizationId, // Will be resolved to admin
      type: 'trial_started',
      title: 'Your Trial Has Started',
      message: `Your 30-day trial for ${seatCount} seats begins now. Full platform access enabled.`,
      data: {
        trialEndsAt,
        seatCount,
      },
    });

    return subscription;
  }

  /**
   * Convert trial to paid subscription
   */
  async activateSubscription(
    organizationId: string,
    paymentMethodId: string,
  ): Promise<any> {
    const subscription = await this.prisma.subscription.findUnique({
      where: { organizationId },
      include: { tier: true },
    });

    if (!subscription) {
      throw new NotFoundException('Subscription not found');
    }

    if (subscription.status !== SubscriptionStatus.TRIAL) {
      throw new BadRequestException('Subscription is not in trial status');
    }

    // Create Stripe customer and subscription
    const stripeCustomer = await this.stripeService.createCustomer({
      email: subscription.billingEmail,
      name: subscription.billingName,
      address: subscription.billingAddress,
    });

    const stripeSubscription = await this.stripeService.createSubscription({
      customerId: stripeCustomer.id,
      priceAmount: subscription.tier.totalPriceCents,
      seatCount: subscription.tier.seatCount,
    });

    // Update subscription
    const periodEnd = new Date();
    periodEnd.setMonth(periodEnd.getMonth() + 1);

    const updated = await this.prisma.subscription.update({
      where: { organizationId },
      data: {
        status: SubscriptionStatus.ACTIVE,
        stripeCustomerId: stripeCustomer.id,
        stripeSubscriptionId: stripeSubscription.id,
        stripePaymentMethodId: paymentMethodId,
        currentPeriodStart: new Date(),
        currentPeriodEnd: periodEnd,
      },
      include: { tier: true },
    });

    // Log event
    await this.logBillingEvent(
      subscription.id,
      'SUBSCRIPTION_ACTIVATED',
      subscription.tier.totalPriceCents,
      `Subscription activated for ${subscription.tier.seatCount} seats`,
    );

    return updated;
  }

  /**
   * Upgrade seats (25 -> 50 -> 75, etc.)
   */
  async upgradeSeats(
    organizationId: string,
    newSeatCount: number,
  ): Promise<any> {
    const subscription = await this.prisma.subscription.findUnique({
      where: { organizationId },
      include: { tier: true },
    });

    if (!subscription) {
      throw new NotFoundException('Subscription not found');
    }

    if (newSeatCount <= subscription.tier.seatCount) {
      throw new BadRequestException(
        'New seat count must be greater than current',
      );
    }

    if (newSeatCount % SEAT_INCREMENTS !== 0) {
      throw new BadRequestException(
        `Seat count must be in increments of ${SEAT_INCREMENTS}`,
      );
    }

    const newTier = await this.prisma.subscriptionTier.findFirst({
      where: { seatCount: newSeatCount },
    });

    if (!newTier) {
      throw new BadRequestException('Invalid seat count');
    }

    // Calculate prorated amount
    const daysRemaining = Math.ceil(
      (subscription.currentPeriodEnd.getTime() - Date.now()) /
        (1000 * 60 * 60 * 24),
    );
    const daysInPeriod = 30;
    const proratedAmount = Math.round(
      ((newTier.totalPriceCents - subscription.tier.totalPriceCents) *
        daysRemaining) /
        daysInPeriod,
    );

    // Update Stripe subscription
    if (subscription.stripeSubscriptionId) {
      await this.stripeService.updateSubscription(
        subscription.stripeSubscriptionId,
        newTier.totalPriceCents,
      );

      if (proratedAmount > 0) {
        await this.stripeService.createProratedCharge(
          subscription.stripeCustomerId,
          proratedAmount,
        );
      }
    }

    // Update subscription
    const updated = await this.prisma.subscription.update({
      where: { organizationId },
      data: {
        tierId: newTier.id,
        seatsAvailable: newSeatCount,
      },
      include: { tier: true },
    });

    // Log event
    await this.logBillingEvent(
      subscription.id,
      'SEATS_UPGRADED',
      proratedAmount,
      `Upgraded from ${subscription.tier.seatCount} to ${newSeatCount} seats`,
    );

    return {
      subscription: updated,
      proratedChargeCents: proratedAmount,
    };
  }

  /**
   * Assign seat to user
   */
  async assignSeat(
    organizationId: string,
    userId: string,
    assignedById: string,
  ): Promise<any> {
    const subscription = await this.prisma.subscription.findUnique({
      where: { organizationId },
    });

    if (!subscription) {
      throw new NotFoundException('Subscription not found');
    }

    if (subscription.seatsUsed >= subscription.seatsAvailable) {
      throw new BadRequestException(
        'No seats available. Please upgrade your plan.',
      );
    }

    // Check if user already has a seat
    const existing = await this.prisma.seatAssignment.findFirst({
      where: {
        subscriptionId: subscription.id,
        userId,
        deassignedAt: null,
      },
    });

    if (existing) {
      throw new BadRequestException('User already has a seat assigned');
    }

    // Assign seat
    await this.prisma.seatAssignment.create({
      data: {
        subscriptionId: subscription.id,
        userId,
        organizationId,
        assignedById,
      },
    });

    // Update seat count
    await this.prisma.subscription.update({
      where: { id: subscription.id },
      data: { seatsUsed: { increment: 1 } },
    });

    // Log event
    await this.logBillingEvent(
      subscription.id,
      'SEAT_ASSIGNED',
      null,
      `Seat assigned to user ${userId}`,
    );

    return { success: true };
  }

  /**
   * Unassign seat from user
   */
  async unassignSeat(
    organizationId: string,
    userId: string,
    unassignedById: string,
    reason?: string,
  ): Promise<any> {
    const subscription = await this.prisma.subscription.findUnique({
      where: { organizationId },
    });

    if (!subscription) {
      throw new NotFoundException('Subscription not found');
    }

    const assignment = await this.prisma.seatAssignment.findFirst({
      where: {
        subscriptionId: subscription.id,
        userId,
        deassignedAt: null,
      },
    });

    if (!assignment) {
      throw new NotFoundException('Seat assignment not found');
    }

    // Calculate prorated refund
    const daysRemaining = Math.ceil(
      (subscription.currentPeriodEnd.getTime() - Date.now()) /
        (1000 * 60 * 60 * 24),
    );
    const daysInPeriod = 30;
    const seatPricePerDay =
      subscription.tierId === '' // Will be resolved from tier
        ? PRICE_PER_SEAT_CENTS / daysInPeriod
        : 0;

    // Update assignment
    await this.prisma.seatAssignment.update({
      where: { id: assignment.id },
      data: {
        deassignedById: unassignedById,
        deassignedAt: new Date(),
        deassignmentReason: reason,
      },
    });

    // Update seat count
    await this.prisma.subscription.update({
      where: { id: subscription.id },
      data: { seatsUsed: { decrement: 1 } },
    });

    // Log event
    await this.logBillingEvent(
      subscription.id,
      'SEAT_UNASSIGNED',
      null,
      `Seat unassigned from user ${userId}`,
    );

    return { success: true };
  }

  /**
   * Get billing info for organization
   */
  async getBillingInfo(organizationId: string): Promise<BillingInfo> {
    const subscription = await this.prisma.subscription.findUnique({
      where: { organizationId },
      include: {
        tier: true,
        invoices: {
          orderBy: { createdAt: 'desc' },
          take: 5,
        },
        paymentMethods: {
          where: { isDefault: true },
          take: 1,
        },
      },
    });

    if (!subscription) {
      throw new NotFoundException('Subscription not found');
    }

    const now = new Date();
    const trialDaysRemaining = subscription.trialEndsAt
      ? Math.max(
          0,
          Math.ceil(
            (subscription.trialEndsAt.getTime() - now.getTime()) /
              (1000 * 60 * 60 * 24),
          ),
        )
      : 0;

    return {
      subscription: {
        id: subscription.id,
        status: subscription.status,
        tier: {
          name: subscription.tier.name,
          seatCount: subscription.tier.seatCount,
          totalPriceCents: subscription.tier.totalPriceCents,
        },
        seatsUsed: subscription.seatsUsed,
        seatsAvailable: subscription.seatsAvailable,
      },
      trial: {
        isActive: subscription.status === SubscriptionStatus.TRIAL,
        daysRemaining: trialDaysRemaining,
        endsAt: subscription.trialEndsAt,
      },
      billing: {
        nextBillingDate: subscription.currentPeriodEnd,
        amountDueCents: subscription.tier.totalPriceCents,
        paymentMethod: subscription.paymentMethods[0] || null,
      },
      invoices: subscription.invoices,
    };
  }

  /**
   * Check trial expiration and update access
   */
  async checkTrialExpiration(): Promise<void> {
    const expiredTrials = await this.prisma.subscription.findMany({
      where: {
        status: SubscriptionStatus.TRIAL,
        trialEndsAt: { lt: new Date() },
      },
      include: { organization: true },
    });

    for (const subscription of expiredTrials) {
      // Update subscription status
      await this.prisma.subscription.update({
        where: { id: subscription.id },
        data: { status: SubscriptionStatus.TRIAL_EXPIRED },
      });

      // Update organization access mode
      await this.prisma.organization.update({
        where: { id: subscription.organizationId },
        data: { accessMode: AccessMode.READ_ONLY },
      });

      // Log event
      await this.logBillingEvent(
        subscription.id,
        'TRIAL_ENDED',
        null,
        'Trial expired, access restricted to read-only',
      );

      // Send notification
      await this.notificationService.sendWorkspaceNotification(
        subscription.organizationId,
        {
          type: 'trial_expired',
          title: 'Trial Period Ended',
          message:
            'Your trial has expired. Please upgrade to continue full access.',
          data: {
            subscriptionId: subscription.id,
          },
        },
      );

      this.logger.log(`Trial expired for organization ${subscription.organizationId}`);
    }
  }

  /**
   * Cancel subscription
   */
  async cancelSubscription(
    organizationId: string,
    reason?: string,
  ): Promise<any> {
    const subscription = await this.prisma.subscription.findUnique({
      where: { organizationId },
    });

    if (!subscription) {
      throw new NotFoundException('Subscription not found');
    }

    // Cancel in Stripe
    if (subscription.stripeSubscriptionId) {
      await this.stripeService.cancelSubscription(
        subscription.stripeSubscriptionId,
      );
    }

    // Update subscription
    const updated = await this.prisma.subscription.update({
      where: { organizationId },
      data: {
        status: SubscriptionStatus.CANCELED,
        canceledAt: new Date(),
        cancellationReason: reason,
        cancelAtPeriodEnd: true,
      },
    });

    // Log event
    await this.logBillingEvent(
      subscription.id,
      'SUBSCRIPTION_CANCELED',
      null,
      reason || 'Subscription canceled by user',
    );

    return updated;
  }

  /**
   * Get available tiers
   */
  async getTiers(): Promise<any[]> {
    return this.prisma.subscriptionTier.findMany({
      where: { isActive: true },
      orderBy: { seatCount: 'asc' },
    });
  }

  /**
   * Log billing event
   */
  private async logBillingEvent(
    subscriptionId: string,
    eventType: string,
    amountCents: number | null,
    description: string,
  ): Promise<void> {
    await this.prisma.billingEvent.create({
      data: {
        subscriptionId,
        eventType,
        amountCents,
        description,
      },
    });
  }
}
