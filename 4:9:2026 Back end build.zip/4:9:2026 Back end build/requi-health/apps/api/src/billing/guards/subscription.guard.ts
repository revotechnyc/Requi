import {
  Injectable,
  CanActivate,
  ExecutionContext,
  ForbiddenException,
} from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { SubscriptionStatus, AccessMode } from '@prisma/client';

@Injectable()
export class SubscriptionGuard implements CanActivate {
  constructor(private readonly prisma: PrismaService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const user = request.user;
    const organizationId =
      request.params.organizationId ||
      request.query.organizationId ||
      request.body?.organizationId;

    if (!user) {
      throw new ForbiddenException('Not authenticated');
    }

    if (!organizationId) {
      // Allow if no org specified (might be a public endpoint)
      return true;
    }

    // Get organization with subscription
    const organization = await this.prisma.organization.findUnique({
      where: { id: organizationId },
      include: { subscription: true },
    });

    if (!organization) {
      throw new ForbiddenException('Organization not found');
    }

    // Check access mode
    if (organization.accessMode === AccessMode.BLOCKED) {
      throw new ForbiddenException(
        'Organization access has been suspended. Please contact support.',
      );
    }

    // Check subscription status
    const subscription = organization.subscription;

    if (!subscription) {
      throw new ForbiddenException(
        'No active subscription. Please start a trial or subscribe.',
      );
    }

    // Allow access for active subscriptions
    if (subscription.status === SubscriptionStatus.ACTIVE) {
      return true;
    }

    // Allow access for trial
    if (subscription.status === SubscriptionStatus.TRIAL) {
      return true;
    }

    // Deny access for expired/canceled subscriptions
    if (subscription.status === SubscriptionStatus.TRIAL_EXPIRED) {
      throw new ForbiddenException(
        'Trial has expired. Please upgrade to continue.',
      );
    }

    if (subscription.status === SubscriptionStatus.CANCELED) {
      throw new ForbiddenException(
        'Subscription has been canceled. Please resubscribe.',
      );
    }

    if (subscription.status === SubscriptionStatus.UNPAID) {
      throw new ForbiddenException(
        'Payment required. Please update your payment method.',
      );
    }

    return true;
  }
}
