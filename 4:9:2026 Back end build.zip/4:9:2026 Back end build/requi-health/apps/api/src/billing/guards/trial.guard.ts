import {
  Injectable,
  CanActivate,
  ExecutionContext,
  ForbiddenException,
} from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { SubscriptionStatus, AccessMode } from '@prisma/client';

/**
 * TrialGuard - Restricts access to certain features during trial period
 * 
 * Use this guard for features that should be limited during trial:
 * - Advanced AI features
 * - Bulk operations
 * - API access
 * - Custom integrations
 */
@Injectable()
export class TrialGuard implements CanActivate {
  constructor(private readonly prisma: PrismaService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const user = request.user;
    const organizationId =
      request.params.organizationId ||
      request.query.organizationId ||
      request.body?.organizationId;

    if (!user) {
      throw new ForbiddenException('Not authenticated');
    }

    if (!organizationId) {
      return true;
    }

    // Get organization with subscription
    const organization = await this.prisma.organization.findUnique({
      where: { id: organizationId },
      include: { subscription: true },
    });

    if (!organization) {
      throw new ForbiddenException('Organization not found');
    }

    // Full access for paid subscriptions
    if (organization.subscription?.status === SubscriptionStatus.ACTIVE) {
      return true;
    }

    // Check if in trial
    if (organization.subscription?.status === SubscriptionStatus.TRIAL) {
      // Trial users have limited access - throw with helpful message
      throw new ForbiddenException(
        'This feature requires a paid subscription. Please upgrade to access advanced features.',
      );
    }

    // Any other status (expired, canceled, unpaid) - deny access
    if (organization.accessMode === AccessMode.BLOCKED) {
      throw new ForbiddenException(
        'Organization access has been suspended. Please contact support.',
      );
    }

    if (organization.subscription?.status === SubscriptionStatus.TRIAL_EXPIRED) {
      throw new ForbiddenException(
        'Trial has expired. Please upgrade to continue.',
      );
    }

    if (organization.subscription?.status === SubscriptionStatus.CANCELED) {
      throw new ForbiddenException(
        'Subscription has been canceled. Please resubscribe.',
      );
    }

    if (organization.subscription?.status === SubscriptionStatus.UNPAID) {
      throw new ForbiddenException(
        'Payment required. Please update your payment method.',
      );
    }

    // No subscription at all
    throw new ForbiddenException(
      'Subscription required. Please start a trial or subscribe.',
    );
  }
}
