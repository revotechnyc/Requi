import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { PrismaService } from '../prisma/prisma.service';
import { BillingService } from './billing.service';
import { SubscriptionStatus, AccessMode } from '@prisma/client';

/**
 * BillingScheduler - Handles scheduled billing tasks
 * 
 * Tasks:
 * - Check trial expirations daily
 * - Check subscription renewals
 * - Generate usage reports
 * - Send billing notifications
 */
@Injectable()
export class BillingScheduler {
  private readonly logger = new Logger(BillingScheduler.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly billingService: BillingService,
  ) {}

  /**
   * Check trial expirations - runs daily at midnight
   * Converts expired trials to read-only mode
   */
  @Cron(CronExpression.EVERY_DAY_AT_MIDNIGHT)
  async checkTrialExpirations(): Promise<void> {
    this.logger.log('Checking trial expirations...');

    const now = new Date();

    // Find all active trials that have expired
    const expiredTrials = await this.prisma.subscription.findMany({
      where: {
        status: SubscriptionStatus.TRIAL,
        trialEndsAt: {
          lt: now,
        },
      },
      include: {
        organization: true,
      },
    });

    this.logger.log(`Found ${expiredTrials.length} expired trials`);

    for (const subscription of expiredTrials) {
      try {
        // Update subscription status to TRIAL_EXPIRED
        await this.prisma.subscription.update({
          where: { id: subscription.id },
          data: {
            status: SubscriptionStatus.TRIAL_EXPIRED,
          },
        });

        // Set organization to READ_ONLY mode
        await this.prisma.organization.update({
          where: { id: subscription.organizationId },
          data: {
            accessMode: AccessMode.READ_ONLY,
          },
        });

        // Create billing event
        await this.prisma.billingEvent.create({
          data: {
            organizationId: subscription.organizationId,
            eventType: 'TRIAL_EXPIRED',
            description: 'Trial period has expired',
            metadata: {
              trialStartedAt: subscription.trialStartedAt,
              trialEndsAt: subscription.trialEndsAt,
            },
          },
        });

        // TODO: Send notification email to organization admins
        this.logger.log(
          `Trial expired for organization: ${subscription.organization.name}`,
        );
      } catch (error) {
        this.logger.error(
          `Failed to process trial expiration for ${subscription.organizationId}:`,
          error,
        );
      }
    }
  }

  /**
   * Check subscription renewals - runs daily at 1 AM
   * Handles upcoming renewals and payment reminders
   */
  @Cron(CronExpression.EVERY_DAY_AT_1AM)
  async checkUpcomingRenewals(): Promise<void> {
    this.logger.log('Checking upcoming renewals...');

    const now = new Date();
    const threeDaysFromNow = new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000);

    // Find subscriptions renewing in the next 3 days
    const upcomingRenewals = await this.prisma.subscription.findMany({
      where: {
        status: SubscriptionStatus.ACTIVE,
        currentPeriodEnd: {
          gte: now,
          lte: threeDaysFromNow,
        },
      },
      include: {
        organization: true,
      },
    });

    this.logger.log(
      `Found ${upcomingRenewals.length} upcoming renewals`,
    );

    for (const subscription of upcomingRenewals) {
      try {
        // Create billing event for renewal reminder
        await this.prisma.billingEvent.create({
          data: {
            organizationId: subscription.organizationId,
            eventType: 'RENEWAL_REMINDER',
            description: `Subscription renews on ${subscription.currentPeriodEnd.toISOString()}`,
            metadata: {
              renewalDate: subscription.currentPeriodEnd,
              seatsUsed: subscription.seatsUsed,
              monthlyCost: subscription.seatsUsed * 1000,
            },
          },
        });

        // TODO: Send renewal reminder email
        this.logger.log(
          `Renewal reminder for: ${subscription.organization.name}`,
        );
      } catch (error) {
        this.logger.error(
          `Failed to process renewal reminder for ${subscription.organizationId}:`,
          error,
        );
      }
    }
  }

  /**
   * Generate monthly usage reports - runs on the 1st of each month at 2 AM
   */
  @Cron('0 2 1 * *')
  async generateMonthlyUsageReports(): Promise<void> {
    this.logger.log('Generating monthly usage reports...');

    const activeSubscriptions = await this.prisma.subscription.findMany({
      where: {
        status: {
          in: [SubscriptionStatus.ACTIVE, SubscriptionStatus.TRIAL],
        },
      },
      include: {
        organization: {
          include: {
            workspaces: true,
            members: true,
          },
        },
      },
    });

    for (const subscription of activeSubscriptions) {
      try {
        // Calculate usage metrics
        const workspaceCount = subscription.organization.workspaces.length;
        const memberCount = subscription.organization.members.length;

        // Get conversation count for the past month
        const monthStart = new Date();
        monthStart.setMonth(monthStart.getMonth() - 1);
        monthStart.setDate(1);
        monthStart.setHours(0, 0, 0, 0);

        const monthEnd = new Date();
        monthEnd.setDate(1);
        monthEnd.setHours(0, 0, 0, 0);

        const conversationCount = await this.prisma.conversation.count({
          where: {
            workspace: {
              organizationId: subscription.organizationId,
            },
            createdAt: {
              gte: monthStart,
              lt: monthEnd,
            },
          },
        });

        // Create usage record
        await this.prisma.usageRecord.create({
          data: {
            organizationId: subscription.organizationId,
            periodStart: monthStart,
            periodEnd: monthEnd,
            workspaceCount,
            memberCount,
            conversationCount,
            metadata: {
              subscriptionStatus: subscription.status,
              seatsAvailable: subscription.seatsAvailable,
              seatsUsed: subscription.seatsUsed,
            },
          },
        });

        this.logger.log(
          `Usage report generated for: ${subscription.organization.name}`,
        );
      } catch (error) {
        this.logger.error(
          `Failed to generate usage report for ${subscription.organizationId}:`,
          error,
        );
      }
    }
  }

  /**
   * Check for unpaid subscriptions - runs daily at 3 AM
   * Suspend access for unpaid accounts after grace period
   */
  @Cron(CronExpression.EVERY_DAY_AT_3AM)
  async checkUnpaidSubscriptions(): Promise<void> {
    this.logger.log('Checking unpaid subscriptions...');

    const now = new Date();
    const gracePeriodDays = 7;
    const gracePeriodEnd = new Date(
      now.getTime() - gracePeriodDays * 24 * 60 * 60 * 1000,
    );

    // Find unpaid subscriptions past grace period
    const unpaidSubscriptions = await this.prisma.subscription.findMany({
      where: {
        status: SubscriptionStatus.UNPAID,
        updatedAt: {
          lt: gracePeriodEnd,
        },
      },
      include: {
        organization: true,
      },
    });

    this.logger.log(
      `Found ${unpaidSubscriptions.length} unpaid subscriptions past grace period`,
    );

    for (const subscription of unpaidSubscriptions) {
      try {
        // Suspend organization access
        await this.prisma.organization.update({
          where: { id: subscription.organizationId },
          data: {
            accessMode: AccessMode.SUSPENDED,
          },
        });

        // Create billing event
        await this.prisma.billingEvent.create({
          data: {
            organizationId: subscription.organizationId,
            eventType: 'SUBSCRIPTION_SUSPENDED',
            description: 'Subscription suspended due to non-payment',
            metadata: {
              gracePeriodDays,
              suspendedAt: now,
            },
          },
        });

        this.logger.log(
          `Suspended organization: ${subscription.organization.name}`,
        );
      } catch (error) {
        this.logger.error(
          `Failed to suspend organization ${subscription.organizationId}:`,
          error,
        );
      }
    }
  }
}
