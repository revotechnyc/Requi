import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Req,
  UseGuards,
  HttpCode,
  HttpStatus,
  Headers,
  RawBody,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth } from '@nestjs/swagger';
import { BillingService } from './billing.service';
import { StripeService } from './stripe.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { WorkspaceRolesGuard } from '../auth/guards/workspace-roles.guard';
import { WorkspaceRoles } from '../auth/decorators/workspace-roles.decorator';
import { UserRole } from '@requi/shared-types';

@ApiTags('Billing')
@Controller('billing')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class BillingController {
  constructor(
    private readonly billingService: BillingService,
    private readonly stripeService: StripeService,
  ) {}

  @Get('tiers')
  @ApiOperation({ summary: 'Get available subscription tiers' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Tiers retrieved' })
  async getTiers() {
    return this.billingService.getTiers();
  }

  @Get(':organizationId')
  @ApiOperation({ summary: 'Get billing info for organization' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Billing info retrieved' })
  async getBillingInfo(@Param('organizationId') organizationId: string) {
    return this.billingService.getBillingInfo(organizationId);
  }

  @Post('trial/:organizationId')
  @ApiOperation({ summary: 'Start trial for organization' })
  @ApiResponse({ status: HttpStatus.CREATED, description: 'Trial started' })
  async startTrial(
    @Param('organizationId') organizationId: string,
    @Body() body: { seatCount: number; billingEmail: string },
  ) {
    return this.billingService.startTrial(
      organizationId,
      body.seatCount,
      body.billingEmail,
    );
  }

  @Post('activate/:organizationId')
  @ApiOperation({ summary: 'Activate paid subscription' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Subscription activated' })
  async activateSubscription(
    @Param('organizationId') organizationId: string,
    @Body() body: { paymentMethodId: string },
  ) {
    return this.billingService.activateSubscription(
      organizationId,
      body.paymentMethodId,
    );
  }

  @Post('upgrade/:organizationId')
  @UseGuards(WorkspaceRolesGuard)
  @WorkspaceRoles(UserRole.ADMIN, UserRole.OWNER)
  @ApiOperation({ summary: 'Upgrade seat count' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Seats upgraded' })
  async upgradeSeats(
    @Param('organizationId') organizationId: string,
    @Body() body: { newSeatCount: number },
  ) {
    return this.billingService.upgradeSeats(
      organizationId,
      body.newSeatCount,
    );
  }

  @Post('seats/assign/:organizationId')
  @UseGuards(WorkspaceRolesGuard)
  @WorkspaceRoles(UserRole.ADMIN, UserRole.OWNER)
  @ApiOperation({ summary: 'Assign seat to user' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Seat assigned' })
  async assignSeat(
    @Param('organizationId') organizationId: string,
    @Body() body: { userId: string },
    @Req() req: any,
  ) {
    return this.billingService.assignSeat(
      organizationId,
      body.userId,
      req.user.id,
    );
  }

  @Post('seats/unassign/:organizationId')
  @UseGuards(WorkspaceRolesGuard)
  @WorkspaceRoles(UserRole.ADMIN, UserRole.OWNER)
  @ApiOperation({ summary: 'Unassign seat from user' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Seat unassigned' })
  async unassignSeat(
    @Param('organizationId') organizationId: string,
    @Body() body: { userId: string; reason?: string },
    @Req() req: any,
  ) {
    return this.billingService.unassignSeat(
      organizationId,
      body.userId,
      req.user.id,
      body.reason,
    );
  }

  @Post('cancel/:organizationId')
  @UseGuards(WorkspaceRolesGuard)
  @WorkspaceRoles(UserRole.OWNER)
  @ApiOperation({ summary: 'Cancel subscription' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Subscription canceled' })
  async cancelSubscription(
    @Param('organizationId') organizationId: string,
    @Body() body: { reason?: string },
  ) {
    return this.billingService.cancelSubscription(
      organizationId,
      body.reason,
    );
  }

  // Stripe Payment Methods

  @Post('payment-methods/setup-intent/:organizationId')
  @ApiOperation({ summary: 'Create setup intent for adding payment method' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Setup intent created' })
  async createSetupIntent(@Param('organizationId') organizationId: string) {
    const subscription = await this.billingService.getBillingInfo(organizationId);
    
    if (!subscription.billing.paymentMethod) {
      throw new Error('No subscription found');
    }

    // This would need the stripe customer ID from the subscription
    // For now, returning a mock response
    return { clientSecret: 'seti_mock_secret' };
  }

  // Stripe Webhook

  @Post('webhook')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Stripe webhook handler' })
  async handleWebhook(
    @RawBody() rawBody: Buffer,
    @Headers('stripe-signature') signature: string,
  ) {
    try {
      const event = await this.stripeService.constructEvent(rawBody, signature);

      switch (event.type) {
        case 'invoice.paid':
          // Handle successful payment
          break;
        case 'invoice.payment_failed':
          // Handle failed payment
          break;
        case 'customer.subscription.deleted':
          // Handle subscription cancellation
          break;
      }

      return { received: true };
    } catch (error) {
      return { error: error.message };
    }
  }

  // Invoices

  @Get('invoices/:organizationId')
  @ApiOperation({ summary: 'Get invoices for organization' })
  @ApiResponse({ status: HttpStatus.OK, description: 'Invoices retrieved' })
  async getInvoices(@Param('organizationId') organizationId: string) {
    // This would fetch from Stripe
    return { invoices: [] };
  }
}
