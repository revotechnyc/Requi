import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { BillingController } from './billing.controller';
import { BillingService } from './billing.service';
import { StripeService } from './stripe.service';
import { BillingScheduler } from './billing.scheduler';
import { SubscriptionGuard } from './guards/subscription.guard';
import { TrialGuard } from './guards/trial.guard';
import { PrismaModule } from '../prisma/prisma.module';
import { NotificationModule } from '../notification/notification.module';

@Module({
  imports: [ConfigModule, PrismaModule, NotificationModule],
  controllers: [BillingController],
  providers: [
    BillingService,
    StripeService,
    BillingScheduler,
    SubscriptionGuard,
    TrialGuard,
  ],
  exports: [BillingService, StripeService, SubscriptionGuard, TrialGuard],
})
export class BillingModule {}
