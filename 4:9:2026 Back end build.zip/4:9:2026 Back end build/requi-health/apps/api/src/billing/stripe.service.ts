import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Stripe from 'stripe';

@Injectable()
export class StripeService {
  private readonly logger = new Logger(StripeService.name);
  private stripe: Stripe;

  constructor(private readonly configService: ConfigService) {
    const apiKey = this.configService.get<string>('STRIPE_SECRET_KEY');
    if (!apiKey) {
      this.logger.warn('STRIPE_SECRET_KEY not configured');
    } else {
      this.stripe = new Stripe(apiKey, {
        apiVersion: '2024-04-10',
      });
    }
  }

  /**
   * Create Stripe customer
   */
  async createCustomer(data: {
    email: string;
    name?: string;
    address?: any;
  }): Promise<Stripe.Customer> {
    if (!this.stripe) {
      throw new Error('Stripe not configured');
    }

    return this.stripe.customers.create({
      email: data.email,
      name: data.name,
      address: data.address,
    });
  }

  /**
   * Create subscription
   */
  async createSubscription(data: {
    customerId: string;
    priceAmount: number;
    seatCount: number;
  }): Promise<Stripe.Subscription> {
    if (!this.stripe) {
      throw new Error('Stripe not configured');
    }

    // Create price (or use existing)
    const price = await this.stripe.prices.create({
      unit_amount: data.priceAmount,
      currency: 'usd',
      recurring: {
        interval: 'month',
      },
      product_data: {
        name: `Enterprise Plan - ${data.seatCount} Users`,
      },
    });

    return this.stripe.subscriptions.create({
      customer: data.customerId,
      items: [{ price: price.id }],
      billing_cycle_anchor_config: {
        day_of_month: new Date().getDate(),
      },
    });
  }

  /**
   * Update subscription
   */
  async updateSubscription(
    subscriptionId: string,
    newPriceAmount: number,
  ): Promise<Stripe.Subscription> {
    if (!this.stripe) {
      throw new Error('Stripe not configured');
    }

    const subscription = await this.stripe.subscriptions.retrieve(subscriptionId);
    
    const price = await this.stripe.prices.create({
      unit_amount: newPriceAmount,
      currency: 'usd',
      recurring: {
        interval: 'month',
      },
      product_data: {
        name: 'Enterprise Plan - Updated',
      },
    });

    return this.stripe.subscriptions.update(subscriptionId, {
      items: [
        {
          id: subscription.items.data[0].id,
          price: price.id,
        },
      ],
      proration_behavior: 'create_prorations',
    });
  }

  /**
   * Cancel subscription
   */
  async cancelSubscription(subscriptionId: string): Promise<Stripe.Subscription> {
    if (!this.stripe) {
      throw new Error('Stripe not configured');
    }

    return this.stripe.subscriptions.cancel(subscriptionId, {
      cancellation_details: {
        comment: 'Canceled by customer',
      },
    });
  }

  /**
   * Create prorated charge
   */
  async createProratedCharge(
    customerId: string,
    amountCents: number,
  ): Promise<Stripe.InvoiceItem> {
    if (!this.stripe) {
      throw new Error('Stripe not configured');
    }

    return this.stripe.invoiceItems.create({
      customer: customerId,
      amount: amountCents,
      currency: 'usd',
      description: 'Prorated seat upgrade',
    });
  }

  /**
   * Create payment intent
   */
  async createPaymentIntent(data: {
    amount: number;
    customerId: string;
    paymentMethodId?: string;
  }): Promise<Stripe.PaymentIntent> {
    if (!this.stripe) {
      throw new Error('Stripe not configured');
    }

    return this.stripe.paymentIntents.create({
      amount: data.amount,
      currency: 'usd',
      customer: data.customerId,
      payment_method: data.paymentMethodId,
      confirm: !!data.paymentMethodId,
      automatic_payment_methods: {
        enabled: true,
        allow_redirects: 'never',
      },
    });
  }

  /**
   * Attach payment method
   */
  async attachPaymentMethod(
    customerId: string,
    paymentMethodId: string,
  ): Promise<Stripe.PaymentMethod> {
    if (!this.stripe) {
      throw new Error('Stripe not configured');
    }

    return this.stripe.paymentMethods.attach(paymentMethodId, {
      customer: customerId,
    });
  }

  /**
   * Set default payment method
   */
  async setDefaultPaymentMethod(
    customerId: string,
    paymentMethodId: string,
  ): Promise<Stripe.Customer> {
    if (!this.stripe) {
      throw new Error('Stripe not configured');
    }

    return this.stripe.customers.update(customerId, {
      invoice_settings: {
        default_payment_method: paymentMethodId,
      },
    });
  }

  /**
   * Create setup intent for adding payment method
   */
  async createSetupIntent(customerId: string): Promise<Stripe.SetupIntent> {
    if (!this.stripe) {
      throw new Error('Stripe not configured');
    }

    return this.stripe.setupIntents.create({
      customer: customerId,
      payment_method_types: ['card', 'us_bank_account'],
    });
  }

  /**
   * Get invoices
   */
  async getInvoices(customerId: string): Promise<Stripe.Invoice[]> {
    if (!this.stripe) {
      throw new Error('Stripe not configured');
    }

    const invoices = await this.stripe.invoices.list({
      customer: customerId,
      limit: 100,
    });

    return invoices.data;
  }

  /**
   * Generate invoice PDF URL
   */
  async getInvoicePdfUrl(invoiceId: string): Promise<string | null> {
    if (!this.stripe) {
      throw new Error('Stripe not configured');
    }

    const invoice = await this.stripe.invoices.retrieve(invoiceId);
    return invoice.invoice_pdf;
  }

  /**
   * Handle webhook events
   */
  async constructEvent(
    payload: Buffer,
    signature: string,
  ): Promise<Stripe.Event> {
    if (!this.stripe) {
      throw new Error('Stripe not configured');
    }

    const webhookSecret = this.configService.get<string>('STRIPE_WEBHOOK_SECRET');
    
    return this.stripe.webhooks.constructEvent(
      payload,
      signature,
      webhookSecret,
    );
  }
}
