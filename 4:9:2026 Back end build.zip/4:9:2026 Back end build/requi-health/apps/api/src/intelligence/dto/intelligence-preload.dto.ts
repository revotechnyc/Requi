import { ApiProperty } from '@nestjs/swagger';

export class UserProfileDto {
  @ApiProperty({ description: 'User ID' })
  id: string;

  @ApiProperty({ description: 'User email' })
  email: string;

  @ApiProperty({ description: 'User full name' })
  name: string;

  @ApiProperty({ description: 'User role' })
  role: string;

  @ApiProperty({ description: 'User preferences', type: 'object' })
  preferences: Record<string, any>;

  @ApiProperty({ description: 'Last login timestamp' })
  lastLoginAt: string;
}

export class OrganizationProfileDto {
  @ApiProperty({ description: 'Organization ID' })
  id: string;

  @ApiProperty({ description: 'Organization name' })
  name: string;

  @ApiProperty({ description: 'Subscription plan' })
  plan: string;

  @ApiProperty({ description: 'Subscription status' })
  subscriptionStatus: string;

  @ApiProperty({ description: 'Days remaining in trial', nullable: true })
  trialDaysRemaining: number | null;

  @ApiProperty({ description: 'Number of organization members' })
  memberCount: number;

  @ApiProperty({ description: 'Organization settings', type: 'object' })
  settings: Record<string, any>;
}

export class RecentConversationDto {
  @ApiProperty({ description: 'Conversation ID' })
  id: string;

  @ApiProperty({ description: 'Conversation title' })
  title: string;

  @ApiProperty({ description: 'Last activity timestamp' })
  lastActivity: string;

  @ApiProperty({ description: 'Number of unread messages' })
  unreadCount: number;
}

export class SuggestedPromptDto {
  @ApiProperty({ description: 'Prompt ID' })
  id: string;

  @ApiProperty({ description: 'Prompt category' })
  category: string;

  @ApiProperty({ description: 'Prompt text' })
  text: string;

  @ApiProperty({ description: 'Prompt context type' })
  context: string;
}

export class RecommendedActionDto {
  @ApiProperty({ description: 'Action ID' })
  id: string;

  @ApiProperty({ description: 'Action title' })
  title: string;

  @ApiProperty({ description: 'Action description' })
  description: string;

  @ApiProperty({ description: 'Priority level', enum: ['critical', 'high', 'medium', 'low'] })
  priority: string;

  @ApiProperty({ description: 'Action type', enum: ['task', 'gap', 'reminder'] })
  type: string;

  @ApiProperty({ description: 'Due date', nullable: true })
  dueDate: string | null;

  @ApiProperty({ description: 'URL to take action' })
  actionUrl: string;
}

export class ComplianceSnapshotDto {
  @ApiProperty({ description: 'Overall compliance score (0-100)' })
  overallScore: number;

  @ApiProperty({ description: 'Domain-specific scores', type: 'object' })
  domainScores: Record<string, number>;

  @ApiProperty({ description: 'Last calculation timestamp' })
  lastCalculated: string;

  @ApiProperty({ description: 'Task counts', type: 'object' })
  taskCounts: {
    total: number;
    pending: number;
    inProgress: number;
    completed: number;
    overdue: number;
  };

  @ApiProperty({ description: 'Gap counts by severity', type: 'object' })
  gapCounts: {
    critical: number;
    high: number;
    medium: number;
    low: number;
  };
}

export class NewsUpdateDto {
  @ApiProperty({ description: 'News ID' })
  id: string;

  @ApiProperty({ description: 'News title' })
  title: string;

  @ApiProperty({ description: 'News summary' })
  summary: string;

  @ApiProperty({ description: 'News source' })
  source: string;

  @ApiProperty({ description: 'Jurisdiction' })
  jurisdiction: string;

  @ApiProperty({ description: 'Publication timestamp' })
  publishedAt: string;

  @ApiProperty({ description: 'Relevance score (0-100)' })
  relevanceScore: number;
}

export class PreloadMetaDto {
  @ApiProperty({ description: 'Data load time in milliseconds' })
  loadTimeMs: number;

  @ApiProperty({ description: 'Server timestamp' })
  serverTime: string;

  @ApiProperty({ description: 'API version' })
  version: string;
}

export class IntelligencePreloadResponseDto {
  @ApiProperty({ description: 'User profile', type: UserProfileDto })
  user: UserProfileDto;

  @ApiProperty({ description: 'Organization profile', type: OrganizationProfileDto })
  organization: OrganizationProfileDto;

  @ApiProperty({ description: 'Recent conversations', type: [RecentConversationDto] })
  recentConversations: RecentConversationDto[];

  @ApiProperty({ description: 'Suggested prompts', type: [SuggestedPromptDto] })
  suggestedPrompts: SuggestedPromptDto[];

  @ApiProperty({ description: 'Recommended actions', type: [RecommendedActionDto] })
  recommendedActions: RecommendedActionDto[];

  @ApiProperty({ description: 'Compliance snapshot', type: ComplianceSnapshotDto })
  complianceSnapshot: ComplianceSnapshotDto;

  @ApiProperty({ description: 'News updates', type: [NewsUpdateDto] })
  newsUpdates: NewsUpdateDto[];

  @ApiProperty({ description: 'Metadata', type: PreloadMetaDto })
  meta: PreloadMetaDto;
}
