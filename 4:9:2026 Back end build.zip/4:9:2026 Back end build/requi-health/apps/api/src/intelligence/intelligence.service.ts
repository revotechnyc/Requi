import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../common/database/prisma.service';
import { IntelligencePreloadResponseDto } from './dto/intelligence-preload.dto';

@Injectable()
export class IntelligenceService {
  private readonly logger = new Logger(IntelligenceService.name);

  constructor(private readonly prisma: PrismaService) {}

  async getPreloadData(
    userId: string,
    organizationId: string,
  ): Promise<IntelligencePreloadResponseDto> {
    this.logger.log(`Loading intelligence preload for user ${userId}`);

    const startTime = Date.now();

    // Fetch all data in parallel for optimal performance
    const [
      userProfile,
      organizationProfile,
      recentConversations,
      suggestedPrompts,
      recommendedActions,
      complianceSnapshot,
      newsUpdates,
    ] = await Promise.all([
      this.getUserProfile(userId),
      this.getOrganizationProfile(organizationId),
      this.getRecentConversations(userId, 5),
      this.getSuggestedPrompts(organizationId),
      this.getRecommendedActions(organizationId, 5),
      this.getComplianceSnapshot(organizationId),
      this.getNewsUpdates(organizationId, 3),
    ]);

    const loadTime = Date.now() - startTime;
    this.logger.log(`Intelligence preload completed in ${loadTime}ms`);

    return {
      user: userProfile,
      organization: organizationProfile,
      recentConversations,
      suggestedPrompts,
      recommendedActions,
      complianceSnapshot,
      newsUpdates,
      meta: {
        loadTimeMs: loadTime,
        serverTime: new Date().toISOString(),
        version: '2.0.0',
      },
    };
  }

  private async getUserProfile(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        firstName: true,
        lastName: true,
        role: true,
        preferences: true,
        lastLoginAt: true,
      },
    });

    return {
      id: user.id,
      email: user.email,
      name: `${user.firstName} ${user.lastName}`,
      role: user.role,
      preferences: user.preferences || {},
      lastLoginAt: user.lastLoginAt?.toISOString(),
    };
  }

  private async getOrganizationProfile(organizationId: string) {
    const org = await this.prisma.organization.findUnique({
      where: { id: organizationId },
      select: {
        id: true,
        name: true,
        plan: true,
        subscriptionStatus: true,
        trialEndsAt: true,
        settings: true,
        _count: {
          select: {
            members: true,
          },
        },
      },
    });

    const trialDaysRemaining = org.trialEndsAt
      ? Math.max(0, Math.ceil((org.trialEndsAt.getTime() - Date.now()) / (1000 * 60 * 60 * 24)))
      : null;

    return {
      id: org.id,
      name: org.name,
      plan: org.plan,
      subscriptionStatus: org.subscriptionStatus,
      trialDaysRemaining,
      memberCount: org._count.members,
      settings: org.settings || {},
    };
  }

  private async getRecentConversations(userId: string, limit: number) {
    const conversations = await this.prisma.conversation.findMany({
      where: {
        userId,
        status: { not: 'archived' },
      },
      orderBy: { updatedAt: 'desc' },
      take: limit,
      select: {
        id: true,
        title: true,
        updatedAt: true,
        _count: {
          select: {
            messages: {
              where: {
                read: false,
                role: 'assistant',
              },
            },
          },
        },
      },
    });

    return conversations.map((conv) => ({
      id: conv.id,
      title: conv.title || 'New Conversation',
      lastActivity: conv.updatedAt.toISOString(),
      unreadCount: conv._count.messages,
    }));
  }

  private async getSuggestedPrompts(organizationId: string): Promise<Array<{
    id: string;
    category: string;
    text: string;
    context: string;
  }>> {
    // Get organization context to personalize prompts
    const org = await this.prisma.organization.findUnique({
      where: { id: organizationId },
      select: {
        industry: true,
        size: true,
        settings: true,
      },
    });

    // Determine prompts based on organization context
    const prompts = [
      {
        id: 'compliance-status',
        category: 'Compliance',
        text: 'What is my current compliance score and what needs attention?',
        context: 'overview',
      },
      {
        id: 'policy-updates',
        category: 'Policies',
        text: 'Which policies need to be updated this quarter?',
        context: 'maintenance',
      },
      {
        id: 'risk-areas',
        category: 'Risk',
        text: 'Show me my highest risk areas and how to address them',
        context: 'risk',
      },
      {
        id: 'upcoming-tasks',
        category: 'Tasks',
        text: 'What tasks are due this week?',
        context: 'tasks',
      },
      {
        id: 'document-search',
        category: 'Documents',
        text: 'Find my HIPAA compliance documents',
        context: 'documents',
      },
      {
        id: 'audit-prep',
        category: 'Audit',
        text: 'Help me prepare for the upcoming audit',
        context: 'audit',
      },
    ];

    // Add industry-specific prompts if available
    if (org?.industry === 'healthcare') {
      prompts.push({
        id: 'hipaa-specific',
        category: 'HIPAA',
        text: 'Are we compliant with the latest HIPAA Security Rule updates?',
        context: 'compliance',
      });
    }

    return prompts;
  }

  private async getRecommendedActions(organizationId: string, limit: number) {
    // Fetch high-priority tasks, gaps, and reminders
    const [tasks, gaps, reminders] = await Promise.all([
      // High priority tasks
      this.prisma.task.findMany({
        where: {
          organizationId,
          status: { in: ['pending', 'in_progress'] },
          priority: { in: ['high', 'critical'] },
        },
        orderBy: [{ dueDate: 'asc' }, { priority: 'desc' }],
        take: Math.ceil(limit / 2),
        select: {
          id: true,
          title: true,
          description: true,
          priority: true,
          dueDate: true,
          status: true,
        },
      }),

      // Critical/high gaps
      this.prisma.complianceGap.findMany({
        where: {
          organizationId,
          status: 'open',
          severity: { in: ['critical', 'high'] },
        },
        orderBy: [{ identifiedAt: 'desc' }],
        take: Math.ceil(limit / 3),
        select: {
          id: true,
          title: true,
          description: true,
          severity: true,
          identifiedAt: true,
        },
      }),

      // Upcoming reminders
      this.prisma.reminder.findMany({
        where: {
          organizationId,
          status: 'pending',
          dueDate: {
            lte: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // Next 7 days
          },
        },
        orderBy: { dueDate: 'asc' },
        take: Math.ceil(limit / 3),
        select: {
          id: true,
          title: true,
          description: true,
          dueDate: true,
          type: true,
        },
      }),
    ]);

    // Combine and format actions
    const actions = [
      ...tasks.map((t) => ({
        id: `task-${t.id}`,
        title: t.title,
        description: t.description,
        priority: t.priority,
        type: 'task' as const,
        dueDate: t.dueDate?.toISOString(),
        actionUrl: `/tasks/${t.id}`,
      })),
      ...gaps.map((g) => ({
        id: `gap-${g.id}`,
        title: g.title,
        description: g.description,
        priority: g.severity,
        type: 'gap' as const,
        dueDate: null,
        actionUrl: `/compliance/gaps/${g.id}`,
      })),
      ...reminders.map((r) => ({
        id: `reminder-${r.id}`,
        title: r.title,
        description: r.description,
        priority: 'medium',
        type: 'reminder' as const,
        dueDate: r.dueDate?.toISOString(),
        actionUrl: `/tasks?reminder=${r.id}`,
      })),
    ];

    // Sort by priority and limit
    const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
    return actions
      .sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority])
      .slice(0, limit);
  }

  private async getComplianceSnapshot(organizationId: string) {
    const [scores, taskStats, gapStats] = await Promise.all([
      // Latest compliance scores
      this.prisma.complianceScore.findFirst({
        where: { organizationId },
        orderBy: { calculatedAt: 'desc' },
        select: {
          overallScore: true,
          domainScores: true,
          calculatedAt: true,
        },
      }),

      // Task statistics
      this.prisma.task.groupBy({
        by: ['status'],
        where: { organizationId },
        _count: { status: true },
      }),

      // Gap statistics
      this.prisma.complianceGap.groupBy({
        by: ['severity', 'status'],
        where: { organizationId },
        _count: { severity: true },
      }),
    ]);

    // Calculate task counts
    const taskCounts = {
      total: taskStats.reduce((sum, t) => sum + t._count.status, 0),
      pending: taskStats.find((t) => t.status === 'pending')?._count.status || 0,
      inProgress: taskStats.find((t) => t.status === 'in_progress')?._count.status || 0,
      completed: taskStats.find((t) => t.status === 'completed')?._count.status || 0,
      overdue: taskStats.find((t) => t.status === 'overdue')?._count.status || 0,
    };

    // Calculate gap counts
    const gapCounts = {
      critical: gapStats
        .filter((g) => g.severity === 'critical' && g.status === 'open')
        .reduce((sum, g) => sum + g._count.severity, 0),
      high: gapStats
        .filter((g) => g.severity === 'high' && g.status === 'open')
        .reduce((sum, g) => sum + g._count.severity, 0),
      medium: gapStats
        .filter((g) => g.severity === 'medium' && g.status === 'open')
        .reduce((sum, g) => sum + g._count.severity, 0),
      low: gapStats
        .filter((g) => g.severity === 'low' && g.status === 'open')
        .reduce((sum, g) => sum + g._count.severity, 0),
    };

    return {
      overallScore: scores?.overallScore || 0,
      domainScores: (scores?.domainScores as Record<string, number>) || {},
      lastCalculated: scores?.calculatedAt?.toISOString(),
      taskCounts,
      gapCounts,
    };
  }

  private async getNewsUpdates(organizationId: string, limit: number) {
    // Get organization's jurisdictions and interests
    const org = await this.prisma.organization.findUnique({
      where: { id: organizationId },
      select: {
        jurisdictions: true,
        interests: true,
      },
    });

    const jurisdictions = (org?.jurisdictions as string[]) || ['federal'];
    const interests = (org?.interests as string[]) || [];

    // Fetch relevant news updates
    const updates = await this.prisma.newsUpdate.findMany({
      where: {
        OR: [
          { jurisdiction: { in: jurisdictions } },
          { category: { in: interests } },
        ],
        publishedAt: {
          gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // Last 30 days
        },
      },
      orderBy: { publishedAt: 'desc' },
      take: limit,
      select: {
        id: true,
        title: true,
        summary: true,
        source: true,
        jurisdiction: true,
        publishedAt: true,
        relevanceScore: true,
      },
    });

    return updates.map((u) => ({
      id: u.id,
      title: u.title,
      summary: u.summary,
      source: u.source,
      jurisdiction: u.jurisdiction,
      publishedAt: u.publishedAt.toISOString(),
      relevanceScore: u.relevanceScore,
    }));
  }
}
