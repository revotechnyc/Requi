import { Controller, Get, UseGuards, Req } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { IntelligenceService } from './intelligence.service';
import { IntelligencePreloadResponseDto } from './dto/intelligence-preload.dto';

@ApiTags('Intelligence')
@Controller('intelligence')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class IntelligenceController {
  constructor(private readonly intelligenceService: IntelligenceService) {}

  @Get('preload')
  @ApiOperation({
    summary: 'Preload Intelligence Workspace data',
    description: 'Fetches all data needed for the Intelligence landing page in a single request. Called immediately after login/session restore.',
  })
  @ApiResponse({
    status: 200,
    description: 'Preload data retrieved successfully',
    type: IntelligencePreloadResponseDto,
  })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  async preload(@Req() req): Promise<IntelligencePreloadResponseDto> {
    const userId = req.user.id;
    const organizationId = req.user.organizationId;
    
    return this.intelligenceService.getPreloadData(userId, organizationId);
  }
}
