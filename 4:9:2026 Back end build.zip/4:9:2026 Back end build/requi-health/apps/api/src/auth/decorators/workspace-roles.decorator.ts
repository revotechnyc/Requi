import { SetMetadata } from '@nestjs/common';
import { UserRole } from '@requi/shared-types';

export const WORKSPACE_ROLES_KEY = 'workspaceRoles';

export const WorkspaceRoles = (...roles: UserRole[]) =>
  SetMetadata(WORKSPACE_ROLES_KEY, roles);
