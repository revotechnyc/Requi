import { create } from 'zustand';
import { Conversation, Message, AIResponse } from '@requi/shared-types';
import { api } from '@/lib/api';
import { useWebSocket } from '@/hooks/useWebSocket';

interface ChatState {
  conversations: Conversation[];
  currentConversation: Conversation | null;
  messages: Message[];
  isLoading: boolean;
  isStreaming: boolean;
  error: string | null;

  // Actions
  fetchConversations: (workspaceId: string) => Promise<void>;
  fetchMessages: (conversationId: string) => Promise<void>;
  createConversation: (workspaceId: string, title?: string) => Promise<Conversation>;
  sendMessage: (workspaceId: string, conversationId: string, content: string) => Promise<void>;
  setCurrentConversation: (conversation: Conversation | null) => void;
  addMessage: (message: Message) => void;
  updateStreamingMessage: (content: string) => void;
}

export const useChatStore = create<ChatState>((set, get) => ({
  conversations: [],
  currentConversation: null,
  messages: [],
  isLoading: false,
  isStreaming: false,
  error: null,

  fetchConversations: async (workspaceId: string) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get<{ data: Conversation[] }>(
        `/conversations?workspaceId=${workspaceId}`
      );
      set({ conversations: response.data, isLoading: false });
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : 'Failed to fetch conversations',
        isLoading: false,
      });
    }
  },

  fetchMessages: async (conversationId: string) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.get<{ data: Message[] }>(
        `/conversations/${conversationId}/messages`
      );
      set({ messages: response.data, isLoading: false });
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : 'Failed to fetch messages',
        isLoading: false,
      });
    }
  },

  createConversation: async (workspaceId: string, title?: string) => {
    set({ isLoading: true, error: null });
    try {
      const conversation = await api.post<Conversation>('/conversations', {
        workspaceId,
        title: title || 'New Conversation',
      });
      set((state) => ({
        conversations: [conversation, ...state.conversations],
        currentConversation: conversation,
        isLoading: false,
      }));
      return conversation;
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : 'Failed to create conversation',
        isLoading: false,
      });
      throw error;
    }
  },

  sendMessage: async (workspaceId: string, conversationId: string, content: string) => {
    const { addMessage, updateStreamingMessage } = get();

    // Add user message immediately
    const userMessage: Message = {
      id: `temp-${Date.now()}`,
      conversationId,
      role: 'user',
      content,
      createdAt: new Date(),
    };
    addMessage(userMessage);

    set({ isStreaming: true, error: null });

    try {
      // Use streaming API
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/conversations/${conversationId}/messages/stream`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('accessToken')}`,
        },
        body: JSON.stringify({ content, workspaceId }),
      });

      if (!response.ok) {
        throw new Error('Failed to send message');
      }

      const reader = response.body?.getReader();
      if (!reader) {
        throw new Error('No response body');
      }

      let assistantContent = '';
      const assistantMessage: Message = {
        id: `assistant-${Date.now()}`,
        conversationId,
        role: 'assistant',
        content: '',
        isStreaming: true,
        createdAt: new Date(),
      };
      addMessage(assistantMessage);

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = new TextDecoder().decode(value);
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data === '[DONE]') {
              set((state) => ({
                messages: state.messages.map((m) =>
                  m.id === assistantMessage.id ? { ...m, isStreaming: false } : m
                ),
                isStreaming: false,
              }));
              return;
            }

            try {
              const event = JSON.parse(data);
              if (event.type === 'chunk') {
                assistantContent += event.content;
                updateStreamingMessage(assistantContent);
              } else if (event.type === 'citation') {
                // Handle citation
              } else if (event.type === 'confidence') {
                // Handle confidence
              } else if (event.type === 'complete') {
                set((state) => ({
                  messages: state.messages.map((m) =>
                    m.id === assistantMessage.id
                      ? {
                          ...m,
                          content: event.finalContent,
                          citations: event.citations,
                          confidence: event.confidence,
                          isStreaming: false,
                        }
                      : m
                  ),
                  isStreaming: false,
                }));
              }
            } catch {
              // Ignore parse errors
            }
          }
        }
      }
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : 'Failed to send message',
        isStreaming: false,
      });
    }
  },

  setCurrentConversation: (conversation) => set({ currentConversation: conversation }),

  addMessage: (message) =>
    set((state) => ({ messages: [...state.messages, message] })),

  updateStreamingMessage: (content) =>
    set((state) => ({
      messages: state.messages.map((m, idx) =>
        idx === state.messages.length - 1 && m.role === 'assistant'
          ? { ...m, content }
          : m
      ),
    })),
}));
