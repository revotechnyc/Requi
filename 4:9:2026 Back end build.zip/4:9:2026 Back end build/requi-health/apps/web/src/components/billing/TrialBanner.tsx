'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/Button';
import { Clock, AlertTriangle, X } from 'lucide-react';

interface TrialBannerProps {
  daysRemaining: number;
  organizationId: string;
  onDismiss?: () => void;
}

export function TrialBanner({ daysRemaining, organizationId, onDismiss }: TrialBannerProps) {
  const [isVisible, setIsVisible] = useState(true);
  const [isDismissed, setIsDismissed] = useState(false);

  useEffect(() => {
    // Check if user has dismissed this banner recently
    const dismissedKey = `trial-banner-dismissed-${organizationId}`;
    const dismissedAt = localStorage.getItem(dismissedKey);
    if (dismissedAt) {
      const hoursSinceDismissed = (Date.now() - parseInt(dismissedAt)) / (1000 * 60 * 60);
      // Don't show again for 24 hours
      if (hoursSinceDismissed < 24) {
        setIsDismissed(true);
      }
    }
  }, [organizationId]);

  const handleDismiss = () => {
    setIsVisible(false);
    const dismissedKey = `trial-banner-dismissed-${organizationId}`;
    localStorage.setItem(dismissedKey, Date.now().toString());
    onDismiss?.();
  };

  if (isDismissed || !isVisible) return null;

  // Determine urgency level
  let variant: 'info' | 'warning' | 'danger' = 'info';
  let icon = Clock;
  let message = `Your trial ends in ${daysRemaining} days`;

  if (daysRemaining <= 3) {
    variant = 'danger';
    icon = AlertTriangle;
    message = `Your trial ends in ${daysRemaining} day${daysRemaining === 1 ? '' : 's'} - Upgrade now to avoid interruption`;
  } else if (daysRemaining <= 7) {
    variant = 'warning';
    icon = AlertTriangle;
    message = `Your trial ends in ${daysRemaining} days - Don't forget to upgrade`;
  }

  const Icon = icon;

  const variantStyles = {
    info: 'bg-blue-50 border-blue-200 text-blue-900',
    warning: 'bg-orange-50 border-orange-200 text-orange-900',
    danger: 'bg-red-50 border-red-200 text-red-900',
  };

  const buttonStyles = {
    info: 'bg-blue-600 hover:bg-blue-700',
    warning: 'bg-orange-600 hover:bg-orange-700',
    danger: 'bg-red-600 hover:bg-red-700',
  };

  return (
    <div className={`border-b ${variantStyles[variant]}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between py-3">
          <div className="flex items-center gap-3">
            <Icon className={`w-5 h-5 ${
              variant === 'info' ? 'text-blue-600' :
              variant === 'warning' ? 'text-orange-600' : 'text-red-600'
            }`} />
            <span className="font-medium">{message}</span>
          </div>
          <div className="flex items-center gap-3">
            <Link href={`/admin/billing`}>
              <Button
                size="sm"
                className={`text-white ${buttonStyles[variant]}`}
              >
                Upgrade Now
              </Button>
            </Link>
            <button
              onClick={handleDismiss}
              className="p-1 hover:bg-black/5 rounded transition-colors"
              aria-label="Dismiss"
            >
              <X className="w-4 h-4 opacity-60" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
