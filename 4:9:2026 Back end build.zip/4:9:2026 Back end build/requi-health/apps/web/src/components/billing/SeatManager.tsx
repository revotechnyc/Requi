'use client';

import { useState } from 'react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { Input } from '@/components/ui/Input';
import {
  Users,
  Plus,
  Minus,
  Search,
  Mail,
  UserCheck,
  UserX,
  AlertTriangle,
} from 'lucide-react';

interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  seatAssigned: boolean;
  assignedAt?: string;
}

interface SeatManagerProps {
  seatsAvailable: number;
  seatsUsed: number;
  users: User[];
  onAssignSeat: (userId: string) => Promise<void>;
  onUnassignSeat: (userId: string, reason?: string) => Promise<void>;
}

export function SeatManager({
  seatsAvailable,
  seatsUsed,
  users,
  onAssignSeat,
  onUnassignSeat,
}: SeatManagerProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [showUnassignModal, setShowUnassignModal] = useState<string | null>(null);
  const [unassignReason, setUnassignReason] = useState('');
  const [isProcessing, setIsProcessing] = useState<string | null>(null);

  const filteredUsers = users.filter(
    (user) =>
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const assignedUsers = filteredUsers.filter((u) => u.seatAssigned);
  const unassignedUsers = filteredUsers.filter((u) => !u.seatAssigned);

  const handleAssign = async (userId: string) => {
    setIsProcessing(userId);
    try {
      await onAssignSeat(userId);
    } finally {
      setIsProcessing(null);
    }
  };

  const handleUnassign = async () => {
    if (!showUnassignModal) return;
    setIsProcessing(showUnassignModal);
    try {
      await onUnassignSeat(showUnassignModal, unassignReason);
      setShowUnassignModal(null);
      setUnassignReason('');
    } finally {
      setIsProcessing(null);
    }
  };

  const usagePercentage = (seatsUsed / seatsAvailable) * 100;

  return (
    <div className="space-y-6">
      {/* Seat Usage Overview */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Users className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <h3 className="font-semibold">Seat Allocation</h3>
              <p className="text-sm text-gray-500">
                {seatsUsed} of {seatsAvailable} seats assigned
              </p>
            </div>
          </div>
          <Badge
            variant={usagePercentage >= 90 ? 'red' : usagePercentage >= 75 ? 'orange' : 'green'}
          >
            {Math.round(usagePercentage)}% Used
          </Badge>
        </div>

        <div className="w-full bg-gray-200 rounded-full h-3">
          <div
            className={`h-3 rounded-full transition-all ${
              usagePercentage >= 90
                ? 'bg-red-500'
                : usagePercentage >= 75
                ? 'bg-orange-500'
                : 'bg-green-500'
            }`}
            style={{ width: `${usagePercentage}%` }}
          />
        </div>

        {usagePercentage >= 90 && (
          <div className="flex items-center gap-2 mt-3 text-red-600 text-sm">
            <AlertTriangle className="w-4 h-4" />
            <span>You're running low on available seats. Consider upgrading your plan.</span>
          </div>
        )}
      </Card>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <Input
          placeholder="Search users by name or email..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Assigned Users */}
      <div>
        <h3 className="font-semibold mb-3 flex items-center gap-2">
          <UserCheck className="w-4 h-4" />
          Assigned Users ({assignedUsers.length})
        </h3>
        {assignedUsers.length > 0 ? (
          <div className="space-y-2">
            {assignedUsers.map((user) => (
              <Card key={user.id} className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <span className="text-blue-600 font-medium">
                      {user.name.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium">{user.name}</p>
                    <p className="text-sm text-gray-500 flex items-center gap-1">
                      <Mail className="w-3 h-3" />
                      {user.email}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant="green">Active</Badge>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowUnassignModal(user.id)}
                    disabled={isProcessing === user.id}
                  >
                    <Minus className="w-4 h-4 mr-1" />
                    Unassign
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="p-8 text-center text-gray-500">
            <UserX className="mx-auto h-8 w-8 mb-2" />
            <p>No users have been assigned seats yet</p>
          </Card>
        )}
      </div>

      {/* Unassigned Users */}
      <div>
        <h3 className="font-semibold mb-3 flex items-center gap-2">
          <Users className="w-4 h-4" />
          Unassigned Users ({unassignedUsers.length})
        </h3>
        {unassignedUsers.length > 0 ? (
          <div className="space-y-2">
            {unassignedUsers.map((user) => (
              <Card key={user.id} className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                    <span className="text-gray-600 font-medium">
                      {user.name.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium">{user.name}</p>
                    <p className="text-sm text-gray-500 flex items-center gap-1">
                      <Mail className="w-3 h-3" />
                      {user.email}
                    </p>
                  </div>
                </div>
                <Button
                  variant="primary"
                  size="sm"
                  onClick={() => handleAssign(user.id)}
                  disabled={isProcessing === user.id || seatsUsed >= seatsAvailable}
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Assign Seat
                </Button>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="p-8 text-center text-gray-500">
            <UserCheck className="mx-auto h-8 w-8 mb-2" />
            <p>All users have been assigned seats</p>
          </Card>
        )}
      </div>

      {/* Unassign Modal */}
      {showUnassignModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg max-w-md w-full mx-4">
            <div className="p-6 border-b">
              <h3 className="text-lg font-semibold">Unassign Seat</h3>
            </div>
            <div className="p-6">
              <p className="text-gray-600 mb-4">
                Are you sure you want to unassign this seat? The user will lose access to the
                platform immediately.
              </p>
              <div className="space-y-2">
                <label className="text-sm font-medium">Reason (optional)</label>
                <Input
                  placeholder="e.g., Employee left company"
                  value={unassignReason}
                  onChange={(e) => setUnassignReason(e.target.value)}
                />
              </div>
            </div>
            <div className="p-6 border-t bg-gray-50 flex justify-end gap-3">
              <Button variant="outline" onClick={() => setShowUnassignModal(null)}>
                Cancel
              </Button>
              <Button
                variant="danger"
                onClick={handleUnassign}
                disabled={isProcessing === showUnassignModal}
              >
                Unassign Seat
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
