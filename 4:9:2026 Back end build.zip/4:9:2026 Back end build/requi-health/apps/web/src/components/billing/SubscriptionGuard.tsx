'use client';

import { ReactNode } from 'react';
import Link from 'next/link';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { AlertTriangle, Lock, Clock, CreditCard } from 'lucide-react';

interface SubscriptionGuardProps {
  status: 'TRIAL' | 'ACTIVE' | 'TRIAL_EXPIRED' | 'CANCELED' | 'UNPAID' | null;
  children: ReactNode;
  fallback?: ReactNode;
}

export function SubscriptionGuard({ status, children, fallback }: SubscriptionGuardProps) {
  // Allow access for active subscriptions and trials
  if (status === 'ACTIVE' || status === 'TRIAL') {
    return <>{children}</>;
  }

  // Custom fallback if provided
  if (fallback) {
    return <>{fallback}</>;
  }

  // Default blocked states
  if (status === 'TRIAL_EXPIRED') {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Card className="max-w-md w-full p-8 text-center">
          <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Clock className="w-8 h-8 text-orange-600" />
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">Trial Expired</h2>
          <p className="text-gray-500 mb-6">
            Your 30-day trial has ended. Upgrade to a paid plan to continue using all features.
          </p>
          <div className="space-y-3">
            <Link href="/admin/billing">
              <Button variant="primary" className="w-full">
                <CreditCard className="w-4 h-4 mr-2" />
                Upgrade Now
              </Button>
            </Link>
            <p className="text-sm text-gray-500">
              Your data is safe. You can still view your content in read-only mode.
            </p>
          </div>
        </Card>
      </div>
    );
  }

  if (status === 'CANCELED') {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Card className="max-w-md w-full p-8 text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertTriangle className="w-8 h-8 text-red-600" />
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">Subscription Canceled</h2>
          <p className="text-gray-500 mb-6">
            Your subscription has been canceled. Resubscribe to restore full access.
          </p>
          <Link href="/admin/billing">
            <Button variant="primary" className="w-full">
              <CreditCard className="w-4 h-4 mr-2" />
              Resubscribe
            </Button>
          </Link>
        </Card>
      </div>
    );
  }

  if (status === 'UNPAID') {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Card className="max-w-md w-full p-8 text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CreditCard className="w-8 h-8 text-red-600" />
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">Payment Required</h2>
          <p className="text-gray-500 mb-6">
            We couldn't process your last payment. Please update your payment method to continue.
          </p>
          <Link href="/admin/billing">
            <Button variant="primary" className="w-full">
              <CreditCard className="w-4 h-4 mr-2" />
              Update Payment Method
            </Button>
          </Link>
        </Card>
      </div>
    );
  }

  // No subscription / loading state
  return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <Card className="max-w-md w-full p-8 text-center">
        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Lock className="w-8 h-8 text-gray-600" />
        </div>
        <h2 className="text-xl font-bold text-gray-900 mb-2">Subscription Required</h2>
        <p className="text-gray-500 mb-6">
          You need an active subscription to access this feature. Start a free trial today.
        </p>
        <Link href="/onboarding">
          <Button variant="primary" className="w-full">
            Start Free Trial
          </Button>
        </Link>
      </Card>
    </div>
  );
}
