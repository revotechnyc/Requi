// ============================================
// Requi Health - Frontend Types
// ============================================

// Re-export from shared types
export * from '@requi/shared-types';

// Frontend-specific types
export interface SidebarItem {
  id: string;
  label: string;
  href: string;
  icon?: React.ComponentType<{ className?: string }>;
  badge?: number;
}

export interface NavSection {
  title: string;
  items: SidebarItem[];
}

export interface FilterOption {
  value: string;
  label: string;
  count?: number;
}

export interface DataTableColumn<T> {
  key: keyof T | string;
  header: string;
  cell: (row: T) => React.ReactNode;
  sortable?: boolean;
  width?: string;
}

export interface ChartDataPoint {
  label: string;
  value: number;
  color?: string;
}

export interface NotificationToast {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message?: string;
  duration?: number;
}

export interface FormField {
  name: string;
  label: string;
  type: 'text' | 'email' | 'password' | 'select' | 'textarea' | 'checkbox' | 'date';
  placeholder?: string;
  required?: boolean;
  options?: Array<{ value: string; label: string }>;
  validation?: {
    min?: number;
    max?: number;
    pattern?: RegExp;
    message?: string;
  };
}
