'use client';

import { useEffect, useRef, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';
import { useAuthStore } from '@/stores/auth';

const WS_URL = process.env.NEXT_PUBLIC_WS_URL || 'http://localhost:3001';

export function useWebSocket() {
  const socketRef = useRef<Socket | null>(null);
  const accessToken = useAuthStore((state) => state.accessToken);

  useEffect(() => {
    if (!accessToken) return;

    socketRef.current = io(WS_URL, {
      auth: { token: accessToken },
      transports: ['websocket'],
    });

    socketRef.current.on('connect', () => {
      console.log('WebSocket connected');
    });

    socketRef.current.on('disconnect', () => {
      console.log('WebSocket disconnected');
    });

    socketRef.current.on('error', (error) => {
      console.error('WebSocket error:', error);
    });

    return () => {
      socketRef.current?.disconnect();
    };
  }, [accessToken]);

  const joinConversation = useCallback((conversationId: string, workspaceId: string) => {
    socketRef.current?.emit('conversation:join', { conversationId, workspaceId });
  }, []);

  const leaveConversation = useCallback((conversationId: string) => {
    socketRef.current?.emit('conversation:leave', { conversationId });
  }, []);

  const sendMessage = useCallback(
    (content: string, conversationId: string, workspaceId: string) => {
      socketRef.current?.emit('message:send', { content, conversationId, workspaceId });
    },
    []
  );

  const onMessageStream = useCallback((callback: (event: unknown) => void) => {
    socketRef.current?.on('message:stream', callback);
    return () => {
      socketRef.current?.off('message:stream', callback);
    };
  }, []);

  const onTyping = useCallback((callback: (event: unknown) => void) => {
    socketRef.current?.on('typing', callback);
    return () => {
      socketRef.current?.off('typing', callback);
    };
  }, []);

  return {
    socket: socketRef.current,
    joinConversation,
    leaveConversation,
    sendMessage,
    onMessageStream,
    onTyping,
  };
}
