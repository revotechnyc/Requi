'use client';

import { useState, useEffect, useCallback } from 'react';
import { api } from '@/lib/api';

export interface Subscription {
  id: string;
  status: 'TRIAL' | 'ACTIVE' | 'TRIAL_EXPIRED' | 'CANCELED' | 'UNPAID';
  tier: {
    name: string;
    seatCount: number;
    totalPriceCents: number;
  };
  seatsUsed: number;
  seatsAvailable: number;
}

export interface BillingInfo {
  subscription: Subscription;
  trial: {
    isActive: boolean;
    daysRemaining: number;
    endsAt: string | null;
  };
  billing: {
    nextBillingDate: string;
    amountDueCents: number;
    paymentMethod: {
      type: string;
      last4: string;
      expiryMonth: number;
      expiryYear: number;
    } | null;
  };
  invoices: Array<{
    id: string;
    amountCents: number;
    status: string;
    createdAt: string;
    pdfUrl?: string;
  }>;
}

export interface SubscriptionTier {
  id: string;
  name: string;
  displayName: string;
  seatCount: number;
  pricePerSeatCents: number;
  totalPriceCents: number;
}

interface UseBillingReturn {
  billingInfo: BillingInfo | null;
  tiers: SubscriptionTier[];
  isLoading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
  startTrial: (organizationId: string, seatCount: number, billingEmail: string) => Promise<void>;
  upgradeSeats: (organizationId: string, newSeatCount: number) => Promise<void>;
  assignSeat: (organizationId: string, userId: string) => Promise<void>;
  unassignSeat: (organizationId: string, userId: string, reason?: string) => Promise<void>;
  cancelSubscription: (organizationId: string, reason?: string) => Promise<void>;
  createSetupIntent: (organizationId: string) => Promise<{ clientSecret: string }>;
}

export function useBilling(organizationId?: string): UseBillingReturn {
  const [billingInfo, setBillingInfo] = useState<BillingInfo | null>(null);
  const [tiers, setTiers] = useState<SubscriptionTier[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchBillingInfo = useCallback(async () => {
    if (!organizationId) return;
    
    try {
      setIsLoading(true);
      setError(null);
      const response = await api.get(`/billing/${organizationId}`);
      setBillingInfo(response.data);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to fetch billing info');
    } finally {
      setIsLoading(false);
    }
  }, [organizationId]);

  const fetchTiers = useCallback(async () => {
    try {
      const response = await api.get('/billing/tiers');
      setTiers(response.data);
    } catch (err: any) {
      console.error('Failed to fetch tiers:', err);
    }
  }, []);

  useEffect(() => {
    fetchTiers();
    if (organizationId) {
      fetchBillingInfo();
    }
  }, [fetchBillingInfo, fetchTiers, organizationId]);

  const startTrial = async (orgId: string, seatCount: number, billingEmail: string) => {
    const response = await api.post(`/billing/trial/${orgId}`, {
      seatCount,
      billingEmail,
    });
    if (organizationId === orgId) {
      await fetchBillingInfo();
    }
    return response.data;
  };

  const upgradeSeats = async (orgId: string, newSeatCount: number) => {
    const response = await api.post(`/billing/upgrade/${orgId}`, {
      newSeatCount,
    });
    if (organizationId === orgId) {
      await fetchBillingInfo();
    }
    return response.data;
  };

  const assignSeat = async (orgId: string, userId: string) => {
    const response = await api.post(`/billing/seats/assign/${orgId}`, {
      userId,
    });
    if (organizationId === orgId) {
      await fetchBillingInfo();
    }
    return response.data;
  };

  const unassignSeat = async (orgId: string, userId: string, reason?: string) => {
    const response = await api.post(`/billing/seats/unassign/${orgId}`, {
      userId,
      reason,
    });
    if (organizationId === orgId) {
      await fetchBillingInfo();
    }
    return response.data;
  };

  const cancelSubscription = async (orgId: string, reason?: string) => {
    const response = await api.post(`/billing/cancel/${orgId}`, {
      reason,
    });
    if (organizationId === orgId) {
      await fetchBillingInfo();
    }
    return response.data;
  };

  const createSetupIntent = async (orgId: string) => {
    const response = await api.post(`/billing/payment-methods/setup-intent/${orgId}`);
    return response.data;
  };

  return {
    billingInfo,
    tiers,
    isLoading,
    error,
    refetch: fetchBillingInfo,
    startTrial,
    upgradeSeats,
    assignSeat,
    unassignSeat,
    cancelSubscription,
    createSetupIntent,
  };
}
