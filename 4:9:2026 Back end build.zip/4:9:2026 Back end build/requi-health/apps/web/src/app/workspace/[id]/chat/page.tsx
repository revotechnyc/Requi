'use client';

import { useEffect, useRef, useState } from 'react';
import { useParams } from 'next/navigation';
import { Send, Sparkles, BookOpen, AlertCircle } from 'lucide-react';
import { useChatStore } from '@/stores/chat';
import { useAuthStore } from '@/stores/auth';
import { ConfidenceLevel } from '@requi/shared-types';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  citations?: Array<{
    sourceId: string;
    excerpt: string;
    sourceTitle: string;
  }>;
  confidence?: ConfidenceLevel;
  isStreaming?: boolean;
}

export default function WorkspaceChatPage() {
  const params = useParams();
  const workspaceId = params.id as string;
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [input, setInput] = useState('');
  const user = useAuthStore((state) => state.user);
  const {
    messages,
    isLoading,
    currentConversation,
    sendMessage,
    fetchConversations,
    createConversation,
  } = useChatStore();

  useEffect(() => {
    fetchConversations(workspaceId);
  }, [workspaceId, fetchConversations]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const message = input.trim();
    setInput('');

    if (!currentConversation) {
      await createConversation(workspaceId, message);
    }

    await sendMessage(workspaceId, currentConversation?.id || '', message);
  };

  const getConfidenceColor = (confidence?: ConfidenceLevel) => {
    switch (confidence) {
      case ConfidenceLevel.HIGH:
        return 'bg-green-100 text-green-800';
      case ConfidenceLevel.MEDIUM:
        return 'bg-yellow-100 text-yellow-800';
      case ConfidenceLevel.LOW:
        return 'bg-orange-100 text-orange-800';
      case ConfidenceLevel.UNSUPPORTED:
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="flex h-screen flex-col bg-gray-50">
      {/* Header */}
      <header className="flex h-16 items-center justify-between border-b border-gray-200 bg-white px-4">
        <div className="flex items-center gap-4">
          <div className="h-8 w-8 rounded-lg bg-primary-600" />
          <div>
            <h1 className="font-semibold text-gray-900">Compliance Chat</h1>
            <p className="text-xs text-gray-500">Workspace: {workspaceId}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-1.5 text-sm font-medium text-gray-700 hover:bg-gray-50">
            <BookOpen className="h-4 w-4" />
            Sources
          </button>
          <div className="h-8 w-8 rounded-full bg-primary-100">
            {user?.avatarUrl ? (
              <img
                src={user.avatarUrl}
                alt={user.firstName}
                className="h-full w-full rounded-full object-cover"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center text-sm font-medium text-primary-700">
                {user?.firstName?.[0]}
                {user?.lastName?.[0]}
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="mx-auto max-w-3xl space-y-6">
          {messages.length === 0 ? (
            <div className="py-12 text-center">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-primary-100">
                <Sparkles className="h-8 w-8 text-primary-600" />
              </div>
              <h2 className="mt-4 text-xl font-semibold text-gray-900">
                How can I help with compliance today?
              </h2>
              <p className="mt-2 text-gray-600">
                Ask me about Medicaid, Medicare, or healthcare regulations. I will
                provide answers backed by authoritative sources.
              </p>
              <div className="mt-8 flex flex-wrap justify-center gap-2">
                {[
                  'What are the eligibility requirements for Medicaid?',
                  'Explain CMS billing guidelines',
                  'HIPAA compliance checklist',
                  'State plan amendment process',
                ].map((suggestion) => (
                  <button
                    key={suggestion}
                    onClick={() => setInput(suggestion)}
                    className="rounded-full border border-gray-300 bg-white px-4 py-2 text-sm text-gray-700 hover:bg-gray-50"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-4 ${
                  message.role === 'user' ? 'flex-row-reverse' : ''
                }`}
              >
                <div
                  className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${
                    message.role === 'user'
                      ? 'bg-primary-600'
                      : 'bg-gradient-to-br from-purple-500 to-blue-500'
                  }`}
                >
                  {message.role === 'user' ? (
                    <span className="text-sm font-medium text-white">
                      {user?.firstName?.[0]}
                    </span>
                  ) : (
                    <Sparkles className="h-4 w-4 text-white" />
                  )}
                </div>
                <div
                  className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                    message.role === 'user'
                      ? 'bg-primary-600 text-white'
                      : 'bg-white shadow-sm'
                  }`}
                >
                  <div className="prose prose-sm max-w-none">
                    {message.content}
                    {message.isStreaming && (
                      <span className="ml-1 inline-flex gap-1">
                        <span className="typing-dot h-1.5 w-1.5 rounded-full bg-current" />
                        <span className="typing-dot h-1.5 w-1.5 rounded-full bg-current" />
                        <span className="typing-dot h-1.5 w-1.5 rounded-full bg-current" />
                      </span>
                    )}
                  </div>

                  {message.role === 'assistant' && message.confidence && (
                    <div className="mt-3 flex items-center gap-2">
                      <span
                        className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium ${getConfidenceColor(
                          message.confidence
                        )}`}
                      >
                        <AlertCircle className="h-3 w-3" />
                        {message.confidence} Confidence
                      </span>
                    </div>
                  )}

                  {message.citations && message.citations.length > 0 && (
                    <div className="mt-3 space-y-2">
                      <p className="text-xs font-medium text-gray-500">Sources:</p>
                      {message.citations.map((citation, idx) => (
                        <div
                          key={idx}
                          className="rounded-lg border border-gray-200 bg-gray-50 p-2 text-xs"
                        >
                          <p className="font-medium text-gray-700">
                            {citation.sourceTitle}
                          </p>
                          <p className="mt-1 text-gray-600 line-clamp-2">
                            {citation.excerpt}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input */}
      <div className="border-t border-gray-200 bg-white p-4">
        <form onSubmit={handleSubmit} className="mx-auto max-w-3xl">
          <div className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask a compliance question..."
              disabled={isLoading}
              className="flex-1 rounded-lg border border-gray-300 px-4 py-3 focus:border-primary-500 focus:outline-none focus:ring-2 focus:ring-primary-500 disabled:bg-gray-100"
            />
            <button
              type="submit"
              disabled={!input.trim() || isLoading}
              className="flex items-center gap-2 rounded-lg bg-primary-600 px-4 py-3 font-medium text-white hover:bg-primary-700 disabled:opacity-50"
            >
              <Send className="h-4 w-4" />
              Send
            </button>
          </div>
          <p className="mt-2 text-center text-xs text-gray-500">
            Requi provides guidance based on available sources. Always verify with
            legal counsel for critical decisions.
          </p>
        </form>
      </div>
    </div>
  );
}
