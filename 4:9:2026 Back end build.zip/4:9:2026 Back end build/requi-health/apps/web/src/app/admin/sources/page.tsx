'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import {
  Plus,
  Search,
  Filter,
  MoreVertical,
  FileText,
  Globe,
  BookOpen,
  Scale,
  AlertCircle,
} from 'lucide-react';
import { api } from '@/lib/api';
import { SourceType, AuthorityTier, SourceStatus } from '@requi/shared-types';

interface Source {
  id: string;
  title: string;
  sourceType: SourceType;
  authorityTier: AuthorityTier;
  jurisdiction: string;
  status: SourceStatus;
  createdAt: string;
  _count?: { chunks: number };
}

export default function AdminSourcesPage() {
  const [sources, setSources] = useState<Source[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('');

  useEffect(() => {
    fetchSources();
  }, []);

  const fetchSources = async () => {
    try {
      const response = await api.get('/sources');
      setSources(response.data || []);
    } catch (error) {
      console.error('Error fetching sources:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getSourceTypeIcon = (type: SourceType) => {
    switch (type) {
      case SourceType.FEDERAL_STATUTE:
      case SourceType.STATE_STATUTE:
        return <Scale className="h-4 w-4" />;
      case SourceType.FEDERAL_REGULATION:
      case SourceType.STATE_REGULATION:
        return <BookOpen className="h-4 w-4" />;
      case SourceType.WEB_PAGE:
        return <Globe className="h-4 w-4" />;
      default:
        return <FileText className="h-4 w-4" />;
    }
  };

  const getAuthorityTierBadge = (tier: AuthorityTier) => {
    const colors: Record<AuthorityTier, string> = {
      [AuthorityTier.TIER_1_BINDING_PRIMARY]: 'bg-red-100 text-red-800',
      [AuthorityTier.TIER_2_BINDING_SECONDARY]: 'bg-orange-100 text-orange-800',
      [AuthorityTier.TIER_3_OFFICIAL_GUIDANCE]: 'bg-yellow-100 text-yellow-800',
      [AuthorityTier.TIER_4_INTERPRETIVE]: 'bg-blue-100 text-blue-800',
      [AuthorityTier.TIER_5_INFORMATIVE]: 'bg-gray-100 text-gray-800',
      [AuthorityTier.TIER_6_GENERAL]: 'bg-gray-50 text-gray-600',
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${colors[tier]}`}>
        {tier.replace('TIER_', '').replace(/_/g, ' ')}
      </span>
    );
  };

  const filteredSources = sources.filter((source) => {
    const matchesSearch =
      source.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      source.jurisdiction.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType ? source.sourceType === filterType : true;
    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Sources</h1>
          <p className="text-gray-600 mt-1">
            Manage your knowledge base sources
          </p>
        </div>
        <Link
          href="/admin/sources/new"
          className="inline-flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700"
        >
          <Plus className="h-4 w-4" />
          Add Source
        </Link>
      </div>

      {/* Filters */}
      <div className="flex gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search sources..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
          />
        </div>
        <select
          value={filterType}
          onChange={(e) => setFilterType(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
        >
          <option value="">All Types</option>
          {Object.values(SourceType).map((type) => (
            <option key={type} value={type}>
              {type.replace(/_/g, ' ')}
            </option>
          ))}
        </select>
      </div>

      {/* Sources Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Source
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Type
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Authority
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Jurisdiction
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Chunks
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Status
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {isLoading ? (
              <tr>
                <td colSpan={7} className="px-6 py-8 text-center">
                  <div className="animate-pulse space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="h-12 bg-gray-100 rounded" />
                    ))}
                  </div>
                </td>
              </tr>
            ) : filteredSources.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-6 py-12 text-center">
                  <AlertCircle className="mx-auto h-12 w-12 text-gray-300" />
                  <h3 className="mt-4 text-lg font-medium text-gray-900">
                    No sources found
                  </h3>
                  <p className="mt-2 text-gray-500">
                    Get started by adding your first source.
                  </p>
                  <Link
                    href="/admin/sources/new"
                    className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700"
                  >
                    <Plus className="h-4 w-4" />
                    Add Source
                  </Link>
                </td>
              </tr>
            ) : (
              filteredSources.map((source) => (
                <tr key={source.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-gray-100 rounded-lg">
                        {getSourceTypeIcon(source.sourceType)}
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">
                          {source.title}
                        </p>
                        <p className="text-sm text-gray-500">
                          {new Date(source.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-gray-600">
                      {source.sourceType.replace(/_/g, ' ')}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    {getAuthorityTierBadge(source.authorityTier)}
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-gray-600">
                      {source.jurisdiction}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-gray-600">
                      {source._count?.chunks || 0}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span
                      className={`px-2 py-1 rounded-full text-xs font-medium ${
                        source.status === SourceStatus.ACTIVE
                          ? 'bg-green-100 text-green-800'
                          : source.status === SourceStatus.PENDING_REVIEW
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-gray-100 text-gray-800'
                      }`}
                    >
                      {source.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button className="p-2 hover:bg-gray-100 rounded-lg">
                      <MoreVertical className="h-4 w-4 text-gray-400" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
