'use client';

import { useEffect, useState } from 'react';
import {
  BookOpen,
  MessageSquare,
  AlertTriangle,
  Users,
  TrendingUp,
  TrendingDown,
} from 'lucide-react';
import { api } from '@/lib/api';

interface DashboardStats {
  totalSources: number;
  totalConversations: number;
  openKnowledgeGaps: number;
  totalUsers: number;
  sourcesTrend: number;
  conversationsTrend: number;
  gapsTrend: number;
  usersTrend: number;
}

export default function AdminDashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const response = await api.get('/admin/stats');
      setStats(response);
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const statCards = [
    {
      title: 'Total Sources',
      value: stats?.totalSources || 0,
      trend: stats?.sourcesTrend || 0,
      icon: BookOpen,
      color: 'blue',
    },
    {
      title: 'Conversations',
      value: stats?.totalConversations || 0,
      trend: stats?.conversationsTrend || 0,
      icon: MessageSquare,
      color: 'green',
    },
    {
      title: 'Knowledge Gaps',
      value: stats?.openKnowledgeGaps || 0,
      trend: stats?.gapsTrend || 0,
      icon: AlertTriangle,
      color: 'orange',
    },
    {
      title: 'Total Users',
      value: stats?.totalUsers || 0,
      trend: stats?.usersTrend || 0,
      icon: Users,
      color: 'purple',
    },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
        <p className="text-gray-600 mt-1">
          Overview of your Requi Health instance
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((card) => {
          const Icon = card.icon;
          const isPositive = card.trend >= 0;

          return (
            <div
              key={card.title}
              className="bg-white rounded-lg border border-gray-200 p-6"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">
                    {card.title}
                  </p>
                  <p className="text-3xl font-bold text-gray-900 mt-2">
                    {isLoading ? (
                      <span className="animate-pulse bg-gray-200 rounded w-16 h-8 inline-block" />
                    ) : (
                      card.value.toLocaleString()
                    )}
                  </p>
                </div>
                <div
                  className={`p-3 rounded-lg ${
                    card.color === 'blue'
                      ? 'bg-blue-100'
                      : card.color === 'green'
                      ? 'bg-green-100'
                      : card.color === 'orange'
                      ? 'bg-orange-100'
                      : 'bg-purple-100'
                  }`}
                >
                  <Icon
                    className={`h-6 w-6 ${
                      card.color === 'blue'
                        ? 'text-blue-600'
                        : card.color === 'green'
                        ? 'text-green-600'
                        : card.color === 'orange'
                        ? 'text-orange-600'
                        : 'text-purple-600'
                    }`}
                  />
                </div>
              </div>

              {!isLoading && (
                <div className="flex items-center gap-1 mt-4">
                  {isPositive ? (
                    <TrendingUp className="h-4 w-4 text-green-500" />
                  ) : (
                    <TrendingDown className="h-4 w-4 text-red-500" />
                  )}
                  <span
                    className={`text-sm font-medium ${
                      isPositive ? 'text-green-600' : 'text-red-600'
                    }`}
                  >
                    {Math.abs(card.trend)}%
                  </span>
                  <span className="text-sm text-gray-500">vs last month</span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">
          Quick Actions
        </h2>
        <div className="flex flex-wrap gap-4">
          <a
            href="/admin/sources/new"
            className="inline-flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700"
          >
            <BookOpen className="h-4 w-4" />
            Add New Source
          </a>
          <a
            href="/admin/gaps"
            className="inline-flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700"
          >
            <AlertTriangle className="h-4 w-4" />
            Review Knowledge Gaps
          </a>
          <a
            href="/admin/users/new"
            className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
          >
            <Users className="h-4 w-4" />
            Invite User
          </a>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">
          Recent Activity
        </h2>
        <div className="space-y-4">
          <p className="text-gray-500 text-sm">
            Activity feed will appear here...
          </p>
        </div>
      </div>
    </div>
  );
}
