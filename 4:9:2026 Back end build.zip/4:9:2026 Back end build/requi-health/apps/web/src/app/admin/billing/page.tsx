'use client';

import { useState } from 'react';
import { useBilling } from '@/hooks/useBilling';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { PaymentMethodForm } from '@/components/billing/PaymentMethodForm';
import {
  CreditCard,
  Users,
  Calendar,
  DollarSign,
  AlertTriangle,
  CheckCircle,
  Clock,
  Download,
  Plus,
  ArrowUpRight,
  Loader2,
} from 'lucide-react';
import toast from 'react-hot-toast';

const statusConfig = {
  TRIAL: { label: 'Trial', color: 'blue', icon: Clock },
  ACTIVE: { label: 'Active', color: 'green', icon: CheckCircle },
  TRIAL_EXPIRED: { label: 'Trial Expired', color: 'orange', icon: AlertTriangle },
  CANCELED: { label: 'Canceled', color: 'red', icon: AlertTriangle },
  UNPAID: { label: 'Unpaid', color: 'red', icon: AlertTriangle },
};

// Mock organization ID - in real app, get from context/route
const ORG_ID = 'org_demo_123';

export default function BillingPage() {
  const {
    billingInfo,
    tiers,
    isLoading,
    error,
    refetch,
    upgradeSeats,
    createSetupIntent,
  } = useBilling(ORG_ID);

  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [selectedTier, setSelectedTier] = useState<number | null>(null);
  const [isUpgrading, setIsUpgrading] = useState(false);
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [setupIntentSecret, setSetupIntentSecret] = useState<string | null>(null);

  const formatCurrency = (cents: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(cents / 100);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const handleUpgrade = async () => {
    if (!selectedTier) return;
    setIsUpgrading(true);
    try {
      await upgradeSeats(ORG_ID, selectedTier);
      toast.success(`Successfully upgraded to ${selectedTier} seats!`);
      setShowUpgradeModal(false);
      setSelectedTier(null);
      await refetch();
    } catch (err: any) {
      toast.error(err.message || 'Failed to upgrade');
    } finally {
      setIsUpgrading(false);
    }
  };

  const handleAddPaymentMethod = async () => {
    try {
      const { clientSecret } = await createSetupIntent(ORG_ID);
      setSetupIntentSecret(clientSecret);
      setShowPaymentForm(true);
    } catch (err: any) {
      toast.error(err.message || 'Failed to initialize payment form');
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <AlertTriangle className="mx-auto h-12 w-12 text-orange-500 mb-4" />
        <h3 className="text-lg font-medium text-gray-900">Failed to load billing info</h3>
        <p className="text-gray-500 mt-2">{error}</p>
        <Button variant="outline" className="mt-4" onClick={refetch}>
          Try Again
        </Button>
      </div>
    );
  }

  if (!billingInfo) {
    return (
      <div className="text-center py-12">
        <AlertTriangle className="mx-auto h-12 w-12 text-orange-500 mb-4" />
        <h3 className="text-lg font-medium text-gray-900">No billing information</h3>
        <p className="text-gray-500 mt-2">Please start a trial to access billing features</p>
      </div>
    );
  }

  const status = statusConfig[billingInfo.subscription.status];
  const StatusIcon = status.icon;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Billing & Subscription</h1>
          <p className="text-gray-500 mt-1">Manage your subscription, seats, and payments</p>
        </div>
        <Badge variant={status.color as any} className="flex items-center gap-1.5 px-3 py-1.5">
          <StatusIcon className="w-4 h-4" />
          {status.label}
        </Badge>
      </div>

      {/* Trial Banner */}
      {billingInfo.trial.isActive && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Clock className="w-5 h-5 text-blue-600" />
            <div>
              <p className="font-medium text-blue-900">
                Trial ends in {billingInfo.trial.daysRemaining} days
              </p>
              <p className="text-sm text-blue-700">
                Upgrade before {formatDate(billingInfo.trial.endsAt!)} to avoid interruption
              </p>
            </div>
          </div>
          <Button variant="primary">Upgrade Now</Button>
        </div>
      )}

      {/* Trial Expired Banner */}
      {billingInfo.subscription.status === 'TRIAL_EXPIRED' && (
        <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-orange-600" />
            <div>
              <p className="font-medium text-orange-900">Your trial has expired</p>
              <p className="text-sm text-orange-700">
                Your account is now in read-only mode. Upgrade to restore full access.
              </p>
            </div>
          </div>
          <Button variant="primary">Upgrade Now</Button>
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Users className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Seats Used</p>
              <p className="text-xl font-semibold">
                {billingInfo.subscription.seatsUsed} / {billingInfo.subscription.seatsAvailable}
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-green-100 rounded-lg">
              <DollarSign className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Monthly Cost</p>
              <p className="text-xl font-semibold">
                {formatCurrency(billingInfo.subscription.tier.totalPriceCents)}
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-purple-100 rounded-lg">
              <Calendar className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Next Billing</p>
              <p className="text-xl font-semibold">
                {formatDate(billingInfo.billing.nextBillingDate)}
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-orange-100 rounded-lg">
              <CreditCard className="w-5 h-5 text-orange-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Payment Method</p>
              <p className="text-xl font-semibold">
                {billingInfo.billing.paymentMethod ? '•••• ' + billingInfo.billing.paymentMethod.last4 : 'None'}
              </p>
            </div>
          </div>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Current Plan */}
        <Card className="p-6 lg:col-span-2">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold">Current Plan</h2>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowUpgradeModal(true)}
              disabled={billingInfo.subscription.status === 'CANCELED'}
            >
              <ArrowUpRight className="w-4 h-4 mr-1" />
              Upgrade
            </Button>
          </div>

          <div className="space-y-4">
            <div className="flex justify-between items-center py-3 border-b">
              <span className="text-gray-600">Plan</span>
              <span className="font-medium">Enterprise - {billingInfo.subscription.tier.seatCount} Users</span>
            </div>
            <div className="flex justify-between items-center py-3 border-b">
              <span className="text-gray-600">Price per user</span>
              <span className="font-medium">$1,000/month</span>
            </div>
            <div className="flex justify-between items-center py-3 border-b">
              <span className="text-gray-600">Total monthly cost</span>
              <span className="font-medium text-lg">
                {formatCurrency(billingInfo.subscription.tier.totalPriceCents)}
              </span>
            </div>
            <div className="flex justify-between items-center py-3">
              <span className="text-gray-600">Billing cycle</span>
              <span className="font-medium">Monthly</span>
            </div>
          </div>

          {/* Seat Usage Bar */}
          <div className="mt-6">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-600">Seat Usage</span>
              <span className="font-medium">
                {billingInfo.subscription.seatsUsed} of {billingInfo.subscription.seatsAvailable} used
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div
                className="bg-blue-600 h-2.5 rounded-full transition-all"
                style={{
                  width: `${(billingInfo.subscription.seatsUsed / billingInfo.subscription.seatsAvailable) * 100}%`,
                }}
              />
            </div>
          </div>
        </Card>

        {/* Payment Method */}
        <Card className="p-6">
          <h2 className="text-lg font-semibold mb-4">Payment Method</h2>
          {billingInfo.billing.paymentMethod ? (
            <div className="space-y-4">
              <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                <CreditCard className="w-8 h-8 text-gray-400" />
                <div>
                  <p className="font-medium capitalize">{billingInfo.billing.paymentMethod.type}</p>
                  <p className="text-sm text-gray-500">
                    •••• {billingInfo.billing.paymentMethod.last4} • Expires{' '}
                    {billingInfo.billing.paymentMethod.expiryMonth}/
                    {billingInfo.billing.paymentMethod.expiryYear}
                  </p>
                </div>
              </div>
              <Button variant="outline" className="w-full" onClick={handleAddPaymentMethod}>
                Update Payment Method
              </Button>
            </div>
          ) : (
            <div className="text-center py-6">
              <CreditCard className="mx-auto h-12 w-12 text-gray-300 mb-3" />
              <p className="text-gray-500 mb-4">No payment method on file</p>
              <Button variant="primary" className="w-full" onClick={handleAddPaymentMethod}>
                <Plus className="w-4 h-4 mr-1" />
                Add Payment Method
              </Button>
            </div>
          )}
        </Card>
      </div>

      {/* Payment Method Form Modal */}
      {showPaymentForm && setupIntentSecret && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="max-w-md w-full">
            <PaymentMethodForm
              clientSecret={setupIntentSecret}
              onSuccess={() => {
                setShowPaymentForm(false);
                setSetupIntentSecret(null);
                toast.success('Payment method added successfully!');
                refetch();
              }}
              onCancel={() => {
                setShowPaymentForm(false);
                setSetupIntentSecret(null);
              }}
            />
          </div>
        </div>
      )}

      {/* Invoices */}
      <Card className="p-6">
        <h2 className="text-lg font-semibold mb-4">Invoice History</h2>
        {billingInfo.invoices.length > 0 ? (
          <div className="divide-y">
            {billingInfo.invoices.map((invoice) => (
              <div
                key={invoice.id}
                className="flex items-center justify-between py-4"
              >
                <div>
                  <p className="font-medium">Invoice #{invoice.id}</p>
                  <p className="text-sm text-gray-500">{formatDate(invoice.createdAt)}</p>
                </div>
                <div className="flex items-center gap-4">
                  <span className="font-medium">{formatCurrency(invoice.amountCents)}</span>
                  <Badge variant={invoice.status === 'paid' ? 'green' : 'orange'}>
                    {invoice.status}
                  </Badge>
                  {invoice.pdfUrl && (
                    <Button variant="ghost" size="sm" asChild>
                      <a href={invoice.pdfUrl} target="_blank" rel="noopener noreferrer">
                        <Download className="w-4 h-4" />
                      </a>
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            <p>No invoices yet</p>
            <p className="text-sm mt-1">Invoices will appear here after your first payment</p>
          </div>
        )}
      </Card>

      {/* Upgrade Modal */}
      {showUpgradeModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[80vh] overflow-auto">
            <div className="p-6 border-b">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold">Upgrade Your Plan</h2>
                <button
                  onClick={() => setShowUpgradeModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ×
                </button>
              </div>
            </div>
            <div className="p-6">
              <p className="text-gray-600 mb-6">
                Select the number of seats you need. You can upgrade at any time and will be charged
                a prorated amount for the remainder of your billing cycle.
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {tiers.map((tier) => (
                  <button
                    key={tier.id}
                    onClick={() => setSelectedTier(tier.seatCount)}
                    disabled={tier.seatCount <= billingInfo.subscription.tier.seatCount}
                    className={`p-4 border-2 rounded-lg text-left transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
                      selectedTier === tier.seatCount
                        ? 'border-blue-600 bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <p className="font-semibold text-lg">{tier.seatCount} Users</p>
                    <p className="text-gray-600">{formatCurrency(tier.totalPriceCents)}/mo</p>
                    <p className="text-sm text-gray-500 mt-1">$1,000/user</p>
                  </button>
                ))}
              </div>
            </div>
            <div className="p-6 border-t bg-gray-50 flex justify-end gap-3">
              <Button variant="outline" onClick={() => setShowUpgradeModal(false)}>
                Cancel
              </Button>
              <Button
                variant="primary"
                disabled={!selectedTier || isUpgrading}
                onClick={handleUpgrade}
              >
                {isUpgrading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Upgrading...
                  </>
                ) : (
                  'Confirm Upgrade'
                )}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
