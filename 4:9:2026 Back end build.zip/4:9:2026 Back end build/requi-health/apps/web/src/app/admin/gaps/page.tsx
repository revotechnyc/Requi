'use client';

import { useEffect, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle,
  Clock,
  Filter,
  Search,
  ArrowRight,
} from 'lucide-react';
import { api } from '@/lib/api';
import {
  MissingKnowledgeStatus,
  MissingKnowledgePriority,
} from '@requi/shared-types';

interface KnowledgeGap {
  id: string;
  query: string;
  detectedGaps: string[];
  status: MissingKnowledgeStatus;
  priority: MissingKnowledgePriority;
  createdAt: string;
  resolvedAt?: string;
  resolutionNotes?: string;
}

export default function AdminGapsPage() {
  const [gaps, setGaps] = useState<KnowledgeGap[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState<string>('');

  useEffect(() => {
    fetchGaps();
  }, [filterStatus]);

  const fetchGaps = async () => {
    try {
      const params = new URLSearchParams();
      if (filterStatus) params.append('status', filterStatus);

      const response = await api.get(`/missing-knowledge?${params}`);
      setGaps(response.data || []);
    } catch (error) {
      console.error('Error fetching gaps:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getPriorityBadge = (priority: MissingKnowledgePriority) => {
    const colors: Record<MissingKnowledgePriority, string> = {
      [MissingKnowledgePriority.CRITICAL]: 'bg-red-100 text-red-800',
      [MissingKnowledgePriority.HIGH]: 'bg-orange-100 text-orange-800',
      [MissingKnowledgePriority.MEDIUM]: 'bg-yellow-100 text-yellow-800',
      [MissingKnowledgePriority.LOW]: 'bg-gray-100 text-gray-800',
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${colors[priority]}`}>
        {priority}
      </span>
    );
  };

  const getStatusIcon = (status: MissingKnowledgeStatus) => {
    switch (status) {
      case MissingKnowledgeStatus.RESOLVED:
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case MissingKnowledgeStatus.IN_PROGRESS:
        return <Clock className="h-5 w-5 text-blue-500" />;
      default:
        return <AlertTriangle className="h-5 w-5 text-orange-500" />;
    }
  };

  const handleResolve = async (id: string) => {
    try {
      await api.post(`/missing-knowledge/${id}/resolve`, {
        resolutionNotes: 'Resolved by admin',
      });
      fetchGaps();
    } catch (error) {
      console.error('Error resolving gap:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Knowledge Gaps</h1>
        <p className="text-gray-600 mt-1">
          Review and address identified knowledge gaps
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: 'Open', count: gaps.filter((g) => g.status === MissingKnowledgeStatus.PENDING).length, color: 'orange' },
          { label: 'In Progress', count: gaps.filter((g) => g.status === MissingKnowledgeStatus.IN_PROGRESS).length, color: 'blue' },
          { label: 'Resolved', count: gaps.filter((g) => g.status === MissingKnowledgeStatus.RESOLVED).length, color: 'green' },
          { label: 'Total', count: gaps.length, color: 'gray' },
        ].map((stat) => (
          <div
            key={stat.label}
            className="bg-white rounded-lg border border-gray-200 p-4"
          >
            <p className="text-sm text-gray-600">{stat.label}</p>
            <p className="text-2xl font-bold text-gray-900">{stat.count}</p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex gap-4">
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500"
        >
          <option value="">All Statuses</option>
          {Object.values(MissingKnowledgeStatus).map((status) => (
            <option key={status} value={status}>
              {status.replace(/_/g, ' ')}
            </option>
          ))}
        </select>
      </div>

      {/* Gaps List */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="animate-pulse space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-32 bg-gray-100 rounded-lg" />
            ))}
          </div>
        ) : gaps.length === 0 ? (
          <div className="bg-white rounded-lg border border-gray-200 p-12 text-center">
            <CheckCircle className="mx-auto h-12 w-12 text-green-500" />
            <h3 className="mt-4 text-lg font-medium text-gray-900">
              No knowledge gaps
            </h3>
            <p className="mt-2 text-gray-500">
              All queries are being answered with sufficient confidence.
            </p>
          </div>
        ) : (
          gaps.map((gap) => (
            <div
              key={gap.id}
              className="bg-white rounded-lg border border-gray-200 p-6"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-4">
                  {getStatusIcon(gap.status)}
                  <div>
                    <h3 className="font-medium text-gray-900">{gap.query}</h3>
                    <div className="flex items-center gap-2 mt-2">
                      {getPriorityBadge(gap.priority)}
                      <span className="text-sm text-gray-500">
                        Detected {new Date(gap.createdAt).toLocaleDateString()}
                      </span>
                    </div>

                    {gap.detectedGaps.length > 0 && (
                      <div className="mt-3">
                        <p className="text-sm font-medium text-gray-700">
                          Detected gaps:
                        </p>
                        <ul className="mt-1 space-y-1">
                          {gap.detectedGaps.map((g, i) => (
                            <li
                              key={i}
                              className="text-sm text-gray-600 flex items-center gap-2"
                            >
                              <ArrowRight className="h-3 w-3" />
                              {g}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {gap.resolutionNotes && (
                      <div className="mt-3 p-3 bg-green-50 rounded-lg">
                        <p className="text-sm text-green-800">
                          <span className="font-medium">Resolution:</span>{' '}
                          {gap.resolutionNotes}
                        </p>
                      </div>
                    )}
                  </div>
                </div>

                {gap.status !== MissingKnowledgeStatus.RESOLVED && (
                  <button
                    onClick={() => handleResolve(gap.id)}
                    className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm font-medium"
                  >
                    Mark Resolved
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
