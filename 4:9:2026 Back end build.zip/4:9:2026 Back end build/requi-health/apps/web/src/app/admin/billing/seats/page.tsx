'use client';

import { useState } from 'react';
import { useBilling } from '@/hooks/useBilling';
import { SeatManager } from '@/components/billing';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { Loader2, AlertTriangle, Users, ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import toast from 'react-hot-toast';

// Mock users data - in real app, fetch from users API
const mockUsers = [
  { id: '1', email: 'john.doe@company.com', name: 'John Doe', role: 'ADMIN', seatAssigned: true, assignedAt: '2024-01-15' },
  { id: '2', email: 'jane.smith@company.com', name: 'Jane Smith', role: 'MEMBER', seatAssigned: true, assignedAt: '2024-01-16' },
  { id: '3', email: 'bob.wilson@company.com', name: 'Bob Wilson', role: 'MEMBER', seatAssigned: false },
  { id: '4', email: 'alice.jones@company.com', name: 'Alice Jones', role: 'MEMBER', seatAssigned: true, assignedAt: '2024-01-20' },
  { id: '5', email: 'charlie.brown@company.com', name: 'Charlie Brown', role: 'MEMBER', seatAssigned: false },
  { id: '6', email: 'diana.prince@company.com', name: 'Diana Prince', role: 'MEMBER', seatAssigned: false },
  { id: '7', email: 'eve.davis@company.com', name: 'Eve Davis', role: 'VIEWER', seatAssigned: false },
];

const ORG_ID = 'org_demo_123';

export default function SeatManagementPage() {
  const { billingInfo, isLoading, error, refetch, assignSeat, unassignSeat } = useBilling(ORG_ID);
  const [users, setUsers] = useState(mockUsers);

  const handleAssignSeat = async (userId: string) => {
    try {
      await assignSeat(ORG_ID, userId);
      setUsers(prev => prev.map(u => 
        u.id === userId ? { ...u, seatAssigned: true, assignedAt: new Date().toISOString() } : u
      ));
      toast.success('Seat assigned successfully');
    } catch (err: any) {
      toast.error(err.message || 'Failed to assign seat');
      throw err;
    }
  };

  const handleUnassignSeat = async (userId: string, reason?: string) => {
    try {
      await unassignSeat(ORG_ID, userId, reason);
      setUsers(prev => prev.map(u => 
        u.id === userId ? { ...u, seatAssigned: false, assignedAt: undefined } : u
      ));
      toast.success('Seat unassigned successfully');
    } catch (err: any) {
      toast.error(err.message || 'Failed to unassign seat');
      throw err;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <AlertTriangle className="mx-auto h-12 w-12 text-orange-500 mb-4" />
        <h3 className="text-lg font-medium text-gray-900">Failed to load billing info</h3>
        <p className="text-gray-500 mt-2">{error}</p>
        <Button variant="outline" className="mt-4" onClick={refetch}>
          Try Again
        </Button>
      </div>
    );
  }

  if (!billingInfo) {
    return (
      <div className="text-center py-12">
        <AlertTriangle className="mx-auto h-12 w-12 text-orange-500 mb-4" />
        <h3 className="text-lg font-medium text-gray-900">No subscription found</h3>
        <p className="text-gray-500 mt-2">Please start a trial or subscribe to manage seats</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/admin/billing">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Billing
            </Button>
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Seat Management</h1>
            <p className="text-gray-500 mt-1">Assign and manage user seats</p>
          </div>
        </div>
        <Badge variant="blue" className="flex items-center gap-1.5 px-3 py-1.5">
          <Users className="w-4 h-4" />
          {billingInfo.subscription.seatsUsed} / {billingInfo.subscription.seatsAvailable} Seats
        </Badge>
      </div>

      {/* Seat Usage Overview */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-semibold text-lg">Current Usage</h3>
            <p className="text-gray-500">
              {billingInfo.subscription.seatsUsed} of {billingInfo.subscription.seatsAvailable} seats assigned
            </p>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-500">Available Seats</p>
            <p className="text-2xl font-semibold text-green-600">
              {billingInfo.subscription.seatsAvailable - billingInfo.subscription.seatsUsed}
            </p>
          </div>
        </div>

        <div className="w-full bg-gray-200 rounded-full h-3">
          <div
            className={`h-3 rounded-full transition-all ${
              (billingInfo.subscription.seatsUsed / billingInfo.subscription.seatsAvailable) >= 0.9
                ? 'bg-red-500'
                : (billingInfo.subscription.seatsUsed / billingInfo.subscription.seatsAvailable) >= 0.75
                ? 'bg-orange-500'
                : 'bg-green-500'
            }`}
            style={{
              width: `${(billingInfo.subscription.seatsUsed / billingInfo.subscription.seatsAvailable) * 100}%`,
            }}
          />
        </div>

        {(billingInfo.subscription.seatsAvailable - billingInfo.subscription.seatsUsed) < 5 && (
          <div className="mt-4 p-4 bg-orange-50 border border-orange-200 rounded-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-orange-700">
                <AlertTriangle className="w-5 h-5" />
                <span className="font-medium">
                  Running low on seats ({billingInfo.subscription.seatsAvailable - billingInfo.subscription.seatsUsed} remaining)
                </span>
              </div>
              <Link href="/admin/billing">
                <Button variant="primary" size="sm">
                  Upgrade Plan
                </Button>
              </Link>
            </div>
          </div>
        )}
      </Card>

      {/* Seat Manager */}
      <SeatManager
        seatsAvailable={billingInfo.subscription.seatsAvailable}
        seatsUsed={billingInfo.subscription.seatsUsed}
        users={users}
        onAssignSeat={handleAssignSeat}
        onUnassignSeat={handleUnassignSeat}
      />
    </div>
  );
}
