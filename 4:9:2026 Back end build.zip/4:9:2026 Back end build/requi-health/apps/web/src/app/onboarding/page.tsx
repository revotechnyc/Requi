'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Badge } from '@/components/ui/Badge';
import {
  CheckCircle,
  Users,
  Building2,
  CreditCard,
  ArrowRight,
  ArrowLeft,
  Shield,
  FileText,
  Stethoscope,
  Building,
  GraduationCap,
  Briefcase,
  Loader2,
} from 'lucide-react';

interface OnboardingData {
  // Step 1: Organization
  orgName: string;
  orgType: string;
  orgSize: string;
  // Step 2: Compliance Profile
  programType: string[];
  primaryUseCase: string;
  // Step 3: Plan Selection
  seatCount: number;
  billingEmail: string;
  billingName: string;
  // Step 4: Review
}

const orgTypes = [
  { value: 'HEALTH_SYSTEM', label: 'Health System', icon: Building },
  { value: 'HOSPITAL', label: 'Hospital', icon: Stethoscope },
  { value: 'CLINIC', label: 'Clinic / Practice', icon: Stethoscope },
  { value: 'PAYOR', label: 'Insurance / Payor', icon: Briefcase },
  { value: 'PHARMA', label: 'Pharmaceutical', icon: Building2 },
  { value: 'MED_DEVICE', label: 'Medical Device', icon: Building2 },
  { value: 'ACADEMIC', label: 'Academic / Research', icon: GraduationCap },
  { value: 'OTHER', label: 'Other', icon: Building2 },
];

const programTypes = [
  { value: 'HIPAA', label: 'HIPAA Compliance', description: 'Healthcare data privacy' },
  { value: 'SOC2', label: 'SOC 2', description: 'Security and availability' },
  { value: 'HITRUST', label: 'HITRUST', description: 'Healthcare security framework' },
  { value: 'GDPR', label: 'GDPR', description: 'EU data protection' },
  { value: 'CCPA', label: 'CCPA', description: 'California privacy' },
  { value: 'QUALITY', label: 'Quality Management', description: 'QMS and audits' },
];

const seatTiers = [
  { count: 25, price: 25000, popular: false },
  { count: 50, price: 50000, popular: true },
  { count: 75, price: 75000, popular: false },
  { count: 100, price: 100000, popular: false },
  { count: 150, price: 150000, popular: false },
  { count: 200, price: 200000, popular: false },
  { count: 250, price: 250000, popular: false },
  { count: 500, price: 500000, popular: false },
];

export default function OnboardingPage() {
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [data, setData] = useState<OnboardingData>({
    orgName: '',
    orgType: '',
    orgSize: '',
    programType: [],
    primaryUseCase: '',
    seatCount: 25,
    billingEmail: '',
    billingName: '',
  });

  const totalSteps = 4;

  const updateData = (field: keyof OnboardingData, value: any) => {
    setData((prev) => ({ ...prev, [field]: value }));
  };

  const toggleProgramType = (value: string) => {
    setData((prev) => ({
      ...prev,
      programType: prev.programType.includes(value)
        ? prev.programType.filter((p) => p !== value)
        : [...prev.programType, value],
    }));
  };

  const canProceed = () => {
    switch (currentStep) {
      case 1:
        return data.orgName && data.orgType;
      case 2:
        return data.programType.length > 0;
      case 3:
        return data.seatCount >= 25 && data.billingEmail && data.billingName;
      default:
        return true;
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000));
    setIsSubmitting(false);
    router.push('/workspaces');
  };

  const renderStep1 = () => (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Building2 className="w-8 h-8 text-blue-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900">Tell us about your organization</h2>
        <p className="text-gray-500 mt-2">This helps us customize your compliance experience</p>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Organization Name *
          </label>
          <Input
            placeholder="e.g., Memorial Health System"
            value={data.orgName}
            onChange={(e) => updateData('orgName', e.target.value)}
            className="w-full"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Organization Type *
          </label>
          <div className="grid grid-cols-2 gap-3">
            {orgTypes.map((type) => {
              const Icon = type.icon;
              return (
                <button
                  key={type.value}
                  onClick={() => updateData('orgType', type.value)}
                  className={`flex items-center gap-3 p-4 border-2 rounded-lg text-left transition-all ${
                    data.orgType === type.value
                      ? 'border-blue-600 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <Icon className="w-5 h-5 text-gray-500" />
                  <span className="font-medium">{type.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Organization Size</label>
          <select
            value={data.orgSize}
            onChange={(e) => updateData('orgSize', e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">Select size...</option>
            <option value="1-100">1-100 employees</option>
            <option value="101-500">101-500 employees</option>
            <option value="501-1000">501-1,000 employees</option>
            <option value="1001-5000">1,001-5,000 employees</option>
            <option value="5000+">5,000+ employees</option>
          </select>
        </div>
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Shield className="w-8 h-8 text-green-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900">Your compliance profile</h2>
        <p className="text-gray-500 mt-2">Select the programs you need to maintain</p>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Compliance Programs *
          </label>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {programTypes.map((program) => (
              <button
                key={program.value}
                onClick={() => toggleProgramType(program.value)}
                className={`p-4 border-2 rounded-lg text-left transition-all ${
                  data.programType.includes(program.value)
                    ? 'border-blue-600 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`w-5 h-5 rounded border-2 flex items-center justify-center mt-0.5 ${
                      data.programType.includes(program.value)
                        ? 'bg-blue-600 border-blue-600'
                        : 'border-gray-300'
                    }`}
                  >
                    {data.programType.includes(program.value) && (
                      <CheckCircle className="w-3 h-3 text-white" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium">{program.label}</p>
                    <p className="text-sm text-gray-500">{program.description}</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Primary Use Case
          </label>
          <textarea
            value={data.primaryUseCase}
            onChange={(e) => updateData('primaryUseCase', e.target.value)}
            placeholder="e.g., We need to streamline our HIPAA compliance audits and policy management..."
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 min-h-[100px]"
          />
        </div>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <CreditCard className="w-8 h-8 text-purple-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900">Choose your plan</h2>
        <p className="text-gray-500 mt-2">
          Start with a 30-day free trial. No credit card required.
        </p>
      </div>

      <div className="space-y-6">
        {/* Seat Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Number of Users *
          </label>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {seatTiers.map((tier) => (
              <button
                key={tier.count}
                onClick={() => updateData('seatCount', tier.count)}
                className={`relative p-4 border-2 rounded-lg text-center transition-all ${
                  data.seatCount === tier.count
                    ? 'border-blue-600 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                {tier.popular && (
                  <Badge variant="blue" className="absolute -top-2 left-1/2 -translate-x-1/2 text-xs">
                    Popular
                  </Badge>
                )}
                <p className="font-semibold text-lg">{tier.count}</p>
                <p className="text-sm text-gray-500">users</p>
                <p className="text-sm font-medium mt-1">${tier.price.toLocaleString()}/mo</p>
              </button>
            ))}
          </div>
          <p className="text-sm text-gray-500 mt-2">$1,000 per user per month. Minimum 25 users.</p>
        </div>

        {/* Billing Contact */}
        <div className="border-t pt-6">
          <h3 className="font-medium mb-4 flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Billing Contact
          </h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Billing Contact Name *
              </label>
              <Input
                placeholder="e.g., Jane Smith"
                value={data.billingName}
                onChange={(e) => updateData('billingName', e.target.value)}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Billing Email *
              </label>
              <Input
                type="email"
                placeholder="billing@company.com"
                value={data.billingEmail}
                onChange={(e) => updateData('billingEmail', e.target.value)}
              />
            </div>
          </div>
        </div>

        {/* Trial Info */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <p className="font-medium text-blue-900">30-day free trial</p>
              <p className="text-sm text-blue-700">
                You'll have full access to all features. No credit card required until your trial
                ends.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderStep4 = () => (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <CheckCircle className="w-8 h-8 text-green-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900">Review and start trial</h2>
        <p className="text-gray-500 mt-2">Confirm your details before starting your trial</p>
      </div>

      <div className="space-y-4">
        <Card className="p-4">
          <h3 className="font-medium mb-3 flex items-center gap-2">
            <Building2 className="w-4 h-4" />
            Organization
          </h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-500">Name</span>
              <span>{data.orgName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Type</span>
              <span>{orgTypes.find((t) => t.value === data.orgType)?.label}</span>
            </div>
            {data.orgSize && (
              <div className="flex justify-between">
                <span className="text-gray-500">Size</span>
                <span>{data.orgSize} employees</span>
              </div>
            )}
          </div>
        </Card>

        <Card className="p-4">
          <h3 className="font-medium mb-3 flex items-center gap-2">
            <Shield className="w-4 h-4" />
            Compliance Programs
          </h3>
          <div className="flex flex-wrap gap-2">
            {data.programType.map((program) => (
              <Badge key={program} variant="blue">
                {programTypes.find((p) => p.value === program)?.label}
              </Badge>
            ))}
          </div>
        </Card>

        <Card className="p-4">
          <h3 className="font-medium mb-3 flex items-center gap-2">
            <Users className="w-4 h-4" />
            Subscription
          </h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-500">Plan</span>
              <span>{data.seatCount} users</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Monthly cost</span>
              <span className="font-medium">
                ${(data.seatCount * 1000).toLocaleString()}/month
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Billing contact</span>
              <span>{data.billingName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Billing email</span>
              <span>{data.billingEmail}</span>
            </div>
          </div>
        </Card>

        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
            <div>
              <p className="font-medium text-green-900">Your 30-day trial starts immediately</p>
              <p className="text-sm text-green-700">
                You'll receive an email confirmation with your trial details. No charges until you
                choose to upgrade.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Logo */}
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold text-blue-600">Requi Health</h1>
          <p className="text-gray-500">Enterprise Healthcare Compliance</p>
        </div>

        {/* Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            {Array.from({ length: totalSteps }).map((_, i) => (
              <div
                key={i}
                className={`flex items-center ${i < totalSteps - 1 ? 'flex-1' : ''}`}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    i + 1 < currentStep
                      ? 'bg-green-600 text-white'
                      : i + 1 === currentStep
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-200 text-gray-500'
                  }`}
                >
                  {i + 1 < currentStep ? <CheckCircle className="w-5 h-5" /> : i + 1}
                </div>
                {i < totalSteps - 1 && (
                  <div
                    className={`flex-1 h-1 mx-2 ${
                      i + 1 < currentStep ? 'bg-green-600' : 'bg-gray-200'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between text-sm text-gray-500">
            <span>Organization</span>
            <span>Compliance</span>
            <span>Plan</span>
            <span>Review</span>
          </div>
        </div>

        {/* Content */}
        <Card className="p-8">
          {currentStep === 1 && renderStep1()}
          {currentStep === 2 && renderStep2()}
          {currentStep === 3 && renderStep3()}
          {currentStep === 4 && renderStep4()}

          {/* Navigation */}
          <div className="flex justify-between mt-8 pt-6 border-t">
            <Button
              variant="outline"
              onClick={() => setCurrentStep((s) => Math.max(1, s - 1))}
              disabled={currentStep === 1}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>

            {currentStep < totalSteps ? (
              <Button
                variant="primary"
                onClick={() => setCurrentStep((s) => Math.min(totalSteps, s + 1))}
                disabled={!canProceed()}
              >
                Continue
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            ) : (
              <Button
                variant="primary"
                onClick={handleSubmit}
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Starting Trial...
                  </>
                ) : (
                  <>
                    Start Free Trial
                    <CheckCircle className="w-4 h-4 ml-2" />
                  </>
                )}
              </Button>
            )}
          </div>
        </Card>

        {/* Footer */}
        <p className="text-center text-sm text-gray-500 mt-6">
          Questions? Contact us at{' '}
          <a href="mailto:sales@requi.health" className="text-blue-600 hover:underline">
            sales@requi.health
          </a>
        </p>
      </div>
    </div>
  );
}
