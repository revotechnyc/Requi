'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Sparkles,
  LayoutDashboard,
  CheckSquare,
  Shield,
  FileText,
  ClipboardCheck,
  GraduationCap,
  BarChart3,
  Settings,
  Users,
  CreditCard,
  ChevronLeft,
  ChevronRight,
  Building2,
} from 'lucide-react';
import { Badge } from '@/components/ui/Badge';
import { useState } from 'react';

interface NavItem {
  name: string;
  href: string;
  icon: React.ElementType;
  badge?: string;
  isDefault?: boolean;
}

// Navigation items in new Intelligence-First order
const NAVIGATION_ITEMS: NavItem[] = [
  { name: 'Intelligence', href: '/intelligence', icon: Sparkles, isDefault: true },
  { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { name: 'Tasks', href: '/tasks', icon: CheckSquare, badge: '8' },
  { name: 'Compliance', href: '/compliance', icon: Shield },
  { name: 'Documents', href: '/documents', icon: FileText },
  { name: 'Audits', href: '/audits', icon: ClipboardCheck },
  { name: 'Training', href: '/training', icon: GraduationCap },
  { name: 'Reports', href: '/reports', icon: BarChart3 },
];

const SETTINGS_ITEMS: NavItem[] = [
  { name: 'Organization', href: '/settings/organization', icon: Building2 },
  { name: 'Members', href: '/members', icon: Users },
  { name: 'Billing', href: '/billing', icon: CreditCard },
  { name: 'Settings', href: '/settings', icon: Settings },
];

interface SidebarProps {
  isCollapsed?: boolean;
  onToggle?: () => void;
}

export function Sidebar({ isCollapsed = false, onToggle }: SidebarProps) {
  const pathname = usePathname();

  const isActive = (href: string) => {
    if (href === '/intelligence') {
      return pathname === href;
    }
    return pathname === href || pathname.startsWith(`${href}/`);
  };

  return (
    <aside
      className={`bg-white border-r border-slate-200 flex flex-col h-screen sticky top-0 transition-all duration-300 ${
        isCollapsed ? 'w-16' : 'w-64'
      }`}
    >
      {/* Logo */}
      <div className="h-16 flex items-center px-4 border-b border-slate-200">
        <Link href="/intelligence" className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center flex-shrink-0">
            <Shield className="w-4 h-4 text-white" />
          </div>
          {!isCollapsed && (
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-900">Requi</span>
              <Badge variant="blue" className="text-[10px]">v2.0</Badge>
            </div>
          )}
        </Link>
      </div>

      {/* Main Navigation */}
      <nav className="flex-1 overflow-y-auto py-4 px-2">
        {!isCollapsed && (
          <p className="px-3 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
            Main
          </p>
        )}
        <ul className="space-y-1">
          {NAVIGATION_ITEMS.map((item) => (
            <li key={item.name}>
              <Link
                href={item.href}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  isActive(item.href)
                    ? 'bg-blue-50 text-blue-700'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
                title={isCollapsed ? item.name : undefined}
              >
                <item.icon
                  className={`w-5 h-5 flex-shrink-0 ${
                    isActive(item.href) ? 'text-blue-600' : 'text-slate-400'
                  }`}
                />
                {!isCollapsed && (
                  <>
                    <span className="flex-1">{item.name}</span>
                    {item.isDefault && (
                      <Sparkles className="w-3 h-3 text-amber-500" />
                    )}
                    {item.badge && (
                      <Badge variant="red" className="text-[10px] px-1.5 py-0">
                        {item.badge}
                      </Badge>
                    )}
                  </>
                )}
              </Link>
            </li>
          ))}
        </ul>

        {/* Settings Section */}
        {!isCollapsed && (
          <p className="px-3 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 mt-6">
            Administration
          </p>
        )}
        <ul className="space-y-1 mt-2">
          {SETTINGS_ITEMS.map((item) => (
            <li key={item.name}>
              <Link
                href={item.href}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  isActive(item.href)
                    ? 'bg-blue-50 text-blue-700'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
                title={isCollapsed ? item.name : undefined}
              >
                <item.icon
                  className={`w-5 h-5 flex-shrink-0 ${
                    isActive(item.href) ? 'text-blue-600' : 'text-slate-400'
                  }`}
                />
                {!isCollapsed && <span>{item.name}</span>}
              </Link>
            </li>
          ))}
        </ul>
      </nav>

      {/* Collapse Toggle */}
      <div className="p-2 border-t border-slate-200">
        <button
          onClick={onToggle}
          className="w-full flex items-center justify-center p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
        >
          {isCollapsed ? (
            <ChevronRight className="w-5 h-5" />
          ) : (
            <ChevronLeft className="w-5 h-5" />
          )}
        </button>
      </div>
    </aside>
  );
}
