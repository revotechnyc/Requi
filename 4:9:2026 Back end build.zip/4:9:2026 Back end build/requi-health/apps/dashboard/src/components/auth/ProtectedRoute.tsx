'use client';

import { useEffect, useState } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { Loader2 } from 'lucide-react';

// Route configuration - Intelligence is now the default landing page
export const ROUTES = {
  LOGIN: '/login',
  INTELLIGENCE: '/intelligence',
  DASHBOARD: '/dashboard',
  TASKS: '/tasks',
  COMPLIANCE: '/compliance',
  DOCUMENTS: '/documents',
  AUDITS: '/audits',
  TRAINING: '/training',
  REPORTS: '/reports',
  SETTINGS: '/settings',
  BILLING: '/billing',
  MEMBERS: '/members',
  ONBOARDING: '/onboarding',
} as const;

export const DEFAULT_AUTH_ROUTE = ROUTES.INTELLIGENCE;

// Navigation items in new order (Intelligence first)
export const NAVIGATION_ITEMS = [
  { name: 'Intelligence', href: ROUTES.INTELLIGENCE, icon: 'Sparkles', isDefault: true },
  { name: 'Dashboard', href: ROUTES.DASHBOARD, icon: 'LayoutDashboard' },
  { name: 'Tasks', href: ROUTES.TASKS, icon: 'CheckSquare' },
  { name: 'Compliance', href: ROUTES.COMPLIANCE, icon: 'Shield' },
  { name: 'Documents', href: ROUTES.DOCUMENTS, icon: 'FileText' },
  { name: 'Audits', href: ROUTES.AUDITS, icon: 'ClipboardCheck' },
  { name: 'Training', href: ROUTES.TRAINING, icon: 'GraduationCap' },
  { name: 'Reports', href: ROUTES.REPORTS, icon: 'BarChart3' },
];

interface ProtectedRouteProps {
  children: React.ReactNode;
}

export function ProtectedRoute({ children }: ProtectedRouteProps) {
  const router = useRouter();
  const pathname = usePathname();
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  useEffect(() => {
    // Check authentication status
    const token = localStorage.getItem('token');
    const isAuth = !!token;
    
    setIsAuthenticated(isAuth);

    if (!isAuth) {
      // Not authenticated - redirect to login
      router.push(ROUTES.LOGIN);
    } else if (pathname === '/' || pathname === ROUTES.LOGIN) {
      // Just logged in or at root → Intelligence (NEW DEFAULT)
      router.push(DEFAULT_AUTH_ROUTE);
    }
  }, [router, pathname]);

  // Show loading state while checking auth
  if (isAuthenticated === null) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
          <p className="text-slate-500">Loading...</p>
        </div>
      </div>
    );
  }

  // Not authenticated - don't render children (will redirect)
  if (!isAuthenticated) {
    return null;
  }

  // Authenticated - render children
  return <>{children}</>;
}

// Hook to check if user is authenticated
export function useAuth() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('user');
    
    setIsAuthenticated(!!token);
    if (userData) {
      setUser(JSON.parse(userData));
    }
  }, []);

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = ROUTES.LOGIN;
  };

  return { isAuthenticated, user, logout };
}
