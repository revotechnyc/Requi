// Route configuration for Requi Health Dashboard
// REVISION: Intelligence is now the default landing page

export const ROUTES = {
  // Public routes
  LOGIN: '/login',
  ONBOARDING: '/onboarding',
  AUTH_CALLBACK: '/auth/callback',
  
  // Authenticated routes — NEW ORDER: Intelligence first
  INTELLIGENCE: '/intelligence',
  INTELLIGENCE_CONVERSATION: (id: string) => `/intelligence/conversations/${id}`,
  DASHBOARD: '/dashboard', // Was default, now secondary
  TASKS: '/tasks',
  TASK_DETAIL: (id: string) => `/tasks/${id}`,
  COMPLIANCE: '/compliance',
  COMPLIANCE_GAPS: '/compliance/gaps',
  CALENDAR: '/calendar',
  DOCUMENTS: '/documents',
  NEWS: '/news',
  INTEGRATIONS: '/integrations',
  SETTINGS: '/settings',
  BILLING: '/billing',
  
  // Admin routes
  ADMIN: '/admin',
} as const;

// REVISION: Default authenticated route is now Intelligence
export const DEFAULT_AUTH_ROUTE = ROUTES.INTELLIGENCE;

// Navigation items in order of appearance
export const NAVIGATION_ITEMS = [
  {
    name: 'Intelligence',
    href: ROUTES.INTELLIGENCE,
    icon: 'Sparkles',
    isDefault: true,
    description: 'AI workspace — your compliance assistant',
  },
  {
    name: 'Dashboard',
    href: ROUTES.DASHBOARD,
    icon: 'LayoutDashboard',
    description: 'Progress overview and scores',
  },
  {
    name: 'Tasks',
    href: ROUTES.TASKS,
    icon: 'CheckSquare',
    badge: 'tasksCount',
    description: 'Task execution and reminders',
  },
  {
    name: 'Compliance',
    href: ROUTES.COMPLIANCE,
    icon: 'Shield',
    badge: 'gapsCount',
    description: 'Gap analysis and requirements',
  },
  {
    name: 'Calendar',
    href: ROUTES.CALENDAR,
    icon: 'Calendar',
    description: 'Deadlines and scheduling',
  },
  {
    name: 'Documents',
    href: ROUTES.DOCUMENTS,
    icon: 'FileText',
    description: 'Evidence and policies',
  },
  {
    name: 'News',
    href: ROUTES.NEWS,
    icon: 'Newspaper',
    badge: 'unreadNews',
    description: 'Regulatory updates',
  },
  {
    name: 'Integrations',
    href: ROUTES.INTEGRATIONS,
    icon: 'Plug',
    description: 'Connected applications',
  },
  {
    name: 'Settings',
    href: ROUTES.SETTINGS,
    icon: 'Settings',
    description: 'Profile and organization settings',
  },
] as const;

// Route metadata for breadcrumbs
export const ROUTE_METADATA: Record<string, { title: string; parent?: string }> = {
  [ROUTES.INTELLIGENCE]: { title: 'Intelligence' },
  [ROUTES.DASHBOARD]: { title: 'Dashboard' },
  [ROUTES.TASKS]: { title: 'Tasks' },
  [ROUTES.COMPLIANCE]: { title: 'Compliance' },
  [ROUTES.CALENDAR]: { title: 'Calendar' },
  [ROUTES.DOCUMENTS]: { title: 'Documents' },
  [ROUTES.NEWS]: { title: 'News' },
  [ROUTES.INTEGRATIONS]: { title: 'Integrations' },
  [ROUTES.SETTINGS]: { title: 'Settings' },
  [ROUTES.BILLING]: { title: 'Billing', parent: ROUTES.SETTINGS },
};

// Check if route requires authentication
export function requiresAuth(pathname: string): boolean {
  const publicRoutes = [ROUTES.LOGIN, ROUTES.ONBOARDING, ROUTES.AUTH_CALLBACK];
  return !publicRoutes.some(route => pathname.startsWith(route));
}

// Get redirect path after login
export function getPostLoginRedirect(userRole?: string): string {
  // All users (including admins with user roles) land on Intelligence first
  // Platform admins can navigate to admin section from there
  return DEFAULT_AUTH_ROUTE;
}
