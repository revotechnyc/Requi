'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Badge } from '@/components/ui/Badge';
import { 
  Shield, 
  Mail, 
  Lock, 
  Eye, 
  EyeOff, 
  ArrowRight,
  Building2,
  CheckCircle2
} from 'lucide-react';
import toast from 'react-hot-toast';

// Demo credentials for testing
const DEMO_CREDENTIALS = {
  admin: {
    email: 'demo.admin@acme-health.com',
    password: 'DemoPass123!',
    role: 'Admin',
    name: 'Sarah Chen'
  },
  user: {
    email: 'demo.user@acme-health.com',
    password: 'DemoPass123!',
    role: 'User',
    name: 'Michael Torres'
  }
};

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedDemo, setSelectedDemo] = useState<'admin' | 'user' | null>(null);

  const fillDemoCredentials = (type: 'admin' | 'user') => {
    const creds = DEMO_CREDENTIALS[type];
    setEmail(creds.email);
    setPassword(creds.password);
    setSelectedDemo(type);
    toast.success(`Demo ${type} credentials filled!`);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Store mock token
    localStorage.setItem('token', 'demo_token_' + Date.now());
    localStorage.setItem('user', JSON.stringify({
      email,
      name: selectedDemo ? DEMO_CREDENTIALS[selectedDemo].name : 'Demo User',
      role: selectedDemo ? DEMO_CREDENTIALS[selectedDemo].role : 'User',
      organization: 'Acme Health System'
    }));

    toast.success('Welcome to Requi Health!');
    router.push('/intelligence');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-white rounded-2xl shadow-lg mb-4">
            <Shield className="w-8 h-8 text-blue-600" />
          </div>
          <div className="flex items-center justify-center gap-2">
            <h1 className="text-2xl font-bold text-slate-900">Requi Health</h1>
            <Badge variant="blue" className="text-xs">v2.0</Badge>
          </div>
          <p className="text-slate-500 mt-1">Enterprise Compliance Platform</p>
        </div>

        {/* Demo Credentials Banner */}
        <Card className="mb-6 border-blue-200 bg-blue-50/50">
          <div className="p-4">
            <div className="flex items-center gap-2 mb-3">
              <CheckCircle2 className="w-5 h-5 text-blue-600" />
              <h3 className="font-semibold text-blue-900">Demo Credentials</h3>
            </div>
            <p className="text-sm text-blue-700 mb-3">
              Click below to auto-fill demo credentials:
            </p>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => fillDemoCredentials('admin')}
                className={`p-3 rounded-lg border-2 text-left transition-all ${
                  selectedDemo === 'admin'
                    ? 'border-blue-600 bg-blue-100'
                    : 'border-blue-200 bg-white hover:border-blue-300'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Building2 className="w-4 h-4 text-blue-600" />
                  <span className="font-medium text-sm">Admin User</span>
                </div>
                <p className="text-xs text-slate-500">Full dashboard access</p>
              </button>
              <button
                onClick={() => fillDemoCredentials('user')}
                className={`p-3 rounded-lg border-2 text-left transition-all ${
                  selectedDemo === 'user'
                    ? 'border-blue-600 bg-blue-100'
                    : 'border-blue-200 bg-white hover:border-blue-300'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Shield className="w-4 h-4 text-blue-600" />
                  <span className="font-medium text-sm">Standard User</span>
                </div>
                <p className="text-xs text-slate-500">Limited access</p>
              </button>
            </div>
          </div>
        </Card>

        {/* Login Form */}
        <Card className="shadow-xl">
          <div className="p-6">
            <h2 className="text-xl font-semibold text-slate-900 mb-1">Welcome back</h2>
            <p className="text-slate-500 text-sm mb-6">Sign in to your organization</p>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Email */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <Input
                    type="email"
                    placeholder="you@company.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10"
                    required
                  />
                </div>
              </div>

              {/* Password */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <Input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 pr-10"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {/* Remember & Forgot */}
              <div className="flex items-center justify-between text-sm">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" className="rounded border-slate-300" />
                  <span className="text-slate-600">Remember me</span>
                </label>
                <Link href="/forgot-password" className="text-blue-600 hover:underline">
                  Forgot password?
                </Link>
              </div>

              {/* Submit */}
              <Button
                type="submit"
                variant="primary"
                className="w-full"
                disabled={isLoading || !email || !password}
              >
                {isLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                    Signing in...
                  </>
                ) : (
                  <>
                    Sign In
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </>
                )}
              </Button>
            </form>

            {/* Divider */}
            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-200" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-slate-500">Or continue with</span>
              </div>
            </div>

            {/* SSO Buttons */}
            <div className="grid grid-cols-2 gap-3">
              <button className="flex items-center justify-center gap-2 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors">
                <svg className="w-5 h-5" viewBox="0 0 21 21">
                  <path fill="#f25022" d="M1 1h9v9H1z" />
                  <path fill="#00a4ef" d="M1 11h9v9H1z" />
                  <path fill="#7fba00" d="M11 1h9v9h-9z" />
                  <path fill="#ffb900" d="M11 11h9v9h-9z" />
                </svg>
                <span className="text-sm font-medium text-slate-700">Microsoft</span>
              </button>
              <button className="flex items-center justify-center gap-2 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors">
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                </svg>
                <span className="text-sm font-medium text-slate-700">Google</span>
              </button>
            </div>
          </div>
        </Card>

        {/* Footer */}
        <p className="text-center text-sm text-slate-500 mt-6">
          Don't have an account?{' '}
          <Link href="/onboarding" className="text-blue-600 hover:underline font-medium">
            Start free trial
          </Link>
        </p>

        {/* Demo Info */}
        <div className="mt-8 p-4 bg-slate-100 rounded-lg">
          <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
            Demo Account Details
          </h4>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-500">Organization:</span>
              <span className="text-slate-700 font-medium">Acme Health System</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Plan:</span>
              <Badge variant="blue">Enterprise Trial</Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Trial Ends:</span>
              <span className="text-slate-700">18 days</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Seats:</span>
              <span className="text-slate-700">12 / 25 used</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
