'use client';

import { useState, useRef, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { 
  Sparkles, 
  Send, 
  Mic, 
  Paperclip, 
  Clock, 
  CheckSquare, 
  AlertTriangle,
  FileText,
  ChevronRight,
  Plus,
  MoreHorizontal,
  Star,
  Zap,
  Shield,
  TrendingUp,
  Calendar,
  MessageSquare,
  Loader2,
  Bot,
  User,
  Copy,
  ThumbsUp,
  ThumbsDown,
  Lightbulb
} from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import toast from 'react-hot-toast';

// Types
interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  actions?: QuickAction[];
}

interface QuickAction {
  id: string;
  label: string;
  icon: string;
  onClick: () => void;
}

interface SuggestedPrompt {
  id: string;
  category: string;
  text: string;
  icon: React.ReactNode;
}

interface RecentConversation {
  id: string;
  title: string;
  timestamp: string;
  unread?: boolean;
}

interface RecommendedAction {
  id: string;
  title: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
  type: 'task' | 'gap' | 'reminder';
  dueDate?: string;
}

// Mock data - suggested prompts
const SUGGESTED_PROMPTS: SuggestedPrompt[] = [
  {
    id: '1',
    category: 'Compliance',
    text: 'What policies need updating this quarter?',
    icon: <Shield className="w-4 h-4" />,
  },
  {
    id: '2',
    category: 'Risk',
    text: 'Show me my highest risk areas',
    icon: <AlertTriangle className="w-4 h-4" />,
  },
  {
    id: '3',
    category: 'Tasks',
    text: 'What tasks are due this week?',
    icon: <CheckSquare className="w-4 h-4" />,
  },
  {
    id: '4',
    category: 'Documents',
    text: 'Find my HIPAA compliance documents',
    icon: <FileText className="w-4 h-4" />,
  },
  {
    id: '5',
    category: 'Audit',
    text: 'Prepare me for the upcoming audit',
    icon: <TrendingUp className="w-4 h-4" />,
  },
  {
    id: '6',
    category: 'Insights',
    text: 'Compare my compliance score to last month',
    icon: <Sparkles className="w-4 h-4" />,
  },
];

// Mock data - recent conversations
const RECENT_CONVERSATIONS: RecentConversation[] = [
  { id: '1', title: 'HIPAA policy review questions', timestamp: '2 hours ago' },
  { id: '2', title: 'Risk assessment for Q4', timestamp: 'Yesterday', unread: true },
  { id: '3', title: 'Training compliance check', timestamp: '3 days ago' },
  { id: '4', title: 'Document audit preparation', timestamp: '1 week ago' },
];

// Mock data - recommended actions
const RECOMMENDED_ACTIONS: RecommendedAction[] = [
  {
    id: '1',
    title: 'Review Updated HIPAA Guidelines',
    description: 'New federal guidelines released - 3 policies need updates',
    priority: 'high',
    type: 'task',
    dueDate: '2 days',
  },
  {
    id: '2',
    title: 'Complete Staff Training Module',
    description: '12 employees overdue for cybersecurity training',
    priority: 'high',
    type: 'gap',
    dueDate: '5 days',
  },
  {
    id: '3',
    title: 'Quarterly Compliance Report',
    description: 'Auto-generated report ready for review',
    priority: 'medium',
    type: 'reminder',
    dueDate: '1 week',
  },
];

// Mock welcome message from AI
const WELCOME_MESSAGE: Message = {
  id: 'welcome',
  role: 'assistant',
  content: `Hello! I'm your Requi Intelligence Assistant. I can help you with:

• **Compliance Monitoring** - Track scores, identify gaps, and get recommendations
• **Task Management** - View priorities, deadlines, and automate workflows  
• **Document Analysis** - Search policies, extract insights, and ensure alignment
• **Risk Assessment** - Monitor risk scores and receive early warnings
• **Audit Preparation** - Get ready with automated checklists and evidence collection

What would you like to work on today?`,
  timestamp: new Date(),
};

export default function IntelligencePage() {
  return (
    <ProtectedRoute>
      <IntelligenceContent />
    </ProtectedRoute>
  );
}

function IntelligenceContent() {
  const router = useRouter();
  const [messages, setMessages] = useState<Message[]>([WELCOME_MESSAGE]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Handle sending a message
  const handleSendMessage = async (text: string = inputValue) => {
    if (!text.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: text,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    // Simulate AI response
    await new Promise((resolve) => setTimeout(resolve, 1500));

    const aiResponse = generateAIResponse(text);
    setMessages((prev) => [...prev, aiResponse]);
    setIsLoading(false);
  };

  // Generate mock AI response based on user input
  const generateAIResponse = (userInput: string): Message => {
    const lowerInput = userInput.toLowerCase();
    
    if (lowerInput.includes('policy') || lowerInput.includes('hipaa')) {
      return {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: `Based on your current compliance status, here are the policies that need attention:

**🔴 High Priority (Due within 7 days):**
• HIPAA Privacy Policy - Last updated 18 months ago
• Data Breach Response Plan - Requires annual review
• Business Associate Agreements - 3 agreements expiring soon

**🟡 Medium Priority:**
• Security Risk Assessment - Quarterly review due
• Employee Training Policy - Version 2.1 needs approval

Would you like me to generate updated policy drafts or create tasks for the team?`,
        timestamp: new Date(),
      };
    }

    if (lowerInput.includes('risk') || lowerInput.includes('score')) {
      return {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: `Here's your current risk profile:

**Overall Risk Score: 72/100** (Moderate)

**Top Risk Areas:**
1. **Data Security** - Score: 58/100 ⚠️
   - 12 employees without current security training
   - 2 systems missing MFA

2. **Documentation** - Score: 71/100
   - 5 policies need updates
   - 3 missing required documents

3. **Audit Readiness** - Score: 82/100 ✅
   - Evidence collection on track
   - Last audit: 8 months ago

I've identified 3 high-priority actions to reduce your risk exposure.`,
        timestamp: new Date(),
      };
    }

    if (lowerInput.includes('task') || lowerInput.includes('due')) {
      return {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: `You have **8 tasks** due this week:

**🔴 Overdue (2):**
• Review vendor security assessment (2 days overdue)
• Update incident response contact list (1 day overdue)

**📅 Due Today (1):**
• Submit quarterly compliance report

**📅 Due This Week (5):**
• Complete staff training audit
• Review 3 business associate agreements
• Update privacy notice
• Schedule risk assessment meeting
• Archive old patient records

Would you like me to prioritize these or delegate any to team members?`,
        timestamp: new Date(),
      };
    }

    // Default response
    return {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: `I understand you're asking about "${userInput}". Let me analyze your organization's data to provide a relevant response.

Based on your current compliance profile:
• **Compliance Score:** 87/100
• **Active Tasks:** 23
• **Upcoming Deadlines:** 8 this week
• **Recent Updates:** 3 new regulations affecting your policies

Could you provide more specific details about what you'd like to know? For example:
- Are you looking for a specific document or policy?
- Do you need help with a particular compliance area?
- Would you like me to generate a report?`,
      timestamp: new Date(),
    };
  };

  // Handle quick action click
  const handleQuickAction = (action: string) => {
    switch (action) {
      case 'tasks':
        router.push('/tasks');
        break;
      case 'documents':
        router.push('/documents');
        break;
      case 'compliance':
        router.push('/compliance');
        break;
      case 'reports':
        router.push('/reports');
        break;
      default:
        toast.info('Feature coming soon!');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-900">Intelligence</h1>
                <p className="text-sm text-slate-500">AI-Powered Compliance Assistant</p>
              </div>
            </div>
            <Badge variant="purple" className="ml-4">
              <Zap className="w-3 h-3 mr-1" />
              AI Ready
            </Badge>
          </div>
          
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => router.push('/dashboard')}>
              <TrendingUp className="w-4 h-4 mr-2" />
              Dashboard
            </Button>
            <Button variant="primary" size="sm">
              <Plus className="w-4 h-4 mr-2" />
              New Chat
            </Button>
          </div>
        </div>
      </header>

      <div className="flex h-[calc(100vh-73px)]">
        {/* Sidebar */}
        <aside className="w-72 bg-white border-r border-slate-200 flex flex-col">
          {/* New Chat Button */}
          <div className="p-4">
            <Button variant="outline" className="w-full justify-start">
              <Plus className="w-4 h-4 mr-2" />
              Start New Conversation
            </Button>
          </div>

          {/* Recent Conversations */}
          <div className="flex-1 overflow-auto px-4">
            <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">
              Recent Conversations
            </h3>
            <div className="space-y-1">
              {RECENT_CONVERSATIONS.map((conv) => (
                <button
                  key={conv.id}
                  className="w-full text-left p-3 rounded-lg hover:bg-slate-100 transition-colors group"
                >
                  <div className="flex items-start gap-3">
                    <MessageSquare className="w-4 h-4 text-slate-400 mt-0.5 group-hover:text-blue-600" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-slate-700 truncate">
                        {conv.title}
                      </p>
                      <p className="text-xs text-slate-500 mt-0.5">{conv.timestamp}</p>
                    </div>
                    {conv.unread && (
                      <div className="w-2 h-2 bg-blue-600 rounded-full mt-1.5" />
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Quick Stats */}
          <div className="p-4 border-t border-slate-200">
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-slate-50 rounded-lg p-3">
                <p className="text-2xl font-bold text-slate-900">87</p>
                <p className="text-xs text-slate-500">Compliance Score</p>
              </div>
              <div className="bg-slate-50 rounded-lg p-3">
                <p className="text-2xl font-bold text-slate-900">23</p>
                <p className="text-xs text-slate-500">Active Tasks</p>
              </div>
            </div>
          </div>
        </aside>

        {/* Main Chat Area */}
        <main className="flex-1 flex flex-col bg-slate-50">
          {/* Messages */}
          <div className="flex-1 overflow-auto p-6">
            <div className="max-w-4xl mx-auto space-y-6">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex gap-4 ${
                    message.role === 'user' ? 'flex-row-reverse' : ''
                  }`}
                >
                  {/* Avatar */}
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                      message.role === 'assistant'
                        ? 'bg-gradient-to-br from-blue-600 to-indigo-600'
                        : 'bg-slate-200'
                    }`}
                  >
                    {message.role === 'assistant' ? (
                      <Bot className="w-5 h-5 text-white" />
                    ) : (
                      <User className="w-5 h-5 text-slate-600" />
                    )}
                  </div>

                  {/* Message Content */}
                  <div
                    className={`max-w-[80%] ${
                      message.role === 'user' ? 'items-end' : 'items-start'
                    }`}
                  >
                    <div
                      className={`rounded-2xl px-5 py-4 ${
                        message.role === 'assistant'
                          ? 'bg-white border border-slate-200 shadow-sm'
                          : 'bg-blue-600 text-white'
                      }`}
                    >
                      <div
                        className={`prose prose-sm max-w-none ${
                          message.role === 'user' ? 'prose-invert' : ''
                        }`}
                        dangerouslySetInnerHTML={{
                          __html: message.content.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>'),
                        }}
                      />
                    </div>

                    {/* Message Actions */}
                    {message.role === 'assistant' && (
                      <div className="flex items-center gap-2 mt-2">
                        <button className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded">
                          <Copy className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 text-slate-400 hover:text-green-600 hover:bg-green-50 rounded">
                          <ThumbsUp className="w-4 h-4" />
                        </button>
                        <button className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded">
                          <ThumbsDown className="w-4 h-4" />
                        </button>
                        <span className="text-xs text-slate-400 ml-2">
                          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              ))}

              {/* Loading Indicator */}
              {isLoading && (
                <div className="flex gap-4">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center">
                    <Bot className="w-5 h-5 text-white" />
                  </div>
                  <div className="bg-white border border-slate-200 rounded-2xl px-5 py-4 shadow-sm">
                    <div className="flex items-center gap-2">
                      <Loader2 className="w-4 h-4 text-blue-600 animate-spin" />
                      <span className="text-sm text-slate-500">Thinking...</span>
                    </div>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>
          </div>

          {/* Input Area */}
          <div className="p-6 border-t border-slate-200 bg-white">
            <div className="max-w-4xl mx-auto">
              {/* Suggested Prompts */}
              {messages.length <= 2 && (
                <div className="mb-4">
                  <p className="text-sm text-slate-500 mb-3 flex items-center gap-2">
                    <Lightbulb className="w-4 h-4" />
                    Try asking:
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {SUGGESTED_PROMPTS.map((prompt) => (
                      <button
                        key={prompt.id}
                        onClick={() => handleSendMessage(prompt.text)}
                        className="flex items-center gap-2 px-3 py-2 bg-slate-100 hover:bg-slate-200 rounded-lg text-sm text-slate-700 transition-colors"
                      >
                        {prompt.icon}
                        <span>{prompt.text}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Input */}
              <div className="relative">
                <div className="flex items-center gap-3 bg-slate-100 rounded-2xl px-4 py-3">
                  <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-200 rounded-lg transition-colors">
                    <Paperclip className="w-5 h-5" />
                  </button>
                  <input
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder="Ask me anything about compliance, tasks, documents..."
                    className="flex-1 bg-transparent outline-none text-slate-900 placeholder:text-slate-500"
                  />
                  <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-200 rounded-lg transition-colors">
                    <Mic className="w-5 h-5" />
                  </button>
                  <Button
                    variant="primary"
                    size="sm"
                    onClick={() => handleSendMessage()}
                    disabled={!inputValue.trim() || isLoading}
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-xs text-slate-400 text-center mt-2">
                  Requi Intelligence may produce inaccurate information. Verify important decisions.
                </p>
              </div>
            </div>
          </div>
        </main>

        {/* Right Panel - Recommended Actions */}
        <aside className="w-80 bg-white border-l border-slate-200 overflow-auto">
          <div className="p-5">
            <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-500" />
              Recommended Actions
            </h3>

            <div className="space-y-3">
              {RECOMMENDED_ACTIONS.map((action) => (
                <Card
                  key={action.id}
                  className="p-4 hover:shadow-md transition-shadow cursor-pointer border-l-4"
                  style={{
                    borderLeftColor:
                      action.priority === 'high'
                        ? '#ef4444'
                        : action.priority === 'medium'
                        ? '#f59e0b'
                        : '#22c55e',
                  }}
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                        action.type === 'task'
                          ? 'bg-blue-100 text-blue-600'
                          : action.type === 'gap'
                          ? 'bg-red-100 text-red-600'
                          : 'bg-amber-100 text-amber-600'
                      }`}
                    >
                      {action.type === 'task' ? (
                        <CheckSquare className="w-4 h-4" />
                      ) : action.type === 'gap' ? (
                        <AlertTriangle className="w-4 h-4" />
                      ) : (
                        <Clock className="w-4 h-4" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-slate-900 text-sm">{action.title}</h4>
                      <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                        {action.description}
                      </p>
                      {action.dueDate && (
                        <div className="flex items-center gap-1 mt-2">
                          <Calendar className="w-3 h-3 text-slate-400" />
                          <span className="text-xs text-slate-500">Due: {action.dueDate}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </Card>
              ))}
            </div>

            {/* Quick Links */}
            <div className="mt-6 pt-6 border-t border-slate-200">
              <h3 className="font-semibold text-slate-900 mb-3">Quick Access</h3>
              <div className="space-y-2">
                <button
                  onClick={() => handleQuickAction('tasks')}
                  className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-slate-100 transition-colors text-left"
                >
                  <div className="flex items-center gap-3">
                    <CheckSquare className="w-4 h-4 text-slate-500" />
                    <span className="text-sm text-slate-700">View All Tasks</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </button>
                <button
                  onClick={() => handleQuickAction('documents')}
                  className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-slate-100 transition-colors text-left"
                >
                  <div className="flex items-center gap-3">
                    <FileText className="w-4 h-4 text-slate-500" />
                    <span className="text-sm text-slate-700">Browse Documents</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </button>
                <button
                  onClick={() => handleQuickAction('compliance')}
                  className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-slate-100 transition-colors text-left"
                >
                  <div className="flex items-center gap-3">
                    <Shield className="w-4 h-4 text-slate-500" />
                    <span className="text-sm text-slate-700">Compliance Center</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </button>
                <button
                  onClick={() => handleQuickAction('reports')}
                  className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-slate-100 transition-colors text-left"
                >
                  <div className="flex items-center gap-3">
                    <TrendingUp className="w-4 h-4 text-slate-500" />
                    <span className="text-sm text-slate-700">Generate Reports</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </button>
              </div>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
