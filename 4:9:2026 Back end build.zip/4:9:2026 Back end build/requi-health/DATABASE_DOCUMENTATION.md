# Requi Health — Database Documentation
## PostgreSQL Schema & Operations Guide

---

## 1. Database Architecture

### 1.1 Instance Configuration

```yaml
# Production Configuration
Engine: PostgreSQL 15.4
Instance Class: db.t3.medium (start) → db.t3.large (scale)
Storage: 100 GB GP3 (autoscale to 500 GB)
Multi-AZ: Enabled
Encryption: AES-256 at rest
Backup Retention: 30 days
Maintenance Window: Monday 04:00-05:00 UTC
Backup Window: 03:00-04:00 UTC
Performance Insights: Enabled (7-day retention)
CloudWatch Logs: postgresql
```

### 1.2 Connection Information

```
# Production Database
Host: requi-db.XXXXXXXX.us-east-1.rds.amazonaws.com
Port: 5432
Database: requi_health
Username: requi_admin
Password: [Stored in AWS Secrets Manager]

# Connection String Format
postgresql://requi_admin:[PASSWORD]@requi-db.XXXXXXXX.us-east-1.rds.amazonaws.com:5432/requi_health?schema=public
```

---

## 2. Database Schema

### 2.1 Entity Relationship Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         DATABASE SCHEMA                                      │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌──────────────┐       ┌──────────────┐       ┌──────────────┐            │
│  │ Organization │◄─────►│ Subscription │◄─────►│ Invoice      │            │
│  └──────┬───────┘       └──────────────┘       └──────────────┘            │
│         │                                                                   │
│         │              ┌──────────────┐       ┌──────────────┐             │
│         └─────────────►│ User         │◄─────►│ SeatAssignment│            │
│                        └──────┬───────┘       └──────────────┘            │
│                               │                                            │
│  ┌──────────────┐            │              ┌──────────────┐              │
│  │ Workspace    │◄───────────┘              │ ComplianceGap│              │
│  └──────┬───────┘                          └──────┬───────┘              │
│         │                                         │                        │
│         │         ┌──────────────┐               │                        │
│         └────────►│ Conversation │               │                        │
│                   └──────────────┘               │                        │
│                                                  │                        │
│  ┌──────────────┐       ┌──────────────┐        │                        │
│  │ Source       │       │ Requirement  │◄───────┘                        │
│  └──────────────┘       └──────────────┘                                 │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Core Tables

#### Organization
```sql
CREATE TABLE organizations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    type VARCHAR(50) NOT NULL, -- 'PROVIDER', 'MCO', 'MSO', 'OTHER'
    status VARCHAR(50) NOT NULL DEFAULT 'TRIAL', -- 'TRIAL', 'ACTIVE', 'SUSPENDED', 'CANCELED'
    
    -- Profile
    website VARCHAR(255),
    phone VARCHAR(50),
    address JSONB,
    
    -- Compliance Profile
    states TEXT[], -- Array of state codes
    location_count INTEGER DEFAULT 1,
    lines_of_business TEXT[], -- 'MEDICAID', 'MEDICARE', 'COMMERCIAL'
    payer_relationships TEXT[],
    
    -- Maturity Assessment
    has_compliance_officer BOOLEAN DEFAULT false,
    has_documented_policies BOOLEAN DEFAULT false,
    has_fwa_program BOOLEAN DEFAULT false,
    has_breach_response BOOLEAN DEFAULT false,
    has_exclusion_screening BOOLEAN DEFAULT false,
    training_cadence VARCHAR(50), -- 'NONE', 'ANNUAL', 'QUARTERLY', 'MONTHLY'
    
    -- Metadata
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_organizations_status ON organizations(status);
CREATE INDEX idx_organizations_type ON organizations(type);
CREATE INDEX idx_organizations_slug ON organizations(slug);
```

#### Users
```sql
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    
    -- Profile
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    phone VARCHAR(50),
    avatar_url VARCHAR(500),
    
    -- Role & Status
    role VARCHAR(50) NOT NULL DEFAULT 'MEMBER', -- 'OWNER', 'ADMIN', 'MEMBER', 'VIEWER'
    status VARCHAR(50) NOT NULL DEFAULT 'ACTIVE', -- 'ACTIVE', 'INACTIVE', 'SUSPENDED'
    
    -- Organization
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    
    -- Preferences
    notification_preferences JSONB DEFAULT '{}',
    timezone VARCHAR(50) DEFAULT 'America/New_York',
    
    -- Auth
    email_verified BOOLEAN DEFAULT false,
    last_login_at TIMESTAMP WITH TIME ZONE,
    failed_login_attempts INTEGER DEFAULT 0,
    locked_until TIMESTAMP WITH TIME ZONE,
    
    -- Metadata
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_organization ON users(organization_id);
CREATE INDEX idx_users_status ON users(status);
```

#### Subscription & Billing
```sql
CREATE TABLE subscription_tiers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(50) UNIQUE NOT NULL, -- '25_SEATS', '50_SEATS', etc.
    display_name VARCHAR(100) NOT NULL,
    seat_count INTEGER NOT NULL,
    price_per_seat_cents INTEGER NOT NULL, -- 100000 = $1,000
    total_price_cents INTEGER NOT NULL,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID UNIQUE REFERENCES organizations(id) ON DELETE CASCADE,
    tier_id UUID REFERENCES subscription_tiers(id),
    
    -- Status
    status VARCHAR(50) NOT NULL DEFAULT 'TRIAL', -- 'TRIAL', 'ACTIVE', 'PAST_DUE', 'CANCELED'
    
    -- Trial
    trial_started_at TIMESTAMP WITH TIME ZONE,
    trial_ends_at TIMESTAMP WITH TIME ZONE,
    
    -- Billing Period
    current_period_start TIMESTAMP WITH TIME ZONE,
    current_period_end TIMESTAMP WITH TIME ZONE,
    
    -- Stripe
    stripe_customer_id VARCHAR(255),
    stripe_subscription_id VARCHAR(255),
    stripe_payment_method_id VARCHAR(255),
    
    -- Billing Contact
    billing_email VARCHAR(255) NOT NULL,
    billing_name VARCHAR(255),
    billing_address JSONB,
    
    -- Seats
    seats_used INTEGER DEFAULT 0,
    seats_available INTEGER NOT NULL,
    
    -- Cancellation
    canceled_at TIMESTAMP WITH TIME ZONE,
    cancellation_reason TEXT,
    cancel_at_period_end BOOLEAN DEFAULT false,
    
    -- Metadata
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE invoices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    subscription_id UUID REFERENCES subscriptions(id) ON DELETE CASCADE,
    
    -- Invoice Details
    invoice_number VARCHAR(100) UNIQUE NOT NULL,
    stripe_invoice_id VARCHAR(255),
    
    -- Amounts
    amount_cents INTEGER NOT NULL,
    tax_cents INTEGER DEFAULT 0,
    total_cents INTEGER NOT NULL,
    
    -- Status
    status VARCHAR(50) NOT NULL DEFAULT 'DRAFT', -- 'DRAFT', 'OPEN', 'PAID', 'VOID', 'UNCOLLECTIBLE'
    
    -- Dates
    invoice_date DATE NOT NULL,
    due_date DATE,
    paid_at TIMESTAMP WITH TIME ZONE,
    
    -- PDF
    pdf_url VARCHAR(500),
    
    -- Metadata
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE seat_assignments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    subscription_id UUID REFERENCES subscriptions(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    
    -- Assignment
    assigned_by_id UUID REFERENCES users(id),
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Unassignment (optional)
    deassigned_by_id UUID REFERENCES users(id),
    deassigned_at TIMESTAMP WITH TIME ZONE,
    deassignment_reason TEXT,
    
    UNIQUE(subscription_id, user_id, assigned_at)
);

-- Indexes
CREATE INDEX idx_subscriptions_organization ON subscriptions(organization_id);
CREATE INDEX idx_subscriptions_status ON subscriptions(status);
CREATE INDEX idx_invoices_subscription ON invoices(subscription_id);
CREATE INDEX idx_invoices_status ON invoices(status);
CREATE INDEX idx_seat_assignments_subscription ON seat_assignments(subscription_id);
```

#### Compliance Engine
```sql
CREATE TABLE requirements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(100) UNIQUE NOT NULL, -- e.g., '42-CFR-422.503'
    title VARCHAR(500) NOT NULL,
    description TEXT,
    
    -- Categorization
    category VARCHAR(100) NOT NULL, -- 'FWA', 'HIPAA', 'REPORTING', etc.
    jurisdiction VARCHAR(50) NOT NULL, -- 'FEDERAL', 'STATE'
    states TEXT[], -- NULL if federal, array if state-specific
    
    -- Applicability
    applicable_to TEXT[], -- 'MCO', 'PROVIDER', 'MSO'
    
    -- Compliance Details
    frequency VARCHAR(50), -- 'ANNUAL', 'QUARTERLY', 'MONTHLY', 'ADHOC'
    deadline_pattern VARCHAR(100), -- Cron-like pattern
    evidence_required BOOLEAN DEFAULT true,
    
    -- Source
    source_id UUID REFERENCES sources(id),
    
    -- Scoring
    compliance_weight INTEGER DEFAULT 10,
    risk_weight INTEGER DEFAULT 10,
    
    -- Status
    is_active BOOLEAN DEFAULT true,
    effective_date DATE,
    expiration_date DATE,
    
    -- Metadata
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE compliance_gaps (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    requirement_id UUID REFERENCES requirements(id),
    
    -- Gap Details
    title VARCHAR(500) NOT NULL,
    description TEXT,
    category VARCHAR(100) NOT NULL,
    
    -- Severity
    severity VARCHAR(50) NOT NULL, -- 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'
    
    -- Status
    status VARCHAR(50) NOT NULL DEFAULT 'OPEN', -- 'OPEN', 'IN_PROGRESS', 'RESOLVED', 'ACCEPTED'
    
    -- Assignment
    assigned_to UUID REFERENCES users(id),
    
    -- Due Date
    due_date DATE,
    resolved_at TIMESTAMP WITH TIME ZONE,
    resolved_by UUID REFERENCES users(id),
    resolution_notes TEXT,
    
    -- Evidence
    evidence_urls TEXT[],
    
    -- Metadata
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE compliance_scores (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    
    -- Scores
    overall_score INTEGER NOT NULL, -- 0-100
    compliance_score INTEGER NOT NULL,
    risk_score INTEGER NOT NULL,
    audit_readiness_score INTEGER NOT NULL,
    
    -- Category Breakdown
    category_scores JSONB DEFAULT '{}', -- { 'FWA': 85, 'HIPAA': 72, ... }
    
    -- Calculation
    calculated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    calculation_version INTEGER DEFAULT 1,
    
    -- Source Data
    responses_count INTEGER,
    gaps_count INTEGER,
    
    UNIQUE(organization_id, calculated_at)
);

CREATE TABLE deadlines (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    requirement_id UUID REFERENCES requirements(id),
    
    -- Deadline Details
    title VARCHAR(500) NOT NULL,
    description TEXT,
    category VARCHAR(100) NOT NULL,
    
    -- Dates
    due_date DATE NOT NULL,
    reminder_days INTEGER[] DEFAULT '{7, 3, 1}',
    
    -- Status
    status VARCHAR(50) NOT NULL DEFAULT 'UPCOMING', -- 'UPCOMING', 'DUE_SOON', 'OVERDUE', 'COMPLETED'
    
    -- Assignment
    assigned_to UUID REFERENCES users(id),
    completed_at TIMESTAMP WITH TIME ZONE,
    completed_by UUID REFERENCES users(id),
    
    -- Metadata
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_requirements_category ON requirements(category);
CREATE INDEX idx_requirements_jurisdiction ON requirements(jurisdiction);
CREATE INDEX idx_gaps_organization ON compliance_gaps(organization_id);
CREATE INDEX idx_gaps_status ON compliance_gaps(status);
CREATE INDEX idx_gaps_severity ON compliance_gaps(severity);
CREATE INDEX idx_scores_organization ON compliance_scores(organization_id);
CREATE INDEX idx_deadlines_organization ON deadlines(organization_id);
CREATE INDEX idx_deadlines_due_date ON deadlines(due_date);
CREATE INDEX idx_deadlines_status ON deadlines(status);
```

#### AI & Knowledge
```sql
CREATE TABLE sources (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title VARCHAR(500) NOT NULL,
    description TEXT,
    
    -- Source Type
    type VARCHAR(50) NOT NULL, -- 'REGULATION', 'GUIDANCE', 'ARTICLE', 'TEMPLATE'
    
    -- Origin
    source_url VARCHAR(500),
    document_url VARCHAR(500),
    
    -- Authority
    authority VARCHAR(100), -- 'CMS', 'OIG', 'OCR', 'STATE'
    jurisdiction VARCHAR(50), -- 'FEDERAL', 'STATE'
    state_code VARCHAR(10), -- NULL if federal
    
    -- Status
    status VARCHAR(50) NOT NULL DEFAULT 'PENDING', -- 'PENDING', 'APPROVED', 'REJECTED'
    
    -- Effective Dates
    published_date DATE,
    effective_date DATE,
    expiration_date DATE,
    
    -- Processing
    processed_at TIMESTAMP WITH TIME ZONE,
    processed_by UUID REFERENCES users(id),
    embedding_id VARCHAR(255), -- Pinecone vector ID
    
    -- Metadata
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id UUID REFERENCES workspaces(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id),
    
    -- Conversation
    title VARCHAR(255),
    
    -- Metadata
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id UUID REFERENCES conversations(id) ON DELETE CASCADE,
    
    -- Message
    role VARCHAR(50) NOT NULL, -- 'user', 'assistant', 'system'
    content TEXT NOT NULL,
    
    -- AI Metadata
    model VARCHAR(50),
    tokens_used INTEGER,
    sources_referenced UUID[], -- Array of source IDs
    
    -- Metadata
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_sources_status ON sources(status);
CREATE INDEX idx_sources_type ON sources(type);
CREATE INDEX idx_sources_authority ON sources(authority);
CREATE INDEX idx_conversations_workspace ON conversations(workspace_id);
CREATE INDEX idx_messages_conversation ON messages(conversation_id);
```

---

## 3. Database Operations

### 3.1 Connection Management

```sql
-- View active connections
SELECT 
    datname,
    usename,
    application_name,
    client_addr,
    state,
    query_start,
    query
FROM pg_stat_activity 
WHERE datname = 'requi_health';

-- Kill a connection (use with caution)
SELECT pg_terminate_backend(pid) 
FROM pg_stat_activity 
WHERE pid = [PID];

-- Connection limit check
SELECT 
    max_connections,
    (SELECT count(*) FROM pg_stat_activity WHERE datname = 'requi_health') as current_connections
FROM pg_settings 
WHERE name = 'max_connections';
```

### 3.2 Performance Monitoring

```sql
-- Slow queries (running > 5 seconds)
SELECT 
    pid,
    now() - query_start as duration,
    query
FROM pg_stat_activity 
WHERE state != 'idle' 
AND now() - query_start > interval '5 seconds';

-- Table sizes
SELECT 
    schemaname,
    tablename,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size
FROM pg_tables 
WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;

-- Index usage
SELECT 
    schemaname,
    tablename,
    indexname,
    idx_scan,
    idx_tup_read
FROM pg_stat_user_indexes 
ORDER BY idx_scan DESC;

-- Cache hit ratio
SELECT 
    sum(heap_blks_hit) / (sum(heap_blks_hit) + sum(heap_blks_read)) as cache_hit_ratio
FROM pg_statio_user_tables;
```

### 3.3 Maintenance Tasks

```sql
-- Update table statistics
ANALYZE;

-- Vacuum (run during maintenance window)
VACUUM ANALYZE;

-- Reindex (if needed)
REINDEX TABLE CONCURRENTLY users;

-- Check for bloat
SELECT 
    schemaname,
    tablename,
    n_tup_ins,
    n_tup_upd,
    n_tup_del,
    n_live_tup,
    n_dead_tup
FROM pg_stat_user_tables 
WHERE n_dead_tup > 1000;
```

---

## 4. Backup & Recovery

### 4.1 Automated Backups

RDS automatically handles:
- Daily snapshots (30-day retention)
- Transaction logs for PITR
- Cross-region backup copy (if configured)

### 4.2 Manual Backup

```bash
# Create manual snapshot
aws rds create-db-snapshot \
  --db-instance-identifier requi-db \
  --db-snapshot-identifier requi-db-manual-$(date +%Y%m%d)

# List snapshots
aws rds describe-db-snapshots \
  --db-instance-identifier requi-db
```

### 4.3 Point-in-Time Recovery

```bash
# Restore to specific time
aws rds restore-db-instance-to-point-in-time \
  --source-db-instance-identifier requi-db \
  --target-db-instance-identifier requi-db-restore \
  --restore-time 2024-01-15T12:00:00Z
```

### 4.4 Disaster Recovery

```bash
# Promote read replica (if Multi-AZ fails)
aws rds promote-read-replica \
  --db-instance-identifier requi-db-replica
```

---

## 5. Security

### 5.1 Encryption

- **At Rest:** AES-256 (RDS-managed)
- **In Transit:** TLS 1.2+ required
- **Connection String:** `sslmode=require`

### 5.2 Access Control

```sql
-- Create application user (read-only for reporting)
CREATE USER requi_app WITH PASSWORD '[SECURE_PASSWORD]';
GRANT CONNECT ON DATABASE requi_health TO requi_app;
GRANT USAGE ON SCHEMA public TO requi_app;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO requi_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO requi_app;

-- Create migrator user
CREATE USER requi_migrator WITH PASSWORD '[SECURE_PASSWORD]';
GRANT ALL PRIVILEGES ON DATABASE requi_health TO requi_migrator;
```

### 5.3 Audit Logging

Enable CloudWatch Logs for:
- PostgreSQL logs
- Connection logs
- Slow query logs

---

## 6. Scaling Considerations

### 6.1 Vertical Scaling

```bash
# Scale up instance
aws rds modify-db-instance \
  --db-instance-identifier requi-db \
  --db-instance-class db.t3.large \
  --apply-immediately
```

### 6.2 Read Replicas

```bash
# Create read replica
aws rds create-db-instance-read-replica \
  --db-instance-identifier requi-db-replica \
  --source-db-instance-identifier requi-db

# Use for read-heavy operations
```

### 6.3 Connection Pooling

Consider PgBouncer for connection pooling:
- Max connections: 200
- Pool mode: Transaction
- Default pool size: 20

---

## 7. Troubleshooting

### 7.1 Connection Issues

```bash
# Test connectivity
nc -zv requi-db.XXXXXXXX.us-east-1.rds.amazonaws.com 5432

# Check security groups
aws ec2 describe-security-groups --group-ids sg-xxx
```

### 7.2 Performance Issues

```sql
-- Check for locks
SELECT 
    blocked_locks.pid AS blocked_pid,
    blocked_activity.usename AS blocked_user,
    blocking_locks.pid AS blocking_pid,
    blocking_activity.usename AS blocking_user,
    blocked_activity.query AS blocked_statement,
    blocking_activity.query AS blocking_statement
FROM pg_catalog.pg_locks blocked_locks
JOIN pg_catalog.pg_stat_activity blocked_activity ON blocked_activity.pid = blocked_locks.pid
JOIN pg_catalog.pg_locks blocking_locks ON blocking_locks.locktype = blocked_locks.locktype
JOIN pg_catalog.pg_stat_activity blocking_activity ON blocking_activity.pid = blocking_locks.pid
WHERE NOT blocked_locks.granted;
```

### 7.3 Storage Issues

```sql
-- Check storage usage
SELECT 
    pg_size_pretty(pg_database_size('requi_health')) as db_size;

-- Check table sizes
SELECT 
    tablename,
    pg_size_pretty(pg_total_relation_size(tablename::regclass)) as size
FROM pg_tables 
WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(tablename::regclass) DESC
LIMIT 10;
```

---

## 8. Migration Commands

### 8.1 Using Prisma

```bash
# Generate migration
npx prisma migrate dev --name [migration_name]

# Deploy to production
npx prisma migrate deploy

# Validate schema
npx prisma validate

# Generate client
npx prisma generate
```

### 8.2 Seeding

```bash
# Run seed script
npx prisma db seed
```

---

**Document Version:** 1.0  
**Last Updated:** 2024  
**Owner:** Database Team
