# Requi Health — AWS Deployment Guide
## For: Debasish (AWS Engineer)
## Project: Enterprise Healthcare Compliance Platform

---

## Executive Summary

This document provides a comprehensive deployment roadmap for launching the Requi Health platform on AWS. The platform consists of:

1. **Admin Console** (Next.js) — Internal operations platform
2. **User Dashboard** (Next.js) — Customer-facing compliance dashboard  
3. **Backend API** (NestJS) — Unified backend services
4. **Supporting Infrastructure** — Database, cache, vector search, storage

**Target Environment:** AWS Production
**Estimated Timeline:** 2-3 weeks for full deployment
**Estimated Monthly Cost:** $800-$1,500 (startup scale)

---

## Part 1: Infrastructure Architecture

### 1.1 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              AWS CLOUD                                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         ROUTE 53                                    │   │
│  │     admin.requi.health    app.requi.health    api.requi.health    │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                         │
│  ┌─────────────────────────────────┴─────────────────────────────────────┐  │
│  │                      CLOUDFRONT (CDN)                                 │  │
│  │         Static asset caching + DDoS protection                        │  │
│  └─────────────────────────────────┬─────────────────────────────────────┘  │
│                                    │                                         │
│  ┌─────────────────────────────────┴─────────────────────────────────────┐  │
│  │                         APPLICATION LOAD BALANCER                     │  │
│  │              HTTPS termination, path-based routing                    │  │
│  └──────────────┬──────────────────┬──────────────────┬──────────────────┘  │
│                 │                  │                  │                      │
│         ┌───────▼──────┐  ┌────────▼────────┐  ┌──────▼──────┐             │
│         │   ECS/Fargate │  │    ECS/Fargate   │  │  ECS/Fargate │             │
│         │   (Admin)     │  │   (Dashboard)    │  │   (API)      │             │
│         │   Next.js     │  │   Next.js        │  │   NestJS     │             │
│         └───────┬───────┘  └────────┬────────┘  └──────┬──────┘             │
│                 │                   │                  │                      │
│         ┌───────▼───────────────────▼──────────────────▼──────┐              │
│         │              VPC (10.0.0.0/16)                      │              │
│         │  ┌─────────────────────────────────────────────┐   │              │
│         │  │           PRIVATE SUBNETS                     │   │              │
│         │  │  ┌─────────┐  ┌─────────┐  ┌─────────────┐  │   │              │
│         │  │  │  RDS    │  │ ElastiCache│ │  Pinecone   │  │   │              │
│         │  │  │PostgreSQL│  │  Redis    │ │ (via VPCe)  │  │   │              │
│         │  │  └─────────┘  └─────────┘  └─────────────┘  │   │              │
│         │  └─────────────────────────────────────────────┘   │              │
│         └─────────────────────────────────────────────────────┘              │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         S3 (Static Assets)                          │   │
│  │     Document storage, backups, static exports                       │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                    CLOUDWATCH + X-RAY                               │   │
│  │              Logging, metrics, tracing, alarms                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 1.2 AWS Services Required

| Service | Purpose | Estimated Cost/Month |
|---------|---------|---------------------|
| **ECS Fargate** | Container orchestration (3 services) | $150-$300 |
| **RDS PostgreSQL** | Primary database (db.t3.medium) | $100-$150 |
| **ElastiCache Redis** | Cache & job queue (cache.t3.micro) | $30-$50 |
| **Application Load Balancer** | Traffic distribution | $25-$40 |
| **CloudFront** | CDN for static assets | $20-$50 |
| **Route 53** | DNS management | $5-$10 |
| **S3** | Document storage, backups | $10-$30 |
| **CloudWatch** | Logging & monitoring | $20-$50 |
| **Secrets Manager** | Credential storage | $5-$10 |
| **VPC + NAT Gateway** | Networking | $50-$100 |
| **Total** | | **$415-$790** |

---

## Part 2: Pre-Deployment Checklist

### 2.1 AWS Account Setup

- [ ] Create/verify AWS account
- [ ] Enable MFA on root account
- [ ] Create IAM admin user for Debasish
- [ ] Set up AWS Organizations (if multi-account)
- [ ] Enable CloudTrail for audit logging
- [ ] Set up billing alerts ($100, $500, $1000)
- [ ] Request service limit increases if needed:
  - ECS Fargate vCPU limit
  - RDS instance limit
  - ElastiCache node limit

### 2.2 Domain & SSL

- [ ] Register domains:
  - `requi.health` (primary)
  - `admin.requi.health` (admin console)
  - `app.requi.health` (user dashboard)
  - `api.requi.health` (backend API)
- [ ] Request ACM certificates for all domains
- [ ] Set up Route 53 hosted zones

### 2.3 Third-Party API Keys

| Service | Key Location | Status |
|---------|--------------|--------|
| Anthropic Claude | AWS Secrets Manager | ⬜ |
| Stripe (Secret + Publishable) | AWS Secrets Manager | ⬜ |
| Stripe Webhook Secret | AWS Secrets Manager | ⬜ |
| Pinecone API Key | AWS Secrets Manager | ⬜ |
| SendGrid/AWS SES | AWS Secrets Manager | ⬜ |
| Auth0/Clerk | AWS Secrets Manager | ⬜ |
| Microsoft OAuth | AWS Secrets Manager | ⬜ |
| Google OAuth | AWS Secrets Manager | ⬜ |
| Sentry DSN | AWS Secrets Manager | ⬜ |

---

## Part 3: VPC & Networking Setup

### 3.1 VPC Configuration

```bash
# VPC Configuration
VPC_CIDR="10.0.0.0/16"
VPC_NAME="requi-health-vpc"

# Availability Zones
AZS=("us-east-1a" "us-east-1b" "us-east-1c")

# Subnet CIDRs
PUBLIC_SUBNETS=("10.0.1.0/24" "10.0.2.0/24" "10.0.3.0/24")
PRIVATE_SUBNETS=("10.0.11.0/24" "10.0.12.0/24" "10.0.13.0/24")
DB_SUBNETS=("10.0.21.0/24" "10.0.22.0/24" "10.0.23.0/24")
```

### 3.2 Network Resources to Create

- [ ] **VPC** (10.0.0.0/16) with DNS hostnames enabled
- [ ] **Internet Gateway** attached to VPC
- [ ] **NAT Gateways** (3, one per AZ for high availability)
- [ ] **Public Subnets** (3) with route to IGW
- [ ] **Private Subnets** (3) with route to NAT Gateway
- [ ] **Database Subnets** (3) isolated, no internet
- [ ] **VPC Endpoints**:
  - S3 Gateway endpoint
  - ECR API endpoint
  - ECR DKR endpoint
  - CloudWatch Logs endpoint
  - Secrets Manager endpoint
- [ ] **Security Groups**:
  - ALB SG (80, 443 from internet)
  - ECS Tasks SG (dynamic ports from ALB)
  - RDS SG (5432 from ECS only)
  - ElastiCache SG (6379 from ECS only)

---

## Part 4: Database Setup

### 4.1 RDS PostgreSQL Configuration

```yaml
# RDS Instance Configuration
InstanceClass: db.t3.medium  # Start here, scale as needed
Engine: postgres
EngineVersion: "15.4"
AllocatedStorage: 100  # GB, with autoscaling to 500GB
StorageType: gp3
MultiAZ: true  # Production requirement
PubliclyAccessible: false
BackupRetentionPeriod: 30
DeletionProtection: true
StorageEncrypted: true

# Database Parameters
DBName: requi_health
MasterUsername: requi_admin
# MasterPassword: [Generated, stored in Secrets Manager]

# Parameter Group Settings
Parameters:
  max_connections: 200
  shared_buffers: 256MB
  effective_cache_size: 768MB
  maintenance_work_mem: 64MB
  checkpoint_completion_target: 0.9
  wal_buffers: 7864kB
  default_statistics_target: 100
  random_page_cost: 1.1
  effective_io_concurrency: 200
  work_mem: 655kB
  min_wal_size: 1GB
  max_wal_size: 4GB
```

### 4.2 Database Migration Strategy

```bash
# Step 1: Create migration user
CREATE USER migrator WITH PASSWORD '[secure_password]';
GRANT ALL PRIVILEGES ON DATABASE requi_health TO migrator;

# Step 2: Run Prisma migrations
npx prisma migrate deploy

# Step 3: Seed initial data
npx prisma db seed

# Step 4: Verify schema
npx prisma validate
```

### 4.3 Database Backup Strategy

- [ ] **Automated Backups**: Daily, 30-day retention
- [ ] **Point-in-Time Recovery**: Enabled
- [ ] **Cross-Region Backup**: Weekly snapshot to us-west-2
- [ ] **Manual Snapshots**: Before major deployments
- [ ] **Backup Testing**: Monthly restore to verify

### 4.4 Database Monitoring

```sql
-- Key metrics to monitor
SELECT 
  datname,
  numbackends,
  xact_commit,
  xact_rollback,
  blks_read,
  blks_hit,
  tup_returned,
  tup_fetched,
  tup_inserted,
  tup_updated,
  tup_deleted
FROM pg_stat_database 
WHERE datname = 'requi_health';

-- Connection monitoring
SELECT count(*) as active_connections 
FROM pg_stat_activity 
WHERE state = 'active';

-- Long-running queries
SELECT pid, now() - query_start as duration, query 
FROM pg_stat_activity 
WHERE state != 'idle' 
AND now() - query_start > interval '5 minutes';
```

---

## Part 5: ElastiCache Redis Setup

### 5.1 Redis Configuration

```yaml
# ElastiCache Configuration
CacheNodeType: cache.t3.micro  # Start small, scale up
Engine: redis
EngineVersion: "7.0"
NumCacheNodes: 2  # Multi-AZ
AutomaticFailoverEnabled: true
AtRestEncryptionEnabled: true
TransitEncryptionEnabled: true

# Parameter Group
Parameters:
  maxmemory-policy: allkeys-lru
  timeout: 300
  tcp-keepalive: 300
```

### 5.2 Redis Use Cases

| Use Case | Key Pattern | TTL |
|----------|-------------|-----|
| Session Store | `session:{userId}` | 7 days |
| API Rate Limiting | `ratelimit:{ip}` | 1 hour |
| Compliance Score Cache | `score:{orgId}` | 1 hour |
| Job Queue | `bull:queue-name` | N/A |
| Real-time Notifications | `notifications:{userId}` | 24 hours |

---

## Part 6: ECS Fargate Deployment

### 6.1 Cluster Configuration

```bash
# Create ECS Cluster
aws ecs create-cluster \
  --cluster-name requi-health-cluster \
  --settings name=containerInsights,value=enabled \
  --capacity-providers FARGATE FARGATE_SPOT
```

### 6.2 Task Definitions

#### API Service Task Definition

```json
{
  "family": "requi-api",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "1024",
  "memory": "2048",
  "executionRoleArn": "arn:aws:iam::ACCOUNT:role/ecsTaskExecutionRole",
  "taskRoleArn": "arn:aws:iam::ACCOUNT:role/ecsTaskRole",
  "containerDefinitions": [
    {
      "name": "api",
      "image": "ACCOUNT.dkr.ecr.us-east-1.amazonaws.com/requi-api:latest",
      "portMappings": [
        {
          "containerPort": 3001,
          "protocol": "tcp"
        }
      ],
      "environment": [
        { "name": "NODE_ENV", "value": "production" },
        { "name": "PORT", "value": "3001" }
      ],
      "secrets": [
        { "name": "DATABASE_URL", "valueFrom": "arn:aws:secretsmanager:..." },
        { "name": "REDIS_URL", "valueFrom": "arn:aws:secretsmanager:..." },
        { "name": "JWT_SECRET", "valueFrom": "arn:aws:secretsmanager:..." },
        { "name": "ANTHROPIC_API_KEY", "valueFrom": "arn:aws:secretsmanager:..." },
        { "name": "STRIPE_SECRET_KEY", "valueFrom": "arn:aws:secretsmanager:..." },
        { "name": "PINECONE_API_KEY", "valueFrom": "arn:aws:secretsmanager:..." }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/requi-api",
          "awslogs-region": "us-east-1",
          "awslogs-stream-prefix": "ecs"
        }
      },
      "healthCheck": {
        "command": ["CMD-SHELL", "curl -f http://localhost:3001/health || exit 1"],
        "interval": 30,
        "timeout": 5,
        "retries": 3,
        "startPeriod": 60
      }
    }
  ]
}
```

#### Frontend Services Task Definitions

Similar structure for Admin and Dashboard services with:
- CPU: 512
- Memory: 1024
- Port: 3000
- No database secrets (API-only)

### 6.3 Service Configuration

```bash
# API Service
aws ecs create-service \
  --cluster requi-health-cluster \
  --service-name api \
  --task-definition requi-api:1 \
  --desired-count 2 \
  --launch-type FARGATE \
  --platform-version LATEST \
  --network-configuration "awsvpcConfiguration={subnets=[subnet-xxx,subnet-yyy],securityGroups=[sg-xxx],assignPublicIp=DISABLED}" \
  --load-balancers "targetGroupArn=arn:aws:elasticloadbalancing:...,containerName=api,containerPort=3001" \
  --deployment-configuration "minimumHealthyPercent=100,maximumPercent=200" \
  --health-check-grace-period-seconds 60
```

### 6.4 Auto-Scaling Configuration

```bash
# Register scalable target
aws application-autoscaling register-scalable-target \
  --service-namespace ecs \
  --resource-id service/requi-health-cluster/api \
  --scalable-dimension ecs:service:DesiredCount \
  --min-capacity 2 \
  --max-capacity 10

# CPU-based scaling
aws application-autoscaling put-scaling-policy \
  --service-namespace ecs \
  --resource-id service/requi-health-cluster/api \
  --scalable-dimension ecs:service:DesiredCount \
  --policy-name api-cpu-scaling \
  --policy-type TargetTrackingScaling \
  --target-tracking-scaling-policy-configuration '{
    "PredefinedMetricSpecification": {
      "PredefinedMetricType": "ECSServiceAverageCPUUtilization"
    },
    "TargetValue": 70.0,
    "ScaleOutCooldown": 60,
    "ScaleInCooldown": 300
  }'
```

---

## Part 7: Application Load Balancer Setup

### 7.1 ALB Configuration

```bash
# Create ALB
aws elbv2 create-load-balancer \
  --name requi-health-alb \
  --subnets subnet-xxx subnet-yyy subnet-zzz \
  --security-groups sg-xxx \
  --scheme internet-facing \
  --type application \
  --ip-address-type ipv4

# Create target groups
aws elbv2 create-target-group \
  --name api-tg \
  --protocol HTTP \
  --port 3001 \
  --vpc-id vpc-xxx \
  --target-type ip \
  --health-check-path /health \
  --health-check-interval-seconds 30

# Create HTTPS listener
aws elbv2 create-listener \
  --load-balancer-arn arn:aws:elasticloadbalancing:... \
  --protocol HTTPS \
  --port 443 \
  --ssl-policy ELBSecurityPolicy-TLS13-1-2-2021-06 \
  --certificates CertificateArn=arn:aws:acm:... \
  --default-actions Type=forward,TargetGroupArn=arn:aws:elasticloadbalancing:...
```

### 7.2 Path-Based Routing

| Path | Target Group | Service |
|------|--------------|---------|
| `/api/*` | api-tg | Backend API |
| `/admin/*` | admin-tg | Admin Console |
| `/*` | dashboard-tg | User Dashboard |

---

## Part 8: CI/CD Pipeline

### 8.1 GitHub Actions Workflow

```yaml
# .github/workflows/deploy.yml
name: Deploy to AWS

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

env:
  AWS_REGION: us-east-1
  ECR_REPOSITORY_API: requi-api
  ECR_REPOSITORY_ADMIN: requi-admin
  ECR_REPOSITORY_DASHBOARD: requi-dashboard
  ECS_CLUSTER: requi-health-cluster

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    permissions:
      id-token: write
      contents: read
    
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Configure AWS Credentials
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::ACCOUNT:role/GitHubActionsRole
          aws-region: ${{ env.AWS_REGION }}

      - name: Login to Amazon ECR
        id: login-ecr
        uses: aws-actions/amazon-ecr-login@v2

      - name: Build and Push API
        working-directory: apps/api
        run: |
          docker build -t $ECR_REPOSITORY_API:${{ github.sha }} .
          docker tag $ECR_REPOSITORY_API:${{ github.sha }} ${{ steps.login-ecr.outputs.registry }}/$ECR_REPOSITORY_API:${{ github.sha }}
          docker tag $ECR_REPOSITORY_API:${{ github.sha }} ${{ steps.login-ecr.outputs.registry }}/$ECR_REPOSITORY_API:latest
          docker push ${{ steps.login-ecr.outputs.registry }}/$ECR_REPOSITORY_API:${{ github.sha }}
          docker push ${{ steps.login-ecr.outputs.registry }}/$ECR_REPOSITORY_API:latest

      - name: Update ECS Service
        run: |
          aws ecs update-service \
            --cluster $ECS_CLUSTER \
            --service api \
            --force-new-deployment
```

### 8.2 Required IAM Roles

- [ ] **GitHubActionsRole** — OIDC federated role for GitHub Actions
- [ ] **ECSTaskExecutionRole** — For pulling images, writing logs
- [ ] **ECSTaskRole** — For accessing AWS services from containers

---

## Part 9: Security Configuration

### 9.1 Security Checklist

- [ ] **WAF** — AWS WAF on CloudFront with OWASP rules
- [ ] **Shield Advanced** — DDoS protection (consider for launch)
- [ ] **Security Groups** — Least privilege access
- [ ] **NACLs** — Additional subnet-level protection
- [ ] **Secrets Manager** — All credentials stored securely
- [ ] **KMS** — Encryption keys for data at rest
- [ ] **IAM** — No long-term credentials, use roles
- [ ] **CloudTrail** — Audit all API calls
- [ ] **Config** — Compliance monitoring
- [ ] **GuardDuty** — Threat detection

### 9.2 Encryption Requirements

| Layer | Encryption Method |
|-------|-------------------|
| RDS | AES-256 at rest, TLS in transit |
| ElastiCache | AES-256 at rest, TLS in transit |
| S3 | SSE-S3 or SSE-KMS |
| EBS | KMS-encrypted volumes |
| Secrets Manager | Automatic AES-256 |
| ALB | TLS 1.3 minimum |

---

## Part 10: Monitoring & Alerting

### 10.1 CloudWatch Dashboard

Create dashboard with:
- ECS CPU/Memory utilization
- RDS connections, CPU, storage
- ElastiCache hits/misses
- ALB request count, latency, 5xx errors
- Application error rates

### 10.2 CloudWatch Alarms

```bash
# High CPU alarm
aws cloudwatch put-metric-alarm \
  --alarm-name api-high-cpu \
  --alarm-description "API CPU > 80%" \
  --metric-name CPUUtilization \
  --namespace AWS/ECS \
  --statistic Average \
  --period 300 \
  --threshold 80 \
  --comparison-operator GreaterThanThreshold \
  --evaluation-periods 2 \
  --dimensions Name=ClusterName,Value=requi-health-cluster Name=ServiceName,Value=api

# Database connections alarm
aws cloudwatch put-metric-alarm \
  --alarm-name rds-high-connections \
  --alarm-description "RDS connections > 150" \
  --metric-name DatabaseConnections \
  --namespace AWS/RDS \
  --statistic Average \
  --period 300 \
  --threshold 150 \
  --comparison-operator GreaterThanThreshold \
  --evaluation-periods 2 \
  --dimensions Name=DBInstanceIdentifier,Value=requi-db
```

### 10.3 Log Aggregation

All services log to CloudWatch Logs:
- `/ecs/requi-api`
- `/ecs/requi-admin`
- `/ecs/requi-dashboard`
- `/rds/postgresql`

---

## Part 11: Deployment Tasks for Debasish

### Week 1: Foundation

#### Day 1-2: AWS Account & Networking
- [ ] Set up AWS account with MFA
- [ ] Create VPC with public/private/DB subnets across 3 AZs
- [ ] Set up NAT Gateways, IGW, VPC endpoints
- [ ] Configure Security Groups
- [ ] Set up Route 53 hosted zone
- [ ] Request ACM certificates

#### Day 3-4: Database & Cache
- [ ] Create RDS PostgreSQL instance (Multi-AZ)
- [ ] Create ElastiCache Redis cluster
- [ ] Configure parameter groups
- [ ] Set up backup policies
- [ ] Test connectivity from bastion host

#### Day 5: ECR & Initial Images
- [ ] Create ECR repositories (api, admin, dashboard)
- [ ] Build and push initial Docker images
- [ ] Set up image scanning

### Week 2: Application Deployment

#### Day 1-2: ECS Cluster & ALB
- [ ] Create ECS cluster with Container Insights
- [ ] Create Application Load Balancer
- [ ] Create target groups for each service
- [ ] Set up path-based routing
- [ ] Configure health checks

#### Day 3-4: Service Deployment
- [ ] Create task definitions for all services
- [ ] Deploy API service
- [ ] Deploy Admin service
- [ ] Deploy Dashboard service
- [ ] Configure auto-scaling policies

#### Day 5: CI/CD Pipeline
- [ ] Set up GitHub Actions OIDC provider
- [ ] Create IAM roles for GitHub Actions
- [ ] Configure deployment workflows
- [ ] Test end-to-end deployment

### Week 3: Security & Monitoring

#### Day 1-2: Security Hardening
- [ ] Configure AWS WAF
- [ ] Set up GuardDuty
- [ ] Enable Security Hub
- [ ] Configure Secrets Manager rotation
- [ ] Review IAM policies

#### Day 3-4: Monitoring Setup
- [ ] Create CloudWatch dashboards
- [ ] Set up CloudWatch alarms
- [ ] Configure SNS notifications
- [ ] Set up log retention policies

#### Day 5: Testing & Documentation
- [ ] Run load tests
- [ ] Verify auto-scaling
- [ ] Test disaster recovery
- [ ] Document runbooks

---

## Part 12: Environment Variables Reference

### API Service

```bash
# Database
DATABASE_URL=postgresql://user:pass@host:5432/requi_health

# Cache
REDIS_URL=redis://host:6379

# Auth
JWT_SECRET=[from Secrets Manager]
JWT_EXPIRES_IN=7d

# AI
ANTHROPIC_API_KEY=[from Secrets Manager]
OPENAI_API_KEY=[optional]

# Vector Search
PINECONE_API_KEY=[from Secrets Manager]
PINECONE_INDEX=requi-health
PINECONE_ENVIRONMENT=us-east-1

# Billing
STRIPE_SECRET_KEY=[from Secrets Manager]
STRIPE_WEBHOOK_SECRET=[from Secrets Manager]
STRIPE_PUBLISHABLE_KEY=[from Secrets Manager]

# Email
SENDGRID_API_KEY=[from Secrets Manager]
FROM_EMAIL=noreply@requi.health

# App
NODE_ENV=production
PORT=3001
API_URL=https://api.requi.health
FRONTEND_URL=https://app.requi.health

# Encryption
ENCRYPTION_KEY=[from Secrets Manager]
```

### Frontend Services

```bash
NEXT_PUBLIC_API_URL=https://api.requi.health
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=[from Secrets Manager]
NEXT_PUBLIC_APP_NAME=Requi Health
NEXT_PUBLIC_APP_URL=https://app.requi.health
```

---

## Part 13: Troubleshooting Guide

### Common Issues

#### ECS Task Won't Start
```bash
# Check task status
aws ecs describe-tasks --cluster requi-health-cluster --tasks TASK_ID

# Check service events
aws ecs describe-services --cluster requi-health-cluster --services api

# View logs
aws logs tail /ecs/requi-api --follow
```

#### Database Connection Issues
```bash
# Test connectivity
nc -zv RDS_ENDPOINT 5432

# Check security group rules
aws ec2 describe-security-groups --group-ids sg-xxx

# View RDS logs
aws rds describe-db-log-files --db-instance-identifier requi-db
```

#### High Memory Usage
```bash
# Check container metrics
aws cloudwatch get-metric-statistics \
  --namespace AWS/ECS \
  --metric-name MemoryUtilization \
  --dimensions Name=ClusterName,Value=requi-health-cluster Name=ServiceName,Value=api \
  --start-time 2024-01-01T00:00:00Z \
  --end-time 2024-01-02T00:00:00Z \
  --period 3600 \
  --statistics Average
```

---

## Part 14: Post-Launch Runbooks

### Scaling Runbook

```bash
# Scale up API service
aws ecs update-service \
  --cluster requi-health-cluster \
  --service api \
  --desired-count 4

# Scale RDS
aws rds modify-db-instance \
  --db-instance-identifier requi-db \
  --db-instance-class db.t3.large \
  --apply-immediately
```

### Backup/Restore Runbook

```bash
# Create manual snapshot
aws rds create-db-snapshot \
  --db-instance-identifier requi-db \
  --db-snapshot-identifier requi-db-backup-$(date +%Y%m%d)

# Restore from snapshot
aws rds restore-db-instance-from-db-snapshot \
  --db-instance-identifier requi-db-restore \
  --db-snapshot-identifier SNAPSHOT_ID
```

---

## Contact & Escalation

| Role | Name | Contact |
|------|------|---------|
| AWS Engineer | Debasish | [Your contact] |
| Dev Lead | [Name] | [Contact] |
| On-Call | [Rotation] | [PagerDuty/Opsgenie] |

---

**Document Version:** 1.0  
**Last Updated:** 2024  
**Next Review:** Post-launch
