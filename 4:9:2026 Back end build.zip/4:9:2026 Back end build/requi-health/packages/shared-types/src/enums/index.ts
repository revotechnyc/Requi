// ============================================
// Requi Health - Shared Enums
// ============================================

// User & Organization
export enum UserRole {
  SUPER_ADMIN = 'SUPER_ADMIN',
  ADMIN = 'ADMIN',
  MANAGER = 'MANAGER',
  ANALYST = 'ANALYST',
  VIEWER = 'VIEWER',
}

export enum OrganizationStatus {
  ACTIVE = 'ACTIVE',
  SUSPENDED = 'SUSPENDED',
  PENDING = 'PENDING',
  CANCELLED = 'CANCELLED',
}

// Subscription & Billing
export enum SubscriptionTier {
  FREE = 'FREE',
  PROFESSIONAL = 'PROFESSIONAL',
  ENTERPRISE = 'ENTERPRISE',
}

export enum BillingInterval {
  MONTHLY = 'MONTHLY',
  ANNUAL = 'ANNUAL',
}

// Sources & Authority
export enum AuthorityTier {
  TIER_1_BINDING_PRIMARY = 'TIER_1_BINDING_PRIMARY',
  TIER_2_BINDING_SECONDARY = 'TIER_2_BINDING_SECONDARY',
  TIER_3_AUTHORITATIVE_GUIDANCE = 'TIER_3_AUTHORITATIVE_GUIDANCE',
  TIER_4_OFFICIAL_REFERENCE = 'TIER_4_OFFICIAL_REFERENCE',
  TIER_5_PROFESSIONAL_CONTENT = 'TIER_5_PROFESSIONAL_CONTENT',
  TIER_6_GENERAL_SEARCH = 'TIER_6_GENERAL_SEARCH',
}

export enum SourceType {
  FEDERAL_STATUTE = 'FEDERAL_STATUTE',
  FEDERAL_REGULATION = 'FEDERAL_REGULATION',
  FEDERAL_GUIDANCE = 'FEDERAL_GUIDANCE',
  STATE_STATUTE = 'STATE_STATUTE',
  STATE_REGULATION = 'STATE_REGULATION',
  STATE_GUIDANCE = 'STATE_GUIDANCE',
  PROGRAM_DOCUMENT = 'PROGRAM_DOCUMENT',
  CONTRACT = 'CONTRACT',
  CASE_LAW = 'CASE_LAW',
  ACADEMIC = 'ACADEMIC',
  BEST_PRACTICE = 'BEST_PRACTICE',
  INTERNAL_POLICY = 'INTERNAL_POLICY',
}

export enum SourceStatus {
  ACTIVE = 'ACTIVE',
  DEPRECATED = 'DEPRECATED',
  PENDING_REVIEW = 'PENDING_REVIEW',
  ARCHIVED = 'ARCHIVED',
}

// AI & Confidence
export enum ConfidenceLevel {
  HIGH = 'HIGH',
  MEDIUM = 'MEDIUM',
  LOW = 'LOW',
  UNSUPPORTED = 'UNSUPPORTED',
}

export enum CitationType {
  DIRECT_QUOTE = 'DIRECT_QUOTE',
  PARAPHRASE = 'PARAPHRASE',
  SUMMARY = 'SUMMARY',
  REFERENCE = 'REFERENCE',
}

// Missing Knowledge
export enum MissingKnowledgeStatus {
  OPEN = 'OPEN',
  IN_REVIEW = 'IN_REVIEW',
  SOURCING = 'SOURCING',
  RESOLVED = 'RESOLVED',
  CLOSED = 'CLOSED',
}

export enum MissingKnowledgePriority {
  CRITICAL = 'CRITICAL',
  HIGH = 'HIGH',
  MEDIUM = 'MEDIUM',
  LOW = 'LOW',
}

// Tasks
export enum TaskStatus {
  PENDING = 'PENDING',
  IN_PROGRESS = 'IN_PROGRESS',
  COMPLETED = 'COMPLETED',
  CANCELLED = 'CANCELLED',
}

export enum TaskType {
  SOURCE_REVIEW = 'SOURCE_REVIEW',
  KNOWLEDGE_GAP = 'KNOWLEDGE_GAP',
  COMPLIANCE_CHECK = 'COMPLIANCE_CHECK',
  DOCUMENT_UPLOAD = 'DOCUMENT_UPLOAD',
}

// Documents
export enum DocumentType {
  PDF = 'PDF',
  DOCX = 'DOCX',
  TXT = 'TXT',
  HTML = 'HTML',
  MARKDOWN = 'MARKDOWN',
}

export enum IngestionStatus {
  PENDING = 'PENDING',
  PROCESSING = 'PROCESSING',
  EXTRACTING = 'EXTRACTING',
  CHUNKING = 'CHUNKING',
  EMBEDDING = 'EMBEDDING',
  INDEXING = 'INDEXING',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED',
}

// Templates
export enum TemplateType {
  POLICY = 'POLICY',
  PROCEDURE = 'PROCEDURE',
  CHECKLIST = 'CHECKLIST',
  REPORT = 'REPORT',
  CONTRACT = 'CONTRACT',
}

// Notifications
export enum NotificationType {
  INFO = 'INFO',
  WARNING = 'WARNING',
  ERROR = 'ERROR',
  SUCCESS = 'SUCCESS',
}

export enum NotificationChannel {
  IN_APP = 'IN_APP',
  EMAIL = 'EMAIL',
  SLACK = 'SLACK',
  WEBHOOK = 'WEBHOOK',
}

// Audit
export enum AuditAction {
  CREATE = 'CREATE',
  READ = 'READ',
  UPDATE = 'UPDATE',
  DELETE = 'DELETE',
  LOGIN = 'LOGIN',
  LOGOUT = 'LOGOUT',
  EXPORT = 'EXPORT',
  SHARE = 'SHARE',
  AI_QUERY = 'AI_QUERY',
}

// WebSocket Events
export enum WebSocketEvent {
  CONNECTION = 'connection',
  DISCONNECT = 'disconnect',
  MESSAGE_STREAM = 'message:stream',
  MESSAGE_COMPLETE = 'message:complete',
  MESSAGE_ERROR = 'message:error',
  TYPING_START = 'typing:start',
  TYPING_STOP = 'typing:stop',
  NOTIFICATION = 'notification',
  PRESENCE_UPDATE = 'presence:update',
}

// Job Queue
export enum JobType {
  DOCUMENT_INGESTION = 'DOCUMENT_INGESTION',
  SOURCE_SYNC = 'SOURCE_SYNC',
  REPORT_GENERATION = 'REPORT_GENERATION',
  EMAIL_SEND = 'EMAIL_SEND',
  NOTIFICATION_SEND = 'NOTIFICATION_SEND',
  EMBEDDING_GENERATE = 'EMBEDDING_GENERATE',
}

export enum JobStatus {
  PENDING = 'PENDING',
  PROCESSING = 'PROCESSING',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED',
  RETRYING = 'RETRYING',
}
