// ============================================
// Requi Health - WebSocket Event Types
// ============================================

import { WebSocketEvent, ConfidenceLevel } from '../enums';
import { Citation, MissingKnowledge } from '../models';

// ============================================
// Client -> Server Events
// ============================================

export interface JoinConversationPayload {
  conversationId: string;
  workspaceId: string;
}

export interface LeaveConversationPayload {
  conversationId: string;
}

export interface SendStreamMessagePayload {
  content: string;
  conversationId: string;
  workspaceId: string;
  messageId?: string;
}

export interface TypingPayload {
  conversationId: string;
  isTyping: boolean;
}

export interface SubscribeNotificationsPayload {
  channels: string[];
}

// ============================================
// Server -> Client Events
// ============================================

export interface MessageStreamChunk {
  type: 'chunk';
  messageId: string;
  conversationId: string;
  content: string;
  index: number;
}

export interface MessageStreamCitation {
  type: 'citation';
  messageId: string;
  conversationId: string;
  citation: Citation;
}

export interface MessageStreamConfidence {
  type: 'confidence';
  messageId: string;
  conversationId: string;
  confidence: ConfidenceLevel;
  reasoning?: string;
}

export interface MessageStreamGap {
  type: 'gap';
  messageId: string;
  conversationId: string;
  gap: MissingKnowledge;
}

export interface MessageStreamComplete {
  type: 'complete';
  messageId: string;
  conversationId: string;
  finalContent: string;
  citations: Citation[];
  confidence: ConfidenceLevel;
  gapsDetected: MissingKnowledge[];
  metadata: {
    tokensUsed: number;
    processingTimeMs: number;
    model: string;
  };
}

export interface MessageStreamError {
  type: 'error';
  messageId: string;
  conversationId: string;
  error: {
    code: string;
    message: string;
  };
}

export type MessageStreamEvent =
  | MessageStreamChunk
  | MessageStreamCitation
  | MessageStreamConfidence
  | MessageStreamGap
  | MessageStreamComplete
  | MessageStreamError;

export interface TypingIndicator {
  conversationId: string;
  userId: string;
  isTyping: boolean;
  timestamp: string;
}

export interface PresenceUpdate {
  userId: string;
  status: 'online' | 'away' | 'offline';
  lastSeen?: string;
}

export interface RealtimeNotification {
  id: string;
  type: string;
  title: string;
  message: string;
  data?: Record<string, unknown>;
  timestamp: string;
}

// ============================================
// WebSocket Response Types
// ============================================

export interface WebSocketAcknowledgment {
  success: boolean;
  error?: string;
  timestamp: string;
}

export interface ConnectionEstablished {
  connectionId: string;
  userId: string;
  timestamp: string;
}

// ============================================
// Event Type Mapping
// ============================================

export interface ClientToServerEvents {
  [WebSocketEvent.CONNECTION]: () => void;
  'conversation:join': (payload: JoinConversationPayload) => void;
  'conversation:leave': (payload: LeaveConversationPayload) => void;
  'message:send': (payload: SendStreamMessagePayload) => void;
  'typing': (payload: TypingPayload) => void;
  'notifications:subscribe': (payload: SubscribeNotificationsPayload) => void;
}

export interface ServerToClientEvents {
  'connection:established': (data: ConnectionEstablished) => void;
  [WebSocketEvent.MESSAGE_STREAM]: (event: MessageStreamEvent) => void;
  [WebSocketEvent.TYPING_START]: (data: TypingIndicator) => void;
  [WebSocketEvent.TYPING_STOP]: (data: TypingIndicator) => void;
  [WebSocketEvent.NOTIFICATION]: (notification: RealtimeNotification) => void;
  [WebSocketEvent.PRESENCE_UPDATE]: (update: PresenceUpdate) => void;
  [WebSocketEvent.MESSAGE_ERROR]: (error: MessageStreamError) => void;
}

// ============================================
// Socket Data Types
// ============================================

export interface SocketUserData {
  userId: string;
  organizationId: string;
  role: string;
  workspaces: string[];
}

export interface SocketRoomData {
  roomId: string;
  type: 'conversation' | 'workspace' | 'organization';
  participants: string[];
}
