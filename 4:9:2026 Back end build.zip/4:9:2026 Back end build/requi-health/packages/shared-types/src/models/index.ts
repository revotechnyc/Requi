// ============================================
// Requi Health - Shared Model Types
// ============================================

import {
  UserRole,
  OrganizationStatus,
  SubscriptionTier,
  AuthorityTier,
  SourceType,
  SourceStatus,
  ConfidenceLevel,
  CitationType,
  MissingKnowledgeStatus,
  MissingKnowledgePriority,
  TaskStatus,
  TaskType,
  DocumentType,
  IngestionStatus,
  TemplateType,
  NotificationType,
  NotificationChannel,
  AuditAction,
  JobType,
  JobStatus,
} from '../enums';

// ============================================
// User & Organization Models
// ============================================

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  avatarUrl?: string;
  role: UserRole;
  organizationId: string;
  isActive: boolean;
  lastLoginAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface Organization {
  id: string;
  name: string;
  slug: string;
  logoUrl?: string;
  status: OrganizationStatus;
  subscriptionTier: SubscriptionTier;
  settings: OrganizationSettings;
  createdAt: Date;
  updatedAt: Date;
}

export interface OrganizationSettings {
  defaultWorkspaceId?: string;
  allowedDomains?: string[];
  requireMfa: boolean;
  sessionTimeoutMinutes: number;
  maxWorkspaces: number;
  maxUsers: number;
  maxStorageGb: number;
  features: FeatureFlags;
}

export interface FeatureFlags {
  aiChat: boolean;
  documentUpload: boolean;
  teamCollaboration: boolean;
  apiAccess: boolean;
  advancedAnalytics: boolean;
  customBranding: boolean;
  sso: boolean;
  auditLogs: boolean;
}

export interface Workspace {
  id: string;
  name: string;
  description?: string;
  organizationId: string;
  settings: WorkspaceSettings;
  createdAt: Date;
  updatedAt: Date;
}

export interface WorkspaceSettings {
  defaultSourceIds: string[];
  jurisdictionFilters: string[];
  topicFilters: string[];
  confidenceThreshold: ConfidenceLevel;
}

export interface Team {
  id: string;
  name: string;
  description?: string;
  workspaceId: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface TeamMember {
  id: string;
  teamId: string;
  userId: string;
  role: UserRole;
  joinedAt: Date;
}

// ============================================
// Conversation & Message Models
// ============================================

export interface Conversation {
  id: string;
  title: string;
  workspaceId: string;
  userId: string;
  metadata?: ConversationMetadata;
  isArchived: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface ConversationMetadata {
  topic?: string;
  jurisdiction?: string;
  programType?: string;
  tags?: string[];
}

export interface Message {
  id: string;
  conversationId: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  citations?: Citation[];
  confidence?: ConfidenceLevel;
  metadata?: MessageMetadata;
  tokensUsed?: number;
  processingTimeMs?: number;
  createdAt: Date;
}

export interface MessageMetadata {
  model?: string;
  temperature?: number;
  sourcesUsed?: string[];
  gapsDetected?: string[];
}

export interface Citation {
  id: string;
  messageId: string;
  sourceId: string;
  chunkIndex: number;
  excerpt: string;
  location?: string;
  type: CitationType;
  relevanceScore: number;
}

// ============================================
// Source Models
// ============================================

export interface Source {
  id: string;
  title: string;
  description?: string;
  type: SourceType;
  authorityTier: AuthorityTier;
  url?: string;
  documentUrl?: string;
  jurisdiction?: string;
  program?: string;
  effectiveDate?: Date;
  expirationDate?: Date;
  version?: string;
  metadata?: SourceMetadata;
  status: SourceStatus;
  organizationId?: string;
  isGlobal: boolean;
  chunkCount: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface SourceMetadata {
  author?: string;
  publisher?: string;
  citation?: string;
  keywords?: string[];
  relatedSources?: string[];
  parentSourceId?: string;
}

export interface SourceChunk {
  id: string;
  sourceId: string;
  index: number;
  content: string;
  embedding?: number[];
  tokenCount: number;
  metadata?: ChunkMetadata;
}

export interface ChunkMetadata {
  section?: string;
  pageNumber?: number;
  heading?: string;
}

// ============================================
// Missing Knowledge Models
// ============================================

export interface MissingKnowledge {
  id: string;
  query: string;
  detectedAt: Date;
  conversationId: string;
  messageId: string;
  status: MissingKnowledgeStatus;
  priority: MissingKnowledgePriority;
  suggestedSources?: string[];
  resolution?: KnowledgeResolution;
  assignedTo?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface KnowledgeResolution {
  resolvedAt: Date;
  resolvedBy: string;
  sourceId?: string;
  notes?: string;
}

// ============================================
// Task Models
// ============================================

export interface Task {
  id: string;
  type: TaskType;
  title: string;
  description?: string;
  status: TaskStatus;
  priority: MissingKnowledgePriority;
  assigneeId?: string;
  creatorId: string;
  workspaceId: string;
  dueDate?: Date;
  completedAt?: Date;
  metadata?: TaskMetadata;
  createdAt: Date;
  updatedAt: Date;
}

export interface TaskMetadata {
  relatedSourceId?: string;
  relatedKnowledgeGapId?: string;
  reviewNotes?: string;
}

// ============================================
// Document Models
// ============================================

export interface Document {
  id: string;
  filename: string;
  originalName: string;
  mimeType: string;
  size: number;
  type: DocumentType;
  url: string;
  status: IngestionStatus;
  organizationId: string;
  uploadedBy: string;
  metadata?: DocumentMetadata;
  errorMessage?: string;
  processedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface DocumentMetadata {
  pageCount?: number;
  wordCount?: number;
  author?: string;
  title?: string;
  extractedText?: string;
}

// ============================================
// Template Models
// ============================================

export interface Template {
  id: string;
  name: string;
  description?: string;
  type: TemplateType;
  category: string;
  content: string;
  variables: TemplateVariable[];
  jurisdiction?: string;
  program?: string;
  isGlobal: boolean;
  organizationId?: string;
  createdBy: string;
  usageCount: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface TemplateVariable {
  name: string;
  type: 'text' | 'number' | 'date' | 'select' | 'multiselect';
  label: string;
  required: boolean;
  defaultValue?: string;
  options?: string[];
}

// ============================================
// Billing Models
// ============================================

export interface Subscription {
  id: string;
  organizationId: string;
  tier: SubscriptionTier;
  stripeSubscriptionId?: string;
  stripeCustomerId?: string;
  status: string;
  currentPeriodStart: Date;
  currentPeriodEnd: Date;
  cancelAtPeriodEnd: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface UsageRecord {
  id: string;
  organizationId: string;
  date: Date;
  aiQueries: number;
  documentsUploaded: number;
  storageBytes: number;
  apiCalls: number;
  estimatedCost: number;
}

// ============================================
// Notification Models
// ============================================

export interface Notification {
  id: string;
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  data?: NotificationData;
  channels: NotificationChannel[];
  isRead: boolean;
  readAt?: Date;
  createdAt: Date;
}

export interface NotificationData {
  link?: string;
  actionText?: string;
  relatedId?: string;
  relatedType?: string;
}

// ============================================
// Audit Models
// ============================================

export interface AuditLog {
  id: string;
  organizationId: string;
  userId?: string;
  action: AuditAction;
  resourceType: string;
  resourceId?: string;
  metadata?: AuditMetadata;
  ipAddress?: string;
  userAgent?: string;
  createdAt: Date;
}

export interface AuditMetadata {
  previousValues?: Record<string, unknown>;
  newValues?: Record<string, unknown>;
  reason?: string;
}

// ============================================
// Job Queue Models
// ============================================

export interface Job {
  id: string;
  type: JobType;
  payload: Record<string, unknown>;
  status: JobStatus;
  priority: number;
  attempts: number;
  maxAttempts: number;
  errorMessage?: string;
  stackTrace?: string;
  processedAt?: Date;
  completedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

// ============================================
// Search & Retrieval Models
// ============================================

export interface SearchResult {
  chunk: SourceChunk;
  source: Source;
  score: number;
  distance?: number;
}

export interface RetrievedSource {
  source: Source;
  chunks: SourceChunk[];
  relevanceScore: number;
}

// ============================================
// AI Response Models
// ============================================

export interface AIResponse {
  content: string;
  citations: Citation[];
  confidence: ConfidenceLevel;
  gapsDetected: MissingKnowledge[];
  sourcesUsed: string[];
  metadata: AIResponseMetadata;
}

export interface AIResponseMetadata {
  model: string;
  tokensUsed: number;
  promptTokens: number;
  completionTokens: number;
  processingTimeMs: number;
  temperature: number;
}

export interface StreamingChunk {
  type: 'content' | 'citation' | 'confidence' | 'error' | 'complete';
  data: unknown;
}
