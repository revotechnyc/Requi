// ============================================
// Requi Health - API Request/Response Types
// ============================================

import {
  User,
  Organization,
  Workspace,
  Team,
  Conversation,
  Message,
  Source,
  MissingKnowledge,
  Task,
  Document,
  Template,
  Notification,
  AuditLog,
  Subscription,
  UsageRecord,
  AIResponse,
  SearchResult,
} from '../models';
import {
  UserRole,
  SubscriptionTier,
  AuthorityTier,
  SourceType,
  SourceStatus,
  ConfidenceLevel,
  MissingKnowledgeStatus,
  MissingKnowledgePriority,
  TaskStatus,
  TemplateType,
  IngestionStatus,
} from '../enums';

// ============================================
// Common Types
// ============================================

export interface PaginationParams {
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
}

export interface ApiError {
  code: string;
  message: string;
  details?: Record<string, string[]>;
  timestamp: string;
  path: string;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: ApiError;
  meta?: Record<string, unknown>;
}

// ============================================
// Auth API
// ============================================

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  user: User;
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}

export interface RegisterRequest {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  organizationName?: string;
}

export interface RefreshTokenRequest {
  refreshToken: string;
}

export interface RefreshTokenResponse {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}

export interface ChangePasswordRequest {
  currentPassword: string;
  newPassword: string;
}

export interface ForgotPasswordRequest {
  email: string;
}

export interface ResetPasswordRequest {
  token: string;
  newPassword: string;
}

// ============================================
// User API
// ============================================

export interface UpdateUserRequest {
  firstName?: string;
  lastName?: string;
  avatarUrl?: string;
}

export interface UpdateUserRoleRequest {
  userId: string;
  role: UserRole;
}

export interface ListUsersParams extends PaginationParams {
  search?: string;
  role?: UserRole;
  isActive?: boolean;
}

export type ListUsersResponse = PaginatedResponse<User>;

// ============================================
// Organization API
// ============================================

export interface CreateOrganizationRequest {
  name: string;
  slug: string;
}

export interface UpdateOrganizationRequest {
  name?: string;
  logoUrl?: string;
  settings?: Partial<Organization['settings']>;
}

export interface UpdateSubscriptionRequest {
  tier: SubscriptionTier;
  interval: 'monthly' | 'annual';
}

export interface OrganizationUsageResponse {
  current: {
    aiQueries: number;
    documentsUploaded: number;
    storageBytes: number;
    apiCalls: number;
  };
  limits: {
    aiQueries: number;
    documentsUploaded: number;
    storageBytes: number;
    apiCalls: number;
  };
  period: {
    start: string;
    end: string;
  };
}

// ============================================
// Workspace API
// ============================================

export interface CreateWorkspaceRequest {
  name: string;
  description?: string;
  settings?: Partial<Workspace['settings']>;
}

export interface UpdateWorkspaceRequest {
  name?: string;
  description?: string;
  settings?: Partial<Workspace['settings']>;
}

export interface ListWorkspacesParams extends PaginationParams {
  search?: string;
}

export type ListWorkspacesResponse = PaginatedResponse<Workspace>;

// ============================================
// Team API
// ============================================

export interface CreateTeamRequest {
  name: string;
  description?: string;
}

export interface UpdateTeamRequest {
  name?: string;
  description?: string;
}

export interface AddTeamMemberRequest {
  userId: string;
  role: UserRole;
}

export interface ListTeamsParams extends PaginationParams {
  workspaceId?: string;
}

export type ListTeamsResponse = PaginatedResponse<Team>;

// ============================================
// Conversation API
// ============================================

export interface CreateConversationRequest {
  title?: string;
  workspaceId: string;
  metadata?: Conversation['metadata'];
}

export interface UpdateConversationRequest {
  title?: string;
  metadata?: Conversation['metadata'];
  isArchived?: boolean;
}

export interface ListConversationsParams extends PaginationParams {
  workspaceId?: string;
  search?: string;
  isArchived?: boolean;
}

export type ListConversationsResponse = PaginatedResponse<Conversation>;

// ============================================
// Message API
// ============================================

export interface SendMessageRequest {
  content: string;
  conversationId: string;
  workspaceId: string;
}

export interface SendMessageResponse {
  message: Message;
  aiResponse?: AIResponse;
}

export interface StreamMessageRequest {
  content: string;
  conversationId: string;
  workspaceId: string;
}

export interface ListMessagesParams extends PaginationParams {
  conversationId: string;
}

export type ListMessagesResponse = PaginatedResponse<Message>;

// ============================================
// Source API
// ============================================

export interface CreateSourceRequest {
  title: string;
  description?: string;
  type: SourceType;
  authorityTier: AuthorityTier;
  url?: string;
  jurisdiction?: string;
  program?: string;
  effectiveDate?: string;
  expirationDate?: string;
  version?: string;
  metadata?: Source['metadata'];
  isGlobal?: boolean;
}

export interface UpdateSourceRequest {
  title?: string;
  description?: string;
  authorityTier?: AuthorityTier;
  url?: string;
  jurisdiction?: string;
  program?: string;
  effectiveDate?: string;
  expirationDate?: string;
  version?: string;
  metadata?: Source['metadata'];
  status?: SourceStatus;
}

export interface ListSourcesParams extends PaginationParams {
  search?: string;
  type?: SourceType;
  authorityTier?: AuthorityTier;
  jurisdiction?: string;
  program?: string;
  status?: SourceStatus;
  isGlobal?: boolean;
}

export type ListSourcesResponse = PaginatedResponse<Source>;

export interface SourceSearchRequest {
  query: string;
  workspaceId: string;
  filters?: {
    authorityTiers?: AuthorityTier[];
    types?: SourceType[];
    jurisdictions?: string[];
    programs?: string[];
  };
  topK?: number;
}

export interface SourceSearchResponse {
  results: SearchResult[];
  total: number;
  query: string;
  processingTimeMs: number;
}

// ============================================
// Missing Knowledge API
// ============================================

export interface UpdateMissingKnowledgeRequest {
  status?: MissingKnowledgeStatus;
  priority?: MissingKnowledgePriority;
  assignedTo?: string;
  resolution?: {
    sourceId?: string;
    notes?: string;
  };
}

export interface ListMissingKnowledgeParams extends PaginationParams {
  workspaceId?: string;
  status?: MissingKnowledgeStatus;
  priority?: MissingKnowledgePriority;
  assignedTo?: string;
}

export type ListMissingKnowledgeResponse = PaginatedResponse<MissingKnowledge>;

export interface KnowledgeGapStatsResponse {
  total: number;
  byStatus: Record<MissingKnowledgeStatus, number>;
  byPriority: Record<MissingKnowledgePriority, number>;
  resolvedThisMonth: number;
  averageResolutionTimeHours: number;
}

// ============================================
// Task API
// ============================================

export interface CreateTaskRequest {
  type: Task['type'];
  title: string;
  description?: string;
  priority: MissingKnowledgePriority;
  assigneeId?: string;
  dueDate?: string;
  metadata?: Task['metadata'];
}

export interface UpdateTaskRequest {
  title?: string;
  description?: string;
  status?: TaskStatus;
  priority?: MissingKnowledgePriority;
  assigneeId?: string;
  dueDate?: string;
  metadata?: Task['metadata'];
}

export interface ListTasksParams extends PaginationParams {
  workspaceId?: string;
  status?: TaskStatus;
  priority?: MissingKnowledgePriority;
  assigneeId?: string;
  type?: Task['type'];
}

export type ListTasksResponse = PaginatedResponse<Task>;

// ============================================
// Document API
// ============================================

export interface UploadDocumentResponse {
  document: Document;
  uploadUrl: string;
}

export interface ListDocumentsParams extends PaginationParams {
  search?: string;
  status?: IngestionStatus;
  type?: string;
}

export type ListDocumentsResponse = PaginatedResponse<Document>;

export interface DocumentIngestionStatusResponse {
  document: Document;
  progress: {
    stage: IngestionStatus;
    percentage: number;
    chunksProcessed?: number;
    totalChunks?: number;
  };
}

// ============================================
// Template API
// ============================================

export interface CreateTemplateRequest {
  name: string;
  description?: string;
  type: TemplateType;
  category: string;
  content: string;
  variables: Template['variables'];
  jurisdiction?: string;
  program?: string;
}

export interface UpdateTemplateRequest {
  name?: string;
  description?: string;
  content?: string;
  variables?: Template['variables'];
  jurisdiction?: string;
  program?: string;
}

export interface ListTemplatesParams extends PaginationParams {
  search?: string;
  type?: TemplateType;
  category?: string;
  jurisdiction?: string;
  program?: string;
}

export type ListTemplatesResponse = PaginatedResponse<Template>;

export interface GenerateFromTemplateRequest {
  templateId: string;
  variables: Record<string, string | number | boolean | string[]>;
}

export interface GenerateFromTemplateResponse {
  generatedContent: string;
  template: Template;
}

// ============================================
// Notification API
// ============================================

export interface ListNotificationsParams extends PaginationParams {
  isRead?: boolean;
  type?: string;
}

export type ListNotificationsResponse = PaginatedResponse<Notification>;

export interface MarkNotificationsReadRequest {
  notificationIds: string[];
}

export interface UpdateNotificationPreferencesRequest {
  channels: string[];
  types: string[];
}

// ============================================
// Audit API
// ============================================

export interface ListAuditLogsParams extends PaginationParams {
  userId?: string;
  action?: string;
  resourceType?: string;
  startDate?: string;
  endDate?: string;
}

export type ListAuditLogsResponse = PaginatedResponse<AuditLog>;

// ============================================
// Billing API
// ============================================

export interface CreateSubscriptionRequest {
  tier: SubscriptionTier;
  paymentMethodId: string;
}

export interface UpdateSubscriptionRequest {
  tier?: SubscriptionTier;
  paymentMethodId?: string;
}

export interface CancelSubscriptionRequest {
  atPeriodEnd: boolean;
}

export interface ListUsageParams {
  startDate: string;
  endDate: string;
}

export interface ListUsageResponse {
  records: UsageRecord[];
  summary: {
    totalAiQueries: number;
    totalDocuments: number;
    totalStorageBytes: number;
    totalApiCalls: number;
    totalEstimatedCost: number;
  };
}

export interface BillingPortalResponse {
  url: string;
}

// ============================================
// Admin API
// ============================================

export interface AdminStatsResponse {
  users: {
    total: number;
    active: number;
    newThisMonth: number;
  };
  organizations: {
    total: number;
    byTier: Record<SubscriptionTier, number>;
  };
  sources: {
    total: number;
    byType: Record<SourceType, number>;
    byTier: Record<AuthorityTier, number>;
  };
  conversations: {
    total: number;
    thisMonth: number;
    avgMessagesPerConversation: number;
  };
  knowledgeGaps: {
    total: number;
    open: number;
    resolvedThisMonth: number;
  };
}

export interface AdminCreateSourceRequest extends CreateSourceRequest {
  documentContent?: string;
}

export interface AdminBulkImportRequest {
  sources: CreateSourceRequest[];
}

export interface AdminBulkImportResponse {
  successful: number;
  failed: number;
  errors: Array<{
    index: number;
    error: string;
  }>;
}

// ============================================
// Health API
// ============================================

export interface HealthCheckResponse {
  status: 'healthy' | 'degraded' | 'unhealthy';
  timestamp: string;
  version: string;
  services: {
    database: 'connected' | 'disconnected';
    redis: 'connected' | 'disconnected';
    pinecone: 'connected' | 'disconnected';
    claude: 'connected' | 'disconnected';
  };
  metrics?: {
    uptime: number;
    memoryUsage: number;
    cpuUsage: number;
  };
}
