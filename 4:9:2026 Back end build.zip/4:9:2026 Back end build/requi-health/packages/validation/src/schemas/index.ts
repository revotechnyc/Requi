// ============================================
// Requi Health - Zod Validation Schemas
// ============================================

import { z } from 'zod';

// ============================================
// Common Schemas
// ============================================

export const PaginationSchema = z.object({
  page: z.coerce.number().min(1).default(1),
  limit: z.coerce.number().min(1).max(100).default(20),
  sortBy: z.string().optional(),
  sortOrder: z.enum(['asc', 'desc']).default('desc'),
});

export const UuidSchema = z.string().uuid();

export const DateRangeSchema = z.object({
  startDate: z.string().datetime().optional(),
  endDate: z.string().datetime().optional(),
});

// ============================================
// Auth Schemas
// ============================================

export const LoginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
});

export const RegisterSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
    .regex(/[0-9]/, 'Password must contain at least one number'),
  firstName: z.string().min(1, 'First name is required'),
  lastName: z.string().min(1, 'Last name is required'),
  organizationName: z.string().optional(),
});

export const RefreshTokenSchema = z.object({
  refreshToken: z.string().min(1, 'Refresh token is required'),
});

export const ChangePasswordSchema = z.object({
  currentPassword: z.string().min(1, 'Current password is required'),
  newPassword: z
    .string()
    .min(8, 'New password must be at least 8 characters')
    .regex(/[A-Z]/, 'New password must contain at least one uppercase letter')
    .regex(/[a-z]/, 'New password must contain at least one lowercase letter')
    .regex(/[0-9]/, 'New password must contain at least one number'),
});

export const ForgotPasswordSchema = z.object({
  email: z.string().email('Invalid email address'),
});

export const ResetPasswordSchema = z.object({
  token: z.string().min(1, 'Token is required'),
  newPassword: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
    .regex(/[0-9]/, 'Password must contain at least one number'),
});

// ============================================
// User Schemas
// ============================================

export const UpdateUserSchema = z.object({
  firstName: z.string().min(1).optional(),
  lastName: z.string().min(1).optional(),
  avatarUrl: z.string().url().optional().or(z.literal('')),
});

export const UpdateUserRoleSchema = z.object({
  userId: UuidSchema,
  role: z.enum(['SUPER_ADMIN', 'ADMIN', 'MANAGER', 'ANALYST', 'VIEWER']),
});

export const ListUsersSchema = PaginationSchema.extend({
  search: z.string().optional(),
  role: z.enum(['SUPER_ADMIN', 'ADMIN', 'MANAGER', 'ANALYST', 'VIEWER']).optional(),
  isActive: z.coerce.boolean().optional(),
});

// ============================================
// Organization Schemas
// ============================================

export const CreateOrganizationSchema = z.object({
  name: z.string().min(1, 'Organization name is required'),
  slug: z
    .string()
    .min(3, 'Slug must be at least 3 characters')
    .regex(/^[a-z0-9-]+$/, 'Slug can only contain lowercase letters, numbers, and hyphens'),
});

export const UpdateOrganizationSchema = z.object({
  name: z.string().min(1).optional(),
  logoUrl: z.string().url().optional().or(z.literal('')),
  settings: z
    .object({
      requireMfa: z.boolean().optional(),
      sessionTimeoutMinutes: z.number().min(5).max(480).optional(),
      maxWorkspaces: z.number().min(1).optional(),
      maxUsers: z.number().min(1).optional(),
      maxStorageGb: z.number().min(1).optional(),
    })
    .optional(),
});

export const UpdateSubscriptionSchema = z.object({
  tier: z.enum(['FREE', 'PROFESSIONAL', 'ENTERPRISE']),
  interval: z.enum(['monthly', 'annual']),
});

// ============================================
// Workspace Schemas
// ============================================

export const CreateWorkspaceSchema = z.object({
  name: z.string().min(1, 'Workspace name is required'),
  description: z.string().optional(),
  settings: z
    .object({
      defaultSourceIds: z.array(UuidSchema).optional(),
      jurisdictionFilters: z.array(z.string()).optional(),
      topicFilters: z.array(z.string()).optional(),
      confidenceThreshold: z.enum(['HIGH', 'MEDIUM', 'LOW', 'UNSUPPORTED']).optional(),
    })
    .optional(),
});

export const UpdateWorkspaceSchema = z.object({
  name: z.string().min(1).optional(),
  description: z.string().optional(),
  settings: z
    .object({
      defaultSourceIds: z.array(UuidSchema).optional(),
      jurisdictionFilters: z.array(z.string()).optional(),
      topicFilters: z.array(z.string()).optional(),
      confidenceThreshold: z.enum(['HIGH', 'MEDIUM', 'LOW', 'UNSUPPORTED']).optional(),
    })
    .optional(),
});

export const ListWorkspacesSchema = PaginationSchema.extend({
  search: z.string().optional(),
});

// ============================================
// Team Schemas
// ============================================

export const CreateTeamSchema = z.object({
  name: z.string().min(1, 'Team name is required'),
  description: z.string().optional(),
});

export const UpdateTeamSchema = z.object({
  name: z.string().min(1).optional(),
  description: z.string().optional(),
});

export const AddTeamMemberSchema = z.object({
  userId: UuidSchema,
  role: z.enum(['ADMIN', 'MANAGER', 'ANALYST', 'VIEWER']),
});

export const ListTeamsSchema = PaginationSchema.extend({
  workspaceId: UuidSchema.optional(),
});

// ============================================
// Conversation Schemas
// ============================================

export const CreateConversationSchema = z.object({
  workspaceId: UuidSchema,
  title: z.string().optional(),
  initialMessage: z.string().optional(),
  filters: z
    .object({
      jurisdictions: z.array(z.string()).optional(),
      authorityTiers: z.array(z.string()).optional(),
      sourceTypes: z.array(z.string()).optional(),
      dateRange: z
        .object({
          from: z.string().datetime().optional(),
          to: z.string().datetime().optional(),
        })
        .optional(),
    })
    .optional(),
});

export const UpdateConversationSchema = z.object({
  title: z.string().optional(),
  filters: z
    .object({
      jurisdictions: z.array(z.string()).optional(),
      authorityTiers: z.array(z.string()).optional(),
      sourceTypes: z.array(z.string()).optional(),
      dateRange: z
        .object({
          from: z.string().datetime().optional(),
          to: z.string().datetime().optional(),
        })
        .optional(),
    })
    .optional(),
});

export const ListConversationsSchema = PaginationSchema.extend({
  workspaceId: UuidSchema.optional(),
  search: z.string().optional(),
  isArchived: z.coerce.boolean().optional(),
});

// ============================================
// Message Schemas
// ============================================

export const sendMessageSchema = z.object({
  content: z.string().min(1, 'Message content is required').max(10000, 'Message too long'),
  filters: z
    .object({
      jurisdictions: z.array(z.string()).optional(),
      authorityTiers: z.array(z.string()).optional(),
      sourceTypes: z.array(z.string()).optional(),
      dateRange: z
        .object({
          from: z.string().datetime().optional(),
          to: z.string().datetime().optional(),
        })
        .optional(),
    })
    .optional(),
});

export const StreamMessageSchema = z.object({
  content: z.string().min(1, 'Message content is required').max(10000, 'Message too long'),
  conversationId: UuidSchema,
  workspaceId: UuidSchema,
  messageId: UuidSchema.optional(),
});

export const ListMessagesSchema = PaginationSchema.extend({
  conversationId: UuidSchema,
});

// ============================================
// Source Schemas
// ============================================

export const CreateSourceSchema = z.object({
  title: z.string().min(1, 'Title is required'),
  description: z.string().optional(),
  type: z.enum([
    'FEDERAL_STATUTE',
    'FEDERAL_REGULATION',
    'FEDERAL_GUIDANCE',
    'STATE_STATUTE',
    'STATE_REGULATION',
    'STATE_GUIDANCE',
    'PROGRAM_DOCUMENT',
    'CONTRACT',
    'CASE_LAW',
    'ACADEMIC',
    'BEST_PRACTICE',
    'INTERNAL_POLICY',
  ]),
  authorityTier: z.enum([
    'TIER_1_BINDING_PRIMARY',
    'TIER_2_BINDING_SECONDARY',
    'TIER_3_AUTHORITATIVE_GUIDANCE',
    'TIER_4_OFFICIAL_REFERENCE',
    'TIER_5_PROFESSIONAL_CONTENT',
    'TIER_6_GENERAL_SEARCH',
  ]),
  url: z.string().url().optional().or(z.literal('')),
  jurisdiction: z.string().optional(),
  program: z.string().optional(),
  effectiveDate: z.string().datetime().optional(),
  expirationDate: z.string().datetime().optional(),
  version: z.string().optional(),
  metadata: z
    .object({
      author: z.string().optional(),
      publisher: z.string().optional(),
      citation: z.string().optional(),
      keywords: z.array(z.string()).optional(),
      relatedSources: z.array(z.string()).optional(),
      parentSourceId: z.string().optional(),
    })
    .optional(),
  isGlobal: z.boolean().default(false),
});

export const UpdateSourceSchema = z.object({
  title: z.string().min(1).optional(),
  description: z.string().optional(),
  authorityTier: z.enum([
    'TIER_1_BINDING_PRIMARY',
    'TIER_2_BINDING_SECONDARY',
    'TIER_3_AUTHORITATIVE_GUIDANCE',
    'TIER_4_OFFICIAL_REFERENCE',
    'TIER_5_PROFESSIONAL_CONTENT',
    'TIER_6_GENERAL_SEARCH',
  ]).optional(),
  url: z.string().url().optional().or(z.literal('')),
  jurisdiction: z.string().optional(),
  program: z.string().optional(),
  effectiveDate: z.string().datetime().optional(),
  expirationDate: z.string().datetime().optional(),
  version: z.string().optional(),
  metadata: z
    .object({
      author: z.string().optional(),
      publisher: z.string().optional(),
      citation: z.string().optional(),
      keywords: z.array(z.string()).optional(),
      relatedSources: z.array(z.string()).optional(),
      parentSourceId: z.string().optional(),
    })
    .optional(),
  status: z.enum(['ACTIVE', 'DEPRECATED', 'PENDING_REVIEW', 'ARCHIVED']).optional(),
});

export const ListSourcesSchema = PaginationSchema.extend({
  search: z.string().optional(),
  type: z.enum([
    'FEDERAL_STATUTE',
    'FEDERAL_REGULATION',
    'FEDERAL_GUIDANCE',
    'STATE_STATUTE',
    'STATE_REGULATION',
    'STATE_GUIDANCE',
    'PROGRAM_DOCUMENT',
    'CONTRACT',
    'CASE_LAW',
    'ACADEMIC',
    'BEST_PRACTICE',
    'INTERNAL_POLICY',
  ]).optional(),
  authorityTier: z.enum([
    'TIER_1_BINDING_PRIMARY',
    'TIER_2_BINDING_SECONDARY',
    'TIER_3_AUTHORITATIVE_GUIDANCE',
    'TIER_4_OFFICIAL_REFERENCE',
    'TIER_5_PROFESSIONAL_CONTENT',
    'TIER_6_GENERAL_SEARCH',
  ]).optional(),
  jurisdiction: z.string().optional(),
  program: z.string().optional(),
  status: z.enum(['ACTIVE', 'DEPRECATED', 'PENDING_REVIEW', 'ARCHIVED']).optional(),
  isGlobal: z.coerce.boolean().optional(),
});

export const SourceSearchSchema = z.object({
  query: z.string().min(1, 'Search query is required'),
  workspaceId: UuidSchema,
  filters: z
    .object({
      authorityTiers: z
        .array(
          z.enum([
            'TIER_1_BINDING_PRIMARY',
            'TIER_2_BINDING_SECONDARY',
            'TIER_3_AUTHORITATIVE_GUIDANCE',
            'TIER_4_OFFICIAL_REFERENCE',
            'TIER_5_PROFESSIONAL_CONTENT',
            'TIER_6_GENERAL_SEARCH',
          ])
        )
        .optional(),
      types: z
        .array(
          z.enum([
            'FEDERAL_STATUTE',
            'FEDERAL_REGULATION',
            'FEDERAL_GUIDANCE',
            'STATE_STATUTE',
            'STATE_REGULATION',
            'STATE_GUIDANCE',
            'PROGRAM_DOCUMENT',
            'CONTRACT',
            'CASE_LAW',
            'ACADEMIC',
            'BEST_PRACTICE',
            'INTERNAL_POLICY',
          ])
        )
        .optional(),
      jurisdictions: z.array(z.string()).optional(),
      programs: z.array(z.string()).optional(),
    })
    .optional(),
  topK: z.number().min(1).max(50).default(10),
});

// ============================================
// Missing Knowledge Schemas
// ============================================

export const UpdateMissingKnowledgeSchema = z.object({
  status: z.enum(['OPEN', 'IN_REVIEW', 'SOURCING', 'RESOLVED', 'CLOSED']).optional(),
  priority: z.enum(['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']).optional(),
  assignedTo: UuidSchema.optional(),
  resolution: z
    .object({
      sourceId: UuidSchema.optional(),
      notes: z.string().optional(),
    })
    .optional(),
});

export const ListMissingKnowledgeSchema = PaginationSchema.extend({
  workspaceId: UuidSchema.optional(),
  status: z.enum(['OPEN', 'IN_REVIEW', 'SOURCING', 'RESOLVED', 'CLOSED']).optional(),
  priority: z.enum(['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']).optional(),
  assignedTo: UuidSchema.optional(),
});

// ============================================
// Task Schemas
// ============================================

export const CreateTaskSchema = z.object({
  type: z.enum(['SOURCE_REVIEW', 'KNOWLEDGE_GAP', 'COMPLIANCE_CHECK', 'DOCUMENT_UPLOAD']),
  title: z.string().min(1, 'Title is required'),
  description: z.string().optional(),
  priority: z.enum(['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']),
  assigneeId: UuidSchema.optional(),
  dueDate: z.string().datetime().optional(),
  metadata: z
    .object({
      relatedSourceId: UuidSchema.optional(),
      relatedKnowledgeGapId: UuidSchema.optional(),
      reviewNotes: z.string().optional(),
    })
    .optional(),
});

export const UpdateTaskSchema = z.object({
  title: z.string().min(1).optional(),
  description: z.string().optional(),
  status: z.enum(['PENDING', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED']).optional(),
  priority: z.enum(['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']).optional(),
  assigneeId: UuidSchema.optional(),
  dueDate: z.string().datetime().optional(),
  metadata: z
    .object({
      relatedSourceId: UuidSchema.optional(),
      relatedKnowledgeGapId: UuidSchema.optional(),
      reviewNotes: z.string().optional(),
    })
    .optional(),
});

export const ListTasksSchema = PaginationSchema.extend({
  workspaceId: UuidSchema.optional(),
  status: z.enum(['PENDING', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED']).optional(),
  priority: z.enum(['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']).optional(),
  assigneeId: UuidSchema.optional(),
  type: z.enum(['SOURCE_REVIEW', 'KNOWLEDGE_GAP', 'COMPLIANCE_CHECK', 'DOCUMENT_UPLOAD']).optional(),
});

// ============================================
// Document Schemas
// ============================================

export const ListDocumentsSchema = PaginationSchema.extend({
  search: z.string().optional(),
  status: z.enum(['PENDING', 'PROCESSING', 'EXTRACTING', 'CHUNKING', 'EMBEDDING', 'INDEXING', 'COMPLETED', 'FAILED']).optional(),
  type: z.string().optional(),
});

// ============================================
// Template Schemas
// ============================================

export const TemplateVariableSchema = z.object({
  name: z.string().min(1),
  type: z.enum(['text', 'number', 'date', 'select', 'multiselect']),
  label: z.string().min(1),
  required: z.boolean(),
  defaultValue: z.string().optional(),
  options: z.array(z.string()).optional(),
});

export const CreateTemplateSchema = z.object({
  name: z.string().min(1, 'Template name is required'),
  description: z.string().optional(),
  type: z.enum(['POLICY', 'PROCEDURE', 'CHECKLIST', 'REPORT', 'CONTRACT']),
  category: z.string().min(1, 'Category is required'),
  content: z.string().min(1, 'Content is required'),
  variables: z.array(TemplateVariableSchema),
  jurisdiction: z.string().optional(),
  program: z.string().optional(),
});

export const UpdateTemplateSchema = z.object({
  name: z.string().min(1).optional(),
  description: z.string().optional(),
  content: z.string().min(1).optional(),
  variables: z.array(TemplateVariableSchema).optional(),
  jurisdiction: z.string().optional(),
  program: z.string().optional(),
});

export const ListTemplatesSchema = PaginationSchema.extend({
  search: z.string().optional(),
  type: z.enum(['POLICY', 'PROCEDURE', 'CHECKLIST', 'REPORT', 'CONTRACT']).optional(),
  category: z.string().optional(),
  jurisdiction: z.string().optional(),
  program: z.string().optional(),
});

export const GenerateFromTemplateSchema = z.object({
  templateId: UuidSchema,
  variables: z.record(z.union([z.string(), z.number(), z.boolean(), z.array(z.string())])),
});

// ============================================
// Notification Schemas
// ============================================

export const ListNotificationsSchema = PaginationSchema.extend({
  isRead: z.coerce.boolean().optional(),
  type: z.string().optional(),
});

export const MarkNotificationsReadSchema = z.object({
  notificationIds: z.array(UuidSchema),
});

// ============================================
// Audit Schemas
// ============================================

export const ListAuditLogsSchema = PaginationSchema.extend({
  userId: UuidSchema.optional(),
  action: z.string().optional(),
  resourceType: z.string().optional(),
  startDate: z.string().datetime().optional(),
  endDate: z.string().datetime().optional(),
});

// ============================================
// Billing Schemas
// ============================================

export const CreateSubscriptionSchema = z.object({
  tier: z.enum(['FREE', 'PROFESSIONAL', 'ENTERPRISE']),
  paymentMethodId: z.string().min(1),
});

export const UpdateSubscriptionSchema = z.object({
  tier: z.enum(['FREE', 'PROFESSIONAL', 'ENTERPRISE']).optional(),
  paymentMethodId: z.string().optional(),
});

export const CancelSubscriptionSchema = z.object({
  atPeriodEnd: z.boolean(),
});

export const ListUsageSchema = z.object({
  startDate: z.string().datetime(),
  endDate: z.string().datetime(),
});

// ============================================
// Admin Schemas
// ============================================

export const AdminCreateSourceSchema = CreateSourceSchema.extend({
  documentContent: z.string().optional(),
});

export const AdminBulkImportSchema = z.object({
  sources: z.array(CreateSourceSchema).min(1).max(100),
});

// ============================================
// WebSocket Schemas
// ============================================

export const JoinConversationSchema = z.object({
  conversationId: UuidSchema,
  workspaceId: UuidSchema,
});

export const LeaveConversationSchema = z.object({
  conversationId: UuidSchema,
});

export const TypingSchema = z.object({
  conversationId: UuidSchema,
  isTyping: z.boolean(),
});

// Export types
export type PaginationInput = z.infer<typeof PaginationSchema>;
export type LoginInput = z.infer<typeof LoginSchema>;
export type RegisterInput = z.infer<typeof RegisterSchema>;
export type SendMessageInput = z.infer<typeof SendMessageSchema>;
export type CreateSourceInput = z.infer<typeof CreateSourceSchema>;
export type CreateConversationInput = z.infer<typeof CreateConversationSchema>;
