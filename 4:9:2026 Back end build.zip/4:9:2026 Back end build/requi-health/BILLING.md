# Requi Health - Enterprise Billing System

## Overview

The Requi Health billing system implements an enterprise SaaS pricing model with the following structure:

- **Price**: $1,000 per user per month
- **Minimum**: 25 users ($25,000/month minimum)
- **Seat Increments**: 25, 50, 75, 100, 150, 200, 250, 500
- **Trial**: 30-day free trial with full access
- **Post-Trial**: Read-only access until subscription activated

## Architecture

### Database Schema

```
Organization
├── subscription (1:1)
│   ├── tier (SubscriptionTier)
│   ├── invoices (Invoice[])
│   ├── paymentMethods (PaymentMethod[])
│   ├── seatAssignments (SeatAssignment[])
│   └── billingEvents (BillingEvent[])
```

### Key Entities

- **SubscriptionTier**: Predefined pricing tiers (25, 50, 75, 100+ seats)
- **Subscription**: Organization's subscription state and Stripe IDs
- **Invoice**: Billing records synced with Stripe
- **PaymentMethod**: Stored payment methods (card, ACH)
- **SeatAssignment**: Tracks which users have assigned seats
- **BillingEvent**: Audit trail for all billing actions
- **UsageRecord**: Monthly usage metrics

## API Endpoints

### Public
- `GET /billing/tiers` - List available subscription tiers

### Authenticated
- `GET /billing/:organizationId` - Get billing info
- `POST /billing/trial/:organizationId` - Start trial
- `POST /billing/activate/:organizationId` - Convert trial to paid
- `POST /billing/upgrade/:organizationId` - Upgrade seat count
- `POST /billing/seats/assign/:organizationId` - Assign seat to user
- `POST /billing/seats/unassign/:organizationId` - Unassign seat
- `POST /billing/cancel/:organizationId` - Cancel subscription

### Webhooks
- `POST /billing/webhook` - Stripe webhook handler

## Access Control

### SubscriptionGuard
Protects routes based on subscription status:
- ✅ `TRIAL` - Full access
- ✅ `ACTIVE` - Full access
- ❌ `TRIAL_EXPIRED` - Read-only, upgrade required
- ❌ `CANCELED` - Access denied
- ❌ `UNPAID` - Access denied

### TrialGuard
Restricts advanced features during trial:
- Applied to enterprise-only features
- Shows upgrade prompt

## Scheduled Tasks

### Daily at Midnight
- `checkTrialExpirations()` - Converts expired trials to read-only

### Daily at 1 AM
- `checkUpcomingRenewals()` - Sends renewal reminders

### Daily at 3 AM
- `checkUnpaidSubscriptions()` - Suspends unpaid accounts after grace period

### Monthly (1st at 2 AM)
- `generateMonthlyUsageReports()` - Creates usage records

## Frontend Components

### Billing Page (`/admin/billing`)
- Subscription overview
- Seat usage visualization
- Payment method management
- Invoice history
- Plan upgrade modal

### Seat Manager
- Assign/unassign seats
- Usage tracking
- Bulk operations

### Onboarding Flow (`/onboarding`)
- 4-step wizard
- Organization setup
- Compliance profile
- Plan selection
- Trial activation

## Stripe Integration

### Webhook Events Handled
- `invoice.paid` - Payment successful
- `invoice.payment_failed` - Payment failed
- `customer.subscription.deleted` - Subscription canceled

### Payment Methods
- Credit cards
- ACH bank transfers
- Invoice/PO (enterprise)

## Environment Variables

```bash
# Required for billing
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PUBLISHABLE_KEY=pk_test_...
```

## Pricing Tiers

| Seats | Monthly Cost | Annual Cost |
|-------|--------------|-------------|
| 25    | $25,000      | $300,000    |
| 50    | $50,000      | $600,000    |
| 75    | $75,000      | $900,000    |
| 100   | $100,000     | $1,200,000  |
| 150   | $150,000     | $1,800,000  |
| 200   | $200,000     | $2,400,000  |
| 250   | $250,000     | $3,000,000  |
| 500   | $500,000     | $6,000,000  |

## Prorated Billing

When upgrading mid-cycle:
```
proratedCharge = (newPrice - oldPrice) × (daysRemaining / daysInPeriod)
```

Example: Upgrading from 25 to 50 seats on day 15 of 30-day cycle:
- Price difference: $25,000
- Days remaining: 15
- Prorated charge: $25,000 × (15/30) = $12,500

## Seat Management

### Assigning Seats
- Admin/Owner only
- Checks available seats
- Creates SeatAssignment record
- User gains immediate access

### Unassigning Seats
- Admin/Owner only
- Optional reason tracking
- User loses immediate access
- No refund (prorated credit on next invoice)

## Trial Flow

1. User completes onboarding
2. Trial starts (30 days)
3. Full platform access
4. Reminder emails at 7, 3, 1 days before expiration
5. Trial expires → Read-only mode
6. User upgrades → Full access restored

## Testing

### Stripe Test Cards
- Success: `4242 4242 4242 4242`
- Decline: `4000 0000 0000 0002`
- 3D Secure: `4000 0025 0000 3155`

### Test Webhook
```bash
stripe listen --forward-to localhost:3001/billing/webhook
```
