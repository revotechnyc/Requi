# Requi Health

Enterprise Healthcare Compliance AI Platform - Full-Stack Monorepo

## Architecture Overview

```
requi-health/
├── apps/
│   ├── web/              # Next.js 14 frontend
│   ├── api/              # NestJS backend API
│   └── worker/           # Background job processor
├── packages/
│   ├── shared-types/     # TypeScript contracts
│   ├── ui/               # Design system tokens
│   ├── validation/       # Zod schemas
│   └── prompts/          # AI system prompts
└── infrastructure/       # Docker, docker-compose
```

## Tech Stack

### Frontend
- **Framework**: Next.js 14 with App Router
- **Styling**: Tailwind CSS
- **State**: Zustand (client), React Query (server)
- **Forms**: React Hook Form + Zod
- **Real-time**: Socket.io client

### Backend
- **Framework**: NestJS
- **Database**: PostgreSQL with Prisma ORM
- **Cache/Queue**: Redis
- **AI**: Anthropic Claude API
- **Vector Search**: PostgreSQL pgvector
- **WebSockets**: Socket.io

### Shared
- **Types**: TypeScript contracts between frontend/backend
- **Validation**: Zod schemas
- **Prompts**: AI system prompts

## Key Features

### 1. AI-Powered Chat
- Streaming responses with real-time citations
- Confidence level assessment (HIGH/MEDIUM/LOW/UNSUPPORTED)
- Source attribution with authority tier weighting
- Missing knowledge detection

### 2. 11-Layer Authority Hierarchy
1. Federal Statutes (Binding Primary)
2. Federal Regulations (Binding Secondary)
3. Federal Guidance (Official)
4. State Statutes
5. State Regulations
6. State Guidance
7. Program Documents
8. Contracts
9. Case Law
10. Academic Sources
11. Best Practices

### 3. Document Management
- Upload PDF, Word, HTML, Markdown
- Automatic chunking and embedding
- Vector search with cosine similarity
- Source versioning

### 4. Knowledge Gap Detection
- Automatic detection from low-confidence responses
- Admin review queue
- Task assignment
- Resolution tracking with notifications

### 5. Admin Dashboard
- Source management
- Knowledge gap review
- User management
- Analytics and statistics

## Getting Started

### Prerequisites
- Node.js 20+
- pnpm 9+
- Docker & Docker Compose

### Installation

```bash
# Install dependencies
pnpm install

# Set up environment
cp .env.example .env
# Edit .env with your configuration

# Start infrastructure
docker-compose -f infrastructure/docker-compose.yml up -d

# Generate Prisma client
pnpm db:generate

# Run migrations
pnpm db:migrate

# Seed database
pnpm db:seed

# Start development
pnpm dev
```

### Development URLs
- Frontend: http://localhost:3000
- API: http://localhost:3001
- API Docs: http://localhost:3001/api/docs

## Project Structure

### Frontend (apps/web)
```
src/
├── app/                  # Next.js App Router
│   ├── (auth)/          # Auth route group
│   │   ├── login/
│   │   └── register/
│   ├── (dashboard)/     # Dashboard route group
│   │   └── workspaces/
│   ├── workspace/
│   │   └── [id]/
│   │       └── chat/
│   ├── admin/           # Admin pages
│   │   ├── sources/
│   │   ├── gaps/
│   │   └── users/
│   └── settings/
├── components/
│   └── ui/              # Reusable UI components
├── lib/
│   └── api.ts           # API client
├── stores/
│   ├── auth.ts          # Auth state
│   ├── workspace.ts     # Workspace state
│   └── chat.ts          # Chat state
└── hooks/
    └── useWebSocket.ts  # WebSocket hook
```

### Backend (apps/api)
```
src/
├── auth/                # Authentication
├── users/               # User management
├── workspaces/          # Workspace management
├── conversations/       # Chat functionality
├── sources/             # Document management
├── missing-knowledge/   # Gap detection
├── ai/                  # AI services
│   ├── claude.service.ts
│   ├── retrieval.service.ts
│   ├── prompt-builder.service.ts
│   └── response-parser.service.ts
├── vector-store/        # Vector search
├── queue/               # Job queue
├── redis/               # Redis client
├── notification/        # Notifications
├── websocket/           # WebSocket gateway
└── worker/              # Background processors
```

## API Endpoints

### Authentication
- `POST /api/v1/auth/login` - Login
- `POST /api/v1/auth/register` - Register
- `POST /api/v1/auth/refresh` - Refresh token
- `GET /api/v1/auth/me` - Get current user

### Workspaces
- `GET /api/v1/workspaces` - List workspaces
- `POST /api/v1/workspaces` - Create workspace
- `GET /api/v1/workspaces/:id` - Get workspace
- `PATCH /api/v1/workspaces/:id` - Update workspace

### Conversations
- `GET /api/v1/conversations` - List conversations
- `POST /api/v1/conversations` - Create conversation
- `GET /api/v1/conversations/:id/messages` - Get messages
- `POST /api/v1/conversations/:id/messages` - Send message
- `POST /api/v1/conversations/:id/messages/stream` - Stream message

### Sources
- `GET /api/v1/sources` - List sources
- `POST /api/v1/sources` - Create source
- `POST /api/v1/sources/upload` - Upload document
- `GET /api/v1/sources/:id` - Get source
- `DELETE /api/v1/sources/:id` - Delete source

### Missing Knowledge
- `GET /api/v1/missing-knowledge` - List gaps
- `POST /api/v1/missing-knowledge` - Create entry
- `POST /api/v1/missing-knowledge/:id/resolve` - Resolve gap

## Environment Variables

```env
# Application
NODE_ENV=development
APP_NAME=Requi Health

# Database
DATABASE_URL=postgresql://requi:requi_password@localhost:5432/requi_health

# Redis
REDIS_URL=redis://localhost:6379

# JWT
JWT_SECRET=your-jwt-secret
JWT_REFRESH_SECRET=your-refresh-secret

# Anthropic
ANTHROPIC_API_KEY=sk-ant-...
CLAUDE_MODEL=claude-3-5-sonnet-20241022

# Frontend
NEXT_PUBLIC_API_URL=http://localhost:3001
```

## Scripts

```bash
# Development
pnpm dev              # Start all apps
pnpm dev:web          # Start web only
pnpm dev:api          # Start API only
pnpm dev:worker       # Start worker only

# Build
pnpm build            # Build all apps
pnpm build:web        # Build web only
pnpm build:api        # Build API only

# Database
pnpm db:generate      # Generate Prisma client
pnpm db:migrate       # Run migrations
pnpm db:seed          # Seed database
pnpm db:studio        # Open Prisma Studio

# Docker
pnpm docker:up        # Start infrastructure
pnpm docker:down      # Stop infrastructure
pnpm docker:build     # Build Docker images
```

## License

Proprietary - Requi Health Inc.
