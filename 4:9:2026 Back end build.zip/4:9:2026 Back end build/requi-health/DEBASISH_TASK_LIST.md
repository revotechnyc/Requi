# Debasish — AWS Deployment Task List
## Requi Health Platform Launch

---

## Executive Summary

This document provides a day-by-day breakdown of tasks for deploying the Requi Health platform on AWS. Each task includes:
- Estimated time
- AWS CLI commands where applicable
- Deliverables
- Verification steps

**Total Estimated Time:** 2-3 weeks  
**Priority:** Critical path for launch

---

## Phase 1: Foundation (Week 1)

### Day 1 — AWS Account & IAM
**Time:** 4-6 hours

| Task | Command/Action | Verification |
|------|----------------|--------------|
| Enable MFA on root | AWS Console > IAM | MFA device registered |
| Create `RequiAdmins` group | `aws iam create-group` | Group exists |
| Create your IAM user | `aws iam create-user` | User created |
| Attach admin policies | `aws iam attach-group-policy` | Full admin access |
| Enable CloudTrail | AWS Console > CloudTrail | Logging enabled |
| Set billing alerts | AWS Console > Billing | Alerts at $100, $500, $1000 |
| Enable GuardDuty | AWS Console > GuardDuty | Detector active |
| Enable Security Hub | AWS Console > Security Hub | Standards enabled |

**Deliverable:** Secure AWS account with audit logging

---

### Day 2 — VPC & Networking
**Time:** 6-8 hours

| Task | CIDR Block | AZ |
|------|------------|-----|
| Create VPC | 10.0.0.0/16 | N/A |
| Public subnet 1 | 10.0.1.0/24 | us-east-1a |
| Public subnet 2 | 10.0.2.0/24 | us-east-1b |
| Public subnet 3 | 10.0.3.0/24 | us-east-1c |
| Private subnet 1 | 10.0.11.0/24 | us-east-1a |
| Private subnet 2 | 10.0.12.0/24 | us-east-1b |
| Private subnet 3 | 10.0.13.0/24 | us-east-1c |
| DB subnet 1 | 10.0.21.0/24 | us-east-1a |
| DB subnet 2 | 10.0.22.0/24 | us-east-1b |
| DB subnet 3 | 10.0.23.0/24 | us-east-1c |

**Additional Tasks:**
- [ ] Create Internet Gateway
- [ ] Create 3 NAT Gateways (one per AZ)
- [ ] Allocate 3 Elastic IPs
- [ ] Configure route tables
- [ ] Create VPC endpoints (S3, ECR, CloudWatch, Secrets Manager)

**Verification:**
```bash
aws ec2 describe-vpcs --vpc-ids vpc-xxx
aws ec2 describe-subnets --filters "Name=vpc-id,Values=vpc-xxx"
aws ec2 describe-nat-gateways --filter "Name=vpc-id,Values=vpc-xxx"
```

---

### Day 3 — Security Groups
**Time:** 3-4 hours

| Security Group | Inbound Rules | Outbound |
|----------------|---------------|----------|
| `requi-alb-sg` | 443 from 0.0.0.0/0 | All |
| `requi-ecs-sg` | 3000-3100 from ALB SG | All |
| `requi-rds-sg` | 5432 from ECS SG | All |
| `requi-redis-sg` | 6379 from ECS SG | All |

**CLI Commands:**
```bash
# Create ALB SG
aws ec2 create-security-group \
  --group-name requi-alb-sg \
  --description "ALB Security Group" \
  --vpc-id vpc-xxx

aws ec2 authorize-security-group-ingress \
  --group-id sg-xxx \
  --protocol tcp --port 443 --cidr 0.0.0.0/0

# Create ECS SG
aws ec2 create-security-group \
  --group-name requi-ecs-sg \
  --description "ECS Tasks" \
  --vpc-id vpc-xxx

aws ec2 authorize-security-group-ingress \
  --group-id sg-yyy \
  --protocol tcp --port 3000-3100 \
  --source-group sg-xxx
```

---

### Day 4 — RDS PostgreSQL
**Time:** 4-5 hours

**Configuration:**
```yaml
Instance: db.t3.medium
Engine: postgres 15.4
Storage: 100GB (autoscale to 500GB)
Multi-AZ: true
Backup: 30 days
Encryption: Yes
```

**Steps:**
1. Create DB subnet group
2. Create RDS instance
3. Store password in Secrets Manager
4. Create parameter group with custom settings
5. Enable Performance Insights
6. Enable CloudWatch logs

**Verification:**
```bash
aws rds describe-db-instances --db-instance-identifier requi-db
```

---

### Day 5 — ElastiCache Redis
**Time:** 3-4 hours

**Configuration:**
```yaml
Node Type: cache.t3.micro
Engine: Redis 7.0
Nodes: 2 (Multi-AZ)
Encryption: At-rest + Transit
```

**Steps:**
1. Create subnet group for Redis
2. Create Redis cluster
3. Configure parameter group
4. Test connectivity

---

## Phase 2: Container Infrastructure (Week 2)

### Day 6 — ECR Repositories
**Time:** 2-3 hours

**Create repositories:**
```bash
aws ecr create-repository --repository-name requi-api
aws ecr create-repository --repository-name requi-admin
aws ecr create-repository --repository-name requi-dashboard
```

**Enable scanning:**
```bash
aws ecr put-image-scanning-configuration \
  --repository-name requi-api \
  --image-scanning-configuration scanOnPush=true
```

**Lifecycle policy (keep last 30 images):**
```json
{
  "rules": [{
    "rulePriority": 1,
    "description": "Keep last 30 images",
    "selection": {
      "tagStatus": "any",
      "countType": "imageCountMoreThan",
      "countNumber": 30
    },
    "action": { "type": "expire" }
  }]
}
```

---

### Day 7 — ECS Cluster
**Time:** 2-3 hours

**Create cluster:**
```bash
aws ecs create-cluster \
  --cluster-name requi-health-cluster \
  --settings name=containerInsights,value=enabled \
  --capacity-providers FARGATE FARGATE_SPOT
```

**Create CloudWatch log groups:**
```bash
aws logs create-log-group --log-group-name /ecs/requi-api
aws logs create-log-group --log-group-name /ecs/requi-admin
aws logs create-log-group --log-group-name /ecs/requi-dashboard
```

---

### Day 8 — Application Load Balancer
**Time:** 4-5 hours

**Create ALB:**
```bash
aws elbv2 create-load-balancer \
  --name requi-health-alb \
  --subnets subnet-1 subnet-2 subnet-3 \
  --security-groups sg-alb \
  --scheme internet-facing
```

**Create target groups:**
```bash
# API target group
aws elbv2 create-target-group \
  --name api-tg \
  --protocol HTTP --port 3001 \
  --vpc-id vpc-xxx \
  --target-type ip \
  --health-check-path /health

# Admin target group
aws elbv2 create-target-group \
  --name admin-tg \
  --protocol HTTP --port 3000 \
  --vpc-id vpc-xxx \
  --target-type ip

# Dashboard target group
aws elbv2 create-target-group \
  --name dashboard-tg \
  --protocol HTTP --port 3000 \
  --vpc-id vpc-xxx \
  --target-type ip
```

**Create HTTPS listener:**
```bash
aws elbv2 create-listener \
  --load-balancer-arn arn:aws:elasticloadbalancing:... \
  --protocol HTTPS --port 443 \
  --certificates CertificateArn=arn:aws:acm:... \
  --default-actions Type=forward,TargetGroupArn=arn:aws:...
```

---

### Day 9 — Task Definitions
**Time:** 5-6 hours

**Create task definitions for each service:**

1. API Task Definition
2. Admin Task Definition
3. Dashboard Task Definition

**Key configuration:**
- CPU: 1024 (API), 512 (Frontend)
- Memory: 2048 (API), 1024 (Frontend)
- Network mode: awsvpc
- Execution role: ecsTaskExecutionRole
- Task role: ecsTaskRole

---

### Day 10 — ECS Services
**Time:** 4-5 hours

**Deploy services:**
```bash
# API Service
aws ecs create-service \
  --cluster requi-health-cluster \
  --service-name api \
  --task-definition requi-api:1 \
  --desired-count 2 \
  --launch-type FARGATE \
  --network-configuration "awsvpcConfiguration={subnets=[private-1,private-2],securityGroups=[sg-ecs],assignPublicIp=DISABLED}" \
  --load-balancers "targetGroupArn=arn:aws:...,containerName=api,containerPort=3001" \
  --health-check-grace-period-seconds 60
```

**Configure auto-scaling:**
```bash
aws application-autoscaling register-scalable-target \
  --service-namespace ecs \
  --resource-id service/requi-health-cluster/api \
  --scalable-dimension ecs:service:DesiredCount \
  --min-capacity 2 --max-capacity 10
```

---

## Phase 3: Security & Monitoring (Week 3)

### Day 11 — Secrets Manager
**Time:** 3-4 hours

**Store all secrets:**
```bash
# Database password
aws secretsmanager create-secret \
  --name requi/database/password \
  --secret-string '[GENERATED_PASSWORD]'

# JWT Secret
aws secretsmanager create-secret \
  --name requi/jwt-secret \
  --secret-string '[GENERATED_SECRET]'

# Anthropic API Key
aws secretsmanager create-secret \
  --name requi/anthropic-api-key \
  --secret-string '[API_KEY]'

# Stripe Keys
aws secretsmanager create-secret \
  --name requi/stripe-secret-key \
  --secret-string '[STRIPE_KEY]'

aws secretsmanager create-secret \
  --name requi/stripe-webhook-secret \
  --secret-string '[WEBHOOK_SECRET]'

# Pinecone API Key
aws secretsmanager create-secret \
  --name requi/pinecone-api-key \
  --secret-string '[PINECONE_KEY]'
```

---

### Day 12 — WAF & Security
**Time:** 4-5 hours

**Create WAF WebACL:**
```bash
aws wafv2 create-web-acl \
  --name requi-health-waf \
  --scope REGIONAL \
  --default-action Allow={} \
  --rules '[
    {
      "Name": "AWSManagedRulesCommonRuleSet",
      "Priority": 1,
      "Statement": {
        "ManagedRuleGroupStatement": {
          "VendorName": "AWS",
          "Name": "AWSManagedRulesCommonRuleSet"
        }
      },
      "OverrideAction": { "None": {} },
      "VisibilityConfig": {
        "SampledRequestsEnabled": true,
        "CloudWatchMetricsEnabled": true,
        "MetricName": "AWSManagedRulesCommonRuleSetMetric"
      }
    }
  ]' \
  --visibility-config SampledRequestsEnabled=true,CloudWatchMetricsEnabled=true,MetricName=requi-health-waf
```

**Associate with ALB:**
```bash
aws wafv2 associate-web-acl \
  --web-acl-arn arn:aws:wafv2:... \
  --resource-arn arn:aws:elasticloadbalancing:...
```

---

### Day 13 — CloudWatch Monitoring
**Time:** 4-5 hours

**Create dashboards:**
- ECS Dashboard (CPU, Memory, Running tasks)
- RDS Dashboard (Connections, CPU, Storage)
- ALB Dashboard (Requests, Latency, Errors)
- Application Dashboard (Custom metrics)

**Create alarms:**
```bash
# High CPU alarm
aws cloudwatch put-metric-alarm \
  --alarm-name api-high-cpu \
  --metric-name CPUUtilization \
  --namespace AWS/ECS \
  --statistic Average \
  --period 300 --threshold 80 \
  --comparison-operator GreaterThanThreshold \
  --dimensions Name=ClusterName,Value=requi-health Name=ServiceName,Value=api

# RDS connections alarm
aws cloudwatch put-metric-alarm \
  --alarm-name rds-high-connections \
  --metric-name DatabaseConnections \
  --namespace AWS/RDS \
  --statistic Average \
  --period 300 --threshold 150 \
  --comparison-operator GreaterThanThreshold \
  --dimensions Name=DBInstanceIdentifier,Value=requi-db
```

---

### Day 14 — CI/CD Pipeline
**Time:** 5-6 hours

**Set up GitHub Actions OIDC:**
```bash
# Create OIDC provider
aws iam create-open-id-connect-provider \
  --url https://token.actions.githubusercontent.com \
  --thumbprint-list 6938fd4e98bab03faadb97b34396831e3780aea1 \
  --client-id-list sts.amazonaws.com
```

**Create GitHub Actions role:**
```bash
aws iam create-role \
  --role-name GitHubActionsRole \
  --assume-role-policy-document '{
    "Version": "2012-10-17",
    "Statement": [{
      "Effect": "Allow",
      "Principal": {
        "Federated": "arn:aws:iam::ACCOUNT:oidc-provider/token.actions.githubusercontent.com"
      },
      "Action": "sts:AssumeRoleWithWebIdentity",
      "Condition": {
        "StringEquals": {
          "token.actions.githubusercontent.com:aud": "sts.amazonaws.com"
        },
        "StringLike": {
          "token.actions.githubusercontent.com:sub": "repo:your-org/requi-health:*"
        }
      }
    }]
  }'
```

**Attach policies:**
- AmazonEC2ContainerRegistryFullAccess
- AmazonECS_FullAccess
- CloudWatchLogsFullAccess

---

## Phase 4: Testing & Launch (Week 4)

### Day 15 — End-to-End Testing
**Time:** 6-8 hours

**Test checklist:**
- [ ] API health endpoint responds
- [ ] Database connections working
- [ ] Redis connections working
- [ ] Frontend loads correctly
- [ ] ALB routing works
- [ ] SSL certificates valid
- [ ] Auto-scaling triggers
- [ ] Logs appear in CloudWatch

**Load testing:**
```bash
# Install Artillery
npm install -g artillery

# Run load test
artillery quick --count 100 --num 10 https://api.requi.health/health
```

---

### Day 16 — Documentation
**Time:** 3-4 hours

**Document:**
- Architecture diagrams
- Runbooks for common operations
- Troubleshooting guide
- Contact/escalation procedures

---

### Day 17 — Final Review
**Time:** 2-3 hours

**Final checks:**
- [ ] All security groups reviewed
- [ ] No public access to database
- [ ] All secrets in Secrets Manager
- [ ] Backups configured
- [ ] Monitoring active
- [ ] Alerts tested
- [ ] Documentation complete

---

## Quick Reference: AWS CLI Commands

### VPC
```bash
aws ec2 describe-vpcs
aws ec2 describe-subnets
aws ec2 describe-route-tables
```

### ECS
```bash
aws ecs list-clusters
aws ecs list-services --cluster requi-health-cluster
aws ecs describe-services --cluster requi-health-cluster --services api
```

### RDS
```bash
aws rds describe-db-instances
aws rds describe-db-snapshots
```

### Logs
```bash
aws logs tail /ecs/requi-api --follow
aws logs tail /ecs/requi-admin --follow
```

---

## Contact Information

| Role | Name | Contact |
|------|------|---------|
| AWS Engineer | Debasish | [Your email] |
| Dev Lead | [Name] | [Email] |
| On-Call | [Rotation] | [PagerDuty] |

---

**Document Version:** 1.0  
**Created:** 2024  
**Next Review:** Weekly during deployment
