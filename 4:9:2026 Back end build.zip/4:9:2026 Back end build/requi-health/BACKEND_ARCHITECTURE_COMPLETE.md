# PHASE 9 — API AND SERVICE LAYER (Continued)

## 9.1 API Endpoints (Continued)

### Tasks API (Continued)

```typescript
// GET /api/tasks?status=&category=&priority=
interface GetTasksResponse {
  tasks: {
    id: string;
    title: string;
    description: string;
    status: string;
    priority: string;
    category: string;
    due_date: string | null;
    source: string;
    linked_gap_id: string | null;
    created_at: string;
  }[];
  total: number;
  by_status: Record<string, number>;
}

// POST /api/tasks
interface CreateTaskRequest {
  title: string;
  description?: string;
  category: string;
  priority: string;
  due_date?: string;
  assignee_id?: string;
}

interface CreateTaskResponse {
  id: string;
  title: string;
  status: string;
}
// Side Effects:
// - Creates task
// - Creates reminders if due_date
// - Emits task.created event

// PATCH /api/tasks/:id
interface UpdateTaskRequest {
  status?: string;
  title?: string;
  description?: string;
  due_date?: string;
  assignee_id?: string;
}
// Side Effects:
// - If status -> DONE: emits task.completed, recalculates scores
// - If status -> CANCELLED: cancels reminders

// POST /api/tasks/:id/complete
// Side Effects:
// - Updates task status to DONE
// - Sets completed_at, completed_by
// - Cancels pending reminders
// - Checks gap resolution
// - Emits task.completed event
// - Recalculates scores
```

### Reminders API

```typescript
// GET /api/reminders?status=SCHEDULED&upcoming=true
interface GetRemindersResponse {
  reminders: {
    id: string;
    title: string;
    description: string;
    reminder_type: string;
    scheduled_at: string;
    status: string;
    related_task_id: string | null;
  }[];
}

// POST /api/reminders
interface CreateReminderRequest {
  title: string;
  description?: string;
  scheduled_at: string;
  reminder_type: string;
  related_task_id?: string;
}
// Side Effects:
// - Creates reminder
// - Schedules for delivery
```

### Scores API

```typescript
// GET /api/scores
interface GetScoresResponse {
  compliance: {
    score: number;
    status: string;
    previous_score: number;
    change: number;
    calculated_at: string;
    category_breakdown: Record<string, number>;
  };
  risk: {
    score: number;
    status: string;
    previous_score: number;
    change: number;
    calculated_at: string;
  };
  audit_readiness: {
    score: number;
    status: string;
    previous_score: number;
    change: number;
    calculated_at: string;
  };
}

// GET /api/scores/history?type=compliance&days=30
interface GetScoreHistoryResponse {
  data: {
    date: string;
    score: number;
  }[];
}

// GET /api/scores/explain?type=compliance
interface GetScoreExplanationResponse {
  score: number;
  factors: {
    name: string;
    impact: number;
    description: string;
  }[];
  top_strengths: string[];
  top_gaps: string[];
  recommendations: string[];
}
```

### Gaps API

```typescript
// GET /api/gaps?status=&severity=
interface GetGapsResponse {
  gaps: {
    id: string;
    title: string;
    description: string;
    category: string;
    severity: string;
    status: string;
    detected_by: string;
    created_at: string;
    related_tasks_count: number;
  }[];
  by_severity: {
    critical: number;
    high: number;
    medium: number;
    low: number;
  };
}

// GET /api/gaps/:id
interface GetGapResponse {
  id: string;
  title: string;
  description: string;
  category: string;
  severity: string;
  status: string;
  detected_by: string;
  related_requirement: {
    id: string;
    code: string;
    title: string;
  } | null;
  related_tasks: {
    id: string;
    title: string;
    status: string;
  }[];
  created_at: string;
}

// POST /api/gaps/:id/resolve
interface ResolveGapRequest {
  resolution_notes: string;
  evidence_urls?: string[];
}
// Side Effects:
// - Updates gap status to RESOLVED
// - Sets resolved_at, resolved_by
// - Emits gap.resolved event
// - Recalculates scores
```

## 9.2 Service Layer Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         SERVICE LAYER ARCHITECTURE                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      API CONTROLLERS                                 │   │
│  │  (NestJS - Route handling, validation, auth)                         │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                         │
│                                    ▼                                         │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      SERVICE LAYER                                   │   │
│  │                                                                       │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐│   │
│  │  │   Auth      │  │   Profile   │  │    News     │  │    AI       ││   │
│  │  │   Service   │  │   Service   │  │   Service   │  │  Service    ││   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘│   │
│  │                                                                       │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐│   │
│  │  │  Scoring    │  │    Task     │  │  Reminder   │  │    Gap      ││   │
│  │  │   Engine    │  │   Service   │  │   Service   │  │  Service    ││   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘│   │
│  │                                                                       │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐│   │
│  │  │ Integration │  │   Event     │  │  Billing    │  │  Document   ││   │
│  │  │   Service   │  │   Engine    │  │   Service   │  │   Service   ││   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘│   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                         │
│                                    ▼                                         │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      REPOSITORY LAYER                                │   │
│  │  (Prisma - Database access, queries, transactions)                   │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                         │
│                                    ▼                                         │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      DATA LAYER                                      │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐│   │
│  │  │ PostgreSQL  │  │    Redis    │  │  Pinecone   │  │     S3      ││   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘│   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# PHASE 10 — FRONTEND-BACKEND CONTRACT

## 10.1 Dashboard Hydration Payload

```typescript
// GET /api/dashboard
interface DashboardResponse {
  // User Context
  user: {
    id: string;
    first_name: string;
    last_name: string;
    display_name: string;
    avatar_url: string;
    role: string;
  };
  
  // Organization Context
  organization: {
    id: string;
    name: string;
    type: string;
    trial_days_remaining: number | null;
    subscription_status: string;
  };
  
  // Scores (Primary Widgets)
  scores: {
    compliance: {
      score: number;
      status: string;
      change_7d: number;
      trend: 'up' | 'down' | 'flat';
    };
    risk: {
      score: number;
      status: string;
      change_7d: number;
      trend: 'up' | 'down' | 'flat';
    };
    audit_readiness: {
      score: number;
      status: string;
      change_7d: number;
      trend: 'up' | 'down' | 'flat';
    };
  };
  
  // Top Strengths & Gaps
  insights: {
    top_strengths: {
      category: string;
      score: number;
    }[];
    top_gaps: {
      category: string;
      gap_count: number;
      severity: string;
    }[];
  };
  
  // Upcoming Deadlines
  upcoming_deadlines: {
    id: string;
    title: string;
    due_date: string;
    days_remaining: number;
    priority: string;
  }[];
  
  // Priority Tasks
  priority_tasks: {
    id: string;
    title: string;
    status: string;
    priority: string;
    due_date: string | null;
    category: string;
  }[];
  
  // News Feed (Top 3)
  news_feed: {
    id: string;
    headline: string;
    source: string;
    published_at: string;
    relevance_score: number;
    is_read: boolean;
    requires_action: boolean;
  }[];
  
  // Gap Summary
  gap_summary: {
    total: number;
    critical: number;
    high: number;
    medium: number;
    low: number;
  };
  
  // Reminders
  upcoming_reminders: {
    id: string;
    title: string;
    scheduled_at: string;
    type: string;
  }[];
  
  // Integrations
  integrations: {
    provider: string;
    status: string;
    last_sync_at: string | null;
  }[];
}
```

## 10.2 Score Widget Contract

```typescript
// Simple Score Output
interface ScoreWidgetData {
  compliance_score: number;
  compliance_status: 'STRONG' | 'GOOD' | 'NEEDS_IMPROVEMENT' | 'WEAK' | 'CRITICAL';
  compliance_change_7d: number;
  
  risk_score: number;
  risk_status: 'LOW_RISK' | 'GUARDED' | 'MODERATE_RISK' | 'HIGH_RISK' | 'CRITICAL_RISK';
  risk_change_7d: number;
  
  audit_readiness_score: number;
  audit_readiness_status: 'AUDIT_READY' | 'NEARLY_READY' | 'PARTIALLY_READY' | 'WEAK_READINESS' | 'NOT_READY';
  audit_readiness_change_7d: number;
}

// Example Response
{
  "compliance_score": 73,
  "compliance_status": "NEEDS_IMPROVEMENT",
  "compliance_change_7d": 5,
  
  "risk_score": 75,
  "risk_status": "HIGH_RISK",
  "risk_change_7d": -3,
  
  "audit_readiness_score": 62,
  "audit_readiness_status": "PARTIALLY_READY",
  "audit_readiness_change_7d": 8
}
```

## 10.3 Category Breakdown Contract

```typescript
// Top Strengths / Top Gaps Output
interface CategoryInsightsData {
  top_strengths: {
    category: string;
    category_code: string;
    score: number;
    description: string;
  }[];
  
  top_gaps: {
    category: string;
    category_code: string;
    gap_count: number;
    critical_gaps: number;
    description: string;
  }[];
}

// Example Response
{
  "top_strengths": [
    {
      "category": "Exclusion Screening",
      "category_code": "EXCLUSION",
      "score": 88,
      "description": "Monthly screening program with documented processes"
    },
    {
      "category": "Provider Data Accuracy",
      "category_code": "PROVIDER",
      "score": 95,
      "description": "Regular directory updates and validation"
    },
    {
      "category": "Incident Reporting",
      "category_code": "INCIDENT",
      "score": 90,
      "description": "Timely reporting with complete documentation"
    }
  ],
  
  "top_gaps": [
    {
      "category": "Documentation / Retention",
      "category_code": "DOCUMENTATION",
      "gap_count": 4,
      "critical_gaps": 1,
      "description": "Missing retention policies and incomplete records"
    },
    {
      "category": "Encounter Data / Claims",
      "category_code": "ENCOUNTER",
      "gap_count": 3,
      "critical_gaps": 0,
      "description": "Validation workflow needs improvement"
    },
    {
      "category": "HIPAA / Data Protection",
      "category_code": "HIPAA",
      "gap_count": 2,
      "critical_gaps": 1,
      "description": "Breach response procedures incomplete"
    }
  ]
}
```

## 10.4 Task Suggestion Contract

```typescript
// Task Suggestion Output
interface TaskSuggestionData {
  id: string;
  title: string;
  description: string;
  action_type: 'REQUIRED_TASK' | 'OPTIONAL_TASK' | 'DOCUMENT_REQUEST' | 'REVIEW_REQUEST' | 'INVESTIGATION_TASK';
  priority: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  category: string;
  category_code: string;
  confidence_score: number;
  suggested_due_date: string | null;
  source_conversation_id: string;
  source_message_id: string;
}

// Example Response
[
  {
    "id": "sugg_001",
    "title": "Complete encounter data validation workflow",
    "description": "AI analysis identified missing validation steps in encounter data submission process. Implement automated validation checks.",
    "action_type": "REQUIRED_TASK",
    "priority": "HIGH",
    "category": "Encounter Data / Claims",
    "category_code": "ENCOUNTER",
    "confidence_score": 0.92,
    "suggested_due_date": "2024-02-15",
    "source_conversation_id": "conv_123",
    "source_message_id": "msg_456"
  },
  {
    "id": "sugg_002",
    "title": "Upload document retention policy",
    "description": "No documented retention policy found. Required for compliance with 42 CFR documentation requirements.",
    "action_type": "DOCUMENT_REQUEST",
    "priority": "HIGH",
    "category": "Documentation / Retention",
    "category_code": "DOCUMENTATION",
    "confidence_score": 0.88,
    "suggested_due_date": "2024-02-01",
    "source_conversation_id": "conv_123",
    "source_message_id": "msg_457"
  }
]
```

## 10.5 Explainability Contract

```typescript
// Score Explanation Output
interface ScoreExplanationData {
  score_type: 'compliance' | 'risk' | 'audit_readiness';
  current_score: number;
  previous_score: number;
  change: number;
  
  factors: {
    name: string;
    impact: number; // Positive or negative impact on score
    description: string;
    status: 'strength' | 'neutral' | 'gap';
  }[];
  
  why_this_score: string;
  what_caused_change: string;
  what_improves_it: string[];
}

// Example Response
{
  "score_type": "compliance",
  "current_score": 73,
  "previous_score": 68,
  "change": 5,
  
  "factors": [
    {
      "name": "FWA Training Program",
      "impact": 12,
      "description": "Complete training program with 98% completion rate",
      "status": "strength"
    },
    {
      "name": "Incident Reporting",
      "impact": 9,
      "description": "Timely reporting with full documentation",
      "status": "strength"
    },
    {
      "name": "Documentation Retention",
      "impact": -15,
      "description": "Missing retention policy and incomplete records",
      "status": "gap"
    },
    {
      "name": "Encounter Data Validation",
      "impact": -8,
      "description": "Validation workflow has gaps",
      "status": "gap"
    }
  ],
  
  "why_this_score": "Your compliance score of 73 reflects strong performance in FWA training and incident reporting, offset by gaps in documentation retention and encounter data validation.",
  
  "what_caused_change": "Score improved by 5 points due to completion of Q4 FWA training (all staff now current) and submission of updated incident reporting procedures.",
  
  "what_improves_it": [
    "Upload document retention policy (estimated +8 points)",
    "Complete encounter data validation workflow (estimated +5 points)",
    "Submit evidence of quarterly compliance committee meetings (estimated +3 points)"
  ]
}
```

## 10.6 WebSocket Real-Time Updates

```typescript
// WebSocket Events for Dashboard

// scores.recalculated
{
  type: 'SCORES_UPDATED';
  data: {
    compliance_score: number;
    risk_score: number;
    audit_readiness_score: number;
    timestamp: string;
  };
}

// task.created
{
  type: 'TASK_CREATED';
  data: {
    task_id: string;
    title: string;
    priority: string;
  };
}

// task.completed
{
  type: 'TASK_COMPLETED';
  data: {
    task_id: string;
    title: string;
    completed_by: string;
  };
}

// gap.detected
{
  type: 'GAP_DETECTED';
  data: {
    gap_id: string;
    title: string;
    category: string;
    severity: string;
  };
}

// gap.resolved
{
  type: 'GAP_RESOLVED';
  data: {
    gap_id: string;
    title: string;
  };
}

// news.item.published
{
  type: 'NEWS_ITEM';
  data: {
    news_item_id: string;
    headline: string;
    relevance_score: number;
  };
}

// reminder.sent
{
  type: 'REMINDER';
  data: {
    reminder_id: string;
    title: string;
    scheduled_at: string;
  };
}
```

---

# PHASE 11 — RECOMMENDED IMPLEMENTATION SEQUENCE

## 11.1 Build Roadmap

### Sprint 1: Foundation (Weeks 1-2)
**Goal:** Core infrastructure and data model

| Priority | Component | Dependencies | Deliverable |
|----------|-----------|--------------|-------------|
| 1 | Database Schema | None | All tables created, migrations ready |
| 2 | Auth Service | Database | JWT auth, user registration/login |
| 3 | Organization Service | Database | Org CRUD, profile management |
| 4 | Profile Service | Auth, Organization | Avatar upload, sync logic |

**Sprint 1 Exit Criteria:**
- [ ] Database migrations run successfully
- [ ] Users can register and login
- [ ] Organizations can be created
- [ ] Profile images can be uploaded

---

### Sprint 2: Scoring Engine (Weeks 3-4)
**Goal:** Deterministic scoring system

| Priority | Component | Dependencies | Deliverable |
|----------|-----------|--------------|-------------|
| 1 | Control/Requirement Models | Database | Requirements library populated |
| 2 | Compliance Score Engine | Requirements | Category scoring working |
| 3 | Risk Score Engine | Requirements, Tasks | Risk calculation working |
| 4 | Audit Readiness Engine | Documents, Tasks | Audit score working |
| 5 | Score History & Logs | All scores | Change tracking implemented |

**Sprint 2 Exit Criteria:**
- [ ] All three scores calculate correctly
- [ ] Score history is tracked
- [ ] Score changes trigger events
- [ ] Scores recalculate on data changes

---

### Sprint 3: AI Foundation (Weeks 5-6)
**Goal:** AI service and prompt library

| Priority | Component | Dependencies | Deliverable |
|----------|-----------|--------------|-------------|
| 1 | Prompt Logic Library | Database | All categories populated |
| 2 | AI Service (Claude) | Prompt Library | Conversations working |
| 3 | Message Storage | AI Service | Messages persisted |
| 4 | Source Integration | AI Service | Pinecone retrieval working |

**Sprint 3 Exit Criteria:**
- [ ] Users can start AI conversations
- [ ] AI responses include citations
- [ ] Conversations are persisted
- [ ] Context-aware responses work

---

### Sprint 4: Action Extraction (Weeks 7-8)
**Goal:** AI-to-action pipeline

| Priority | Component | Dependencies | Deliverable |
|----------|-----------|--------------|-------------|
| 1 | Action Extraction Engine | AI Service | Parsing rules implemented |
| 2 | Action Suggestion Model | Extraction Engine | Suggestions stored |
| 3 | Confidence Scoring | Extraction Engine | Confidence calculated |
| 4 | Suggestion UI Backend | Suggestion Model | API endpoints ready |

**Sprint 4 Exit Criteria:**
- [ ] AI responses are parsed for actions
- [ ] Suggestions created with confidence scores
- [ ] Users can accept/reject suggestions
- [ ] High-confidence suggestions auto-suggest

---

### Sprint 5: Task & Reminder System (Weeks 9-10)
**Goal:** Full task lifecycle

| Priority | Component | Dependencies | Deliverable |
|----------|-----------|--------------|-------------|
| 1 | Task Service | Action Suggestions | Task CRUD working |
| 2 | Reminder Service | Tasks | Reminders scheduled |
| 3 | Reminder Delivery | Reminder Service | In-app + email delivery |
| 4 | Task Completion Flow | Tasks | Completion triggers score recalc |

**Sprint 5 Exit Criteria:**
- [ ] Tasks can be created from suggestions
- [ ] Reminders are scheduled and delivered
- [ ] Task completion updates scores
- [ ] Overdue tasks increase risk score

---

### Sprint 6: Gap Detection (Weeks 11-12)
**Goal:** Automated gap detection

| Priority | Component | Dependencies | Deliverable |
|----------|-----------|--------------|-------------|
| 1 | Gap Service | Scoring Engine | Gap detection rules |
| 2 | Gap-Task Linkage | Gap Service, Task Service | Gaps linked to tasks |
| 3 | Gap Resolution Flow | Gap Service | Resolution updates scores |
| 4 | Gap Dashboard API | Gap Service | Gap endpoints ready |

**Sprint 6 Exit Criteria:**
- [ ] Gaps are detected automatically
- [ ] Gaps linked to tasks
- [ ] Gap resolution recalculates scores
- [ ] Gap summary available in dashboard

---

### Sprint 7: News Feed (Weeks 13-14)
**Goal:** Regulatory intelligence

| Priority | Component | Dependencies | Deliverable |
|----------|-----------|--------------|-------------|
| 1 | News Ingestion Pipeline | None | RSS/API ingestion working |
| 2 | News Classification | Ingestion | Categorization working |
| 3 | Relevance Engine | Classification | Per-org relevance scores |
| 4 | News API | Relevance Engine | Feed endpoints ready |

**Sprint 7 Exit Criteria:**
- [ ] News items ingested automatically
- [ ] Items categorized correctly
- [ ] Relevance scores calculated per org
- [ ] News feed API returns personalized results

---

### Sprint 8: Event Engine & Orchestration (Weeks 15-16)
**Goal:** Event-driven automation

| Priority | Component | Dependencies | Deliverable |
|----------|-----------|--------------|-------------|
| 1 | Event Bus (Redis) | All services | Event publishing/subscribing |
| 2 | Scoring Consumer | Event Bus | Score recalc on events |
| 3 | Notification Consumer | Event Bus | Notifications sent |
| 4 | Dashboard Consumer | Event Bus | Real-time updates via WebSocket |

**Sprint 8 Exit Criteria:**
- [ ] All major events published to bus
- [ ] Consumers process events correctly
- [ ] Scores recalculate on relevant events
- [ ] Dashboard receives real-time updates

---

### Sprint 9: Dashboard API (Weeks 17-18)
**Goal:** Unified dashboard endpoint

| Priority | Component | Dependencies | Deliverable |
|----------|-----------|--------------|-------------|
| 1 | Dashboard Service | All services | Aggregation logic |
| 2 | Dashboard Endpoint | Dashboard Service | Single endpoint |
| 3 | Score Widgets API | Scoring Engine | Score endpoints |
| 4 | Insights API | All services | Strengths/gaps endpoints |

**Sprint 9 Exit Criteria:**
- [ ] Dashboard endpoint returns all data
- [ ] Score widgets have dedicated endpoints
- [ ] Insights API returns strengths/gaps
- [ ] Explainability endpoints work

---

### Sprint 10: Integration & QA (Weeks 19-20)
**Goal:** Polish and testing

| Priority | Component | Dependencies | Deliverable |
|----------|-----------|--------------|-------------|
| 1 | Integration Tests | All services | E2E test suite |
| 2 | Performance Optimization | All services | Query optimization |
| 3 | Documentation | All services | API docs, runbooks |
| 4 | Load Testing | All services | Performance validated |

**Sprint 10 Exit Criteria:**
- [ ] All E2E tests pass
- [ ] Performance meets targets
- [ ] Documentation complete
- [ ] Load testing successful

---

## 11.2 Critical Path Dependencies

```
Database Schema
    │
    ├──► Auth Service
    │       │
    │       └──► Profile Service
    │
    ├──► Organization Service
    │       │
    │       ├──► Requirements Library
    │       │       │
    │       │       └──► Scoring Engine
    │       │               │
    │       │               ├──► Compliance Score
    │       │               ├──► Risk Score
    │       │               └──► Audit Readiness Score
    │       │
    │       └──► AI Service
    │               │
    │               ├──► Prompt Library
    │               │
    │               ├──► Action Extraction
    │               │       │
    │               │       └──► Action Suggestions
    │               │               │
    │               │               ├──► Task Service
    │               │               │       │
    │               │               │       ├──► Reminder Service
    │               │               │       │
    │               │               │       └──► Gap Service
    │               │               │
    │               │               └──► Event Bus
    │               │                       │
    │               │                       ├──► Scoring Consumer
    │               │                       ├──► Notification Consumer
    │               │                       └──► Dashboard Consumer
    │               │
    │               └──► Source Integration (Pinecone)
    │
    └──► News Service
            │
            ├──► Ingestion Pipeline
            ├──► Classification
            └──► Relevance Engine
```

## 11.3 Team Allocation Recommendation

| Sprint | Backend Devs | AI Engineer | DevOps | QA |
|--------|-------------|-------------|--------|-----|
| 1-2 (Foundation) | 2 | 0 | 1 | 0 |
| 3-4 (AI) | 1 | 1 | 0 | 0 |
| 5-6 (Tasks/Gaps) | 2 | 0 | 0 | 1 |
| 7-8 (News/Events) | 2 | 0 | 1 | 1 |
| 9-10 (Dashboard/QA) | 2 | 0 | 1 | 2 |

---

## 11.4 Risk Mitigation

| Risk | Mitigation |
|------|-----------|
| AI response quality | Start with Claude, have GPT-4 fallback |
| Score calculation performance | Cache scores, recalc async |
| Event bus failure | Implement retry logic, dead letter queue |
| Database performance | Add indexes, read replicas for reporting |
| Integration sync failures | Exponential backoff, manual retry UI |

---

# APPENDIX: Quick Reference

## A.1 Score Calculation Summary

| Score | Formula | Triggers |
|-------|---------|----------|
| Compliance | Σ(Category Score × Weight) | Task complete, evidence upload, gap resolved |
| Risk | Σ(Risk Factor × Weight) | Overdue tasks, critical gaps, missed deadlines |
| Audit Readiness | Σ(Factor × Weight) | Documents uploaded, training completed |

## A.2 Action Type Decision Tree

```
AI Response
    │
    ├──► Contains "must/required/shall" ──► REQUIRED_TASK
    │
    ├──► Contains "should consider/best practice" ──► OPTIONAL_TASK
    │
    ├──► Contains deadline ──► REQUIRED_TASK + REMINDER
    │
    ├──► Contains "no policy/document" ──► DOCUMENT_REQUEST
    │
    ├──► Contains "high risk/exposure" ──► ALERT + REQUIRED_TASK
    │
    └──► None of above ──► No action created
```

## A.3 Event Priority Queue

| Queue | Events | SLA |
|-------|--------|-----|
| high | score.recalculated, gap.detected | < 1s |
| default | task.created, reminder.sent | < 5s |
| low | audit.log, analytics | < 60s |

---

**Document Version:** 1.0  
**Last Updated:** 2024  
**Author:** Principal Backend Architecture Team
