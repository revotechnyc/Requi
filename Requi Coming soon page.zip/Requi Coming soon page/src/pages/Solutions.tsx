import { Shield, Brain, Eye, TrendingUp, Building2, Users, Landmark, ArrowRight, CheckCircle2, Sparkles } from 'lucide-react'
import { Link } from 'react-router-dom'

export function Solutions() {
  const solutions = [
    {
      icon: Brain,
      title: 'Compliance Intelligence',
      description: 'Transform complex regulations into clear, actionable guidance. Our AI understands the nuances of healthcare compliance and delivers answers your team can act on.',
      features: [
        'Natural language queries',
        'Structured, cited answers',
        'Regulatory updates tracking',
        'Context-aware responses'
      ]
    },
    {
      icon: Shield,
      title: 'Risk Reduction',
      description: 'Identify and address compliance gaps before they become problems. Proactive risk management that keeps your organization ahead of the curve.',
      features: [
        'Gap analysis',
        'Risk scoring',
        'Priority recommendations',
        'Remediation tracking'
      ]
    },
    {
      icon: Eye,
      title: 'Operational Clarity',
      description: 'Get a unified view of your compliance posture across the entire organization. Know where you stand at a glance.',
      features: [
        'Organization-wide dashboards',
        'Real-time status updates',
        'Department-level insights',
        'Historical trend analysis'
      ]
    },
    {
      icon: Sparkles,
      title: 'Smarter Decision-Making',
      description: 'Make informed decisions with confidence. Data-driven insights that help compliance teams become strategic partners.',
      features: [
        'Predictive analytics',
        'Scenario modeling',
        'Resource optimization',
        'Executive reporting'
      ]
    }
  ]

  const audiences = [
    {
      icon: Building2,
      title: 'Healthcare Operators',
      description: 'Hospitals, clinics, and care facilities that need to maintain compliance across multiple departments and locations.',
      benefits: ['Streamlined workflows', 'Reduced administrative burden', 'Improved audit readiness']
    },
    {
      icon: Users,
      title: 'Compliance Teams',
      description: 'Dedicated compliance professionals who need better tools to manage complex regulatory requirements.',
      benefits: ['Faster research', 'Better documentation', 'Proactive risk management']
    },
    {
      icon: TrendingUp,
      title: 'Growing Organizations',
      description: 'Healthcare businesses scaling their operations and need compliance systems that grow with them.',
      benefits: ['Scalable processes', 'Consistent standards', 'Reduced overhead']
    },
    {
      icon: Landmark,
      title: 'Enterprise Leadership',
      description: 'Executives who need visibility into organizational compliance and confidence in their risk posture.',
      benefits: ['Executive dashboards', 'Risk visibility', 'Strategic insights']
    }
  ]

  return (
    <div className="pt-24 lg:pt-32">
      {/* Hero Section */}
      <section className="relative py-16 lg:py-24">
        <div className="section-container">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-lavender/20 rounded-full mb-6">
              <Sparkles className="w-4 h-4 text-lavender-dark" />
              <span className="text-sm font-medium text-charcoal">Solutions</span>
            </div>
            <h1 className="font-heading text-[clamp(36px,5vw,64px)] leading-tight text-charcoal mb-6">
              Compliance solutions for modern healthcare
            </h1>
            <p className="text-xl text-gray-custom leading-relaxed max-w-3xl mx-auto">
              REQUI helps healthcare organizations transform compliance from a burden into a strategic advantage. 
              Our platform brings intelligence, clarity, and action to every aspect of your compliance program.
            </p>
          </div>
        </div>
      </section>

      {/* Solutions Grid */}
      <section className="relative py-16 lg:py-24 bg-white">
        <div className="section-container">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="font-heading text-3xl text-charcoal mb-4">
              How REQUI Helps
            </h2>
            <p className="text-gray-custom leading-relaxed">
              Four core capabilities that transform how you approach compliance
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {solutions.map((solution, idx) => {
              const Icon = solution.icon
              return (
                <div key={idx} className="bg-bg-primary rounded-[22px] p-8 lg:p-10">
                  <div className="icon-chip icon-chip-lavender mb-6">
                    <Icon className="w-5 h-5 text-charcoal/70" />
                  </div>
                  <h3 className="font-heading text-2xl text-charcoal mb-4">
                    {solution.title}
                  </h3>
                  <p className="text-gray-custom leading-relaxed mb-6">
                    {solution.description}
                  </p>
                  <ul className="space-y-2">
                    {solution.features.map((feature, fidx) => (
                      <li key={fidx} className="flex items-center gap-2 text-sm text-charcoal">
                        <CheckCircle2 className="w-4 h-4 text-mint flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Who We Serve */}
      <section className="relative py-16 lg:py-24">
        <div className="section-container">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="font-heading text-3xl text-charcoal mb-4">
              Built For Your Organization
            </h2>
            <p className="text-gray-custom leading-relaxed">
              REQUI serves healthcare organizations of all sizes and types
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {audiences.map((audience, idx) => {
              const Icon = audience.icon
              return (
                <div key={idx} className="bg-white rounded-[22px] p-8 border border-gray-100 shadow-subtle">
                  <div className="icon-chip icon-chip-lavender mb-6">
                    <Icon className="w-5 h-5 text-charcoal/70" />
                  </div>
                  <h3 className="font-heading text-xl text-charcoal mb-3">
                    {audience.title}
                  </h3>
                  <p className="text-gray-custom leading-relaxed mb-6">
                    {audience.description}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {audience.benefits.map((benefit, bidx) => (
                      <span 
                        key={bidx} 
                        className="px-3 py-1 bg-bg-primary rounded-full text-sm text-charcoal"
                      >
                        {benefit}
                      </span>
                    ))}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Value Proposition */}
      <section className="relative py-16 lg:py-24 bg-white">
        <div className="section-container">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <div>
              <h2 className="font-heading text-3xl text-charcoal mb-6">
                The REQUI Difference
              </h2>
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="icon-chip icon-chip-mint flex-shrink-0">
                    <CheckCircle2 className="w-5 h-5 text-charcoal/70" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg text-charcoal mb-1">AI-Powered Intelligence</h3>
                    <p className="text-gray-custom text-sm leading-relaxed">
                      Unlike traditional compliance tools, REQUI uses advanced AI to understand context, 
                      provide nuanced answers, and learn from your organization's unique needs.
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="icon-chip icon-chip-sky flex-shrink-0">
                    <CheckCircle2 className="w-5 h-5 text-charcoal/70" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg text-charcoal mb-1">Built for Healthcare</h3>
                    <p className="text-gray-custom text-sm leading-relaxed">
                      Every feature is designed specifically for healthcare compliance. No generic 
                      templates—just purpose-built tools that understand your world.
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="icon-chip icon-chip-lavender flex-shrink-0">
                    <CheckCircle2 className="w-5 h-5 text-charcoal/70" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg text-charcoal mb-1">Proactive, Not Reactive</h3>
                    <p className="text-gray-custom text-sm leading-relaxed">
                      Stay ahead of requirements with intelligent alerts, gap identification, 
                      and predictive insights that help you address issues before they become problems.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-bg-primary rounded-[22px] p-8 lg:p-12">
              <blockquote className="text-xl text-charcoal leading-relaxed mb-6">
                "REQUI transforms compliance from a cost center into a strategic advantage. 
                Organizations that get compliance right build trust, reduce risk, and operate with confidence."
              </blockquote>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-lavender rounded-full flex items-center justify-center">
                  <span className="font-heading font-bold text-charcoal">R</span>
                </div>
                <div>
                  <div className="font-medium text-charcoal">REQUI Team</div>
                  <div className="text-sm text-gray-custom">Building the future of compliance</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative py-16 lg:py-24">
        <div className="section-container">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="font-heading text-3xl text-charcoal mb-4">
              Ready to transform your compliance?
            </h2>
            <p className="text-gray-custom mb-8">
              Join the waitlist to be among the first to experience REQUI.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/" className="btn-primary flex items-center gap-2">
                Join the Waitlist
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link 
                to="/contact" 
                className="px-6 py-3 text-charcoal font-medium text-sm hover:text-lavender-dark transition-colors"
              >
                Talk to Our Team
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
