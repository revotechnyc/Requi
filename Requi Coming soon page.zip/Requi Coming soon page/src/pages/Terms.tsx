import { FileText, Scale, Copyright, AlertTriangle, Gavel, Globe, Mail, CheckCircle2 } from 'lucide-react'

export function Terms() {
  const lastUpdated = 'January 2026'

  const sections = [
    {
      id: 'acceptance',
      title: 'Acceptance of Terms',
      icon: CheckCircle2,
      content: `
        By accessing or using the REQUI website and services (collectively, the "Services"), 
        you agree to be bound by these Terms of Service ("Terms"). If you do not agree to these Terms, 
        you may not access or use the Services.
        
        These Terms constitute a legally binding agreement between you and Requi Technologies LLC 
        ("REQUI," "we," "us," or "our"), a Delaware limited liability company.
        
        We reserve the right to modify these Terms at any time. We will notify you of any material 
        changes by posting the updated Terms on our website and updating the "Last Updated" date. 
        Your continued use of the Services after such changes constitutes your acceptance of the new Terms.
      `
    },
    {
      id: 'eligibility',
      title: 'Eligibility and Accounts',
      icon: FileText,
      content: `
        You must be at least 18 years old and capable of forming a binding contract to use our Services. 
        By using the Services, you represent and warrant that you meet these requirements.
        
        To access certain features of the Services, you may need to create an account. You are responsible 
        for maintaining the confidentiality of your account credentials and for all activities that occur 
        under your account.
        
        You agree to:
        
        Provide accurate, current, and complete information when creating your account.
        
        Maintain and promptly update your account information to keep it accurate and complete.
        
        Notify us immediately of any unauthorized use of your account or any other breach of security.
        
        Accept responsibility for all activities that occur under your account.
        
        We reserve the right to suspend or terminate your account if any information provided proves 
        to be inaccurate, false, or incomplete.
      `
    },
    {
      id: 'use-of-services',
      title: 'Use of the Services',
      icon: Globe,
      content: `
        Subject to your compliance with these Terms, REQUI grants you a limited, non-exclusive, 
        non-transferable, revocable license to access and use the Services for your internal business purposes.
        
        You agree not to:
        
        Use the Services for any illegal purpose or in violation of any local, state, national, or international law.
        
        Violate or infringe other people's intellectual property, privacy, publicity, or other legal rights.
        
        Interfere with or disrupt the Services or servers or networks connected to the Services.
        
        Attempt to gain unauthorized access to any portion of the Services or any other accounts, 
        computer systems, or networks connected to the Services.
        
        Use any robot, spider, scraper, or other automated means to access the Services for any purpose.
        
        Introduce any viruses, trojan horses, worms, logic bombs, or other harmful material to the Services.
        
        Reverse engineer, decompile, or disassemble any aspect of the Services.
      `
    },
    {
      id: 'intellectual-property',
      title: 'Intellectual Property Rights',
      icon: Copyright,
      content: `
        The Services and their entire contents, features, and functionality (including but not limited 
        to all information, software, text, displays, images, video, and audio, and the design, selection, 
        and arrangement thereof) are owned by REQUI, its licensors, or other providers of such material 
        and are protected by United States and international copyright, trademark, patent, trade secret, 
        and other intellectual property or proprietary rights laws.
        
        REQUI, the REQUI logo, and all related names, logos, product and service names, designs, 
        and slogans are trademarks of REQUI or its affiliates or licensors. You must not use such marks 
        without the prior written permission of REQUI.
        
        You retain ownership of any content you submit, post, or display on or through the Services 
        ("User Content"). By submitting User Content, you grant REQUI a worldwide, non-exclusive, 
        royalty-free license to use, reproduce, modify, adapt, publish, translate, and distribute 
        your User Content in connection with operating and providing the Services.
      `
    },
    {
      id: 'disclaimers',
      title: 'Disclaimers',
      icon: AlertTriangle,
      content: `
        THE SERVICES ARE PROVIDED ON AN "AS IS" AND "AS AVAILABLE" BASIS, WITHOUT ANY WARRANTIES 
        OF ANY KIND, EITHER EXPRESS OR IMPLIED. TO THE FULLEST EXTENT PERMITTED BY APPLICABLE LAW, 
        REQUI DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED 
        WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
        
        REQUI DOES NOT WARRANT THAT:
        
        THE SERVICES WILL FUNCTION UNINTERRUPTED, SECURE, OR AVAILABLE AT ANY PARTICULAR TIME OR LOCATION.
        
        ANY ERRORS OR DEFECTS WILL BE CORRECTED.
        
        THE SERVICES ARE FREE OF VIRUSES OR OTHER HARMFUL COMPONENTS.
        
        THE RESULTS OF USING THE SERVICES WILL MEET YOUR REQUIREMENTS.
        
        YOUR USE OF THE SERVICES IS SOLELY AT YOUR OWN RISK. SOME JURISDICTIONS DO NOT ALLOW THE 
        EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSION MAY NOT APPLY TO YOU.
      `
    },
    {
      id: 'limitation-of-liability',
      title: 'Limitation of Liability',
      icon: Scale,
      content: `
        TO THE FULLEST EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL REQUI, ITS AFFILIATES, 
        DIRECTORS, EMPLOYEES, AGENTS, OR LICENSORS BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, 
        CONSEQUENTIAL, OR PUNITIVE DAMAGES, INCLUDING WITHOUT LIMITATION, LOSS OF PROFITS, DATA, USE, 
        GOODWILL, OR OTHER INTANGIBLE LOSSES, RESULTING FROM:
        
        YOUR ACCESS TO OR USE OF OR INABILITY TO ACCESS OR USE THE SERVICES.
        
        ANY CONDUCT OR CONTENT OF ANY THIRD PARTY ON THE SERVICES.
        
        ANY CONTENT OBTAINED FROM THE SERVICES.
        
        UNAUTHORIZED ACCESS, USE, OR ALTERATION OF YOUR TRANSMISSIONS OR CONTENT.
        
        IN NO EVENT SHALL REQUI'S TOTAL LIABILITY TO YOU FOR ALL CLAIMS EXCEED THE AMOUNT PAID BY YOU, 
        IF ANY, TO REQUI DURING THE TWELVE (12) MONTH PERIOD IMMEDIATELY PRECEDING THE EVENT GIVING 
        RISE TO LIABILITY, OR ONE HUNDRED DOLLARS ($100), WHICHEVER IS GREATER.
        
        SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF LIABILITY FOR CONSEQUENTIAL 
        OR INCIDENTAL DAMAGES, SO THE ABOVE LIMITATION MAY NOT APPLY TO YOU.
      `
    },
    {
      id: 'indemnification',
      title: 'Indemnification',
      icon: Gavel,
      content: `
        You agree to defend, indemnify, and hold harmless REQUI, its affiliates, licensors, and service 
        providers, and its and their respective officers, directors, employees, contractors, agents, 
        licensors, suppliers, successors, and assigns from and against any claims, liabilities, damages, 
        judgments, awards, losses, costs, expenses, or fees (including reasonable attorneys' fees) 
        arising out of or relating to:
        
        Your violation of these Terms.
        
        Your User Content.
        
        Your use of the Services.
        
        Your violation of any rights of another.
        
        Your violation of any applicable laws, rules, or regulations.
      `
    },
    {
      id: 'termination',
      title: 'Termination',
      icon: FileText,
      content: `
        We may terminate or suspend your account and access to the Services immediately, without prior 
        notice or liability, for any reason whatsoever, including without limitation if you breach these Terms.
        
        Upon termination, your right to use the Services will immediately cease. If you wish to terminate 
        your account, you may simply discontinue using the Services or contact us to request account deletion.
        
        All provisions of these Terms which by their nature should survive termination shall survive 
        termination, including, without limitation, ownership provisions, warranty disclaimers, indemnity, 
        and limitations of liability.
      `
    },
    {
      id: 'governing-law',
      title: 'Governing Law and Jurisdiction',
      icon: Scale,
      content: `
        These Terms shall be governed by and construed in accordance with the laws of the State of Delaware, 
        United States, without regard to its conflict of law provisions.
        
        Any legal suit, action, or proceeding arising out of, or related to, these Terms or the Services 
        shall be instituted exclusively in the federal or state courts located in Delaware. You waive any 
        objection to this venue and to personal jurisdiction in such courts.
        
        You agree that any dispute resolution proceedings will be conducted only on an individual basis 
        and not in a class, consolidated, or representative action.
      `
    },
    {
      id: 'miscellaneous',
      title: 'Miscellaneous',
      icon: FileText,
      content: `
        Entire Agreement: These Terms constitute the entire agreement between you and REQUI regarding 
        the Services and supersede all prior agreements and understandings.
        
        Waiver: Our failure to enforce any right or provision of these Terms will not be considered a 
        waiver of those rights. If any provision of these Terms is held to be invalid or unenforceable, 
        the remaining provisions will remain in full force and effect.
        
        Assignment: You may not assign or transfer these Terms, by operation of law or otherwise, 
        without our prior written consent. We may assign these Terms at any time without restriction.
        
        Notices: Any notices or other communications provided by us under these Terms will be given 
        by posting to the Services or by email to the address associated with your account.
        
        Force Majeure: We will not be liable for any failure or delay in performing our obligations 
        where such failure or delay results from any cause beyond our reasonable control.
      `
    },
    {
      id: 'contact',
      title: 'Contact Information',
      icon: Mail,
      content: `
        If you have any questions about these Terms, please contact us:
        
        By email: info@requi.io
        
        By mail: Requi Technologies LLC, Delaware, United States
        
        We welcome your feedback and will make every effort to address your concerns promptly.
      `
    }
  ]

  return (
    <div className="pt-24 lg:pt-32">
      {/* Hero Section */}
      <section className="relative py-16 lg:py-24 border-b border-gray-100">
        <div className="section-container">
          <div className="max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-lavender/20 rounded-full mb-6">
              <Scale className="w-4 h-4 text-lavender-dark" />
              <span className="text-sm font-medium text-charcoal">Legal</span>
            </div>
            <h1 className="font-heading text-[clamp(36px,5vw,64px)] leading-tight text-charcoal mb-6">
              Terms of Service
            </h1>
            <p className="text-lg text-gray-custom leading-relaxed">
              These Terms of Service govern your use of the REQUI website and services. 
              Please read them carefully before using our platform.
            </p>
            <p className="text-sm text-gray-custom/70 mt-4">
              Last Updated: {lastUpdated}
            </p>
          </div>
        </div>
      </section>

      {/* Terms Content */}
      <section className="relative py-16 lg:py-24">
        <div className="section-container">
          <div className="max-w-4xl mx-auto">
            <div className="space-y-16">
              {sections.map((section) => {
                const Icon = section.icon
                return (
                  <div key={section.id} id={section.id} className="scroll-mt-24">
                    <div className="flex items-start gap-4 mb-4">
                      <div className="icon-chip icon-chip-lavender flex-shrink-0">
                        <Icon className="w-5 h-5 text-charcoal/70" />
                      </div>
                      <h2 className="font-heading text-2xl text-charcoal pt-3">
                        {section.title}
                      </h2>
                    </div>
                    <div className="pl-[72px]">
                      <div className="prose prose-gray max-w-none">
                        {section.content.split('\n\n').map((paragraph, idx) => {
                          const lines = paragraph.trim().split('\n')
                          const isList = lines.length > 1 && lines.some(l => l.trim().startsWith('-'))
                          
                          if (isList) {
                            const introLines = lines.filter(l => !l.trim().startsWith('-'))
                            const listItems = lines.filter(l => l.trim().startsWith('-'))
                            
                            return (
                              <div key={idx} className="mb-4">
                                {introLines.map((line, lineIdx) => (
                                  <p key={lineIdx} className="text-gray-custom leading-relaxed mb-2">
                                    {line.trim()}
                                  </p>
                                ))}
                                <ul className="space-y-2 mt-2">
                                  {listItems.map((item, itemIdx) => (
                                    <li key={itemIdx} className="text-gray-custom flex items-start gap-2">
                                      <span className="w-1.5 h-1.5 bg-lavender rounded-full mt-2 flex-shrink-0" />
                                      <span>{item.replace('-', '').trim()}</span>
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )
                          }
                          
                          return (
                            <p key={idx} className="text-gray-custom leading-relaxed mb-4">
                              {paragraph.trim()}
                            </p>
                          )
                        })}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="relative py-16 lg:py-24 bg-white border-t border-gray-100">
        <div className="section-container">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="font-heading text-2xl text-charcoal mb-4">
              Questions about our Terms?
            </h2>
            <p className="text-gray-custom mb-6">
              We're happy to clarify any part of our Terms of Service. Reach out and we'll respond promptly.
            </p>
            <a 
              href="mailto:info@requi.io" 
              className="inline-flex items-center gap-2 text-lavender-dark hover:underline font-medium"
            >
              <Mail className="w-4 h-4" />
              info@requi.io
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}
