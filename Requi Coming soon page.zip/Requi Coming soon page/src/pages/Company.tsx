import { Target, Eye, Heart, Users, Building2, Sparkles, ArrowRight } from 'lucide-react'
import { Link } from 'react-router-dom'

export function Company() {
  const values = [
    {
      icon: Heart,
      title: 'Patient Safety First',
      description: 'Every decision we make is guided by the ultimate goal of protecting patients and ensuring the highest standards of care.'
    },
    {
      icon: Sparkles,
      title: 'Intelligent Simplicity',
      description: 'We believe the most powerful solutions are the ones that feel effortless. Complexity should be handled by technology, not users.'
    },
    {
      icon: Users,
      title: 'Empowering Teams',
      description: 'Healthcare professionals are heroes. Our job is to give them the tools they need to focus on what matters most—caring for people.'
    },
    {
      icon: Building2,
      title: 'Enterprise Ready',
      description: 'We build for scale, security, and reliability. Healthcare organizations deserve technology that meets the highest standards.'
    }
  ]

  return (
    <div className="pt-24 lg:pt-32">
      {/* Hero Section */}
      <section className="relative py-16 lg:py-24">
        <div className="section-container">
          <div className="max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-lavender/20 rounded-full mb-6">
              <Building2 className="w-4 h-4 text-lavender-dark" />
              <span className="text-sm font-medium text-charcoal">About Us</span>
            </div>
            <h1 className="font-heading text-[clamp(36px,5vw,64px)] leading-tight text-charcoal mb-6">
              We're building the future of healthcare compliance
            </h1>
            <p className="text-xl text-gray-custom leading-relaxed max-w-3xl">
              REQUI is a healthcare technology company on a mission to transform how organizations 
              manage compliance—making it simpler, smarter, and more effective.
            </p>
          </div>
        </div>
      </section>

      {/* Company Overview */}
      <section className="relative py-16 lg:py-24 bg-white">
        <div className="section-container">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <div>
              <h2 className="font-heading text-3xl text-charcoal mb-6">
                Who We Are
              </h2>
              <div className="space-y-4 text-gray-custom leading-relaxed">
                <p>
                  Requi Technologies LLC is a Delaware-based healthcare technology company founded by a team 
                  of engineers, healthcare operators, and compliance experts who have experienced the pain 
                  of healthcare compliance firsthand.
                </p>
                <p>
                  We've seen brilliant healthcare professionals spend countless hours navigating complex 
                  regulations, digging through documents, and trying to keep up with ever-changing requirements. 
                  We knew there had to be a better way.
                </p>
                <p>
                  REQUI was born from a simple belief: healthcare compliance shouldn't be a burden. 
                  It should be a seamless part of how organizations operate—intelligent, proactive, 
                  and empowering rather than restrictive and reactive.
                </p>
              </div>
            </div>
            <div className="bg-bg-primary rounded-[22px] p-8 lg:p-12">
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center">
                  <div className="font-heading text-4xl text-charcoal mb-2">2024</div>
                  <div className="text-sm text-gray-custom">Founded</div>
                </div>
                <div className="text-center">
                  <div className="font-heading text-4xl text-charcoal mb-2">Delaware</div>
                  <div className="text-sm text-gray-custom">Incorporated</div>
                </div>
                <div className="text-center">
                  <div className="font-heading text-4xl text-charcoal mb-2">USA</div>
                  <div className="text-sm text-gray-custom">Headquarters</div>
                </div>
                <div className="text-center">
                  <div className="font-heading text-4xl text-charcoal mb-2">Healthcare</div>
                  <div className="text-sm text-gray-custom">Focus</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="relative py-16 lg:py-24">
        <div className="section-container">
          <div className="grid md:grid-cols-2 gap-8">
            {/* Mission */}
            <div className="bg-white rounded-[22px] p-8 lg:p-12 border border-gray-100 shadow-subtle">
              <div className="icon-chip icon-chip-lavender mb-6">
                <Target className="w-5 h-5 text-charcoal/70" />
              </div>
              <h2 className="font-heading text-2xl text-charcoal mb-4">
                Our Mission
              </h2>
              <p className="text-gray-custom leading-relaxed">
                To simplify healthcare compliance through intelligent technology, empowering organizations 
                to focus on delivering exceptional care while maintaining the highest standards of regulatory 
                adherence. We believe compliance should be a competitive advantage, not a burden.
              </p>
            </div>

            {/* Vision */}
            <div className="bg-white rounded-[22px] p-8 lg:p-12 border border-gray-100 shadow-subtle">
              <div className="icon-chip icon-chip-mint mb-6">
                <Eye className="w-5 h-5 text-charcoal/70" />
              </div>
              <h2 className="font-heading text-2xl text-charcoal mb-4">
                Our Vision
              </h2>
              <p className="text-gray-custom leading-relaxed">
                A world where every healthcare organization, regardless of size, has access to the tools 
                and insights needed to maintain compliance with confidence. Where regulatory complexity 
                is transformed into operational clarity, and where compliance teams are celebrated as 
                strategic partners in delivering quality care.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Why REQUI Exists */}
      <section className="relative py-16 lg:py-24 bg-white">
        <div className="section-container">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="font-heading text-3xl text-charcoal mb-4">
              Why REQUI Exists
            </h2>
            <p className="text-gray-custom leading-relaxed">
              Healthcare compliance is broken. We're here to fix it.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-bg-primary rounded-[22px] p-8">
              <div className="font-heading text-5xl text-lavender-dark mb-4">01</div>
              <h3 className="font-heading text-xl text-charcoal mb-3">The Problem</h3>
              <p className="text-gray-custom leading-relaxed">
                Healthcare organizations spend countless hours navigating complex regulations, 
                scattered documents, and manual processes. Compliance becomes reactive rather than proactive.
              </p>
            </div>

            <div className="bg-bg-primary rounded-[22px] p-8">
              <div className="font-heading text-5xl text-mint mb-4">02</div>
              <h3 className="font-heading text-xl text-charcoal mb-3">The Impact</h3>
              <p className="text-gray-custom leading-relaxed">
                Burned-out compliance teams, missed requirements, audit anxiety, and resources 
                diverted from patient care. The cost of getting it wrong is enormous.
              </p>
            </div>

            <div className="bg-bg-primary rounded-[22px] p-8">
              <div className="font-heading text-5xl text-sky mb-4">03</div>
              <h3 className="font-heading text-xl text-charcoal mb-3">Our Solution</h3>
              <p className="text-gray-custom leading-relaxed">
                An AI-powered platform that brings intelligence, clarity, and action into one place. 
                Compliance becomes streamlined, proactive, and strategic.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Who We Serve */}
      <section className="relative py-16 lg:py-24">
        <div className="section-container">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="font-heading text-3xl text-charcoal mb-4">
              Who We Serve
            </h2>
            <p className="text-gray-custom leading-relaxed">
              REQUI is built for the people carrying the weight of compliance
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { title: 'Healthcare Operators', desc: 'Hospitals, clinics, and care facilities' },
              { title: 'Compliance Teams', desc: 'Dedicated compliance professionals' },
              { title: 'Home Health Orgs', desc: 'In-home care providers' },
              { title: 'Growing Businesses', desc: 'Scaling healthcare companies' },
            ].map((item, idx) => (
              <div key={idx} className="bg-white rounded-[22px] p-6 border border-gray-100 shadow-subtle">
                <h3 className="font-heading text-lg text-charcoal mb-2">{item.title}</h3>
                <p className="text-sm text-gray-custom">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="relative py-16 lg:py-24 bg-white">
        <div className="section-container">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="font-heading text-3xl text-charcoal mb-4">
              Our Values
            </h2>
            <p className="text-gray-custom leading-relaxed">
              The principles that guide everything we do
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {values.map((value, idx) => {
              const Icon = value.icon
              return (
                <div key={idx} className="flex gap-4 p-6 bg-bg-primary rounded-[22px]">
                  <div className="icon-chip icon-chip-lavender flex-shrink-0">
                    <Icon className="w-5 h-5 text-charcoal/70" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg text-charcoal mb-2">{value.title}</h3>
                    <p className="text-gray-custom text-sm leading-relaxed">{value.description}</p>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative py-16 lg:py-24">
        <div className="section-container">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="font-heading text-3xl text-charcoal mb-4">
              Want to learn more?
            </h2>
            <p className="text-gray-custom mb-8">
              Discover how REQUI can transform compliance for your organization.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/product" className="btn-primary flex items-center gap-2">
                Explore Our Product
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link 
                to="/contact" 
                className="px-6 py-3 text-charcoal font-medium text-sm hover:text-lavender-dark transition-colors"
              >
                Get in Touch
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
