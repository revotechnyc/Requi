import { Brain, Shield, Eye, Workflow, FileText, BarChart3, Zap, CheckCircle2, ArrowRight, Sparkles, Lock } from 'lucide-react'
import { Link } from 'react-router-dom'

export function Product() {
  const capabilities = [
    {
      icon: Brain,
      title: 'AI Compliance Assistant',
      description: 'Ask questions in plain English and get structured, cited answers. Our AI understands healthcare regulations and your organizational context.',
      features: ['Natural language queries', 'Cited sources', 'Context awareness', 'Continuous learning']
    },
    {
      icon: Shield,
      title: 'Risk & Readiness',
      description: 'Identify gaps, assess readiness, and track remediation. Know exactly where you stand and what needs attention.',
      features: ['Gap analysis', 'Risk scoring', 'Remediation tracking', 'Audit preparation']
    },
    {
      icon: Eye,
      title: 'Organization Visibility',
      description: 'Unified dashboards that show compliance posture across departments, locations, and requirements.',
      features: ['Real-time dashboards', 'Department views', 'Trend analysis', 'Custom reporting']
    },
    {
      icon: Workflow,
      title: 'Workflow Integration',
      description: 'Compliance guidance that fits into how your team actually works. No disruption, just better decisions.',
      features: ['Task management', 'Team collaboration', 'Approval workflows', 'Notifications']
    },
    {
      icon: FileText,
      title: 'Documentation & Reporting',
      description: 'Generate reports, maintain documentation, and demonstrate compliance with confidence.',
      features: ['Auto-generated reports', 'Documentation templates', 'Evidence collection', 'Export options']
    },
    {
      icon: BarChart3,
      title: 'Analytics & Insights',
      description: 'Data-driven insights that help you understand patterns, predict issues, and optimize your compliance program.',
      features: ['Performance metrics', 'Predictive alerts', 'Benchmarking', 'Executive summaries']
    }
  ]

  const benefits = [
    {
      title: 'Save Time',
      description: 'Reduce research time by up to 80% with instant, accurate answers to compliance questions.',
      stat: '80%',
      statLabel: 'faster research'
    },
    {
      title: 'Reduce Risk',
      description: 'Identify and address gaps before they become problems. Proactive compliance management.',
      stat: '24/7',
      statLabel: 'risk monitoring'
    },
    {
      title: 'Build Confidence',
      description: 'Walk into any audit knowing your documentation is complete and your posture is strong.',
      stat: '100%',
      statLabel: 'audit readiness'
    }
  ]

  const securityFeatures = [
    'SOC 2 Type II certified infrastructure',
    'End-to-end encryption for data in transit and at rest',
    'Role-based access controls',
    'Regular security audits and penetration testing',
    'HIPAA-compliant data handling',
    '99.9% uptime SLA'
  ]

  return (
    <div className="pt-24 lg:pt-32">
      {/* Hero Section */}
      <section className="relative py-16 lg:py-24">
        <div className="section-container">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-lavender/20 rounded-full mb-6">
              <Sparkles className="w-4 h-4 text-lavender-dark" />
              <span className="text-sm font-medium text-charcoal">Product</span>
            </div>
            <h1 className="font-heading text-[clamp(36px,5vw,64px)] leading-tight text-charcoal mb-6">
              The intelligent compliance platform
            </h1>
            <p className="text-xl text-gray-custom leading-relaxed max-w-3xl mx-auto mb-8">
              REQUI combines advanced AI with deep healthcare compliance expertise to deliver 
              a platform that transforms how organizations manage regulatory requirements.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/" className="btn-primary flex items-center gap-2">
                Join the Waitlist
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link 
                to="/solutions" 
                className="px-6 py-3 text-charcoal font-medium text-sm hover:text-lavender-dark transition-colors"
              >
                Explore Solutions
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Product Overview */}
      <section className="relative py-16 lg:py-24 bg-white">
        <div className="section-container">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <div>
              <h2 className="font-heading text-3xl text-charcoal mb-6">
                What REQUI Does
              </h2>
              <div className="space-y-4 text-gray-custom leading-relaxed">
                <p>
                  REQUI is an AI-powered compliance intelligence platform designed specifically for healthcare organizations. 
                  It brings together everything you need to manage compliance in one place.
                </p>
                <p>
                  Unlike traditional compliance tools that require you to search through documents and manuals, 
                  REQUI understands your questions and provides direct, actionable answers. It's like having a 
                  compliance expert available 24/7.
                </p>
                <p>
                  The platform continuously learns from regulatory updates, industry best practices, and your 
                  organization's specific context to deliver increasingly relevant and accurate guidance.
                </p>
              </div>
            </div>
            <div className="bg-bg-primary rounded-[22px] p-8 lg:p-12">
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="icon-chip icon-chip-lavender flex-shrink-0">
                    <Zap className="w-5 h-5 text-charcoal/70" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg text-charcoal mb-1">Instant Answers</h3>
                    <p className="text-gray-custom text-sm">Get compliance answers in seconds, not hours</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="icon-chip icon-chip-mint flex-shrink-0">
                    <CheckCircle2 className="w-5 h-5 text-charcoal/70" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg text-charcoal mb-1">Always Current</h3>
                    <p className="text-gray-custom text-sm">Regulatory updates automatically reflected</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="icon-chip icon-chip-sky flex-shrink-0">
                    <Brain className="w-5 h-5 text-charcoal/70" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg text-charcoal mb-1">Context Aware</h3>
                    <p className="text-gray-custom text-sm">Answers tailored to your organization</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="icon-chip icon-chip-blush flex-shrink-0">
                    <Shield className="w-5 h-5 text-charcoal/70" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg text-charcoal mb-1">Enterprise Secure</h3>
                    <p className="text-gray-custom text-sm">HIPAA-compliant, SOC 2 certified</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Capabilities Grid */}
      <section className="relative py-16 lg:py-24">
        <div className="section-container">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="font-heading text-3xl text-charcoal mb-4">
              Platform Capabilities
            </h2>
            <p className="text-gray-custom leading-relaxed">
              Everything you need to manage compliance with confidence
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {capabilities.map((capability, idx) => {
              const Icon = capability.icon
              return (
                <div key={idx} className="bg-white rounded-[22px] p-8 border border-gray-100 shadow-subtle hover:shadow-elevated transition-shadow">
                  <div className="icon-chip icon-chip-lavender mb-6">
                    <Icon className="w-5 h-5 text-charcoal/70" />
                  </div>
                  <h3 className="font-heading text-xl text-charcoal mb-3">
                    {capability.title}
                  </h3>
                  <p className="text-gray-custom text-sm leading-relaxed mb-4">
                    {capability.description}
                  </p>
                  <ul className="space-y-1">
                    {capability.features.map((feature, fidx) => (
                      <li key={fidx} className="flex items-center gap-2 text-sm text-charcoal">
                        <span className="w-1 h-1 bg-lavender rounded-full" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="relative py-16 lg:py-24 bg-white">
        <div className="section-container">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="font-heading text-3xl text-charcoal mb-4">
              The Impact
            </h2>
            <p className="text-gray-custom leading-relaxed">
              Real results that transform how teams work
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {benefits.map((benefit, idx) => (
              <div key={idx} className="bg-bg-primary rounded-[22px] p-8 text-center">
                <div className="font-heading text-5xl text-lavender-dark mb-2">
                  {benefit.stat}
                </div>
                <div className="text-sm text-gray-custom mb-4">{benefit.statLabel}</div>
                <h3 className="font-heading text-xl text-charcoal mb-2">{benefit.title}</h3>
                <p className="text-gray-custom text-sm leading-relaxed">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Security Section */}
      <section className="relative py-16 lg:py-24">
        <div className="section-container">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-mint/20 rounded-full mb-6">
                <Lock className="w-4 h-4 text-mint" />
                <span className="text-sm font-medium text-charcoal">Security First</span>
              </div>
              <h2 className="font-heading text-3xl text-charcoal mb-6">
                Enterprise-Grade Security
              </h2>
              <p className="text-gray-custom leading-relaxed mb-6">
                We understand that compliance data is among the most sensitive information your organization handles. 
                That's why security is built into every layer of REQUI.
              </p>
              <ul className="space-y-3">
                {securityFeatures.map((feature, idx) => (
                  <li key={idx} className="flex items-center gap-3 text-charcoal">
                    <CheckCircle2 className="w-5 h-5 text-mint flex-shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-bg-primary rounded-[22px] p-8 lg:p-12">
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center p-4 bg-white rounded-2xl">
                  <div className="font-heading text-3xl text-charcoal mb-1">SOC 2</div>
                  <div className="text-xs text-gray-custom">Type II Certified</div>
                </div>
                <div className="text-center p-4 bg-white rounded-2xl">
                  <div className="font-heading text-3xl text-charcoal mb-1">HIPAA</div>
                  <div className="text-xs text-gray-custom">Compliant</div>
                </div>
                <div className="text-center p-4 bg-white rounded-2xl">
                  <div className="font-heading text-3xl text-charcoal mb-1">99.9%</div>
                  <div className="text-xs text-gray-custom">Uptime SLA</div>
                </div>
                <div className="text-center p-4 bg-white rounded-2xl">
                  <div className="font-heading text-3xl text-charcoal mb-1">256-bit</div>
                  <div className="text-xs text-gray-custom">Encryption</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="relative py-16 lg:py-24 bg-white">
        <div className="section-container">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="font-heading text-3xl text-charcoal mb-4">
              How It Works
            </h2>
            <p className="text-gray-custom leading-relaxed">
              Getting started with REQUI is simple
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-6">
            {[
              { step: '01', title: 'Connect', desc: 'Integrate with your existing systems and data sources' },
              { step: '02', title: 'Configure', desc: 'Set up your organization structure and requirements' },
              { step: '03', title: 'Ask', desc: 'Start asking compliance questions in plain English' },
              { step: '04', title: 'Act', desc: 'Get structured answers and take action with confidence' },
            ].map((item, idx) => (
              <div key={idx} className="text-center">
                <div className="font-heading text-5xl text-lavender/30 mb-4">{item.step}</div>
                <h3 className="font-heading text-lg text-charcoal mb-2">{item.title}</h3>
                <p className="text-gray-custom text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative py-16 lg:py-24">
        <div className="section-container">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="font-heading text-3xl text-charcoal mb-4">
              Experience the future of compliance
            </h2>
            <p className="text-gray-custom mb-8">
              Join the waitlist to get early access to REQUI and be among the first to transform your compliance program.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/" className="btn-primary flex items-center gap-2">
                Join the Waitlist
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link 
                to="/contact" 
                className="px-6 py-3 text-charcoal font-medium text-sm hover:text-lavender-dark transition-colors"
              >
                Request a Demo
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
