import { useState } from 'react'
import { Mail, MessageSquare, Send, Clock, CheckCircle2 } from 'lucide-react'

export function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: ''
  })
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitted(true)
    setTimeout(() => {
      setFormData({ name: '', email: '', company: '', message: '' })
      setIsSubmitted(false)
    }, 3000)
  }

  return (
    <div className="pt-24 lg:pt-32">
      {/* Hero Section */}
      <section className="relative py-16 lg:py-24">
        <div className="section-container">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-lavender/20 rounded-full mb-6">
              <MessageSquare className="w-4 h-4 text-lavender-dark" />
              <span className="text-sm font-medium text-charcoal">Get in touch</span>
            </div>
            <h1 className="font-heading text-[clamp(36px,5vw,64px)] leading-tight text-charcoal mb-6">
              Let's talk about compliance
            </h1>
            <p className="text-lg text-gray-custom leading-relaxed max-w-2xl mx-auto">
              Have questions about REQUI? Want to learn more about how we're building 
              the future of healthcare compliance? We'd love to hear from you.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Info Cards */}
      <section className="relative py-12 lg:py-16">
        <div className="section-container">
          <div className="grid md:grid-cols-2 gap-6 max-w-3xl mx-auto">
            <div className="bg-white rounded-[22px] p-8 border border-gray-100 shadow-subtle text-center">
              <div className="icon-chip icon-chip-lavender mx-auto mb-6">
                <Mail className="w-5 h-5 text-charcoal/70" />
              </div>
              <h3 className="font-heading text-lg text-charcoal mb-2">Email us</h3>
              <a 
                href="mailto:info@requi.io" 
                className="text-lavender-dark hover:underline font-medium"
              >
                info@requi.io
              </a>
            </div>
            
            <div className="bg-white rounded-[22px] p-8 border border-gray-100 shadow-subtle text-center">
              <div className="icon-chip icon-chip-mint mx-auto mb-6">
                <Clock className="w-5 h-5 text-charcoal/70" />
              </div>
              <h3 className="font-heading text-lg text-charcoal mb-2">Response time</h3>
              <p className="text-gray-custom">
                We typically respond within 24-48 hours
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="relative py-16 lg:py-24">
        <div className="section-container">
          <div className="max-w-2xl mx-auto">
            <div className="bg-white rounded-[22px] p-8 lg:p-12 border border-gray-100 shadow-subtle">
              <h2 className="font-heading text-2xl text-charcoal mb-2">
                Send us a message
              </h2>
              <p className="text-gray-custom mb-8">
                Fill out the form below and we'll get back to you as soon as possible.
              </p>

              {isSubmitted ? (
                <div className="text-center py-12">
                  <div className="icon-chip icon-chip-mint mx-auto mb-6">
                    <CheckCircle2 className="w-6 h-6 text-charcoal/70" />
                  </div>
                  <h3 className="font-heading text-xl text-charcoal mb-2">
                    Message sent!
                  </h3>
                  <p className="text-gray-custom">
                    Thank you for reaching out. We'll be in touch soon.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid sm:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-charcoal mb-2">
                        Name
                      </label>
                      <input
                        type="text"
                        id="name"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="Your name"
                        className="input-field"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-charcoal mb-2">
                        Email
                      </label>
                      <input
                        type="email"
                        id="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="you@company.com"
                        className="input-field"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="company" className="block text-sm font-medium text-charcoal mb-2">
                      Company
                    </label>
                    <input
                      type="text"
                      id="company"
                      value={formData.company}
                      onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                      placeholder="Your organization"
                      className="input-field"
                    />
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-charcoal mb-2">
                      Message
                    </label>
                    <textarea
                      id="message"
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="How can we help?"
                      rows={5}
                      className="input-field resize-none"
                      required
                    />
                  </div>

                  <button type="submit" className="btn-primary w-full flex items-center justify-center gap-2">
                    Send Message
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Company Info */}
      <section className="relative py-16 lg:py-24 bg-white">
        <div className="section-container">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-heading text-2xl text-charcoal mb-4">
              Requi Technologies LLC
            </h2>
            <p className="text-gray-custom leading-relaxed mb-6">
              A Delaware corporation building intelligent healthcare compliance solutions. 
              We're headquartered in the United States and serve healthcare organizations nationwide.
            </p>
            <div className="inline-flex items-center gap-2 text-sm text-gray-custom">
              <span>Primary contact:</span>
              <a href="mailto:info@requi.io" className="text-lavender-dark hover:underline font-medium">
                info@requi.io
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
