import { Shield, Lock, Eye, Database, Cookie, Mail, UserCheck, RefreshCw } from 'lucide-react'

export function Privacy() {
  const lastUpdated = 'January 2026'

  const sections = [
    {
      id: 'introduction',
      title: 'Introduction',
      icon: Shield,
      content: `
        Requi Technologies LLC ("REQUI," "we," "us," or "our") is committed to protecting your privacy. 
        This Privacy Policy explains how we collect, use, disclose, and safeguard your information when 
        you visit our website at requi.io (the "Site") and use our services.
        
        We take your privacy seriously. This policy is designed to be transparent about our data practices 
        and to help you understand how we handle the information you entrust to us.
      `
    },
    {
      id: 'information-collected',
      title: 'Information We Collect',
      icon: Eye,
      content: `
        We collect several types of information from and about users of our Site and services:
        
        Personal Information: When you sign up for our waitlist, contact us, or create an account, 
        we may collect your name, email address, company name, job title, and phone number.
        
        Usage Data: We automatically collect information about how you interact with our Site, 
        including your IP address, browser type, operating system, pages visited, time spent on pages, 
        and referring website addresses.
        
        Device Information: We collect information about the device you use to access our services, 
        including hardware model, operating system version, unique device identifiers, and mobile network information.
      `
    },
    {
      id: 'how-we-use',
      title: 'How We Use Your Information',
      icon: Database,
      content: `
        We use the information we collect for various purposes, including:
        
        Providing and maintaining our services, including monitoring usage and improving performance.
        
        Communicating with you about updates, security alerts, support messages, and administrative messages.
        
        Sending you marketing communications about new features, products, and services (with your consent).
        
        Analyzing usage patterns to improve our Site, products, and user experience.
        
        Detecting, preventing, and addressing technical issues, fraud, and security concerns.
        
        Complying with legal obligations and enforcing our terms and policies.
      `
    },
    {
      id: 'cookies',
      title: 'Cookies and Tracking Technologies',
      icon: Cookie,
      content: `
        We use cookies and similar tracking technologies to track activity on our Site and hold certain information.
        
        Cookies are files with a small amount of data that may include an anonymous unique identifier. 
        They are sent to your browser from a website and stored on your device.
        
        We use the following types of cookies:
        
        Essential Cookies: Necessary for the Site to function properly and cannot be disabled.
        
        Analytics Cookies: Help us understand how visitors interact with our Site by collecting 
        and reporting information anonymously.
        
        Marketing Cookies: Used to track visitors across websites to display relevant advertisements.
        
        You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. 
        However, if you do not accept cookies, you may not be able to use some portions of our Site.
      `
    },
    {
      id: 'data-sharing',
      title: 'Data Sharing and Third Parties',
      icon: Lock,
      content: `
        We do not sell your personal information to third parties. We may share your information 
        in the following circumstances:
        
        Service Providers: We may employ third-party companies and individuals to facilitate our services, 
        provide services on our behalf, perform service-related activities, or assist us in analyzing 
        how our services are used.
        
        Business Transfers: If REQUI is involved in a merger, acquisition, or asset sale, your personal 
        information may be transferred as a business asset.
        
        Legal Requirements: We may disclose your personal information if required to do so by law 
        or in response to valid requests by public authorities.
        
        Protection of Rights: We may disclose your information to protect the rights, property, 
        or safety of REQUI, our users, or others.
        
        Our third-party service providers are contractually obligated to use your information only 
        as necessary to provide services to us and are required to maintain the confidentiality 
        and security of your information.
      `
    },
    {
      id: 'data-security',
      title: 'Data Security',
      icon: Lock,
      content: `
        The security of your data is important to us. We implement appropriate technical and 
        organizational measures to protect the personal information we collect and process.
        
        These measures include:
        
        Encryption of data in transit using TLS/SSL protocols.
        
        Regular security assessments and vulnerability testing.
        
        Access controls and authentication mechanisms.
        
        Employee training on data protection and security practices.
        
        However, please be aware that no method of transmission over the internet or method of 
        electronic storage is 100% secure. While we strive to use commercially acceptable means 
        to protect your personal information, we cannot guarantee its absolute security.
      `
    },
    {
      id: 'data-retention',
      title: 'Data Retention',
      icon: Database,
      content: `
        We retain your personal information only for as long as necessary to fulfill the purposes 
        for which we collected it, including for the purposes of satisfying any legal, accounting, 
        or reporting requirements.
        
        To determine the appropriate retention period, we consider:
        
        The amount, nature, and sensitivity of the personal information.
        
        The potential risk of harm from unauthorized use or disclosure.
        
        The purposes for which we process the information and whether we can achieve those purposes 
        through other means.
        
        Applicable legal requirements.
        
        When we no longer need your personal information, we will securely delete or anonymize it 
        in accordance with our data retention policies.
      `
    },
    {
      id: 'your-rights',
      title: 'Your Privacy Rights',
      icon: UserCheck,
      content: `
        Depending on your location, you may have certain rights regarding your personal information:
        
        Access: You have the right to request copies of your personal information.
        
        Rectification: You have the right to request that we correct any information you believe 
        is inaccurate or complete information you believe is incomplete.
        
        Erasure: You have the right to request that we erase your personal information under 
        certain conditions.
        
        Restrict Processing: You have the right to request that we restrict the processing of 
        your personal information under certain conditions.
        
        Data Portability: You have the right to request that we transfer the data we have collected 
        to another organization or directly to you under certain conditions.
        
        Object to Processing: You have the right to object to our processing of your personal information.
        
        To exercise any of these rights, please contact us at info@requi.io.
      `
    },
    {
      id: 'children',
      title: "Children's Privacy",
      icon: Shield,
      content: `
        Our services are not intended for use by children under the age of 13. We do not knowingly 
        collect personally identifiable information from children under 13.
        
        If you are a parent or guardian and you are aware that your child has provided us with 
        personal information, please contact us at info@requi.io. If we become aware that we have 
        collected personal information from children without verification of parental consent, 
        we take steps to remove that information from our servers.
      `
    },
    {
      id: 'international',
      title: 'International Data Transfers',
      icon: RefreshCw,
      content: `
        Your information may be transferred to and maintained on computers located outside of your 
        state, province, country, or other governmental jurisdiction where data protection laws 
        may differ from those in your jurisdiction.
        
        If you are located outside the United States and choose to provide information to us, 
        please note that we transfer the data to the United States and process it there.
        
        We ensure appropriate safeguards are in place to protect your information when transferred 
        internationally, including standard contractual clauses and adequacy decisions where applicable.
      `
    },
    {
      id: 'changes',
      title: 'Changes to This Privacy Policy',
      icon: RefreshCw,
      content: `
        We may update our Privacy Policy from time to time. We will notify you of any changes by 
        posting the new Privacy Policy on this page and updating the "Last Updated" date.
        
        We encourage you to review this Privacy Policy periodically for any changes. Changes to 
        this Privacy Policy are effective when they are posted on this page.
        
        For material changes, we will make reasonable efforts to notify you through email or 
        a prominent notice on our Site prior to the change becoming effective.
      `
    },
    {
      id: 'contact',
      title: 'Contact Us',
      icon: Mail,
      content: `
        If you have any questions about this Privacy Policy or our data practices, please contact us:
        
        By email: info@requi.io
        
        By mail: Requi Technologies LLC, Delaware, United States
        
        We are committed to working with you to obtain a fair resolution of any complaint or concern 
        about privacy. If you believe that we have not been able to assist with your complaint or concern, 
        you may have the right to make a complaint to your local data protection authority.
      `
    }
  ]

  return (
    <div className="pt-24 lg:pt-32">
      {/* Hero Section */}
      <section className="relative py-16 lg:py-24 border-b border-gray-100">
        <div className="section-container">
          <div className="max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-lavender/20 rounded-full mb-6">
              <Shield className="w-4 h-4 text-lavender-dark" />
              <span className="text-sm font-medium text-charcoal">Legal</span>
            </div>
            <h1 className="font-heading text-[clamp(36px,5vw,64px)] leading-tight text-charcoal mb-6">
              Privacy Policy
            </h1>
            <p className="text-lg text-gray-custom leading-relaxed">
              At REQUI, we believe that trust is earned through transparency. This Privacy Policy 
              explains how we collect, use, and protect your personal information.
            </p>
            <p className="text-sm text-gray-custom/70 mt-4">
              Last Updated: {lastUpdated}
            </p>
          </div>
        </div>
      </section>

      {/* Policy Content */}
      <section className="relative py-16 lg:py-24">
        <div className="section-container">
          <div className="max-w-4xl mx-auto">
            <div className="space-y-16">
              {sections.map((section) => {
                const Icon = section.icon
                return (
                  <div key={section.id} id={section.id} className="scroll-mt-24">
                    <div className="flex items-start gap-4 mb-4">
                      <div className="icon-chip icon-chip-lavender flex-shrink-0">
                        <Icon className="w-5 h-5 text-charcoal/70" />
                      </div>
                      <h2 className="font-heading text-2xl text-charcoal pt-3">
                        {section.title}
                      </h2>
                    </div>
                    <div className="pl-[72px]">
                      <div className="prose prose-gray max-w-none">
                        {section.content.split('\n\n').map((paragraph, idx) => {
                          const lines = paragraph.trim().split('\n')
                          const isList = lines.length > 1 && lines[0].includes(':')
                          
                          if (isList) {
                            const [title, ...items] = lines
                            return (
                              <div key={idx} className="mb-4">
                                <p className="text-charcoal font-medium mb-2">{title.replace(':', '')}</p>
                                <ul className="space-y-2">
                                  {items.filter(item => item.trim().startsWith('-')).map((item, itemIdx) => (
                                    <li key={itemIdx} className="text-gray-custom flex items-start gap-2">
                                      <span className="w-1.5 h-1.5 bg-lavender rounded-full mt-2 flex-shrink-0" />
                                      <span>{item.replace('-', '').trim()}</span>
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )
                          }
                          
                          return (
                            <p key={idx} className="text-gray-custom leading-relaxed mb-4">
                              {paragraph.trim()}
                            </p>
                          )
                        })}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="relative py-16 lg:py-24 bg-white border-t border-gray-100">
        <div className="section-container">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="font-heading text-2xl text-charcoal mb-4">
              Questions about our Privacy Policy?
            </h2>
            <p className="text-gray-custom mb-6">
              We're here to help. Reach out to us and we'll get back to you as soon as possible.
            </p>
            <a 
              href="mailto:info@requi.io" 
              className="inline-flex items-center gap-2 text-lavender-dark hover:underline font-medium"
            >
              <Mail className="w-4 h-4" />
              info@requi.io
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}
