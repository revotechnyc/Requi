import { useEffect, useRef, useState } from 'react'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { 
  Shield, 
  Brain, 
  Zap, 
  Building2, 
  Home as HomeIcon, 
  TrendingUp, 
  Landmark,
  CheckCircle2,
  Sparkles,
  BarChart3,
  FileText,
  Eye,
  Workflow,
  Lightbulb,
  ArrowRight,
  Mail,
  User,
  Building
} from 'lucide-react'

gsap.registerPlugin(ScrollTrigger)

export function Home() {
  const [email, setEmail] = useState('')
  const [firstName, setFirstName] = useState('')
  const [company, setCompany] = useState('')
  const [updatesChecked, setUpdatesChecked] = useState(false)
  
  const heroRef = useRef<HTMLDivElement>(null)
  const sphereRef = useRef<HTMLDivElement>(null)
  const auraRef = useRef<HTMLDivElement>(null)
  const headlineRef = useRef<HTMLDivElement>(null)
  const formRef = useRef<HTMLDivElement>(null)
  const trustRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Hero entrance animation
      const tl = gsap.timeline({ defaults: { ease: 'power2.out' } })
      
      tl.fromTo(auraRef.current, 
        { scale: 0.85, opacity: 0 },
        { scale: 1, opacity: 1, duration: 0.8 }
      )
      .fromTo(sphereRef.current,
        { scale: 0.9, opacity: 0 },
        { scale: 1, opacity: 1, duration: 0.8 },
        0.1
      )
      .fromTo('.floating-card-item',
        { y: 60, rotateX: 10, opacity: 0 },
        { y: 0, rotateX: 0, opacity: 1, duration: 0.75, stagger: 0.08 },
        0.25
      )
      .fromTo('.icon-chip-item',
        { y: 40, scale: 0.9, opacity: 0 },
        { y: 0, scale: 1, opacity: 1, duration: 0.6, stagger: 0.06 },
        0.35
      )
      .fromTo('.headline-word',
        { y: 24, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.5, stagger: 0.03 },
        0.45
      )
      .fromTo([formRef.current, trustRef.current],
        { y: 20, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.5 },
        0.6
      )

      // Scroll-driven exit animation for hero
      const heroScrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: heroRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            gsap.set([headlineRef.current, formRef.current, trustRef.current], { 
              x: 0, opacity: 1 
            })
            gsap.set('.floating-card-item', { x: 0, opacity: 1 })
            gsap.set('.icon-chip-item', { x: 0, opacity: 1 })
            gsap.set([sphereRef.current, auraRef.current], { scale: 1, opacity: 1 })
          }
        }
      })

      heroScrollTl
        .fromTo(headlineRef.current,
          { x: 0, opacity: 1 },
          { x: '-18vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo([formRef.current, trustRef.current],
          { x: 0, opacity: 1 },
          { x: '-12vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo('.floating-card-item',
          { x: 0, opacity: 1 },
          { x: '10vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo('.icon-chip-item',
          { x: 0, opacity: 1 },
          { x: '10vw', opacity: 0, ease: 'power2.in' },
          0.75
        )
        .fromTo([sphereRef.current, auraRef.current],
          { scale: 1, opacity: 1 },
          { scale: 1.25, opacity: 0.35, ease: 'power2.in' },
          0.7
        )

      // Flowing section animations
      gsap.utils.toArray<HTMLElement>('.reveal-section').forEach((section) => {
        gsap.fromTo(section,
          { y: 40, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: section,
              start: 'top 80%',
              end: 'top 50%',
              scrub: 0.4,
            }
          }
        )
      })

      // Staggered card animations
      gsap.utils.toArray<HTMLElement>('.stagger-card').forEach((card, i) => {
        gsap.fromTo(card,
          { y: 60, rotateX: 8, opacity: 0 },
          {
            y: 0,
            rotateX: 0,
            opacity: 1,
            duration: 0.6,
            delay: i * 0.1,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
              end: 'top 55%',
              scrub: 0.4,
            }
          }
        )
      })

      // Feature items stagger
      gsap.utils.toArray<HTMLElement>('.feature-item-anim').forEach((item, i) => {
        gsap.fromTo(item,
          { y: 30, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.5,
            delay: i * 0.08,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: item,
              start: 'top 85%',
              end: 'top 60%',
              scrub: 0.4,
            }
          }
        )
      })

      // Audience blocks stagger
      gsap.utils.toArray<HTMLElement>('.audience-block').forEach((block, i) => {
        gsap.fromTo(block,
          { y: 24, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.5,
            delay: i * 0.08,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: block,
              start: 'top 85%',
              end: 'top 65%',
              scrub: 0.4,
            }
          }
        )
      })

    }, heroRef)

    return () => ctx.revert()
  }, [])

  const handleNotifySubmit = (e: React.FormEvent) => {
    e.preventDefault()
    alert('Thank you! We\'ll notify you when we launch.')
    setEmail('')
  }

  const handleWaitlistSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    alert('Thank you for joining the waitlist!')
    setFirstName('')
    setEmail('')
    setCompany('')
  }

  return (
    <div className="relative overflow-x-hidden">
      {/* Section 1: Hero */}
      <section ref={heroRef} className="relative w-full h-screen overflow-hidden">
        {/* Background wash */}
        <div className="absolute inset-0 bg-gradient-radial from-lavender/10 via-transparent to-transparent" />
        
        {/* Aura blob */}
        <div 
          ref={auraRef}
          className="absolute aura animate-pulse-soft"
          style={{ 
            left: '56vw', 
            top: '54vh', 
            width: 'min(70vw, 80vh)', 
            height: 'min(70vw, 80vh)',
            transform: 'translate(-50%, -50%)'
          }}
        />
        
        {/* Intelligence sphere */}
        <div 
          ref={sphereRef}
          className="absolute sphere animate-float"
          style={{ 
            left: '58vw', 
            top: '52vh', 
            width: 'min(52vw, 62vh)', 
            height: 'min(52vw, 62vh)',
            transform: 'translate(-50%, -50%)'
          }}
        />
        
        {/* Floating dashboard cards */}
        <div className="absolute inset-0 pointer-events-none">
          <div 
            className="floating-card-item floating-card absolute pointer-events-auto animate-float-slow"
            style={{ 
              left: '62vw', 
              top: '18vh', 
              width: 'min(34vw, 480px)', 
              height: 'auto',
              animationDelay: '0s'
            }}
          >
            <img 
              src="/dashboard_card_a.jpg" 
              alt="Compliance Dashboard" 
              className="w-full h-auto rounded-[20px]"
            />
          </div>
          
          <div 
            className="floating-card-item floating-card absolute pointer-events-auto animate-float-slow"
            style={{ 
              left: '70vw', 
              top: '46vh', 
              width: 'min(26vw, 360px)', 
              height: 'auto',
              animationDelay: '0.8s'
            }}
          >
            <img 
              src="/dashboard_card_b.jpg" 
              alt="Risk Insights" 
              className="w-full h-auto rounded-[20px]"
            />
          </div>
          
          <div 
            className="floating-card-item floating-card absolute pointer-events-auto animate-float-slow"
            style={{ 
              left: '66vw', 
              top: '72vh', 
              width: 'min(22vw, 300px)', 
              height: 'auto',
              animationDelay: '1.6s'
            }}
          >
            <img 
              src="/dashboard_card_c.jpg" 
              alt="Compliance Checklist" 
              className="w-full h-auto rounded-[20px]"
            />
          </div>
        </div>
        
        {/* Icon chips */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="icon-chip-item icon-chip icon-chip-lavender absolute animate-float" style={{ left: '48vw', top: '22vh', animationDelay: '0.2s' }}>
            <Shield className="w-5 h-5 text-charcoal/70" />
          </div>
          <div className="icon-chip-item icon-chip icon-chip-mint absolute animate-float" style={{ left: '44vw', top: '38vh', animationDelay: '0.5s' }}>
            <Brain className="w-5 h-5 text-charcoal/70" />
          </div>
          <div className="icon-chip-item icon-chip icon-chip-sky absolute animate-float" style={{ left: '46vw', top: '58vh', animationDelay: '0.8s' }}>
            <Zap className="w-5 h-5 text-charcoal/70" />
          </div>
          <div className="icon-chip-item icon-chip icon-chip-blush absolute animate-float" style={{ left: '52vw', top: '74vh', animationDelay: '1.1s' }}>
            <CheckCircle2 className="w-5 h-5 text-charcoal/70" />
          </div>
          <div className="icon-chip-item icon-chip icon-chip-lavender absolute animate-float" style={{ left: '82vw', top: '34vh', animationDelay: '1.4s' }}>
            <Sparkles className="w-5 h-5 text-charcoal/70" />
          </div>
          <div className="icon-chip-item icon-chip icon-chip-mint absolute animate-float" style={{ left: '86vw', top: '62vh', animationDelay: '1.7s' }}>
            <BarChart3 className="w-5 h-5 text-charcoal/70" />
          </div>
        </div>
        
        {/* Content */}
        <div className="relative z-10 h-full flex flex-col justify-center px-6 sm:px-8 lg:px-[7vw]">
          <div ref={headlineRef} className="max-w-full lg:max-w-[44vw]">
            <h1 className="font-heading text-[clamp(32px,8vw,72px)] leading-[1.05] text-charcoal mb-6">
              <span className="headline-word inline-block">Healthcare</span>{' '}
              <span className="headline-word inline-block">compliance,</span>
              <br className="hidden sm:block" />
              <span className="headline-word inline-block">made</span>{' '}
              <span className="headline-word inline-block gradient-text">intelligent.</span>
            </h1>
            <p className="text-base lg:text-lg text-gray-custom max-w-full lg:max-w-[38vw] leading-relaxed">
              AI-powered platform for healthcare compliance. Stay ahead, reduce risk, operate with confidence.
            </p>
          </div>
          
          <div ref={formRef} className="mt-8 w-full max-w-full lg:max-w-[38vw]">
            <p className="text-sm font-medium text-charcoal mb-3">Get early access</p>
            <form onSubmit={handleNotifySubmit} className="flex flex-col sm:flex-row gap-3">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                className="input-field flex-1 min-w-0"
                required
              />
              <button type="submit" className="btn-primary whitespace-nowrap w-full sm:w-auto">
                Notify Me
              </button>
            </form>
          </div>
          
          <div ref={trustRef} className="mt-6">
            <p className="text-sm text-gray-custom">
              For healthcare teams and compliance leaders.
            </p>
          </div>
        </div>
      </section>

      {/* Section 2: What is REQUI Health */}
      <section className="relative py-16 lg:py-24">
        <div className="section-container">
          <div className="reveal-section max-w-3xl">
            <h2 className="font-heading text-[clamp(24px,6vw,48px)] leading-tight text-charcoal mb-6">
              Compliance, simplified
            </h2>
            <p className="text-base lg:text-lg text-gray-custom leading-relaxed">
              REQUI brings intelligence, clarity, and action into one platform. Get answers, identify gaps, and stay audit-ready—without the complexity.
            </p>
          </div>
        </div>
      </section>

      {/* Section 3: Benefits */}
      <section className="relative py-16 lg:py-24">
        <div className="section-container">
          <div className="reveal-section mb-8">
            <h2 className="font-heading text-[clamp(24px,6vw,48px)] leading-tight text-charcoal">
              Why REQUI
            </h2>
          </div>
          
          <div className="grid md:grid-cols-3 gap-4 lg:gap-6">
            <div className="stagger-card benefit-card">
              <div className="icon-chip icon-chip-lavender mb-4">
                <Eye className="w-5 h-5 text-charcoal/70" />
              </div>
              <h3 className="font-heading text-lg text-charcoal mb-2">
                Stay ahead
              </h3>
              <p className="text-gray-custom text-sm leading-relaxed">
                Clear visibility into rules and changes—without digging through documents.
              </p>
            </div>
            
            <div className="stagger-card benefit-card">
              <div className="icon-chip icon-chip-mint mb-4">
                <Shield className="w-5 h-5 text-charcoal/70" />
              </div>
              <h3 className="font-heading text-lg text-charcoal mb-2">
                Reduce risk
              </h3>
              <p className="text-gray-custom text-sm leading-relaxed">
                Identify gaps early and make smarter decisions before issues escalate.
              </p>
            </div>
            
            <div className="stagger-card benefit-card">
              <div className="icon-chip icon-chip-sky mb-4">
                <Brain className="w-5 h-5 text-charcoal/70" />
              </div>
              <h3 className="font-heading text-lg text-charcoal mb-2">
                Move faster
              </h3>
              <p className="text-gray-custom text-sm leading-relaxed">
                Get direct, structured answers to complex compliance questions.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Section 4: Feature Preview */}
      <section className="relative py-16 lg:py-24">
        <div className="section-container">
          <div className="reveal-section mb-8">
            <h2 className="font-heading text-[clamp(24px,6vw,48px)] leading-tight text-charcoal mb-4">
              What's coming
            </h2>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            <div className="feature-item-anim feature-item">
              <div className="icon-chip icon-chip-lavender flex-shrink-0 w-10 h-10">
                <Brain className="w-4 h-4 text-charcoal/70" />
              </div>
              <div>
                <h4 className="font-medium text-charcoal text-sm">AI compliance intelligence</h4>
              </div>
            </div>
            
            <div className="feature-item-anim feature-item">
              <div className="icon-chip icon-chip-mint flex-shrink-0 w-10 h-10">
                <BarChart3 className="w-4 h-4 text-charcoal/70" />
              </div>
              <div>
                <h4 className="font-medium text-charcoal text-sm">Risk insights</h4>
              </div>
            </div>
            
            <div className="feature-item-anim feature-item">
              <div className="icon-chip icon-chip-sky flex-shrink-0 w-10 h-10">
                <FileText className="w-4 h-4 text-charcoal/70" />
              </div>
              <div>
                <h4 className="font-medium text-charcoal text-sm">Reporting</h4>
              </div>
            </div>
            
            <div className="feature-item-anim feature-item">
              <div className="icon-chip icon-chip-blush flex-shrink-0 w-10 h-10">
                <Eye className="w-4 h-4 text-charcoal/70" />
              </div>
              <div>
                <h4 className="font-medium text-charcoal text-sm">Organization visibility</h4>
              </div>
            </div>
            
            <div className="feature-item-anim feature-item">
              <div className="icon-chip icon-chip-lavender flex-shrink-0 w-10 h-10">
                <Workflow className="w-4 h-4 text-charcoal/70" />
              </div>
              <div>
                <h4 className="font-medium text-charcoal text-sm">Workflow guidance</h4>
              </div>
            </div>
            
            <div className="feature-item-anim feature-item">
              <div className="icon-chip icon-chip-mint flex-shrink-0 w-10 h-10">
                <Lightbulb className="w-4 h-4 text-charcoal/70" />
              </div>
              <div>
                <h4 className="font-medium text-charcoal text-sm">Decision support</h4>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Section 5: Who It's For */}
      <section className="relative py-16 lg:py-24">
        <div className="section-container">
          <div className="reveal-section mb-8">
            <h2 className="font-heading text-[clamp(24px,6vw,48px)] leading-tight text-charcoal mb-4">
              Built for
            </h2>
          </div>
          
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
            <div className="audience-block flex items-center gap-2 p-3 bg-white/60 rounded-xl border border-white/80">
              <Building2 className="w-4 h-4 text-lavender-dark" />
              <span className="font-medium text-charcoal text-xs">Healthcare operators</span>
            </div>
            <div className="audience-block flex items-center gap-2 p-3 bg-white/60 rounded-xl border border-white/80">
              <Shield className="w-4 h-4 text-mint" />
              <span className="font-medium text-charcoal text-xs">Compliance teams</span>
            </div>
            <div className="audience-block flex items-center gap-2 p-3 bg-white/60 rounded-xl border border-white/80">
              <HomeIcon className="w-4 h-4 text-sky" />
              <span className="font-medium text-charcoal text-xs">Home health</span>
            </div>
            <div className="audience-block flex items-center gap-2 p-3 bg-white/60 rounded-xl border border-white/80">
              <TrendingUp className="w-4 h-4 text-blush" />
              <span className="font-medium text-charcoal text-xs">Growing businesses</span>
            </div>
            <div className="audience-block flex items-center gap-2 p-3 bg-white/60 rounded-xl border border-white/80 col-span-2 lg:col-span-1">
              <Landmark className="w-4 h-4 text-lavender-dark" />
              <span className="font-medium text-charcoal text-xs">Enterprise</span>
            </div>
          </div>
        </div>
      </section>

      {/* Section 6: Early Access CTA */}
      <section className="relative py-16 lg:py-24 bg-white">
        <div className="section-container">
          <div className="max-w-xl mx-auto text-center reveal-section">
            <h2 className="font-heading text-[clamp(24px,6vw,40px)] leading-tight text-charcoal mb-4">
              Join the waitlist
            </h2>
            <p className="text-base text-gray-custom mb-8">
              Get early access to REQUI.
            </p>
            
            <form onSubmit={handleWaitlistSubmit} className="bg-bg-primary rounded-[22px] p-6 shadow-subtle">
              <div className="grid sm:grid-cols-3 gap-3 mb-3">
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-custom" />
                  <input
                    type="text"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    placeholder="Name"
                    className="input-field pl-10"
                    required
                  />
                </div>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-custom" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Email"
                    className="input-field pl-10"
                    required
                  />
                </div>
                <div className="relative">
                  <Building className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-custom" />
                  <input
                    type="text"
                    value={company}
                    onChange={(e) => setCompany(e.target.value)}
                    placeholder="Company"
                    className="input-field pl-10"
                  />
                </div>
              </div>
              
              <button type="submit" className="btn-primary w-full flex items-center justify-center gap-2">
                Join the Waitlist
                <ArrowRight className="w-4 h-4" />
              </button>
              
              <div className="mt-3 flex items-center justify-center gap-2">
                <input
                  type="checkbox"
                  id="updates"
                  checked={updatesChecked}
                  onChange={(e) => setUpdatesChecked(e.target.checked)}
                  className="w-4 h-4 rounded border-gray-300 text-lavender focus:ring-lavender"
                />
                <label htmlFor="updates" className="text-xs text-gray-custom">
                  Send me product updates
                </label>
              </div>
            </form>
          </div>
        </div>
      </section>
    </div>
  )
}
