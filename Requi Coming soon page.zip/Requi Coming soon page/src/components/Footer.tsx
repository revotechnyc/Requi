import { Link } from 'react-router-dom'

export function Footer() {
  const currentYear = new Date().getFullYear()

  const footerLinks = {
    product: [
      { to: '/product', label: 'Product' },
      { to: '/solutions', label: 'Solutions' },
    ],
    company: [
      { to: '/company', label: 'About' },
      { to: '/contact', label: 'Contact' },
    ],
    legal: [
      { to: '/privacy', label: 'Privacy' },
      { to: '/terms', label: 'Terms' },
    ],
  }

  return (
    <footer className="relative py-16 lg:py-20 bg-white border-t border-gray-100">
      <div className="section-container">
        <div className="grid md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <Link to="/" className="font-heading font-bold text-2xl text-charcoal mb-4 block">
              REQUI
            </Link>
            <p className="text-gray-custom max-w-sm leading-relaxed mb-6">
              Intelligent healthcare compliance for modern organizations. 
              Built by Requi Technologies LLC.
            </p>
            <a 
              href="mailto:info@requi.io" 
              className="text-sm text-charcoal hover:text-lavender-dark transition-colors"
            >
              info@requi.io
            </a>
          </div>

          {/* Product Links */}
          <div>
            <h4 className="font-heading font-medium text-charcoal mb-4">Product</h4>
            <ul className="space-y-3">
              {footerLinks.product.map((link) => (
                <li key={link.to}>
                  <Link 
                    to={link.to}
                    className="text-sm text-gray-custom hover:text-charcoal transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company Links */}
          <div>
            <h4 className="font-heading font-medium text-charcoal mb-4">Company</h4>
            <ul className="space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.to}>
                  <Link 
                    to={link.to}
                    className="text-sm text-gray-custom hover:text-charcoal transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-gray-100 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-gray-custom/70">
            © {currentYear} Requi Technologies LLC. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            {footerLinks.legal.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className="text-sm text-gray-custom hover:text-charcoal transition-colors"
              >
                {link.label}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}
