import { Outlet, useLocation } from 'react-router-dom'
import { useEffect } from 'react'
import { Navigation } from './Navigation'
import { Footer } from './Footer'

export function Layout() {
  const location = useLocation()

  // Scroll to top on route change
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [location.pathname])

  return (
    <div className="relative min-h-screen bg-bg-primary">
      {/* Noise overlay */}
      <div className="noise-overlay" />
      
      {/* Navigation */}
      <Navigation />
      
      {/* Main content */}
      <main className="relative">
        <Outlet />
      </main>
      
      {/* Footer */}
      <Footer />
    </div>
  )
}
