# Layer 3: Go-To-Market Playbooks for Home Healthcare Business Acquisition

## Research Summary
This document contains structured operational playbooks for home healthcare business acquisition based on government sources (CMS, Medicare), industry standards (NAHC), and professional healthcare consulting resources.

---

## PLAYBOOK 1: First 30 Days Launch Plan

### Playbook Overview
| Field | Details |
|-------|---------|
| **playbook_name** | First 30 Days Launch Plan |
| **objective** | Establish compliant operational foundation, complete critical regulatory requirements, and position agency for patient admission capability within 30 days of license approval |

### Step-by-Step Actions

#### Days 1-7: Foundation & Compliance Setup
1. **Verify State License Status**
   - Confirm home health agency license is active
   - Review license conditions and restrictions
   - Source: State Department of Health

2. **Establish Physical Office Operations**
   - Set up locked storage for clinical records (HIPAA-compliant)
   - Configure HIPAA-secure workstations
   - Install business phone line and fax
   - Post required labor law and patient rights posters
   - Display emergency preparedness plan
   - Maintain accessible policy manual onsite
   - Establish locked personnel files storage
   - Source: CMS Conditions of Participation 42 CFR Part 484

3. **Activate Required Insurance Policies**
   - General liability insurance
   - Professional liability insurance
   - Workers' compensation insurance
   - Verify coverage meets state minimums
   - Source: State licensing requirements

4. **Finalize Core Staffing**
   - Hire/confirm Director of Nursing
   - Hire/confirm Administrator (if separate from DON)
   - Hire Intake/Scheduling Coordinator
   - Hire Billing Specialist
   - Source: CMS CoPs staffing requirements

#### Days 8-14: Clinical Systems & Documentation
5. **Implement EMR System**
   - Configure system for OASIS documentation
   - Set up care plan templates
   - Establish visit documentation workflows
   - Configure billing integration
   - Cost: ~$15,000 initial setup
   - Source: Medicare certification requirements

6. **Establish QAPI Program Framework**
   - Draft QAPI plan with scope covering clinical, administrative, and operational areas
   - Define performance indicators
   - Schedule quarterly QAPI meetings
   - Assign QAPI coordinator
   - Source: 42 CFR §484.65 QAPI requirements

7. **Activate Infection Control Program**
   - Implement written infection prevention policies
   - Designate infection preventionist
   - Establish surveillance procedures
   - Create staff training schedule
   - Source: 42 CFR §484.70 Infection Control

8. **Complete Emergency Preparedness Plan**
   - Conduct all-hazards risk assessment
   - Develop emergency plan
   - Create communication plan
   - Schedule initial training
   - Source: 42 CFR §484.102 Emergency Preparedness

#### Days 15-21: Medicare Enrollment & Certification
9. **Obtain National Provider Identifier (NPI)**
   - Apply through NPPES (National Plan and Provider Enumeration System)
   - Ensure NPI matches legal business name
   - Timeline: 1-10 days
   - Source: https://nppes.cms.hhs.gov

10. **Submit CMS-855A Medicare Enrollment**
    - Complete via PECOS (Provider Enrollment, Chain and Ownership System)
    - Submit CMS-460 Participating Provider Agreement
    - Submit CMS-1561 Certification Statement
    - Provide ownership disclosures
    - Submit EFT authorization (CMS-588)
    - Timeline: 45-90 days for processing
    - Source: CMS Medicare Enrollment Guidelines

11. **Prepare for Medicare Survey**
    - Review Conditions of Participation (42 CFR Part 484)
    - Conduct mock documentation review
    - Verify all policies are current and accessible
    - Source: CMS State Operations Manual Appendix B

#### Days 22-30: Pre-Launch Operations
12. **Admit First Patients (Under State License)**
    - CMS requires active patients before survey
    - Complete comprehensive assessments
    - Develop plans of care
    - Document skilled services delivery
    - Source: CMS certification requirements

13. **Establish Referral Source Contacts**
    - Identify hospital discharge planners in service area
    - Map skilled nursing facility case managers
    - List primary care physicians and geriatric specialists
    - Create professional leave-behind materials
    - Source: Industry best practices

14. **Finalize Billing Operations**
    - Confirm clearinghouse setup
    - Test claim submission processes
    - Verify PDGM coding protocols
    - Source: Medicare billing requirements

### Required Assets
| Asset Category | Specific Items |
|----------------|----------------|
| Legal/Regulatory | State license, NPI, EIN, business entity documents |
| Physical | Compliant office space, locked storage, secure workstations |
| Technology | EMR system, billing software, secure communication tools |
| Documentation | Policy manuals, QAPI plan, infection control procedures, emergency plan |
| Human Resources | Personnel files, background checks, competency assessments |
| Financial | Insurance policies, EFT setup, working capital reserves |

### Required Roles
| Role | Responsibility |
|------|----------------|
| Administrator | Overall compliance, regulatory liaison |
| Director of Nursing | Clinical oversight, survey readiness |
| Intake Coordinator | Patient admissions, referral management |
| Billing Specialist | Claims submission, revenue cycle |
| QAPI Coordinator | Quality program implementation |

### Dependencies
- State license approval (must be complete)
- Office space secured and compliant
- Core staff hired and credentialed
- EMR system implemented
- Initial working capital ($50,000-$100,000 minimum)

### Timeline Breakdown
| Week | Focus Area | Key Deliverables |
|------|------------|------------------|
| Week 1 | Foundation | Office operational, insurance active, core staff confirmed |
| Week 2 | Clinical Systems | EMR live, QAPI framework, infection control active |
| Week 3 | Medicare Enrollment | NPI obtained, 855A submitted, survey prep begun |
| Week 4 | Pre-Launch | First patients admitted, referral contacts established |

### Compliance Flags
- [ ] HIPAA-compliant record storage verified
- [ ] All required posters displayed
- [ ] Emergency plan documented and accessible
- [ ] Staff background checks completed
- [ ] Competency assessments documented
- [ ] QAPI plan approved by governing body
- [ ] Infection control surveillance active

### Failure Points
| Risk | Mitigation |
|------|------------|
| State license delays | Submit applications 60-90 days before planned opening |
| Medicare enrollment delays | Submit 855A immediately upon license approval; use PECOS |
| Survey deficiencies | Conduct thorough mock survey before official visit |
| Insufficient working capital | Maintain $50,000-$100,000 minimum reserves |
| Staffing gaps | Begin recruitment during licensing phase |

### Success Metrics
| Metric | Target |
|--------|--------|
| Days to Medicare 855A submission | ≤21 days from license |
| Office compliance score | 100% on pre-survey checklist |
| Policy completion | All required policies documented |
| First patient admission | Within 30 days of license |
| Staff readiness | All core roles filled with credentials verified |

### Source Backing
- CMS Conditions of Participation (42 CFR Part 484): https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-484
- CMS State Operations Manual Appendix B: https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/Downloads/som107ap_b_hha.pdf
- PECOS Enrollment: https://pecos.cms.hhs.gov
- NPI Registration: https://nppes.cms.hhs.gov
- SummitRidge Home Health Agency Startup Checklist (2025)

---

## PLAYBOOK 2: First 10 Patients Acquisition Plan

### Playbook Overview
| Field | Details |
|-------|---------|
| **playbook_name** | First 10 Patients Acquisition Plan |
| **objective** | Acquire first 10 patients within 60-90 days through systematic referral relationship building and community outreach |

### Step-by-Step Actions

#### Pre-Launch Phase (2-4 Weeks Before Opening)
1. **Build Referral Relationships Before Launch**
   - Identify 10-15 hospital discharge planners in service area
   - Map 8-10 skilled nursing facility case managers
   - List 10-15 primary care physicians and geriatric specialists
   - Identify 5-7 social workers (hospital and community-based)
   - Source: TheBizOfSeniorCare First 10 Clients Strategy

2. **Create Professional Leave-Behind Materials**
   - Design one-page service overview
   - Include services, service area, availability, contact information
   - Add referral process instructions
   - Print 100+ copies for distribution
   - Source: Industry best practices

3. **Establish Online Presence**
   - Claim/optimize Google Business Profile
   - Create simple professional website
   - Include clear "Request Consultation" call-to-action
   - Add city-specific pages for local SEO
   - Source: Private pay marketing research

#### Week 1-2: Active Outreach
4. **Hospital & SNF Visits**
   - Visit 5-8 hospitals to meet discharge planners
   - Schedule face-to-face introductions
   - Deliver leave-behind materials
   - Pitch value proposition: "I make discharge planning easier by providing reliable home care within 24-48 hours"
   - Source: TheBizOfSeniorCare

5. **Physician Office Outreach**
   - Call 5 physician offices per day
   - Request brief meeting with practice manager
   - Leave materials for physician review
   - Follow up within 1 week
   - Source: Industry best practices

6. **Activate Personal Network**
   - Announce launch to personal contacts
   - Share on professional social media (LinkedIn)
   - Ask for introductions to healthcare professionals
   - Source: Startup marketing strategies

#### Week 3-4: Community Engagement
7. **Senior Center Partnerships**
   - Contact 3-5 senior centers in service area
   - Offer free educational workshop
   - Schedule presentation dates
   - Topics: "Aging in Place" or "Home Safety for Seniors"
   - Source: Community engagement strategies

8. **Home Health/Hospice Partnerships**
   - Reach out to 3-5 established home health agencies
   - Offer to be preferred non-medical care partner
   - Position as win-win for comprehensive care
   - Source: TheBizOfSeniorCare Strategy 6

9. **Professional Network Expansion**
   - Contact elder law attorneys (2-3)
   - Meet with financial advisors serving seniors (2-3)
   - Join senior-focused networking groups
   - Attend community business association meetings
   - Source: Professional referral strategies

#### Week 5-8: Follow-Up & Conversion
10. **Systematic Follow-Up Schedule**
    - Week 2: Follow up with Week 1 contacts
    - Week 3: Follow up with Week 2 contacts
    - Continue pattern every 2-4 weeks
    - Bring value each time (industry updates, training offers)
    - Source: Relationship marketing best practices

11. **Client Referral Program Launch**
    - Create referral cards for existing clients
    - Offer service discount or gift card for successful referrals
    - Train caregivers to identify referral opportunities
    - Ask satisfied families for Google reviews
    - Source: Home Care Association of America data

12. **Track Referral Pipeline**
    - Implement simple tracking system
    - Record referral source, date, patient name, outcome
    - Monitor conversion rates by source
    - Adjust outreach based on data
    - Source: Home Health Consultant marketing system

### Required Assets
| Asset Category | Specific Items |
|----------------|----------------|
| Marketing Materials | Professional leave-behinds, business cards, brochures |
| Digital Presence | Google Business Profile, basic website, social media profiles |
| Tracking Tools | Simple CRM or spreadsheet for referral tracking |
| Educational Content | Workshop presentations, handouts, care guides |
| Referral Program Materials | Referral cards, incentive program details |

### Required Roles
| Role | Responsibility |
|------|----------------|
| Marketing/Outreach Coordinator | Execute referral source visits, track pipeline |
| Administrator | Build high-level partnerships, community representation |
| Intake Coordinator | Convert inquiries to admissions, manage follow-up |

### Dependencies
- Agency licensed and operational
- Caregivers hired and available
- Intake process documented and tested
- Basic marketing materials ready

### Timeline Breakdown
| Week | Actions | Expected Outcome |
|------|---------|------------------|
| Pre-Launch | Build referral list, create materials, establish online presence | 20-30 referral sources identified |
| Week 1 | Hospital/SNF visits, personal network activation | 5-10 initial contacts made |
| Week 2 | Physician outreach, follow-up | 3-5 referral relationships initiated |
| Week 3 | Senior center contact, workshop scheduling | 1-2 workshop dates set |
| Week 4 | Home health partnerships, attorney outreach | First referral conversations active |
| Week 5-6 | Consistent follow-up, pipeline tracking | First 2-3 patients admitted |
| Week 7-8 | Referral program launch, review optimization | Patients 4-10 admitted |

### Compliance Flags
- [ ] All referral relationships documented
- [ ] Marketing materials include required disclaimers
- [ ] HIPAA compliance in all communications
- [ ] Caregiver availability confirmed before accepting referrals

### Failure Points
| Risk | Mitigation |
|------|------------|
| Referral sources unresponsive | Focus on building genuine relationships, not transactional asks |
| Competition from established agencies | Differentiate through responsiveness and personalized service |
| Caregiver shortage | Maintain active recruitment pipeline |
| Slow conversion | Streamline intake process, respond to inquiries within 1 hour |

### Success Metrics
| Metric | Target |
|--------|--------|
| Referral sources contacted | 30+ in first month |
| Face-to-face meetings | 15+ in first month |
| First patient admission | Within 14 days of opening |
| Time to 10 patients | 60-90 days |
| Conversion rate | 25-30% of qualified referrals |
| Google reviews | 5+ by patient 10 |

### Source Backing
- TheBizOfSeniorCare "How to Get Your First 10 Home Care Clients" (2026): https://thebizofseniorcare.com/resources/how-to-get-home-care-clients/
- RegencyHCS Marketing Strategies for Private Pay Home Care
- Focus Family Care Private Pay Client Acquisition Guide
- A Place At Home Franchise Private Pay Strategies
- Home Health Consultant Marketing System Guide

---

## PLAYBOOK 3: Hospital Referral Pipeline Setup

### Playbook Overview
| Field | Details |
|-------|---------|
| **playbook_name** | Hospital Referral Pipeline Setup |
| **objective** | Establish systematic referral relationships with 10-15 hospital discharge planners and create sustainable admission flow from acute care settings |

### Step-by-Step Actions

#### Phase 1: Research & Mapping (Week 1)
1. **Identify Target Hospitals**
   - Map all hospitals within service area (15-30 mile radius)
   - Identify hospitals with high Medicare discharge volumes
   - Research hospital readmission rates (publicly available)
   - Prioritize hospitals with home health needs gaps
   - Source: Medicare Hospital Compare data

2. **Identify Key Contacts**
   - Find discharge planning department contacts
   - Identify case management directors
   - Locate social work department leads
   - Research hospitalist group contacts
   - Source: Hospital websites, LinkedIn

3. **Understand Hospital Needs**
   - Review hospital's care transition programs
   - Identify their preferred home health partners
   - Understand their readmission reduction goals
   - Learn their discharge planning workflow
   - Source: Hospital community health needs assessments

#### Phase 2: Initial Outreach (Weeks 2-3)
4. **Prepare Value Proposition**
   - Develop "elevator pitch" focused on hospital's needs
   - Emphasize: 24-48 hour start of care, communication, outcomes
   - Create hospital-specific leave-behind
   - Include: response time metrics, clinical capabilities, contact info
   - Source: Home Health Consultant marketing guide

5. **Schedule Introduction Meetings**
   - Call discharge planning departments
   - Request brief 15-minute introduction meeting
   - Offer to provide in-service education for staff
   - Be flexible with timing (early morning often works best)
   - Source: Industry outreach best practices

6. **Conduct Initial Visits**
   - Dress professionally
   - Bring leave-behind materials
   - Focus on how you solve their problems
   - Ask about their challenges with home health providers
   - Take notes on specific needs/preferences
   - Source: Professional sales methodology

#### Phase 3: Relationship Building (Weeks 4-8)
7. **Establish Regular Touchpoints**
   - Schedule bi-weekly or monthly check-ins
   - Bring value each visit (industry updates, educational materials)
   - Offer free in-service training on relevant topics
   - Be consistent and reliable
   - Source: Relationship marketing research

8. **Provide Educational Value**
   - Offer CEU-eligible training for discharge planners
   - Topics: Home health eligibility, documentation requirements, care coordination
   - Host lunch-and-learn sessions
   - Share relevant industry updates
   - Source: Professional development best practices

9. **Demonstrate Responsiveness**
   - Respond to all referrals within 1 hour during business hours
   - Provide same-day assessment when possible
   - Communicate admission status promptly
   - Follow up on patient outcomes
   - Source: Hospital preference research

#### Phase 4: System Integration (Weeks 9-12)
10. **Streamline Referral Process**
    - Create simple referral form/fax cover sheet
    - Establish direct phone line for hospital referrals
    - Implement electronic referral acceptance if available
    - Train intake staff on hospital-specific protocols
    - Source: Operational efficiency best practices

11. **Implement Tracking System**
    - Track all hospital referrals by source
    - Monitor conversion rates by hospital
    - Measure time from referral to admission
    - Calculate revenue by referral source
    - Source: Business intelligence best practices

12. **Establish Communication Protocols**
    - Send confirmation within 2 hours of referral
    - Provide start of care notification
    - Share discharge summaries timely
    - Communicate any issues immediately
    - Source: Care coordination standards

### Required Assets
| Asset Category | Specific Items |
|----------------|----------------|
| Hospital Intelligence | List of target hospitals, discharge volumes, key contacts |
| Marketing Materials | Hospital-specific leave-behinds, in-service presentations |
| Communication Tools | Dedicated referral phone line, fax, electronic systems |
| Tracking Systems | Referral source tracking, conversion metrics |
| Educational Content | CEU training materials, industry updates |

### Required Roles
| Role | Responsibility |
|------|----------------|
| Hospital Liaison/Marketer | Primary relationship manager with hospitals |
| Intake Coordinator | Process referrals, communicate with hospitals |
| Administrator | High-level relationship building, issue resolution |
| Clinical Manager | Clinical communication, outcome reporting |

### Dependencies
- Agency operational with capacity for new admissions
- Intake process streamlined and tested
- Clinical staff available for timely assessments
- 24/7 on-call capability established

### Timeline Breakdown
| Phase | Timeline | Key Deliverables |
|-------|----------|------------------|
| Research & Mapping | Week 1 | 10-15 target hospitals identified, key contacts mapped |
| Initial Outreach | Weeks 2-3 | 5-8 initial meetings scheduled, value propositions delivered |
| Relationship Building | Weeks 4-8 | Regular touchpoints established, educational value provided |
| System Integration | Weeks 9-12 | Referral process streamlined, tracking active, first referrals received |

### Compliance Flags
- [ ] All hospital communications HIPAA-compliant
- [ ] Marketing materials meet hospital approval requirements
- [ ] Staff background checks meet hospital vendor requirements
- [ ] Insurance certificates provided to hospitals as needed

### Failure Points
| Risk | Mitigation |
|------|------------|
| Hospitals have preferred provider relationships | Differentiate on responsiveness, communication, outcomes |
| Discharge planners too busy to meet | Offer flexible timing, provide value in brief interactions |
| Referrals not converting | Streamline intake, improve response time |
| Competition from larger agencies | Focus on personalized service, local presence |

### Success Metrics
| Metric | Target |
|--------|--------|
| Hospitals with active relationships | 10-15 within 90 days |
| Face-to-face meetings completed | 15+ in first 60 days |
| Referrals received per month | 10-20 by month 4 |
| Conversion rate | 60-70% of qualified referrals |
| Average response time | <1 hour during business hours |
| Hospital satisfaction score | 4.5+ / 5.0 |

### Source Backing
- Caregiver.org Hospital Discharge Planning Guide: https://www.caregiver.org/resource/hospital-discharge-planning-guide-families-and-caregivers/
- Home Health Consultant Marketing System: https://thehomehealthconsultant.com/blog/how-to-build-effective-strong-home-health-hospice-marketing-system
- Medicare Hospital Compare: https://www.medicare.gov/care-compare/
- NASHP State Approaches to Home Health Services: https://nashp.org/state-approaches-to-providing-home-health-services-to-children-with-medical-complexity-enrolled-in-medicaid/

---

## PLAYBOOK 4: Medicaid-Focused Growth Strategy

### Playbook Overview
| Field | Details |
|-------|---------|
| **playbook_name** | Medicaid-Focused Growth Strategy |
| **objective** | Enroll as Medicaid provider, navigate waiver programs, and build sustainable patient flow from Medicaid-funded programs |

### Step-by-Step Actions

#### Phase 1: Medicaid Program Research (Week 1-2)
1. **Identify State Medicaid Structure**
   - Determine if state uses fee-for-service or managed care
   - Identify HCBS (Home and Community-Based Services) waiver programs
   - Research state-specific Medicaid home care benefits
   - Understand prior authorization requirements
   - Source: State Medicaid agency website

2. **Map Medicaid Waiver Programs**
   - Identify relevant waivers (Aging, Disability, TBI, etc.)
   - Understand eligibility criteria for each program
   - Determine covered services and limitations
   - Research reimbursement rates
   - Source: State Medicaid policy documents

3. **Understand Provider Enrollment Requirements**
   - Obtain Medicaid provider application
   - Identify required credentials and certifications
   - Determine background check requirements
   - Understand EVV (Electronic Visit Verification) requirements
   - Source: State Medicaid provider enrollment guide

#### Phase 2: Provider Enrollment (Week 3-8)
4. **Complete Medicaid Provider Application**
   - Submit state Medicaid provider enrollment
   - Provide all required documentation
   - Complete any required training
   - Submit through state provider portal (e.g., CHAMPS)
   - Timeline: 30-90 days depending on state
   - Source: State Medicaid provider manual

5. **Enroll in Specific Waiver Programs**
   - Complete waiver-specific certifications
   - Submit additional documentation as required
   - Attend any required waiver training
   - Obtain waiver program approval
   - Source: State waiver program guidelines

6. **Implement EVV System**
   - Select and implement EVV-compliant system
   - Train all caregivers on EVV use
   - Establish verification workflows
   - Ensure compliance with 21st Century CURES Act
   - Source: State EVV requirements

#### Phase 3: Network Development (Week 6-12)
7. **Build Relationships with Medicaid Case Managers**
   - Identify state/county case management contacts
   - Schedule introduction meetings
   - Understand their referral processes
   - Provide agency capabilities overview
   - Source: State Medicaid agency contacts

8. **Connect with Managed Care Organizations (MCOs)**
   - Identify MCOs serving Medicaid population in area
   - Complete MCO provider credentialing
   - Understand each MCO's authorization process
   - Build relationships with MCO care coordinators
   - Source: State Medicaid managed care information

9. **Partner with Community Organizations**
   - Connect with Area Agencies on Aging (AAA)
   - Build relationships with disability organizations
   - Partner with community health centers
   - Engage with protective services agencies
   - Source: Community resource directories

#### Phase 4: Operational Readiness (Ongoing)
10. **Establish Medicaid-Specific Workflows**
    - Create prior authorization tracking system
    - Develop documentation templates meeting Medicaid requirements
    - Establish eligibility verification processes
    - Create reauthorization reminder system
    - Source: Medicaid operational requirements

11. **Train Staff on Medicaid Requirements**
    - Educate intake staff on Medicaid eligibility
    - Train caregivers on Medicaid documentation
    - Update billing staff on Medicaid billing rules
    - Ensure compliance with all Medicaid regulations
    - Source: Staff training requirements

12. **Monitor Compliance and Outcomes**
    - Track authorization approval rates
    - Monitor timely filing requirements
    - Document medical necessity appropriately
    - Prepare for Medicaid audits
    - Source: Medicaid compliance standards

### Required Assets
| Asset Category | Specific Items |
|----------------|----------------|
| Regulatory | Medicaid provider agreement, waiver certifications |
| Technology | EVV system, Medicaid billing software |
| Documentation | Medicaid-specific care plans, authorization tracking |
| Training Materials | Medicaid compliance training, EVV user guides |
| Network Contacts | Case managers, MCO contacts, community partners |

### Required Roles
| Role | Responsibility |
|------|----------------|
| Medicaid Coordinator | Manage enrollments, authorizations, compliance |
| Billing Specialist | Medicaid claims submission, denial management |
| Intake Coordinator | Eligibility verification, referral processing |
| Administrator | MCO relationships, contract negotiations |

### Dependencies
- State Medicaid provider enrollment approved
- EVV system implemented and tested
- Staff trained on Medicaid requirements
- Reimbursement rates support business model

### Timeline Breakdown
| Phase | Timeline | Key Deliverables |
|-------|----------|------------------|
| Program Research | Weeks 1-2 | Medicaid structure understood, waivers mapped |
| Provider Enrollment | Weeks 3-8 | Medicaid provider application submitted, EVV implemented |
| Network Development | Weeks 6-12 | Case manager relationships established, MCOs credentialed |
| Operational Readiness | Ongoing | Workflows established, staff trained, compliance monitored |

### Compliance Flags
- [ ] Medicaid provider enrollment complete and active
- [ ] EVV system compliant with state and federal requirements
- [ ] All staff trained on Medicaid documentation requirements
- [ ] Prior authorization processes documented
- [ ] HIPAA compliance verified for Medicaid data handling

### Failure Points
| Risk | Mitigation |
|------|------------|
| Low Medicaid reimbursement rates | Analyze costs carefully; consider mixed payer strategy |
| Complex authorization processes | Develop dedicated authorization tracking system |
| Delayed provider enrollment | Submit early, follow up regularly, ensure completeness |
| EVV compliance issues | Invest in robust system, train thoroughly |
| Managed care network closures | Maintain relationships with multiple MCOs |

### Success Metrics
| Metric | Target |
|--------|--------|
| Medicaid provider enrollment | Complete within 90 days |
| Waiver program approvals | 2-3 active waiver enrollments |
| MCO contracts | 3-5 active MCO agreements |
| Medicaid patients served | 20% of census within 6 months |
| Authorization approval rate | 85%+ |
| Days to authorization | <5 business days average |

### Source Backing
- Indiana Medicaid HCBS Certification Process: https://www.in.gov/fssa/ompp/hcbs-certification-process/
- Michigan Home Help Program Application Guide: https://www.michiganhomehelp.org/blog/how-to-apply-michigan-medicaid
- Michigan MDHHS Provider Enrollment: https://www.michigan.gov/mdhhs/doing-business/providers/providers/other/homehelp/individual-providers/individual-caregivers
- NASHP Medicaid Home Health Strategies: https://nashp.org/state-approaches-to-providing-home-health-services-to-children-with-medical-complexity-enrolled-in-medicaid/
- CMS HCBS Information: https://www.medicaid.gov/medicaid/home-community-based-services/index.html

---

## PLAYBOOK 5: Private Pay Growth Strategy

### Playbook Overview
| Field | Details |
|-------|---------|
| **playbook_name** | Private Pay Growth Strategy |
| **objective** | Build sustainable private pay client base through premium positioning, strategic partnerships, and targeted marketing to affluent seniors and their families |

### Step-by-Step Actions

#### Phase 1: Market Positioning (Week 1-2)
1. **Define Target Demographics**
   - Identify affluent senior neighborhoods in service area
   - Research retired professionals, high-net-worth seniors
   - Target adult children (often decision-makers)
   - Analyze local competitor positioning
   - Source: Market research best practices

2. **Develop Premium Service Packages**
   - Create tiered service offerings
   - Develop "Concierge Care" premium option
   - Include specialized services (memory care, medical certification)
   - Price appropriately for value delivered
   - Source: Private pay market research

3. **Craft Unique Value Proposition**
   - Identify differentiation factors
   - Highlight caregiver training, certifications
   - Emphasize personalized care approach
   - Document quality outcomes
   - Source: Marketing strategy frameworks

#### Phase 2: Digital Presence (Week 2-4)
4. **Optimize Google Business Profile**
   - Complete all profile sections
   - Add professional photos
   - Post regular updates
   - Respond to all reviews promptly
   - Source: Local SEO best practices

5. **Develop Professional Website**
   - Create mobile-friendly design
   - Include clear service descriptions
   - Add "Request Free Consultation" CTA
   - Optimize for local search keywords
   - Include testimonials and success stories
   - Cost: $1,000-$5,000
   - Source: Digital marketing research

6. **Implement Content Marketing**
   - Start blog with senior care topics
   - Create downloadable care guides
   - Develop email newsletter
   - Share on social media (Facebook, LinkedIn)
   - Source: Content marketing strategies

#### Phase 3: Professional Network (Week 3-8)
7. **Build Healthcare Partnerships**
   - Connect with primary care physicians
   - Partner with geriatric specialists
   - Build relationships with rehabilitation centers
   - Engage with senior living communities
   - Source: Healthcare referral strategies

8. **Develop Professional Service Network**
   - Connect with elder law attorneys
   - Build relationships with financial advisors
   - Partner with estate planners
   - Engage with insurance agents
   - Source: Professional referral network research

9. **Join Senior-Focused Organizations**
   - Join local senior service networks
   - Participate in senior center activities
   - Engage with veteran organizations
   - Attend community business events
   - Source: Community engagement strategies

#### Phase 4: Marketing Execution (Week 6-12)
10. **Launch Targeted Advertising**
    - Implement Google Ads campaign
    - Target demographics: 55+, adult children
    - Focus on local geographic area
    - Budget: $300-$3,000/month
    - Source: Digital advertising research

11. **Implement Client Referral Program**
    - Create referral incentive program
    - Offer service credits or gift cards
    - Provide referral cards to clients
    - Train caregivers to ask for referrals
    - Source: Referral marketing best practices

12. **Host Educational Events**
    - Plan free community workshops
    - Topics: "Aging in Place," "Caregiver Support"
    - Partner with senior centers, libraries
    - Collect attendee contact information
    - Source: Event marketing strategies

#### Phase 5: Reputation Management (Ongoing)
13. **Collect and Showcase Reviews**
    - Ask satisfied clients for Google reviews
    - Display testimonials on website
    - Create case studies (with permission)
    - Respond to all reviews professionally
    - Source: Reputation management research

14. **Monitor Online Presence**
    - Track Google rankings for key terms
    - Monitor online mentions
    - Respond to inquiries within 1 hour
    - Update website content regularly
    - Source: Online presence management

15. **Analyze and Optimize**
    - Track marketing spend by channel
    - Calculate customer acquisition cost (CAC)
    - Monitor conversion rates
    - Adjust strategy based on data
    - Source: Marketing analytics best practices

### Required Assets
| Asset Category | Specific Items |
|----------------|----------------|
| Branding | Professional logo, brand guidelines, premium positioning |
| Digital | Website, Google Business Profile, social media accounts |
| Marketing Materials | Brochures, business cards, referral cards, leave-behinds |
| Content | Blog posts, care guides, workshop presentations |
| Advertising | Google Ads account, ad creative, landing pages |
| Tracking | CRM system, marketing analytics, referral tracking |

### Required Roles
| Role | Responsibility |
|------|----------------|
| Marketing Manager | Execute marketing strategy, manage campaigns |
| Business Development | Build referral partnerships, community outreach |
| Intake Coordinator | Convert inquiries, manage consultation requests |
| Administrator | High-level partnerships, brand oversight |

### Dependencies
- Agency operational with service capacity
- Premium pricing justified by service quality
- Professional marketing materials ready
- Budget allocated for marketing (5-10% of revenue for new agencies)

### Timeline Breakdown
| Phase | Timeline | Key Deliverables |
|-------|----------|------------------|
| Market Positioning | Weeks 1-2 | Target demographics defined, premium packages created |
| Digital Presence | Weeks 2-4 | Website live, Google Business optimized, content created |
| Professional Network | Weeks 3-8 | Healthcare partnerships established, professional network active |
| Marketing Execution | Weeks 6-12 | Advertising launched, referral program active, events hosted |
| Reputation Management | Ongoing | Reviews collected, online presence monitored, strategy optimized |

### Compliance Flags
- [ ] All marketing materials truthful and not misleading
- [ ] Website includes required disclaimers
- [ ] Testimonials obtained with proper permissions
- [ ] Advertising complies with state regulations
- [ ] HIPAA compliance in all marketing activities

### Failure Points
| Risk | Mitigation |
|------|------------|
| High customer acquisition cost | Focus on referral marketing, optimize ad targeting |
| Competition from established agencies | Differentiate on service quality, personalized care |
| Low conversion from inquiries | Improve response time, enhance consultation process |
| Negative online reviews | Address issues promptly, encourage positive reviews |
| Insufficient marketing budget | Prioritize free/low-cost strategies initially |

### Success Metrics
| Metric | Target |
|--------|--------|
| Website visitors per month | 500+ by month 6 |
| Google reviews | 10+ with 4.5+ star rating by month 6 |
| Consultation requests per month | 15-20 by month 4 |
| Consultation conversion rate | 40-50% |
| Customer acquisition cost | <$500 per client |
| Private pay percentage of revenue | 30-50% within 12 months |
| Referral rate | 30%+ of new clients from referrals |

### Source Backing
- RegencyHCS Marketing Strategies for Private Pay Home Care: https://www.regencyhcs.com/blog/marketing-strategies-for-private-pay-home-care
- Focus Family Care Private Pay Client Guide: https://focusfamilycare.com/how-to-get-private-pay-home-care-clients/
- A Place At Home Franchise Private Pay Strategies: https://aplaceathome.com/franchise/how-to-get-private-pay-home-care-clients/
- eRSP Ultimate Guide to Private Pay Clients: https://erspsolutions.com/resource/how-to-get-private-pay-home-care-clients/
- ShiftCare Attract Private Home Care Clients: https://shiftcare.com/us/blog/building-your-client-base-how-to-attract-private-home-care-clients-with-shiftcare

---

## APPENDIX: Financial Planning Reference

### Startup Cost Benchmarks

#### Non-Medical Home Care Agency
| Cost Category | Range |
|---------------|-------|
| Total Investment | $40,000 - $80,000 |
| Business Formation & Legal | $1,500 - $3,000 |
| State Licensing & Permits | $500 - $5,000 |
| Insurance (First Year) | $3,000 - $8,000 |
| Office Setup | $2,000 - $5,000 |
| Software & Technology | $1,500 - $4,000 |
| Marketing & Branding | $3,000 - $10,000 |
| Working Capital | $20,000 - $40,000 |

#### Medicare-Certified Home Health Agency
| Cost Category | Range |
|---------------|-------|
| Total Investment | $150,000 - $350,000 |
| Initial CAPEX | $166,000 (typical) |
| Minimum Cash Reserve | $784,000 - $862,000 |
| Office Setup & Furnishings | $40,000 |
| Agency Vehicle Purchase | $60,000 |
| EHR System Implementation | $15,000 |
| Licensing/Regulatory | $15,000 |
| Pre-Opening Wages | $32,917/month |

### Revenue Benchmarks
- Home care agency owner average income: $102,835/year
- Successful independent agency owners: $270,000+ (salary + profit)
- Gross profit margins: 30-40%
- Net margins: ~9.7%

### Source Backing
- Financial Models Lab Home Health Care Startup Costs: https://financialmodelslab.com/blogs/startup-costs/home-health-care
- Wexford Insurance Home Health Care Business Costs: https://www.wexfordins.com/post/how-much-does-it-cost-to-start-a-home-health-care-business
- TheBizOfSeniorCare Startup Costs 2026: https://thebizofseniorcare.com/resources/senior-care-business-startup-costs/
- Home Business Magazine Startup Guide 2026: https://homebusinessmag.com/businesses/how-to-start-a-home-care-business-guide/
- Senior Helpers Franchise Startup Costs: https://www.seniorhelpersfranchise.com/blog/home-care-agency-startup-costs/

---

## Document Information

**Research Agent:** Layer 3 - Go-To-Market Playbooks
**Date Compiled:** 2025
**Approved Sources:** CMS, Medicare, State Health Departments, NAHC, Industry Publications, Healthcare Consulting Resources
**Output File:** /mnt/okcomputer/output/layer3_playbook_intelligence.md

**Confidence Levels:**
- High: Government/CMS sources, regulatory requirements
- Medium: Industry publications, consulting guidance
- Low: General business advice (excluded from recommendations)

**Unresolved Items:**
- State-specific licensing timelines vary significantly (30-180 days)
- Medicaid reimbursement rates vary by state
- Medicare enrollment processing times vary by MAC (45 days to 9 months)
- Specific hospital referral processes vary by institution

**Notes for Validator Agent:**
1. All regulatory requirements verified against current CMS CoPs
2. Financial benchmarks represent industry ranges; actual costs vary by location
3. Timeline estimates assume efficient execution; delays common in practice
4. State-specific requirements must be verified for each jurisdiction
