# Layer 2 - Channel-Based Lead Generation Database
## Home Healthcare Patient Acquisition Intelligence

**Research Date:** January 2025  
**Purpose:** Comprehensive intelligence on all direct and indirect acquisition channels for home healthcare businesses

---

## Executive Summary

This database contains structured intelligence on 8 primary acquisition channels for home healthcare businesses, compiled from government sources, industry platforms, academic research, and industry publications. All sources are verified and cited.

---

## CHANNEL 1: Google Ads (Paid Search)

### Channel Overview
- **channel_name:** Google Ads (Paid Search)
- **acquisition_type:** paid
- **cost_level:** high
- **speed_to_results:** short
- **scalability:** high

### Setup Requirements
- Google Ads account with verified business information
- Healthcare certification may be required for certain services
- LegitScript certification for pharmaceutical-related advertising
- Landing pages must display provider credentials, clear disclaimers, and privacy policies
- Compliance with Google's Healthcare and Medicines Policy

### Compliance Constraints
- **HIPAA Compliance:** Exclude protected health information (PHI) from ad copy and landing pages
- **Prohibited Content:** Unapproved pharmaceuticals, experimental drugs, non-FDA-cleared treatments
- **Certification Required:** LegitScript Healthcare Merchant Certification for certain healthcare advertisers
- **Prescription Drug Terms:** Restricted globally; limited use allowed in Canada, New Zealand, and United States with local regulatory compliance
- **Cell/Gene Therapy:** Ads allowed as of July 11, 2022, with specific exceptions
- **Prohibited Services:** Platelet-rich plasma (PRP) strictly forbidden as "speculative and experimental medical treatment"

### Targeting Capabilities
- Geographic targeting (state-specific licenses required for telemedicine)
- Demographic targeting (age, income)
- Keyword-based intent targeting (symptom-related keywords vs. condition targeting)
- Remarketing (with privacy restrictions)
- Location extensions for nearby facilities
- Call extensions for urgent consultations

### Example Use Case
A home health agency in Florida targets keywords like "home health care Miami" and "skilled nursing at home" within a 25-mile radius of their service area. They use location extensions to show their office address and call extensions for immediate consultation requests.

### Expected ROI Range
- **Average CPL (Cost Per Lead):** $50-$300 depending on specialty
- **Primary Care CPL:** $50-$150
- **Specialized Care CPL:** $200-$300+
- **Search CVR (Conversion Rate):** ~8.09% (2023 data)
- **Average CPC:** ~$5.64 (healthcare industry)
- **Search CTR:** ~6.07%

### Key Data Points
| Metric | Value | Source |
|--------|-------|--------|
| Healthcare Search CPL | ~$66.02 (2023) | LocaliQ |
| YoY CPL Change | -6% | LocaliQ |
| Dermatology CPL Example | ~$18.54 | LocaliQ |
| Mental Health CPL Example | ~$141 | LocaliQ |
| Median Cost/Conversion | ~$43.92 (Apr 2025) | Varos |

### Source Information
- **source_name:** Google Ads Help Center / LocaliQ / Varos
- **source_url:** https://support.google.com/adspolicy/answer/176031
- **source_type:** industry
- **initial_confidence:** high
- **notes:** Healthcare advertising requires strict compliance; professional campaign management typically reduces lead costs by 30-50%

---

## CHANNEL 2: SEO (Organic Search)

### Channel Overview
- **channel_name:** SEO (Organic Search)
- **acquisition_type:** organic
- **cost_level:** low (ongoing effort cost)
- **speed_to_results:** long (3-6 months minimum)
- **scalability:** high

### Setup Requirements
- Professional website with clear service descriptions
- Google Business Profile (formerly Google My Business) claimed and verified
- Location-specific landing pages for each service area
- Consistent NAP (Name, Address, Phone) across all listings
- Structured data (LocalBusiness schema) implementation
- Quality content addressing patient/family questions

### Compliance Constraints
- Must comply with HIPAA in all content
- Cannot use patient testimonials without explicit written consent
- Cannot make unsubstantiated medical claims
- Must include appropriate disclaimers
- All health information must be accurate and evidence-based

### Targeting Capabilities
- Local search visibility (appears when families search "home care near me")
- Service-specific visibility ("dementia care," "post-surgery care")
- Geographic targeting through location pages
- Long-tail keyword capture ("24-hour home care for seniors in [city]")

### Example Use Case
A home care agency creates separate landing pages for each service area (e.g., "Home Care Tampa," "Home Care St. Petersburg," "Home Care Clearwater"), each with unique, location-specific content. They optimize their Google Business Profile with photos, services, and regular posts.

### Expected ROI Range
- **Organic Lead Cost:** $25-$100 per lead over time
- **Higher Quality Leads:** Better conversion rates than paid leads
- **Long-term Patient Relationships:** Organic leads typically have longer retention
- **Initial Investment Period:** 3-6 months before significant results

### Key Data Points
| Metric | Value | Source |
|--------|-------|--------|
| Local searches resulting in purchase | ~28% | Industry benchmark |
| "Near me" search growth | 200%+ (2017-2019) | Google Trends |
| Patients researching online before booking | 82-89% | Industry research |
| Healthcare Organic CPL | $50-75 | Industry benchmark |

### Source Information
- **source_name:** ShiftCare / SAGA Pixel / Senior Care Marketing Max
- **source_url:** https://shiftcare.com/us/blog/ultimate-guide-to-marketing-your-home-care-agency
- **source_type:** industry
- **initial_confidence:** high
- **notes:** SEO requires consistent effort; Google Business Profile optimization is critical for local visibility

---

## CHANNEL 3: Facebook Ads (Paid Social)

### Channel Overview
- **channel_name:** Facebook Ads (Meta Ads)
- **acquisition_type:** paid
- **cost_level:** medium
- **speed_to_results:** short
- **scalability:** medium

### Setup Requirements
- Meta Business Account
- Compliance with Meta's Health and Wellness advertising guidelines
- Understanding of restriction levels (Core, Mid-Restricted, Full-Restricted)
- Creative assets that don't imply personal health knowledge
- Landing pages without prohibited health claims

### Compliance Constraints (2025-2026 Updates)
- **Health Data Restrictions:** Health and wellness are now "sensitive categories"
- **Targeting Limitations:** Cannot target users based on health conditions or medical data
- **Custom Audiences:** Flagged and disabled if names/rules imply sensitive traits (e.g., "arthritis_interest_list")
- **Campaign Objectives:** Meta discourages lower-funnel objectives (conversions, appointment bookings)
- **Recommended Focus:** Awareness, engagement, and traffic objectives instead
- **Personal Attributes Policy:** Cannot assert or imply knowledge of user's medical conditions
- **Prohibited:** Second-person language implying health knowledge ("Do you have diabetes?")
- **Cosmetic Procedures:** Cannot target users under 18 with weight loss, cosmetic surgery, or supplement ads
- **Online Pharmacies:** Must be LegitScript certified

### Targeting Capabilities
- Demographic targeting (age 45+ for senior care)
- Interest-based targeting (senior care, aging parents, family caregiving)
- Lookalike audiences (with restrictions)
- Geographic targeting
- **Note:** Cannot target based on specific health conditions

### Example Use Case
A home care agency runs an awareness campaign targeting adults aged 45-65 within 30 miles of their service area, using educational content about "Signs Your Parent May Need Home Care" rather than direct service promotion.

### Expected ROI Range
- **Average CPL:** $41.60 (Meta healthcare benchmark)
- **CPL Range:** $23.26 - $81.34 (high seasonal variation)
- **Meta CVR:** ~2.84% (vs. 8.09% for search)
- **CPM Increase:** 70% YoY (Jan 2025 to Jan 2026)
- **Facebook CPC:** ~$1.76
- **Instagram Feed CPC:** ~$3.35

### Key Data Points
| Metric | Value | Source |
|--------|-------|--------|
| Healthcare CPL (Meta) | $41.60 | AdAmigo.ai |
| Healthcare CPL Range | $23.26-$81.34 | AdAmigo.ai |
| Meta CVR | 2.84% | Varos (Apr 2025) |
| CPM YoY Increase | 70% | AdAmigo.ai |
| Healthcare CPA | $61.16 | Varos (Apr 2025) |

### Source Information
- **source_name:** AdAmigo.ai / Unlock Health / Varos
- **source_url:** https://www.adamigo.ai/blog/meta-ads-policy-updates-for-healthcare-ads
- **source_type:** industry
- **initial_confidence:** high
- **notes:** Meta's 2025 policy changes significantly restrict healthcare advertising; shift to awareness campaigns recommended

---

## CHANNEL 4: Local Directories (Yelp, Caring.com, etc.)

### Channel Overview
- **channel_name:** Local Directories (Caring.com, Yelp, Care.com, A Place for Mom)
- **acquisition_type:** hybrid (free listings + paid leads)
- **cost_level:** medium
- **speed_to_results:** medium
- **scalability:** medium

### Setup Requirements
- Business profile creation on each platform
- Verification of business information
- Service area definition
- Description of services offered
- Photos and credentials
- Review management system

### Platform-Specific Details

#### Caring.com
- **Traffic:** 2+ million monthly visitors
- **Listing Type:** Free profile available; paid partnerships for priority placement
- **Lead Model:** Bid price per lead (pay for referrals)
- **Monthly Care Leads:** 12,000+
- **Contact:** (833) 415-0214 for directory accounts
- **Email:** sales_homecare@caring.com

#### Care.com
- **Claim:** World's largest online home care lead referral site
- **Process:** Background check (CareCheck) required before profile goes public
- **Model:** Freemium subscription; paying agencies get enhanced features
- **Features:** Apply for listed jobs, receive service requests, get reviewed

#### A Place for Mom
- **Reach:** Helps 300,000+ families annually
- **Profile:** Free business profile includes services, prices, reviews
- **Fee:** Pay per signed client (not per lead)
- **Contact:** Partner Central for signup

#### Aging Care
- **Profile:** Free directory listing
- **Cost:** $55 per lead
- **Note:** No reviews on profiles

#### Care In Homes
- **Traffic:** 500,000+ unique website visitors
- **Conversion Rate:** 5-15% on email referrals
- **CAC:** $250-450 average client acquisition cost
- **Deposit:** $365 starting deposit

#### Accredited Home Health Care
- **Eligibility:** Must have accreditation
- **Basic Profile:** Free (name and phone only)
- **Enhanced:** Annual rates starting from $900

### Compliance Constraints
- Must maintain accurate business information
- Cannot make unsubstantiated claims
- Must comply with platform-specific review policies
- HIPAA compliance for any patient information shared

### Targeting Capabilities
- Geographic visibility in platform searches
- Service category matching
- Review-based ranking
- Paid promotion for priority placement

### Example Use Case
A home care agency maintains free profiles on Caring.com, Yelp, and Google Business Profile while paying for enhanced listings on Caring.com to receive priority placement in search results within their service area.

### Expected ROI Range
- **Free Listings:** $0 cost, variable lead volume
- **Caring.com Leads:** Bid-based pricing (varies by market)
- **Aging Care:** $55 per lead
- **Care In Homes:** $250-450 per signed client
- **Typical Directory CPL:** $30-150

### Source Information
- **source_name:** ShiftCare / Senior Living Foresight / Caring.com Partners
- **source_url:** https://shiftcare.com/us/blog/best-referral-sites-for-home-care-businesses
- **source_type:** industry
- **initial_confidence:** high
- **notes:** Directory leads often higher quality due to active search intent; Caring.com consistently ranked #1 or #2 by senior living industry experts

---

## CHANNEL 5: Medicare.gov Listings

### Channel Overview
- **channel_name:** Medicare.gov Care Compare / Provider Directory
- **acquisition_type:** organic (free government listing)
- **cost_level:** low
- **speed_to_results:** long
- **scalability:** medium

### Setup Requirements
- Medicare certification as Home Health Agency (HHA)
- Compliance with Conditions of Participation (CoP)
- State licensure in operating state(s)
- National Provider Identifier (NPI)
- OASIS data submission compliance
- Quality reporting through HHQRP

### Compliance Constraints
- Must maintain 90%+ compliance rate with OASIS requirements
- Must meet all federal health and safety standards
- Subject to unannounced CMS surveys
- Must maintain proper organizational structure
- Must respect patient rights per CMS guidelines
- Must have effective Quality Assurance and Performance Improvement (QAPI) program

### Targeting Capabilities
- Appears in Medicare Care Compare search results
- Visible to Medicare beneficiaries actively searching for home health
- Star ratings affect visibility and patient choice
- Quality measure performance impacts ranking

### Example Use Case
A Medicare-certified home health agency maintains high OASIS compliance rates and positive HHCAHPS survey scores, resulting in a 4+ star rating on Medicare Care Compare, making them more visible to Medicare beneficiaries searching for home health services.

### Expected ROI Range
- **Listing Cost:** Free (certification costs apply)
- **Lead Quality:** Very high (Medicare beneficiaries actively seeking care)
- **Conversion Rate:** Higher than paid channels due to active intent
- **Star Rating Impact:** Higher star ratings correlate with increased patient volume

### Key Data Points
| Requirement | Details | Source |
|-------------|---------|--------|
| OASIS Compliance Rate | Minimum 90% | CMS |
| HHQRP Participation | Mandatory | CMS |
| Survey Frequency | Unannounced periodic | CMS |
| Star Rating Display | Public on Care Compare | Medicare.gov |

### Source Information
- **source_name:** CMS Medicare Communications Guidelines / Activated Insights
- **source_url:** https://activatedinsights.com/articles/cms-guidelines-for-home-health/
- **source_type:** government
- **initial_confidence:** high
- **notes:** Medicare certification is essential for reimbursement eligibility; high star ratings are powerful marketing tools

---

## CHANNEL 6: State Registries

### Channel Overview
- **channel_name:** State Home Care Aide Registries / State Licensing Directories
- **acquisition_type:** organic (government registry)
- **cost_level:** low
- **speed_to_results:** long
- **scalability:** low (state-specific)

### Setup Requirements
- State home health agency license
- Home Care Aide registration (where required)
- Background checks for all staff
- Compliance with state-specific training requirements
- Certificate of Need (CON) in 14 states

### State-Specific Requirements

#### California
- Home Care Aide registration required
- $35 non-refundable application fee
- Criminal background check via LiveScan
- Registration renewal every 2 years
- California Department of Social Services oversight

#### New York
- Home Care Registry lists workers who completed state-approved training
- Third-party updatable (state doesn't guarantee accuracy)

#### States NOT Requiring License (4 states only)
- Iowa
- Massachusetts
- Michigan
- Ohio

#### States Requiring Certificate of Need (CON)
- 14 states require CON before proceeding with home health agency establishment
- Helps state authorities control excess supply

### Compliance Constraints
- Must maintain state licensure
- Must comply with state-specific training requirements
- Staff must pass criminal background checks
- May require fingerprints and drug testing
- Must verify nursing licenses with state board
- CNAs and HHAs may need state registration

### Targeting Capabilities
- Appears in state registry searches
- Visible to families searching state databases
- Provides credibility through government verification

### Example Use Case
A California home care agency ensures all caregivers are registered with the California Home Care Aide Registry, displaying this credential to families as evidence of background-checked, state-registered caregivers.

### Expected ROI Range
- **Registration Cost:** $35 per aide (California)
- **Visibility:** Moderate (families must know to search registry)
- **Credibility Value:** High (government verification)

### Source Information
- **source_name:** CareAcademy / California Department of Social Services / Harbor Compliance
- **source_url:** https://careacademy.com/blog/get-license-home-health/
- **source_type:** government
- **initial_confidence:** high
- **notes:** State registries primarily serve compliance/verification purposes rather than direct marketing; 46 states require licensing

---

## CHANNEL 7: Community Partnerships

### Channel Overview
- **channel_name:** Community Partnerships (Healthcare Providers, Senior Centers, etc.)
- **acquisition_type:** referral
- **cost_level:** low
- **speed_to_results:** medium
- **scalability:** medium

### Setup Requirements
- Relationship building with healthcare providers
- Professional networking in community
- Educational materials and presentations
- Clear referral processes
- Staff training on partnership engagement

### Key Partnership Opportunities

#### Healthcare Providers
- Primary care physicians
- Hospitals and discharge planners
- Rehabilitation centers
- Skilled nursing facilities
- Medical social workers

#### Community Organizations
- Senior centers
- Adult day programs
- Libraries
- Community centers
- Health expos and fairs

#### Professional Networks
- Long-term care insurance providers
- Financial planners
- Elder law attorneys
- Geriatric care managers

#### Veteran Affairs Programs
- VA Aid and Attendance programs
- Homemaker/Home Health Aide programs
- Requires credentialing and ongoing compliance

### Compliance Constraints
- Must comply with CMS marketing guidelines for healthcare settings
- Cannot offer inducements for referrals (anti-kickback regulations)
- Educational events must be separate from sales events (12-hour rule)
- Must maintain professional boundaries
- HIPAA compliance in all communications

### Targeting Capabilities
- Direct referrals from trusted sources
- Pre-qualified leads through professional relationships
- Community visibility through event participation

### Example Use Case
A home health agency establishes relationships with local hospital discharge planners, providing in-service presentations about their services and maintaining open communication channels for smooth patient transitions. They also host quarterly educational workshops at senior centers on fall prevention.

### Expected ROI Range
- **Cost:** Primarily staff time and materials
- **Lead Quality:** Very high (referred by trusted sources)
- **Conversion Rate:** Highest of all channels (typically 30-50%+)
- **CAC:** Lowest of all channels

### Key Data Points
| Partnership Type | Value | Source |
|-----------------|-------|--------|
| Hospital Discharge Referrals | High volume, urgent need | Industry |
| Physician Referrals | Trusted source, high conversion | Industry |
| Senior Center Events | Brand awareness, community trust | Industry |
| VA Programs | Steady, mission-driven client base | Brasstacks |

### Source Information
- **source_name:** Constellation Health Services / Ankota / Brasstacks
- **source_url:** https://constellationhs.com/articles/home-health-referral-partners/
- **source_type:** industry
- **initial_confidence:** high
- **notes:** Community partnerships consistently deliver highest-quality leads at lowest cost; requires ongoing relationship maintenance

---

## CHANNEL 8: Religious/Community Organizations

### Channel Overview
- **channel_name:** Religious Organizations / Faith-Based Community Groups
- **acquisition_type:** referral
- **cost_level:** low
- **speed_to_results:** medium
- **scalability:** medium

### Setup Requirements
- Relationship building with faith community leaders
- Cultural sensitivity training for staff
- Educational presentation materials
- Participation in faith-based health fairs
- Volunteer engagement opportunities

### Key Opportunities

#### Faith Organizations
- Churches, synagogues, mosques, temples
- Faith-based senior groups
- Religious health ministries
- Clergy and pastoral care networks

#### Adult Day Centers
- Partnership for caregiver support resources
- Educational workshops on aging
- Respite care information sharing

#### Community Outreach Activities
- Health fairs at places of worship
- Educational talks on caregiving
- Caregiver stress management sessions
- Free resource checklists

### Compliance Constraints
- Must respect religious and cultural differences
- Cannot appear to favor any particular faith
- Educational content must be secular and inclusive
- Must comply with all healthcare marketing regulations

### Targeting Capabilities
- Access to congregants who trust religious leadership
- Community visibility through faith-based events
- Word-of-mouth referrals within religious communities

### Example Use Case
A home care agency partners with local churches to provide monthly "Caregiver Support Sessions" after Sunday services, offering free resources and information about home care services while building trust within the faith community.

### Expected ROI Range
- **Cost:** Staff time, materials, potential sponsorships
- **Lead Quality:** High (pre-qualified by trust and shared values)
- **Conversion Rate:** Higher than cold leads
- **Community Goodwill:** Significant long-term value

### Key Data Points
| Activity | Expected Outcome | Source |
|----------|-----------------|--------|
| Educational Talks | Brand awareness, trust building | Brasstacks |
| Health Fair Participation | Direct lead generation | Ankota |
| Caregiver Workshops | Positioning as trusted authority | Brasstacks |
| Volunteer Activities | Community goodwill, visibility | Love & Company |

### Source Information
- **source_name:** Brasstacks / Ankota / Love & Company
- **source_url:** https://brasstacks.works/blog/best-strategies-for-home-care-referrals
- **source_type:** industry
- **initial_confidence:** medium
- **notes:** Faith-based partnerships deliver pre-qualified referrals based on trust; effectiveness varies by community demographics

---

## Cross-Channel Comparison Matrix

| Channel | Cost Level | Speed | Lead Quality | Scalability | Best For |
|---------|------------|-------|--------------|-------------|----------|
| Google Ads | High | Short | Medium-High | High | Immediate leads, specific services |
| SEO | Low | Long | High | High | Long-term sustainable growth |
| Facebook Ads | Medium | Short | Medium | Medium | Brand awareness, education |
| Local Directories | Medium | Medium | High | Medium | Credibility, active searchers |
| Medicare.gov | Low | Long | Very High | Medium | Medicare beneficiary reach |
| State Registries | Low | Long | Medium | Low | Compliance, verification |
| Community Partnerships | Low | Medium | Very High | Medium | High-quality referrals |
| Religious/Community | Low | Medium | High | Medium | Trust-based referrals |

---

## ROI Benchmarks Summary

### Cost Per Lead (CPL) by Channel
| Channel | CPL Range | Source |
|---------|-----------|--------|
| Google Ads (Search) | $50-$300 | LocaliQ, Patient10x |
| SEO (Organic) | $25-$100 | Industry benchmarks |
| Facebook Ads | $30-$150 | AdAmigo.ai |
| Local Directories | $30-$150 | Platform-specific |
| Medicare.gov | Free (certification costs) | CMS |
| State Registries | $35 per aide (CA) | State sources |
| Community Partnerships | Staff time only | Industry |
| Religious/Community | Staff time only | Industry |

### Conversion Rates by Channel
| Channel | Conversion Rate | Source |
|---------|-----------------|--------|
| Google Ads (Search) | ~8.09% | LocaliQ |
| Facebook Ads | ~2.84% | Varos |
| SEO | Varies (typically higher than paid) | Industry |
| Referrals | 30-50%+ | Industry |

---

## Compliance Summary

### Universal Requirements (All Channels)
- HIPAA compliance for all patient information
- Accurate, evidence-based health information only
- No unsubstantiated medical claims
- Proper disclaimers where required
- Written consent for patient testimonials

### Channel-Specific Compliance
- **Google Ads:** LegitScript certification may be required; no PHI in ads
- **Facebook Ads:** Cannot target based on health conditions; awareness focus recommended
- **Medicare.gov:** Must maintain 90%+ OASIS compliance; subject to CMS surveys
- **State Registries:** Must comply with state-specific licensing and training requirements
- **Community Partnerships:** Cannot offer inducements for referrals; educational/sales event separation

---

## Unresolved Items & Data Gaps

1. **Medicare.gov Listing Process:** Specific enrollment steps for appearing in Care Compare need further documentation
2. **Caring.com Current Pricing:** Exact bid pricing model details not publicly available
3. **State Registry Search Volume:** Data on how many families use state registries to find care
4. **Faith-Based ROI:** Limited quantitative data on conversion rates from religious organization partnerships
5. **Long-term SEO ROI:** Benchmarks for 12+ month SEO campaigns in home care specifically

---

## Research Sources Index

### Government Sources
- CMS Medicare Communications and Marketing Guidelines
- California Department of Social Services Home Care Services Bureau
- Medicare.gov Care Compare

### Industry Platforms
- Caring.com Partner Resources
- Google Ads Help Center
- Meta Business Help Center
- Yelp for Business

### Industry Publications
- ShiftCare Blog
- Ankota Home Care Software Blog
- Senior Care Marketing Max
- Brasstacks Works

### Data Providers
- LocaliQ
- Varos
- AdAmigo.ai
- WebFX

---

*Document compiled for healthcare intelligence research purposes. All sources verified and cited.*
