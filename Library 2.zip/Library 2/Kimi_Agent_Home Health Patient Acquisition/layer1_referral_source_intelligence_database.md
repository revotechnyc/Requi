# LAYER 1 - REFERRAL SOURCE INTELLIGENCE DATABASE
## Home Healthcare Patient Acquisition Intelligence
### Research Agent Findings - Comprehensive Report

---

## EXECUTIVE SUMMARY

This report provides raw intelligence on ALL major patient referral sources for home healthcare businesses in the United States, gathered from approved government, industry, and academic sources. The findings are organized by the 9 required referral source categories.

---

## CATEGORY 1: HOSPITALS (Discharge Planners)

### FINDING 1.1: Hospital Discharge Planning Requirements
**finding_category:** Hospitals - Discharge Planners  
**finding_description:**  
Under 42 CFR § 482.43, hospitals must have an effective discharge planning process that includes:
- Identification of patients likely to need post-hospital services at early stage of hospitalization
- Discharge planning evaluation by RN, social worker, or qualified personnel
- Evaluation must assess likelihood of needing post-hospital services AND availability of services
- Hospital must include list of Medicare-participating HHAs in discharge plan for patients needing home health
- HHAs must REQUEST to be listed by the hospital as available
- Hospital must inform patient of freedom to choose among participating Medicare providers
- Hospital must NOT specify or limit qualified providers available to patient
- Hospital must arrange for initial implementation of discharge plan
- Must transfer/refer patients with necessary medical information to appropriate facilities

**source_name:** CMS State Operations Manual / 42 CFR § 482.43  
**source_url:** https://www.cms.gov/regulations-and-guidance/guidance/transmittals/downloads/r87soma.pdf  
**source_type:** Government  
**data_points_collected:**
- 42 CFR § 482.43 discharge planning requirements
- HHAs must request to be listed
- Hospital must provide list of Medicare-participating HHAs
- Patient has freedom to choose among providers
- Discharge evaluation by RN/social worker required

**initial_confidence:** HIGH  
**unresolved_items:** Specific volume statistics for hospital referrals by region  
**notes:** Primary regulatory framework governing hospital-to-home health referrals

---

### FINDING 1.2: Hospital Referral Process Workflow
**finding_category:** Hospitals - Discharge Planners  
**finding_description:**  
According to CMS Medicare Claims Processing Manual Chapter 10:
- Hospitals discharging Medicare beneficiaries to home health play important role in alerting beneficiaries to potential liability
- Under COP for Hospitals (42 CFR § 482.43(b)(3) and (6)), hospitals must have discharge planning process applying to all patients
- Discharge planning evaluation must include evaluation of likelihood of patient needing post-hospital services and availability of services
- Hospital must include discharge planning evaluation in patient's medical record
- Hospital must discuss results of evaluation with patient or individual acting on their behalf
- Under 42 CFR § 482.43(c)(5), patient and family must be counseled to prepare them for post-hospital care
- Under 42 CFR § 482.43(d), hospital must transfer or refer patients along with necessary medical information to appropriate facilities, agencies, or outpatient services

**source_name:** CMS Medicare Claims Processing Manual - Chapter 10  
**source_url:** https://www.cms.gov/regulations-and-guidance/guidance/manuals/downloads/clm104c10.pdf  
**source_type:** Government  
**data_points_collected:**
- Hospital must counsel beneficiaries on consolidated billing
- Hospital should provide list of HHAs for beneficiaries to choose from
- Hospital should notify chosen HHA and include counseling notes
- Hospital plays key role in making beneficiaries aware of Medicare home health coverage policies

**initial_confidence:** HIGH  
**unresolved_items:** None  
**notes:** Core regulatory guidance for hospital discharge to home health

---

### FINDING 1.3: Hospital Referral Volume Data
**finding_category:** Hospitals - Discharge Planners  
**finding_description:**  
MedPAC data shows hospital discharge patterns to home health:
- 2019: 15.8% of IPPS hospital discharges to HHA
- 2020: 20.1% of IPPS hospital discharges to HHA (COVID surge)
- 2021: 19.6% of IPPS hospital discharges to HHA
- 2022 (first 10 months): 18.7% of IPPS hospital discharges to HHA
- Total discharges with at least one PAC service: 39.1% (2019) to 41.6% (2022)
- Home health is the SECOND most common post-acute destination after SNF

**source_name:** MedPAC Report to Congress - Home Health Care Services  
**source_url:** https://www.medpac.gov/wp-content/uploads/2024/03/Mar24_Ch7_MedPAC_Report_To_Congress_SEC.pdf  
**source_type:** Government  
**data_points_collected:**
- 15.8-20.1% hospital discharge rate to HHA (2019-2022)
- HHA second most common PAC destination after SNF
- 39-42% of hospital discharges receive some form of PAC

**initial_confidence:** HIGH  
**unresolved_items:** Regional variation data, specific hospital-level statistics  
**notes:** MedPAC is primary data source for Medicare PAC utilization

---

### FINDING 1.4: Discharge Planner Factors Influencing Referrals
**finding_category:** Hospitals - Discharge Planners  
**finding_description:**  
MedPAC interviews with acute care hospital discharge planners revealed key factors influencing referral decisions:
- Environmental factors: availability of IRF/SNF beds, facility admissions policies, treatment capabilities, capacity constraints
- ACH factors: daily census/bed availability, discharge/referral processes, clinical/therapy/discharge planning team perspectives
- Beneficiary factors: diagnoses, functional capabilities, medical needs, potential for discharge to home, Medicare coverage (MA vs FFS), distance/travel time to PAC facilities, patient/caregiver preferences
- Many factors weighted differently by ACH, clinicians, discharge planners, patients, and facilities

**source_name:** MedPAC Interviews with Acute Care Hospital Discharge Planners  
**source_url:** https://www.medpac.gov/wp-content/uploads/2024/03/Mar24_MedPAC_Interviews_ACH_Discharge_Planners_IRF_SNF_CONTRACTOR_SEC.pdf  
**source_type:** Government  
**data_points_collected:**
- Multiple factors influence PAC placement decisions
- Patient preference respected when possible
- Distance/travel time important consideration
- MA vs FFS coverage affects referrals

**initial_confidence:** HIGH  
**unresolved_items:** Specific weighting of factors, decision-tree algorithms  
**notes:** Primary research on discharge planner decision-making

---

### FINDING 1.5: Hospital Referral Outreach Methodology
**finding_category:** Hospitals - Discharge Planners  
**finding_description:**  
Industry sources indicate effective hospital outreach strategies:
- Build genuine relationships with discharge planners (don't just drop off brochures)
- Schedule brief meetings to understand their challenges
- Ask what they look for in home care partner
- Position agency as reliable resource that makes their job easier
- Provide clear, concise information about services
- Share data on patient outcomes, satisfaction rates, ability to handle complex cases
- Emphasize ability to reduce hospital readmission rates
- Provide streamlined processes and fast response times
- Regular touchpoints (monthly check-ins, newsletters)
- Host lunch-and-learn events on relevant topics
- Track referral sources and outcomes

**source_name:** Home Care Marketing Pros / Industry Best Practices  
**source_url:** https://www.homecaremarketing.com/referral-partner-marketing/referral-sources-for-home-health-care/  
**source_type:** Industry  
**data_points_collected:**
- Relationship-building critical
- Data/outcomes demonstration important
- Readmission reduction key selling point
- Regular communication required

**initial_confidence:** MEDIUM  
**unresolved_items:** Quantified conversion rates, specific timeline data  
**notes:** Industry guidance based on practitioner experience

---

### FINDING 1.6: Hospital Referral Statistics
**finding_category:** Hospitals - Discharge Planners  
**finding_description:**  
Private Duty Benchmarking Study (Home Care Association of America) found:
- Hospital discharge planners account for 8.8% of home care referrals
- This is the SECOND largest professional referral source after client/family referrals (19.5%)
- Ranked above SNFs (5.9%), geriatric care managers (4.2%), and assisted living (3.7%)

**source_name:** Home Care Association of America - Private Duty Benchmarking Study  
**source_url:** https://activatedinsights.com/articles/home-health-care-referrals/  
**source_type:** Industry  
**data_points_collected:**
- 8.8% of home care referrals from hospital discharge planners
- Second largest professional referral source

**initial_confidence:** MEDIUM  
**unresolved_items:** Skilled home health specific data (vs private duty)  
**notes:** Data from benchmarking study, may reflect private duty more than skilled home health

---

## CATEGORY 2: SKILLED NURSING FACILITIES (SNFs)

### FINDING 2.1: SNF-to-Home Health Referral Process
**finding_category:** Skilled Nursing Facilities (SNFs)  
**finding_description:**  
Medicare coverage of SNF care and transition to home health:
- Medicare covers up to 100 days of SNF care in a single benefit period
- Patient must have 3-day qualifying inpatient hospital stay
- Must enter SNF within 30 days of leaving hospital
- After SNF coverage ends, patients often transition to home health for continued care
- SNF staff work with patients using assessments to develop care plan
- SNF must provide discharge planning when coverage ends
- Medicare doesn't cover custodial care if it's the only kind of care needed
- When leaving SNF, patients may need help with grocery shopping, bathing, dressing, transportation
- SNF social workers/discharge planners coordinate post-SNF care

**source_name:** Medicare.gov - Skilled Nursing Facility Care  
**source_url:** https://www.medicare.gov/publications/10153-Medicare-Skilled-Nursing-Facility-Care.pdf  
**source_type:** Government  
**data_points_collected:**
- Up to 100 days SNF coverage per benefit period
- 3-day hospital stay requirement
- 30-day window to enter SNF
- Home health common post-SNF transition
- SNF discharge planning required

**initial_confidence:** HIGH  
**unresolved_items:** Specific SNF-to-HHA referral volume data  
**notes:** Core Medicare SNF benefit documentation

---

### FINDING 2.2: SNF Referral Requirements
**finding_category:** Skilled Nursing Facilities (SNFs)  
**finding_description:**  
According to CMS, SNF Conditions of Participation require:
- SNF must develop care plan for each beneficiary
- Must provide services in accordance with care plan
- Must have plan for each beneficiary's discharge
- OIG audit found 31% of SNF stays in 2012 failed to meet at least one discharge planning requirement
- Medicare paid approximately $1.9 billion for these non-compliant stays
- SNF must notify patient about home health options when skilled care no longer needed

**source_name:** MCG - Medicare Requirements for Skilled Nursing Facilities  
**source_url:** https://www.mcg.com/blog/medicare-requirements-skilled-nursing-facilities/  
**source_type:** Industry/Government data  
**data_points_collected:**
- SNF must have discharge plan for each patient
- 31% non-compliance rate for discharge planning (2012 OIG data)
- $1.9 billion paid for non-compliant stays

**initial_confidence:** HIGH  
**unresolved_items:** More recent compliance data  
**notes:** OIG data from 2012, may not reflect current compliance rates

---

### FINDING 2.3: SNF Referral Statistics
**finding_category:** Skilled Nursing Facilities (SNFs)  
**finding_description:**  
Private Duty Benchmarking Study data:
- Skilled Nursing Facilities account for 5.9% of home care referrals
- Ranked 4th among all referral sources
- SNFs are natural bridge to home health as patients leaving rehab often need continued assistance

**source_name:** Home Care Association of America - Private Duty Benchmarking Study  
**source_url:** https://activatedinsights.com/articles/home-health-care-referrals/  
**source_type:** Industry  
**data_points_collected:**
- 5.9% of home care referrals from SNFs
- Ranked 4th among referral sources

**initial_confidence:** MEDIUM  
**unresolved_items:** Skilled home health specific data  
**notes:** Data may reflect private duty more than skilled home health

---

### FINDING 2.4: SNF Outreach Methodology
**finding_category:** Skilled Nursing Facilities (SNFs)  
**finding_description:**  
Effective SNF outreach strategies:
- Network with facility administrators, social workers, and therapists
- Understand their discharge process
- Position agency as supporting patients' long-term goals
- Highlight expertise in areas complementing SNF services (PT support, medication management, dementia care)
- Demonstrate being extension of quality care they provide
- Regular communication and relationship building

**source_name:** Home Care Marketing Pros  
**source_url:** https://www.homecaremarketing.com/referral-partner-marketing/referral-sources-for-home-health-care/  
**source_type:** Industry  
**data_points_collected:**
- Network with administrators, social workers, therapists
- Understand discharge process
- Position as extension of their care

**initial_confidence:** MEDIUM  
**unresolved_items:** Quantified conversion data  
**notes:** Industry best practices guidance

---

## CATEGORY 3: ASSISTED LIVING FACILITIES (ALFs)

### FINDING 3.1: Assisted Living and Home Health
**finding_category:** Assisted Living Facilities  
**finding_description:**  
Key facts about assisted living and home health:
- Roughly 30,600 assisted living communities in U.S. with nearly 1.2 million licensed beds
- Medicare does NOT cover assisted living expenses (considered non-medical/custodial)
- However, Medicare DOES cover home health services for assisted living residents who meet criteria
- Assisted living residents can receive Medicare home health services while living in ALF
- ALF residents are 4.4% more likely to use high-quality home health agencies (2018-2019 data)
- ALF residents had 8.7% more planned home health visits
- ALF residents were 27.6% more likely to have community-initiated referrals
- 15.9% of HHC episodes in 2018-2019 were in congregate living (increased 20.5% between 2014-2019)

**source_name:** NCOA / PubMed - Trends in Medicare Home Health Care  
**source_url:** https://pubmed.ncbi.nlm.nih.gov/39956155/  
**source_type:** Academic/Government  
**data_points_collected:**
- 30,600 ALFs in U.S., 1.2 million licensed beds
- Medicare covers HHC for ALF residents who qualify
- 15.9% of HHC episodes in congregate living (2018-2019)
- 20.5% increase in ALF HHC use (2014-2019)
- ALF residents more likely to have community-initiated referrals

**initial_confidence:** HIGH  
**unresolved_items:** Specific ALF-HHA partnership models  
**notes:** Academic research using Medicare claims data

---

### FINDING 3.2: ALF Referral Statistics
**finding_category:** Assisted Living Facilities  
**finding_description:**  
Private Duty Benchmarking Study data:
- Assisted Living Facilities account for 3.7% of home care referrals
- Ranked among top 10 referral sources
- Senior living communities (including ALF) filled with potential clients who may need additional one-on-one support beyond facility services

**source_name:** Home Care Association of America - Private Duty Benchmarking Study  
**source_url:** https://activatedinsights.com/articles/home-health-care-referrals/  
**source_type:** Industry  
**data_points_collected:**
- 3.7% of home care referrals from ALFs

**initial_confidence:** MEDIUM  
**unresolved_items:** Skilled home health specific data  
**notes:** Data may reflect private duty more than skilled home health

---

### FINDING 3.3: ALF Outreach Methodology
**finding_category:** Assisted Living Facilities  
**finding_description:**  
Effective ALF outreach strategies:
- Partner with community's wellness directors or resident coordinators
- Offer to host free educational workshops for residents (fall prevention, nutrition, navigating healthcare)
- Position as helpful expert, not salesperson
- Frame partnership as win-win: help residents stay healthier/happier, improving community reputation and retention
- Provide service that enhances residents' quality of life and allows aging in place longer

**source_name:** Home Care Marketing Pros  
**source_url:** https://www.homecaremarketing.com/referral-partner-marketing/referral-sources-for-home-health-care/  
**source_type:** Industry  
**data_points_collected:**
- Partner with wellness directors
- Host educational workshops
- Position as win-win partnership

**initial_confidence:** MEDIUM  
**unresolved_items:** Quantified conversion data  
**notes:** Industry best practices guidance

---

## CATEGORY 4: PHYSICIANS / PCPs

### FINDING 4.1: Physician Certification Requirements
**finding_category:** Physicians / PCPs  
**finding_description:**  
Under 42 CFR § 424.22, physician certification requirements for home health:
- Physician or allowed practitioner must certify patient's eligibility for home health benefit
- Patient must need intermittent skilled nursing care OR physical therapy OR speech-language pathology services
- Patient must be homebound (confined to home)
- Plan of care must be established and periodically reviewed by physician
- Services must be furnished while patient under care of physician
- FACE-TO-FACE encounter required: must occur no more than 90 days prior to OR within 30 days after home health start of care
- Face-to-face must be related to primary reason patient requires home health services
- Face-to-face can be performed by: physician, NP, clinical nurse specialist, PA, certified nurse-midwife
- Face-to-face may occur through telehealth
- Physician must document date of encounter as part of certification
- Recertification required at least every 60 days when continuous care needed

**source_name:** 42 CFR § 424.22 - Requirements for Home Health Services  
**source_url:** https://www.law.cornell.edu/cfr/text/42/424.22  
**source_type:** Government  
**data_points_collected:**
- Face-to-face encounter required (90 days before or 30 days after SOC)
- Physician/NPP must certify homebound status and skilled need
- Recertification every 60 days
- Telehealth acceptable for face-to-face

**initial_confidence:** HIGH  
**unresolved_items:** None  
**notes:** Core regulatory requirement for all Medicare home health referrals

---

### FINDING 4.2: Physician Documentation Requirements
**finding_category:** Physicians / PCPs  
**finding_description:**  
According to CMS and Medicare Learning Network:
- Certifying physician's medical record AND acute/post-acute care facility's medical records must justify referral
- Documentation must confirm patient's need for skilled services AND homebound status
- Supporting documentation includes:
  * Order for Home Health Services (type, frequency)
  * Documentation to support homebound status (2 criteria)
  * Documentation to support need for intermittent skilled services
  * Face-to-face encounter documentation (progress note or discharge summary)
- Face-to-face documentation must be clearly titled, dated, signed by certifying physician
- Must include brief narrative describing how patient's clinical condition supports homebound status and skilled services need
- Electronic signatures acceptable

**source_name:** CMS MLN Matters - Physician Guide to Home Health Certification  
**source_url:** https://www.acponline.org/sites/default/files/documents/running_practice/payment_coding/medicare/home_health_certification_guide.pdf  
**source_type:** Government  
**data_points_collected:**
- Face-to-face documentation requirements detailed
- Homebound status documentation (2 criteria)
- Skilled services documentation required
- Electronic signatures acceptable

**initial_confidence:** HIGH  
**unresolved_items:** None  
**notes:** Essential guidance for physician certification

---

### FINDING 4.3: Physician Referral Process
**finding_category:** Physicians / PCPs  
**finding_description:**  
Physician referral workflow:
- Physician evaluates patient and determines need for home health
- Physician (or NPP) conducts face-to-face encounter within required timeframe
- Physician documents encounter and certifies homebound status and skilled need
- Physician office sends referral to Medicare-certified home health agency
- If patient leaving hospital, discharge planner coordinates this
- Home health agency admissions team works with physicians and discharge planners
- HHA must have great working relationships with physicians throughout service area
- Referral is official start of process

**source_name:** Central Coast VNA & Hospice / Medicare Learning Network  
**source_url:** https://ccvna.com/step-by-step-how-to-get-approved-for-medicare-home-health/  
**source_type:** Industry/Government  
**data_points_collected:**
- Physician evaluation triggers process
- Face-to-face required before referral
- Discharge planner coordinates if from hospital
- HHA relationships with physicians critical

**initial_confidence:** HIGH  
**unresolved_items:** None  
**notes:** Standard workflow for physician referrals

---

### FINDING 4.4: Physician Financial Relationship Prohibitions
**finding_category:** Physicians / PCPs  
**finding_description:**  
Under 42 CFR § 424.22(d):
- Need for home health services may NOT be certified or recertified by any physician or allowed practitioner who has financial relationship with that HHA
- Plan of care may not be established and reviewed by physician with financial relationship
- UNLESS relationship meets one of exceptions in section 1877 of Social Security Act
- Exceptions include general exceptions to referral prohibition related to ownership/investment and compensation

**source_name:** 42 CFR § 424.22  
**source_url:** https://www.law.cornell.edu/cfr/text/42/424.22  
**source_type:** Government  
**data_points_collected:**
- Stark Law applies to home health certifications
- Financial relationships prohibited unless exception applies

**initial_confidence:** HIGH  
**unresolved_items:** None  
**notes:** Critical compliance requirement

---

### FINDING 4.5: Physician Outreach Methodology
**finding_category:** Physicians / PCPs  
**finding_description:**  
Effective physician outreach strategies:
- Building relationships with physicians takes time
- Identify key practices in your area
- Have dedicated liaison visit offices to introduce agency
- Goal is to become trusted extension of their care team
- Partner with health networks to be recognized as preferred provider
- Make referral process seamless (provide easy-to-use referral pads or online portal)
- Lead with valuable insights, not sales pitch
- Share helpful tips about long-term care planning, safe transitions, caregiver stress
- Create resources they'll want to keep (tip sheets, digital guides, quick-reference brochures)
- Be consistently helpful with regular communications

**source_name:** Home Care Marketing Pros / Corecubed  
**source_url:** https://www.homecaremarketing.com/referral-partner-marketing/referral-sources-for-home-health-care/  
**source_type:** Industry  
**data_points_collected:**
- Dedicated liaison approach recommended
- Become trusted extension of care team
- Make referral process seamless
- Lead with education, not sales

**initial_confidence:** MEDIUM  
**unresolved_items:** Quantified conversion timelines  
**notes:** Industry best practices

---

## CATEGORY 5: CASE MANAGERS

### FINDING 5.1: Case Manager vs Social Worker Roles
**finding_category:** Case Managers  
**finding_description:**  
Key distinctions between case managers and social workers:
- Case managers focus on coordinating resources and services, organizing operations behind the scenes
- Social workers provide direct therapy, deal with more general social issues
- Case managers provide long-term planning and aid in medical, financial situations
- Case managers assess clients and create ongoing treatment plans
- Case managers focus on connecting individuals to services needed
- Nurse case managers (RNs) have direct clinical training
- Hospital social workers primarily focused on psychosocial assessment, discharge planning, connecting with community resources
- Social worker involvement typically ends at or shortly after discharge
- Medical case managers can speak directly with physicians in clinical terms

**source_name:** Rehab Care Coordination / Alliant University  
**source_url:** https://rehabcarecoord.com/whats-the-difference-between-a-case-manager-and-a-social-worker/  
**source_type:** Industry/Academic  
**data_points_collected:**
- Case managers coordinate resources/services
- Social workers provide therapy/crisis intervention
- Nurse case managers have clinical training
- Hospital social workers focus on discharge planning

**initial_confidence:** HIGH  
**unresolved_items:** None  
**notes:** Role clarification from industry sources

---

### FINDING 5.2: Case Manager Settings and Responsibilities
**finding_category:** Case Managers  
**finding_description:**  
Case managers work in various settings:
- Hospitals
- Rehabilitation clinics
- Long-term care facilities
- Insurance companies
- Worker's compensation programs
- Community agencies
- Nursing homes and assisted living facilities

Typical responsibilities:
- Meeting with patients to assess needs and discuss care options
- Educating patients about diagnosis, treatment plan, transitional care options
- Communicating with medical staff, insurance providers, others involved in care
- Drafting service plans for individuals
- Reviewing case progress and maintaining case files
- Connecting patients with appropriate community resources
- Being a patient advocate
- Coordinating medical appointments, therapy, in-home care

**source_name:** Alliant University / CHW Training  
**source_url:** https://www.alliant.edu/blog/case-manager-vs-social-worker-whats-difference  
**source_type:** Industry/Academic  
**data_points_collected:**
- Case managers work in multiple settings
- Assessment, planning, coordination are key responsibilities
- Patient advocacy role

**initial_confidence:** HIGH  
**unresolved_items:** None  
**notes:** Comprehensive role description

---

### FINDING 5.3: Case Manager Certification
**finding_category:** Case Managers  
**finding_description:**  
Case manager qualifications:
- Most positions require at least bachelor's degree in related field (nursing, social work, healthcare management)
- Many hold master's degrees
- Professional certifications include:
  * Certified Case Manager (CCM)
  * Certified Rehabilitation Counselor (CRC)
- Nurse case managers must hold active RN licensure
- Requirements vary by setting

**source_name:** Alliant University  
**source_url:** https://www.alliant.edu/blog/case-manager-vs-social-worker-whats-difference  
**source_type:** Industry/Academic  
**data_points_collected:**
- Bachelor's degree minimum requirement
- CCM and CRC certifications available
- Nurse case managers need RN license

**initial_confidence:** HIGH  
**unresolved_items:** None  
**notes:** Standard qualification requirements

---

### FINDING 5.4: Case Manager Outreach
**finding_category:** Case Managers  
**finding_description:**  
Effective case manager outreach:
- Case managers are key referral sources in workers' compensation, catastrophic injury, life care planning
- Coordinate full spectrum of care from first injury through return to work
- Building relationships with local VA care coordinators or social workers can help
- Must understand VA credentialing, documentation, and billing requirements
- Regular communication and demonstrating value important

**source_name:** Rehab Care Coordination  
**source_url:** https://rehabcarecoord.com/whats-the-difference-between-a-case-manager-and-a-social-worker/  
**source_type:** Industry  
**data_points_collected:**
- Case managers coordinate care across continuum
- Workers' comp and VA are key areas
- Credentialing requirements must be met

**initial_confidence:** MEDIUM  
**unresolved_items:** Quantified referral volume data  
**notes:** Industry guidance

---

## CATEGORY 6: INSURANCE CASE COORDINATORS

### FINDING 6.1: Medicare Advantage Prior Authorization Requirements
**finding_category:** Insurance Case Coordinators  
**finding_description:**  
Critical data on MA prior authorization for home health:
- In 2024, 90% of Medicare Advantage enrollees were in plan that required prior authorization of home health care
- 99% of MA enrollees in plan with prior authorization requirement in 2024
- Research shows prior authorization leads to delays in care and creates barriers to timely access
- 2022 OIG report found MA plans improperly denied or delayed care by requiring prior authorization for post-acute care
- Both MA plans and HHAs view prior authorization as burdensome
- HHAs report that prior authorization requirements impact access to care, way care is delivered, and patient experiences

**source_name:** PubMed - Prior Authorization and Utilization Management for Post-Acute Home Health  
**source_url:** https://pmc.ncbi.nlm.nih.gov/articles/PMC11886789/  
**source_type:** Academic  
**data_points_collected:**
- 90% of MA enrollees in plans requiring HHC prior auth (2024)
- 99% of MA enrollees in plans with any prior auth requirement
- Prior auth creates delays and barriers
- Both plans and HHAs find it burdensome

**initial_confidence:** HIGH  
**unresolved_items:** None  
**notes:** Academic research with 44 interviews of MA plans, PAC management companies, and HHAs

---

### FINDING 6.2: MA Plan Variation in Prior Authorization
**finding_category:** Insurance Case Coordinators  
**finding_description:**  
MA plans take varying approaches to prior authorization:
- Some plans auto-approve post-acute skilled home health to not slow down process
- Some do "light touch review" to ensure patients meet criteria
- Others require detailed and complete information before authorizing
- Some plans auto-approve HHA for 15 days (varies within organizations)
- Some approve 30 visits without review, then very light touch
- Some PAC management companies don't require prior authorization but do utilization management
- HHA reports variation by plan, worse for plans with PAC management companies
- Range in needing authorization prior to assessment vs after assessment

**source_name:** PubMed - Prior Authorization Research  
**source_url:** https://pmc.ncbi.nlm.nih.gov/articles/PMC11886789/  
**source_type:** Academic  
**data_points_collected:**
- Plans vary significantly in prior auth approaches
- Auto-approval used by some plans
- Light touch review common
- PAC management companies add complexity

**initial_confidence:** HIGH  
**unresolved_items:** None  
**notes:** Research based on 44 industry interviews

---

### FINDING 6.3: Prior Authorization Impact on HHAs
**finding_category:** Insurance Case Coordinators  
**finding_description:**  
HHA experiences with prior authorization:
- HHAs consider UM process when deciding to accept patients
- Many HHAs limit number of plans they work with due to administrative burden
- HHAs report patients delayed in being discharged from hospital because of authorization process
- HHAs delay service until prior authorization received
- Prior authorization challenges clinicians' abilities to treat patients
- Plans sometimes don't authorize home health for patients who need it
- Patients waiting at home while agency "jumping through hoops"
- Patients waiting in pain while waiting for approval
- One HHA reported: "I can see it clearly in outcomes with payers that are authorized vs not authorized... they have measurably lower number of visits to home health, and lower quality outcomes"

**source_name:** PubMed - Prior Authorization Research  
**source_url:** https://pmc.ncbi.nlm.nih.gov/articles/PMC11886789/  
**source_type:** Academic  
**data_points_collected:**
- HHAs limit plans due to burden
- Hospital discharge delays occur
- Patient care delayed
- Outcomes negatively impacted

**initial_confidence:** HIGH  
**unresolved_items:** None  
**notes:** Direct quotes from HHA representatives in research

---

### FINDING 6.4: MA Plan Cost Sharing Impact
**finding_category:** Insurance Case Coordinators  
**finding_description:**  
MedPAC data on MA plan cost sharing for home health:
- Enrollees in plans with cost sharing for home health had lower probability of using home health (7.2% vs 8.7% with no cost sharing)
- 23% of MA enrollees enrolled in plan with home health cost sharing
- Among MA home health users, those in provider-sponsored plans received 15.8 visits vs 18.1 for those not in provider-sponsored plans
- MA enrollees had 1.8 fewer visits (9.3% fewer) than FFS beneficiaries even within same HHA

**source_name:** MedPAC Report to Congress  
**source_url:** https://www.medpac.gov/wp-content/uploads/2025/06/Jun25_Ch3_MedPAC_Report_To_Congress_SEC.pdf  
**source_type:** Government  
**data_points_collected:**
- Cost sharing reduces HHC utilization (7.2% vs 8.7%)
- 23% of MA enrollees have HHC cost sharing
- MA enrollees receive fewer visits than FFS

**initial_confidence:** HIGH  
**unresolved_items:** None  
**notes:** MedPAC analysis of CMS data

---

### FINDING 6.5: Insurance Coordinator Outreach
**finding_category:** Insurance Case Coordinators  
**finding_description:**  
Working with insurance case coordinators:
- Homecare agencies must maintain strong relationships with Medicaid payers and MCOs
- Understanding payer requirements, maintaining compliance, streamlining administrative processes helps agency become preferred provider
- Strong payer relationships can lead to consistent referrals and increased client volume
- Must meet or exceed EVV compliance thresholds
- Clean claim submission process important
- Make good impression through quality performance

**source_name:** HHA Exchange  
**source_url:** https://www.hhaexchange.com/blog/how-homecare-agencies-can-build-a-strong-referral-pipeline  
**source_type:** Industry  
**data_points_collected:**
- Strong payer relationships lead to consistent referrals
- Compliance and clean claims important
- Quality performance matters

**initial_confidence:** MEDIUM  
**unresolved_items:** Quantified referral volume data  
**notes:** Industry guidance

---

## CATEGORY 7: HOSPICE ORGANIZATIONS

### FINDING 7.1: Hospice vs Home Health Distinction
**finding_category:** Hospice Organizations  
**finding_description:**  
Key distinctions between hospice and home health:
- Under standard Medicare Hospice Benefit, patients elect to forgo curative treatments for terminal illness
- Hospice focuses on comfort and symptom management
- Palliative care is broader - all hospice care is palliative, but not all palliative care is hospice
- Palliative care can be provided at any stage of serious illness, even with curative treatment
- Medicare prohibits concurrent skilled nursing and hospice care for same diagnosis
- Skilled care for unrelated conditions may still be covered while on hospice

**source_name:** ViaQuest Hospice / Crossroads Hospice  
**source_url:** https://viaquesthospice.com/understanding-the-medicare-hospice-benefit-a-guide-for-referring-providers/  
**source_type:** Industry  
**data_points_collected:**
- Hospice requires forgoing curative treatment
- Palliative care broader than hospice
- No concurrent skilled care for same diagnosis

**initial_confidence:** HIGH  
**unresolved_items:** None  
**notes:** Standard Medicare hospice benefit structure

---

### FINDING 7.2: Medicare Care Choices Model (Concurrent Care)
**finding_category:** Hospice Organizations  
**finding_description:**  
Medicare Care Choices Model (MCCM) demonstration:
- First Medicare demonstration of concurrent provision of curative and hospice services
- Authorized by Affordable Care Act Section 3120
- Eligible Medicare beneficiaries: those eligible for hospice but who had not yet used Medicare Hospice Benefit
- Must live at home and have diagnoses of advanced cancers, COPD, CHF, or HIV/AIDS
- Hospices responsible for providing access to comprehensive hospice services
- Hospices receive up to $400/month for beneficiaries enrolled >15 days or $200/month for <15 days
- 141 hospices invited to participate in 5-year demonstration starting 2016/2018

**source_name:** PubMed - Medicare Care Choices Model  
**source_url:** https://pmc.ncbi.nlm.nih.gov/articles/PMC4940650/  
**source_type:** Academic  
**data_points_collected:**
- MCCM allows concurrent curative and hospice care
- Limited to specific diagnoses
- Hospices receive monthly per-beneficiary payment
- 141 hospices participated

**initial_confidence:** HIGH  
**unresolved_items:** Current demonstration status, expansion plans  
**notes:** Demonstration program, not standard benefit

---

### FINDING 7.3: Hospice Utilization Statistics
**finding_category:** Hospice Organizations  
**finding_description:**  
NHPCO Facts and Figures (2024 Edition - 2022 data):
- 1.72 million Medicare beneficiaries enrolled in hospice care in 2022
- 49.1% of all Medicare decedents in 2022 chose hospice care
- Hospice utilization increased in 2022 for first time since 2019
- 5,058 Medicare-certified hospices in operation in 2020
- Over 72% of hospices were for-profit (2020)
- Approximately 24% nonprofit, just under 3% government-owned
- Growth in hospice ownership driven by for-profit ownership (7.1% increase 2019-2020)

**source_name:** NHPCO Facts and Figures 2024  
**source_url:** https://allianceforcareathome.org/wp-content/uploads/2024/09/Facts-Figures-2024_FINAL.pdf  
**source_type:** Industry  
**data_points_collected:**
- 1.72 million Medicare beneficiaries in hospice (2022)
- 49.1% of Medicare decedents used hospice
- 5,058 Medicare-certified hospices (2020)
- 72% for-profit hospice ownership

**initial_confidence:** HIGH  
**unresolved_items:** None  
**notes:** Leading industry data source for hospice statistics

---

### FINDING 7.4: Hospice Coordination with Home Health
**finding_category:** Hospice Organizations  
**finding_description:**  
CMS State Operations Manual on hospice coordination:
- Hospice must coordinate its hospice aide and homemaker services with Medicaid personal care benefit
- Must ensure patient receives hospice aide and homemaker services needed
- If Medicaid personal care services benefit more extensive than Medicare hospice benefit, State must pay for covered Medicaid personal care services that exceed scope of Medicare hospice benefit
- Proper coordination of services must occur

**source_name:** CMS State Operations Manual - Hospice  
**source_url:** https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_m_hospice.pdf  
**source_type:** Government  
**data_points_collected:**
- Hospice must coordinate with other benefits
- Medicaid may cover services beyond Medicare hospice

**initial_confidence:** HIGH  
**unresolved_items:** None  
**notes:** Coordination requirements for dually eligible patients

---

### FINDING 7.5: Hospice Outreach
**finding_category:** Hospice Organizations  
**finding_description:**  
Hospice referral relationships:
- Palliative care programs (including those not affiliated with hospice) require reputable home care agency partners
- Can join Center to Advance Palliative Care (CAPC) as preferred provider
- Early referral to hospice improves quality of life and outcomes
- Cost of hospice care should never delay clinically appropriate referral
- Medicare Hospice Benefit designed to remove financial barriers

**source_name:** ViaQuest Hospice / Home Care Marketing Pros  
**source_url:** https://viaquesthospice.com/understanding-the-medicare-hospice-benefit-a-guide-for-referring-providers/  
**source_type:** Industry  
**data_points_collected:**
- CAPC membership available
- Early referral improves outcomes
- Financial barriers minimal

**initial_confidence:** MEDIUM  
**unresolved_items:** Quantified hospice-to-home health referral data  
**notes:** Industry guidance

---

## CATEGORY 8: DIALYSIS CENTERS

### FINDING 8.1: Medicare ESRD Coverage
**finding_category:** Dialysis Centers  
**finding_description:**  
Medicare coverage for End-Stage Renal Disease (ESRD):
- All people with ESRD eligible for Medicare regardless of age
- Medicare Part A covers inpatient dialysis treatments in hospital
- Medicare Part B covers:
  * Outpatient dialysis treatments and doctors' services in Medicare-certified facility or home
  * Home dialysis training for patient and helper
  * Home dialysis equipment and supplies (machine, water treatment, recliner, supplies)
  * Home support services (visits from trained workers, monthly face-to-face visit with doctor/NPP)
  * Drugs for outpatient and home dialysis (heparin, erythropoiesis-stimulating agents, phosphate binders)
  * Direct nursing services (RNs, LPNs, technicians, social workers, dietitians)
- Medicare covers 3 hemodialysis (or equivalent peritoneal dialysis) treatments per week

**source_name:** Medicare.gov / CRS Report  
**source_url:** https://www.medicare.gov/coverage/dialysis-services-supplies  
**source_type:** Government  
**data_points_collected:**
- All ESRD patients eligible for Medicare
- Part B covers home dialysis training and equipment
- 3 treatments per week covered
- Direct nursing services covered

**initial_confidence:** HIGH  
**unresolved_items:** Specific dialysis center-to-home health referral data  
**notes:** Core Medicare ESRD benefit

---

### FINDING 8.2: ESRD Waiting Periods and Eligibility
**finding_category:** Dialysis Centers  
**finding_description:**  
Medicare eligibility for ESRD:
- Eligible for Medicare beginning first day of fourth month of dialysis treatment if receiving dialysis in certified outpatient facility
- May be eligible as early as first month if participating in home dialysis training program and begin training before third month
- Eligible for coverage during first month if admitted to Medicare-approved hospital for kidney transplant
- May be eligible two months prior to transplant if hospitalized in preparation
- Medicare entitlement based solely on ESRD ends when dialysis stopped for 12 months or transplant successful for 36 months
- If transplant fails or dialysis resumes, can re-enroll

**source_name:** Congressional Research Service - Medicare Coverage of ESRD  
**source_url:** https://www.congress.gov/crs-product/R45290  
**source_type:** Government  
**data_points_collected:**
- 4-month waiting period for facility dialysis (can be waived with home training)
- Transplant patients eligible immediately
- Coverage time limits apply

**initial_confidence:** HIGH  
**unresolved_items:** None  
**notes:** CRS reports are authoritative Congressional research

---

### FINDING 8.3: ESRD Payment System
**finding_category:** Dialysis Centers  
**finding_description:**  
ESRD Prospective Payment System (PPS):
- ESRD PPS provides single bundled payment for each dialysis treatment
- Phased in over 4-year period starting 2011
- Bundled payment covers dialysis, support services, training, lab tests, drugs related to ESRD treatment, supplies
- Patients generally allowed up to 3 dialysis treatments per week
- Additional treatments may be covered on basis of medical necessity
- Beneficiaries pay 20% coinsurance
- Medicare fee-for-service spending for ESRD was $33.9 billion in 2015

**source_name:** Congressional Research Service  
**source_url:** https://www.congress.gov/crs-product/R45290  
**source_type:** Government  
**data_points_collected:**
- Bundled PPS payment system
- 20% coinsurance
- $33.9 billion spending (2015)

**initial_confidence:** HIGH  
**unresolved_items:** More recent spending data  
**notes:** Payment system affects dialysis center operations

---

### FINDING 8.4: Dialysis Center Outreach
**finding_category:** Dialysis Centers  
**finding_description:**  
Dialysis center partnership opportunities:
- Palliative care offered in various settings including dialysis units
- Home care agencies can partner with dialysis centers for patients needing additional support
- ESRD patients have complex medical needs creating opportunities for skilled nursing coordination
- Social workers and dietitians at dialysis centers are key contact points

**source_name:** Illinois Department on Aging / Industry Sources  
**source_url:** https://ilaging.illinois.gov/programs/caregiver/in-home-care.html  
**source_type:** Government/Industry  
**data_points_collected:**
- Palliative care in dialysis units
- Complex medical needs create opportunities
- Social workers/dietitians key contacts

**initial_confidence:** MEDIUM  
**unresolved_items:** Quantified referral volume data  
**notes:** Limited direct research on dialysis center referrals

---

## CATEGORY 9: REHAB CENTERS (Inpatient Rehabilitation Facilities)

### FINDING 9.1: IRF-to-Home Health Referral Research
**finding_category:** Rehab Centers (IRFs)  
**finding_description:**  
Academic research on IRF-to-home health referrals:
- Study examined association between home health rehabilitation referral and 90-day hospital readmission after IRF discharge among stroke patients (N=1,219)
- 40.9% of stroke patients received home health referrals at IRF discharge
- Those who received home health referrals were more likely to be older, female, less educated, living alone, have more comorbidities, longer IRF length of stay
- Patients receiving home health referral at IRF discharge had substantially lower odds of 90-day rehospitalization
- Odds ratios: 0.325-0.407 across different statistical models (all statistically significant)
- Home health designed to provide cost-effective and convenient patient care
- Lower risk of rehospitalization may be function of case-management interventions in home health

**source_name:** American Journal of Physical Medicine & Rehabilitation (PubMed)  
**source_url:** https://pmc.ncbi.nlm.nih.gov/articles/PMC7483954/  
**source_type:** Academic  
**data_points_collected:**
- 40.9% of stroke patients received HHC referral at IRF discharge
- HHC referral associated with 60-70% reduction in 90-day readmission odds
- Home health provides cost-effective post-IRF care

**initial_confidence:** HIGH  
**unresolved_items:** Data beyond stroke patients  
**notes:** Peer-reviewed research with strong methodology

---

### FINDING 9.2: IRF vs SNF Distinctions
**finding_category:** Rehab Centers (IRFs)  
**finding_description:**  
Key differences between IRF and SNF:
- IRF provides high level of intensive therapy, specialized nursing and physician care
- Medicare and private insurances have established eligibility requirements for IRF admission
- IRF patients typically able to tolerate and participate in 3+ hours of daily inpatient rehabilitation therapy at least 5 days per week
- SNF programs have fewer requirements
- Discharge planning team assists in determining eligibility for either type of program
- Both offer therapy, physician and nursing care but at different intensity levels

**source_name:** Holy Cross Health  
**source_url:** https://www.holy-cross.com/services/rehabilitation-and-therapy/inpatient-rehabilitation  
**source_type:** Industry  
**data_points_collected:**
- IRF requires 3+ hours therapy daily, 5 days/week
- IRF has stricter eligibility requirements
- Discharge planning team determines appropriate level

**initial_confidence:** HIGH  
**unresolved_items:** None  
**notes:** Clear distinction between IRF and SNF levels of care

---

### FINDING 9.3: IRF Referral Volume Data
**finding_category:** Rehab Centers (IRFs)  
**finding_description:**  
MedPAC data on IRF utilization:
- 2019: 3.7% of IPPS hospital discharges to IRF
- 2020: 4.1% of IPPS hospital discharges to IRF
- 2021: 4.4% of IPPS hospital discharges to IRF
- 2022 (first 10 months): 4.6% of IPPS hospital discharges to IRF
- IRF utilization has been steadily increasing
- IRF patients often transition to home health after IRF discharge

**source_name:** MedPAC Report to Congress  
**source_url:** https://www.medpac.gov/wp-content/uploads/2024/03/Mar24_Ch7_MedPAC_Report_To_Congress_SEC.pdf  
**source_type:** Government  
**data_points_collected:**
- 3.7-4.6% hospital discharge rate to IRF (2019-2022)
- Steady increase in IRF utilization

**initial_confidence:** HIGH  
**unresolved_items:** None  
**notes:** MedPAC analysis of Medicare claims data

---

### FINDING 9.4: IRF Outreach Methodology
**finding_category:** Rehab Centers (IRFs)  
**finding_description:**  
Effective IRF outreach strategies:
- Network with facility administrators, social workers, and therapists
- Understand their discharge process and how agency can support patients' long-term goals
- Highlight expertise in specific areas complementing IRF services (PT support, medication management)
- Demonstrate being extension of quality care they provide
- Emphasize ability to continue therapy gains and prevent readmissions

**source_name:** Home Care Marketing Pros (adapted for IRF)  
**source_url:** https://www.homecaremarketing.com/referral-partner-marketing/referral-sources-for-home-health-care/  
**source_type:** Industry  
**data_points_collected:**
- Network with administrators, therapists
- Understand discharge process
- Position as extension of care

**initial_confidence:** MEDIUM  
**unresolved_items:** Quantified conversion data  
**notes:** Industry best practices adapted for IRF

---

## CROSS-CUTTING FINDINGS

### FINDING C.1: Home Health Agency Credentialing Requirements
**finding_category:** Cross-Cutting  
**finding_description:**  
Home health agency credentialing requirements:
- Must register for NPI (National Provider Identifier)
- Must complete CAQH profile
- Must have legal state licenses for all healthcare workers
- Must meet insurance and liability coverage requirements
- State licensure required for federal Medicare certification
- Must submit CMS Form 1572(a), 690, 1561, 855A
- Must have Joint Commission, ACHC, or CHAP accreditation
- After application acceptance and CMS approval of CMS-855A, department conducts survey before recommending agency for Medicare certification
- General liability, professional liability (malpractice), workers' compensation insurance required

**source_name:** Pennsylvania Department of Health / Credex Healthcare  
**source_url:** https://www.pa.gov/agencies/health/facilities/out-patient-healthcare-facilities/home-health/licensure  
**source_type:** Government/Industry  
**data_points_collected:**
- NPI required
- CAQH profile required
- State licensure required for Medicare certification
- CMS Forms 1572(a), 690, 1561, 855A required
- Accreditation required (Joint Commission, ACHC, or CHAP)

**initial_confidence:** HIGH  
**unresolved_items:** None  
**notes:** Standard credentialing requirements across states

---

### FINDING C.2: CMS New Acceptance-to-Service Policy (2025)
**finding_category:** Cross-Cutting  
**finding_description:**  
New CMS requirement effective 2025:
- CMS finalized new standard at 42 CFR § 484.105(i)
- Requires HHAs to develop, implement and maintain acceptance-to-service policy
- Policy must be applied consistently to each prospective patient referred for home health care
- Purpose is to address concerns regarding referral and acceptance process
- Designed to inform public of HHA's assessment of its capacity and suitability to meet anticipated needs
- Must ensure HHAs only accept patients for whom there is reasonable expectation HHA can meet needs

**source_name:** Hall Render - Home Health Update  
**source_url:** https://hallrender.com/2024/11/14/home-health-update-cms-finalizes-new-acceptance-to-service-policy-requirement/  
**source_type:** Industry/Government  
**data_points_collected:**
- New CoP requirement for acceptance-to-service policy
- Must be applied consistently
- Must assess capacity to meet patient needs

**initial_confidence:** HIGH  
**unresolved_items:** Implementation guidance details  
**notes:** New requirement for CY 2025

---

### FINDING C.3: NAHC Referral Source Statistics
**finding_category:** Cross-Cutting  
**finding_description:**  
National Association for Home Care & Hospice data:
- NAHC represents 33,000 home care and hospice organizations
- Members work with average of 396 referral sources
- 24% of referrals made by phone
- 27% of referrals made by fax
- Hospices face project costs up to $15,000 per integration project (not including yearly maintenance)
- Many referral sources using different communications systems
- Data sharing and interoperability significant challenges

**source_name:** Wikipedia / NAHC Report  
**source_url:** https://en.wikipedia.org/wiki/National_Association_for_Home_Care_%26_Hospice  
**source_type:** Industry  
**data_points_collected:**
- 33,000 organizations represented
- Average 396 referral sources per member
- 24% phone referrals, 27% fax referrals
- Integration costs up to $15,000 per project

**initial_confidence:** HIGH  
**unresolved_items:** More recent statistics  
**notes:** 2018 report data

---

### FINDING C.4: Home Health Timely Initiation
**finding_category:** Cross-Cutting  
**finding_description:**  
CMS data on timely initiation of home health:
- Share of home health stays initiated in timely manner was 95.9% for 12-month period ending June 30, 2022
- Considered timely if care begins within 3 days of hospital discharge or signed physician referral
- Slight increase from prior years
- Suggests timely access to care remains strong

**source_name:** MedPAC Report to Congress  
**source_url:** https://www.medpac.gov/wp-content/uploads/2024/03/Mar24_Ch7_MedPAC_Report_To_Congress_SEC.pdf  
**source_type:** Government  
**data_points_collected:**
- 95.9% timely initiation rate (2022)
- Timely = within 3 days of discharge/referral

**initial_confidence:** HIGH  
**unresolved_items:** None  
**notes:** CMS quality measure data

---

### FINDING C.5: Sales Liaison Role in Home Health
**finding_category:** Cross-Cutting  
**finding_description:**  
Sales/Community Liaison responsibilities:
- Build and maintain relationships with discharge planners, physicians, community partners
- Generate new patient leads
- Develop and manage referral relationships with hospitals, rehab centers, physicians
- Identify new opportunities and expand service territory
- Promote agency services to discharge planners and case managers
- Collaborate with leadership to meet growth targets
- Monitor and analyze referral trends to refine outreach strategies
- Conduct regular sales calls with physicians, social workers, discharge planners
- Facilitate efficient coordination to home and increase number of referrals
- Typical compensation: $35-45/hour plus uncapped commission based on census growth

**source_name:** Career Strategies / WayUp / SalesJobs  
**source_url:** https://www.ziprecruiter.com/c/Career-Strategies-Hospice-&-Home-Health/Job/Sales-Liaison-Home-Healthcare/-in-Saint-Louis,MO?jid=6894419ca317a9cf  
**source_type:** Industry  
**data_points_collected:**
- Liaison builds relationships with key referral sources
- Compensation typically $35-45/hour plus commission
- Responsible for census growth

**initial_confidence:** HIGH  
**unresolved_items:** None  
**notes:** Job posting data shows standard industry role

---

## SUMMARY TABLES

### Table 1: Referral Source Volume Rankings (Private Duty)
| Rank | Referral Source | Percentage |
|------|----------------|------------|
| 1 | Past/current clients & families | 19.5% |
| 2 | Hospital discharge planners | 8.8% |
| 3 | Medicare-certified home health agencies | 7.1% |
| 4 | Skilled nursing facilities | 5.9% |
| 5 | State Medicaid waiver programs | 5.7% |
| 6 | Geriatric care managers | 4.2% |
| 7 | Area Agency on Aging case managers | 4.0% |
| 8 | Assisted living facilities | 3.7% |

### Table 2: Post-Acute Care Discharge Patterns (Medicare FFS)
| Destination | 2019 | 2020 | 2021 | 2022 |
|-------------|------|------|------|------|
| No PAC service | 60.8% | 59.0% | 58.6% | 58.4% |
| Any PAC service | 39.1% | 41.0% | 41.4% | 41.6% |
| Skilled Nursing Facility | 18.7% | 15.9% | 16.6% | 17.4% |
| Home Health Agency | 15.8% | 20.1% | 19.6% | 18.7% |
| Inpatient Rehab Facility | 3.7% | 4.1% | 4.4% | 4.6% |
| Long-term Acute Care | 0.9% | 1.0% | 0.8% | 0.8% |

### Table 3: Conversion Difficulty Assessment
| Referral Source | Conversion Difficulty | Key Barriers |
|----------------|----------------------|--------------|
| Hospitals (Discharge Planners) | MEDIUM | Must request to be listed; compete with other HHAs; readmission risk concerns |
| SNFs | MEDIUM | Discharge coordination; care continuity; competing HHAs |
| Assisted Living | LOW-MEDIUM | Less formal process; relationship-based; education needed |
| Physicians/PCPs | MEDIUM-HIGH | Stark Law compliance; face-to-face requirements; trust building |
| Case Managers | MEDIUM | Certification requirements; care coordination complexity |
| Insurance Coordinators | HIGH | Prior authorization burden; plan variation; administrative complexity |
| Hospice | LOW-MEDIUM | Concurrent care restrictions; clear eligibility criteria |
| Dialysis Centers | MEDIUM | Complex medical needs; ESRD payment rules; coordination requirements |
| Rehab Centers (IRFs) | MEDIUM | Therapy continuation; readmission prevention focus |

---

## DATA QUALITY ASSESSMENT

### High Confidence Sources
- CMS regulations (42 CFR) - Primary legal authority
- Medicare Claims Processing Manual - Official CMS guidance
- MedPAC Reports to Congress - Government analysis of Medicare data
- Academic peer-reviewed research (PubMed) - Rigorous methodology
- NHPCO Facts and Figures - Industry standard data source

### Medium Confidence Sources
- Industry marketing guidance - Based on practitioner experience
- Job posting data - Reflects industry practice but not standardized
- Private duty benchmarking data - May not reflect skilled home health patterns

### Low Confidence Sources
- None used in this report

---

## UNRESOLVED ITEMS REQUIRING FURTHER RESEARCH

1. **Regional Variation Data:** Specific referral patterns by state/region
2. **Skilled vs Private Duty Breakdown:** Most statistics combine both service types
3. **Conversion Timeline Data:** Quantified data on time from initial contact to first referral
4. **Contract Requirements:** Specific contractual arrangements between HHAs and referral sources
5. **Quality Metric Thresholds:** Specific outcome metrics referral sources use to evaluate HHAs
6. **Medicare Advantage Network Data:** Specific MA plan network requirements and contracting
7. **Hospice-to-Home Health Referral Volume:** Data on patients transitioning from hospice to home health
8. **Pediatric Referral Sources:** Data specific to pediatric home health referrals

---

## SOURCE INDEX

### Government Sources
1. CMS - 42 CFR § 424.22 (Home Health Certification)
2. CMS - 42 CFR § 482.43 (Hospital Discharge Planning)
3. CMS Medicare Claims Processing Manual Chapter 10
4. CMS State Operations Manual
5. MedPAC Reports to Congress (Multiple years)
6. Medicare.gov Coverage Information
7. Congressional Research Service (ESRD Report)

### Academic Sources
1. PubMed - Home Health Referral Research (Multiple studies)
2. American Journal of Physical Medicine & Rehabilitation
3. Health Services Research Journal

### Industry Sources
1. National Hospice and Palliative Care Organization (NHPCO)
2. National Association for Home Care & Hospice (NAHC)
3. Home Care Marketing Pros
4. Home Care Association of America
5. HHA Exchange
6. Activated Insights

---

*Report compiled by Research Agent*
*Date: Research Session*
*Step: 7/40*

