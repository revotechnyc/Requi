# Federal Healthcare Compliance Database
## Comprehensive Reference Guide for Healthcare Regulatory Compliance

**Compiled:** March 2026  
**Sources:** CMS.gov, HHS.gov, OIG.hhs.gov, Federal Register, eCFR

---

# SECTION 1: CMS CONDITIONS OF PARTICIPATION

## 1.1 HOSPITALS (42 CFR Part 482)

| Condition | CFR Citation | Key Requirements | Effective Date | Source URL |
|-----------|--------------|------------------|----------------|------------|
| Compliance with Federal, State and Local Laws | 42 CFR 482.11 | Hospital must ensure all applicable Federal, State and local law requirements are met | October 17, 2008 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Transmittals/downloads/R37SOMA.pdf |
| Governing Body | 42 CFR 482.12 | Hospital must have effective governing body legally responsible for conduct of hospital; must have only one governing body | October 17, 2008 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Transmittals/downloads/R37SOMA.pdf |
| Medical Staff | 42 CFR 482.22 | Organized medical staff operating under bylaws approved by governing body; responsible for quality of medical care; periodic appraisals of members | October 17, 2008 | https://www.law.cornell.edu/cfr/text/42/482.22 |
| Nursing Services | 42 CFR 482.23 | 24-hour nursing services rendered or supervised by registered professional nurse; licensed nurse on duty at all times | October 17, 2008 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Transmittals/downloads/R37SOMA.pdf |
| Medical Records | 42 CFR 482.24 | Maintain clinical records on all patients; medical staff bylaws required | October 17, 2008 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Transmittals/downloads/R37SOMA.pdf |
| Pharmacy Services | 42 CFR 482.25 | Hospital must have pharmaceutical services meeting needs of patients | October 17, 2008 | https://www.govinfo.gov/content/pkg/CFR-2019-title42-vol5/pdf/CFR-2019-title42-vol5-part482.pdf |
| Food and Dietetic Services | 42 CFR 482.28 | Organized dietary services directed and staffed by qualified personnel; qualified dietitian full-time, part-time, or consultant | October 17, 2008 | https://www.govinfo.gov/content/pkg/CFR-2019-title42-vol5/pdf/CFR-2019-title42-vol5-part482.pdf |
| Utilization Review | 42 CFR 482.30 | UR plan in effect for review of services furnished to Medicare/Medicaid patients; UR committee of 2+ practitioners | October 17, 2008 | https://www.govinfo.gov/content/pkg/CFR-2019-title42-vol5/pdf/CFR-2019-title42-vol5-part482.pdf |
| Infection Control | 42 CFR 482.42 | Active program for surveillance, prevention, and control of healthcare-associated infections; infection control officer designated | May 16, 2012 (revised) | https://www.govinfo.gov/content/pkg/CFR-2019-title42-vol5/pdf/CFR-2019-title42-vol5-part482.pdf |
| Discharge Planning | 42 CFR 482.43 | Hospital must have discharge planning process; evaluate patients for discharge planning needs | October 17, 2008 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Transmittals/downloads/R37SOMA.pdf |
| Quality Assessment and Performance Improvement | 42 CFR 482.21 | Hospital-wide QAPI program including data-driven quality assessment and performance improvement | October 17, 2008 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Transmittals/downloads/R37SOMA.pdf |
| Patients' Rights | 42 CFR 482.13 | Protection and promotion of patient rights including privacy, safety, and grievance procedures | October 17, 2008 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Transmittals/downloads/R37SOMA.pdf |
| Emergency Services | 42 CFR 482.55 | Hospital must meet emergency services requirements; 24-hour emergency services available | October 17, 2008 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Transmittals/downloads/R37SOMA.pdf |
| Laboratory Services | 42 CFR 482.27 | Hospital must provide laboratory services meeting needs of patients or have arrangement with certified lab | October 17, 2008 | https://www.govinfo.gov/content/pkg/CFR-2019-title42-vol5/pdf/CFR-2019-title42-vol5-part482.pdf |
| Radiologic Services | 42 CFR 42 CFR 482.26 | Hospital must provide radiologic services meeting needs of patients; safety requirements for equipment | October 17, 2008 | https://www.govinfo.gov/content/pkg/CFR-2019-title42-vol5/pdf/CFR-2019-title42-vol5-part482.pdf |
| Anesthesia Services | 42 CFR 482.52 | Qualified personnel must administer anesthesia; organized anesthesia services | October 17, 2008 | https://www.govinfo.gov/content/pkg/CFR-2019-title42-vol5/pdf/CFR-2019-title42-vol5-part482.pdf |
| Surgical Services | 42 CFR 482.51 | Hospital must have organized surgical services if surgery performed; appropriate staffing and equipment | October 17, 2008 | https://www.govinfo.gov/content/pkg/CFR-2019-title42-vol5/pdf/CFR-2019-title42-vol5-part482.pdf |
| Swing-Bed Requirements | 42 CFR 482.66 | Hospitals with swing-bed agreements must meet SNF requirements | October 17, 2008 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Transmittals/downloads/R37SOMA.pdf |

---

## 1.2 NURSING HOMES/LONG-TERM CARE (42 CFR Part 483)

| Condition | CFR Citation | Key Requirements | Effective Date | Source URL |
|-----------|--------------|------------------|----------------|------------|
| Basis and Scope | 42 CFR 483.1 | Statutory basis from Sections 1819 and 1919 of Social Security Act for SNF/NF requirements | February 2, 1989 | https://www.govinfo.gov/content/pkg/CFR-2018-title42-vol5/pdf/CFR-2018-title42-vol5-sec483-1.pdf |
| Resident Rights | 42 CFR 483.10 | Residents have right to dignity, respect, and full exercise of citizenship rights; informed of rights | October 1, 1990 | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-483 |
| Freedom from Abuse, Neglect, and Exploitation | 42 CFR 483.12 | Facility must ensure residents free from abuse, neglect, misappropriation of property | October 1, 1990 | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-483 |
| Admission, Transfer, and Discharge Rights | 42 CFR 483.15 | Requirements for admission, transfer, and discharge including documentation and notice | October 1, 1990 | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-483 |
| Resident Assessment | 42 CFR 483.20 | Comprehensive, accurate, standardized reproducible assessment of each resident's functional capacity | October 1, 1990 | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-483 |
| Comprehensive Person-Centered Care Planning | 42 CFR 483.21 | Development of comprehensive care plan for each resident within 7 days of completion of assessment | October 1, 1990 | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-483 |
| Quality of Care | 42 CFR 483.24 | Facility must provide necessary care and services to attain or maintain highest practicable well-being | October 1, 1990 | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-483 |
| Quality of Life | 42 CFR 483.25 | Facility must care for residents in manner that promotes maintenance or enhancement of quality of life | October 1, 1990 | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-483 |
| Nursing Services | 42 CFR 483.35 | Sufficient nursing staff to provide nursing and related services; RN on duty 8 consecutive hours daily | October 1, 1990 | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-483 |
| Behavioral Health Services | 42 CFR 483.40 | Facility must provide medically-related social services to attain or maintain highest practicable well-being | October 1, 1990 | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-483 |
| Pharmacy Services | 42 CFR 483.45 | Facility must provide routine and emergency drugs and biologicals; licensed pharmacist oversight | October 1, 1990 | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-483 |
| Laboratory Services | 42 CFR 483.50 | Facility must provide or obtain laboratory services to meet needs of residents | October 1, 1990 | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-483 |
| Dental Services | 42 CFR 483.55 | Facility must assist residents in obtaining routine and 24-hour emergency dental care | October 1, 1990 | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-483 |
| Food and Nutrition Services | 42 CFR 483.60 | Facility must provide each resident with nourishing, palatable, well-balanced diet | October 1, 1990 | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-483 |
| Specialized Rehabilitative Services | 42 CFR 483.65 | Facility must provide specialized rehabilitative services as required by physician | October 1, 1990 | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-483 |
| Administration | 42 CFR 483.70 | Governing body responsible for management; administrator qualified; QAPI program required | October 1, 1990 | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-483 |
| Quality Assurance and Performance Improvement | 42 CFR 483.75 | Facility must develop, implement, and maintain effective QAPI program | November 28, 2017 | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-483 |
| Infection Control | 42 CFR 483.80 | Infection prevention and control program including antibiotic stewardship program | November 28, 2017 | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-483 |
| Compliance and Ethics Program | 42 CFR 483.85 | Facility must have effective compliance and ethics program | November 28, 2017 | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-483 |
| Physical Environment | 42 CFR 483.90 | Facility must be designed, constructed, equipped, and maintained to protect health and safety | October 1, 1990 | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-483 |
| Training Requirements | 42 CFR 483.95 | Required training for all staff including dementia care and abuse prevention | November 28, 2017 | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-483 |

---

## 1.3 HOME HEALTH AGENCIES (42 CFR Part 484)

| Condition | CFR Citation | Key Requirements | Effective Date | Source URL |
|-----------|--------------|------------------|----------------|------------|
| Basis and Scope | 42 CFR 484.1 | Based on Sections 1861(o), 1891, and 1861(z) of Social Security Act | January 13, 2018 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_b_hha.pdf |
| Compliance with Federal, State, Local Laws | 42 CFR 484.100 | HHA and staff must operate in compliance with all applicable laws; disclose ownership information | January 13, 2018 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_b_hha.pdf |
| Organization and Administration | 42 CFR 484.105 | Primarily engaged in skilled nursing; policies to govern services; overall plan and budget | January 13, 2018 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_b_hha.pdf |
| Patient Rights | 42 CFR 484.50 | HHA must inform patients of rights; protect patient rights; provide notice in advance of care | January 13, 2018 | https://hallrender.com/2018/09/06/cms-issues-final-interpretive-guidelines-for-the-conditions-of-participation-for-home-health-agencies/ |
| Care Planning | 42 CFR 484.60 | Comprehensive patient assessment; plan of care developed with physician; verbal orders documented | January 13, 2018 | https://hallrender.com/2018/09/06/cms-issues-final-interpretive-guidelines-for-the-conditions-of-participation-for-home-health-agencies/ |
| Quality Assessment and Performance Improvement | 42 CFR 484.65 | HHA-wide QAPI program; data-driven; involves all services | January 13, 2018 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_b_hha.pdf |
| Infection Control | 42 CFR 484.70 | Infection prevention and control program; surveillance, prevention, and control of infections | January 13, 2018 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_b_hha.pdf |
| Skilled Professional Services | 42 CFR 484.75 | Skilled nursing, PT, OT, SLP services provided in accordance with accepted standards | January 13, 2018 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_b_hha.pdf |
| Home Health Aide Services | 42 CFR 484.80 | Aides must complete 75 hours training; 12 hours annual in-service; competency evaluation; supervision every 14 days | January 13, 2018 | https://www.law.cornell.edu/cfr/text/42/484.80 |
| Clinical Records | 42 CFR 484.110 | Maintain clinical records on all patients; records available to patient within 4 business days | January 13, 2018 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_b_hha.pdf |
| Personnel Qualifications | 42 CFR 484.115 | Administrator must be physician, RN, or hold undergraduate degree (for employment on/after 1/13/2018) | January 13, 2018 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_b_hha.pdf |

---

## 1.4 HOSPICE CARE (42 CFR Part 418)

| Condition | CFR Citation | Key Requirements | Effective Date | Source URL |
|-----------|--------------|------------------|----------------|------------|
| Basis and Scope | 42 CFR 418.1 | Based on Sections 1861(u) and 1861(dd) of Social Security Act | May 21, 2004 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Transmittals/downloads/R73SOMA.pdf |
| Organization and Administration | 42 CFR 418.100 | Governing body responsible for management; administrator appointed; 24/7 nursing, physician, medical supplies available | May 21, 2004 | https://allianceforcareathome.org/wp-content/uploads/418.100.pdf |
| Patient Rights | 42 CFR 418.52 | Hospice must inform patient of rights; protect and promote exercise of patient rights | May 21, 2004 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_m_hospice.pdf |
| Initial and Comprehensive Assessment | 42 CFR 418.54 | Initial assessment within 48 hours of election; comprehensive assessment within 5 days | May 21, 2004 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_m_hospice.pdf |
| Interdisciplinary Group | 42 CFR 418.56 | IDG includes physician, RN, social worker, pastoral counselor; develops and reviews plan of care | February 3, 2023 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_m_hospice.pdf |
| Plan of Care | 42 CFR 418.58 | Written plan of care established before services provided; reviewed and updated as needed | May 21, 2004 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_m_hospice.pdf |
| Quality Assessment and Performance Improvement | 42 CFR 418.58 | Hospice-wide data-driven QAPI program; reflects complexity of organization; focuses on palliative outcomes | February 3, 2023 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_m_hospice.pdf |
| Core Services | 42 CFR 418.64 | Physician, nursing, medical social services, counseling services must be routinely provided directly by hospice staff | May 21, 2004 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_m_hospice.pdf |
| Nursing Services | 42 CFR 418.64(b) | Nursing services must be provided directly by hospice employees; waiver available for non-urban areas | May 21, 2004 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_m_hospice.pdf |
| Physician Services | 42 CFR 418.64(a) | Medical director and physician employees or contracted; responsible for medical component of care | May 21, 2004 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_m_hospice.pdf |
| Medical Social Services | 42 CFR 418.64(c) | Medical social services provided by qualified social worker under direction of physician | May 21, 2004 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_m_hospice.pdf |
| Counseling Services | 42 CFR 418.64(d) | Bereavement, dietary, and spiritual counseling services available | May 21, 2004 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_m_hospice.pdf |
| Short-Term Inpatient Care | 42 CFR 418.110 | Hospice providing inpatient care directly must meet specific staffing and service requirements | May 21, 2004 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_m_hospice.pdf |
| Infection Control | 42 CFR 418.60 | Infection control program including surveillance, prevention, and control of infections | May 21, 2004 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_m_hospice.pdf |
| Clinical Records | 42 CFR 418.104 | Clinical records maintained for every patient; protect patient confidentiality | May 21, 2004 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_m_hospice.pdf |
| Volunteer Services | 42 CFR 418.78 | Hospice must recruit and train volunteers; maintain documentation of volunteer activities | May 21, 2004 | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_m_hospice.pdf |

---

## 1.5 OUTPATIENT PHYSICAL THERAPY (42 CFR Part 485, Subpart H)

| Condition | CFR Citation | Key Requirements | Effective Date | Source URL |
|-----------|--------------|------------------|----------------|------------|
| Basis and Scope | 42 CFR 485.701 | Statutory basis under Section 1861(p) of Social Security Act | Various | https://www.in.gov/health/files/Regulations_for_Providers_of_Outpatient_Physical_Therapy_and.pdf |
| Condition of Participation: Organization | 42 CFR 485.703 | Rehabilitation agency, clinic, or public health agency as defined; organizational structure documented | Various | https://www.in.gov/health/files/Regulations_for_Providers_of_Outpatient_Physical_Therapy_and.pdf |
| Condition of Participation: Personnel | 42 CFR 485.705 | Qualified personnel providing services; physical therapist or speech-language pathologist responsible for services | Various | https://www.in.gov/health/files/Regulations_for_Outpatient_Physical_Therapy_and.pdf |
| Condition of Participation: Physical Therapy Services | 42 CFR 485.707 | Provide physical therapy services including therapeutic procedures and modalities (heat, cold, water, electricity) | Various | https://www.in.gov/health/files/Regulations_for_Providers_of_Outpatient_Physical_Therapy_and.pdf |
| Condition of Participation: Speech-Language Pathology Services | 42 CFR 485.709 | Provide speech-language pathology services with required equipment | Various | https://www.in.gov/health/files/Regulations_for_Providers_of_Outpatient_Physical_Therapy_and.pdf |
| Condition of Participation: Medical Records | 42 CFR 485.711 | Maintain clinical records on all patients; records meet professional standards | Various | https://www.in.gov/health/files/Regulations_for_Providers_of_Outpatient_Physical_Therapy_and.pdf |
| Condition of Participation: Compliance with Federal, State, Local Laws | 42 CFR 485.713 | Comply with all applicable laws; licensed if State requires | Various | https://www.in.gov/health/files/Regulations_for_Providers_of_Outpatient_Physical_Therapy_and.pdf |
| Condition of Participation: Emergency Preparedness | 42 CFR 485.727 | Emergency preparedness program; risk assessment; policies and procedures; communication plan; training | November 15, 2017 | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-485 |

---

# SECTION 2: MEDICARE BILLING RULES

## 2.1 MEDICARE PHYSICIAN FEE SCHEDULE (MPFS)

| Rule/Requirement | CFR Citation / Authority | Key Requirements | Effective Date | Source URL |
|------------------|-------------------------|------------------|----------------|------------|
| MPFS Payment Methodology | 42 CFR Part 405, 414 | Payment based on Relative Value Units (RVUs) for work, practice expense, and malpractice; Conversion Factor applied | January 1, 1992 | https://www.cms.gov/medicare/payment/fee-schedules/physician |
| Conversion Factor Updates | Section 1848 of Social Security Act | Annual updates per MACRA; CY 2026 QP CF: $33.57; Non-QP CF: $33.40 | January 1, 2026 | https://www.cms.gov/newsroom/fact-sheets/calendar-year-cy-2026-medicare-physician-fee-schedule-final-rule-cms-1832-f |
| Geographic Practice Cost Index | 42 CFR 414.26 | GPCIs adjust payment for geographic cost variations | January 1, 1992 | https://www.cms.gov/medicare/payment/fee-schedules/physician |
| Budget Neutrality Requirement | OBRA 1989 | Changes may not raise total Medicare spending by more than $20 million annually | January 1, 1990 | https://www.kff.org/medicare/what-to-know-about-how-medicare-pays-physicians/ |
| Incident-to Billing | 42 CFR 410.26 | Services incident to physician services covered when provided under physician supervision | Various | https://www.cms.gov/medicare/payment/fee-schedules/physician |
| Place of Service Differential | 42 CFR 414.20 | Non-facility rate (full) vs. facility rate (professional component only) | January 1, 1992 | https://www.cms.gov/medicare/payment/fee-schedules/physician |
| Care Management Services | CMS Final Rules | Chronic Care Management (CCM), Transitional Care Management (TCM) billing requirements | Various | https://www.cms.gov/medicare/payment/fee-schedules/physician |
| Health-Related Social Needs | CY 2024 PFS Final Rule | New HCPCS codes for screening and addressing unmet HRSNs | January 1, 2024 | https://www.partnership2asc.org/wp-content/uploads/2024/03/FINAL-Understanding-Medicare-PFS-Schedule-Primer.508.pdf |

---

## 2.2 INPATIENT PROSPECTIVE PAYMENT SYSTEM (IPPS)

| Rule/Requirement | CFR Citation / Authority | Key Requirements | Effective Date | Source URL |
|------------------|-------------------------|------------------|----------------|------------|
| IPMS-DRG Classification | 42 CFR 412.60-412.64 | Discharges classified into Medicare Severity Diagnosis-Related Groups (MS-DRGs) | October 1, 2007 | https://www.cms.gov/cms-guide-medical-technology-companies-and-other-interested-parties/payment/ipps |
| Base Payment Rate Calculation | 42 CFR 412.60 | Labor-related share adjusted by wage index; non-labor share with COLA for AK/HI | October 1, 1983 | https://www.cms.gov/cms-guide-medical-technology-companies-and-other-interested-parties/payment/ipps |
| New Technology Add-On Payment (NTAP) | 42 CFR 412.87-412.88 | Additional payment for new, costly technologies with substantial clinical improvement; 65% of costs (75% for QIDP/LPAD) | October 1, 2001 | https://www.cms.gov/cms-guide-medical-technology-companies-and-other-interested-parties/payment/ipps |
| Disproportionate Share Hospital (DSH) Adjustment | 42 CFR 412.106 | Additional payment for hospitals treating high percentage of low-income patients | October 1, 1983 | https://www.cms.gov/cms-guide-medical-technology-companies-and-other-interested-parties/payment/ipps |
| Indirect Medical Education (IME) Adjustment | 42 CFR 412.105 | Additional payment for hospitals with approved residency programs | October 1, 1983 | https://www.cms.gov/cms-guide-medical-technology-companies-and-other-interested-parties/payment/ipps |
| Outlier Payments | 42 CFR 412.80-412.84 | Additional payment for extraordinarily high-cost cases exceeding threshold | October 1, 1983 | https://www.cms.gov/cms-guide-medical-technology-companies-and-other-interested-parties/payment/ipps |
| Hospital-Acquired Condition (HAC) Reduction | 42 CFR 412.172-412.175 | Payment reduction for certain preventable conditions not present on admission | October 1, 2008 | https://www.cms.gov/medicare/payment/prospective-payment-systems/acute-inpatient-pps |
| Hospital Readmissions Reduction Program | 42 CFR 412.150-412.154 | Payment reduction for excess readmissions | October 1, 2012 | https://www.cms.gov/medicare/payment/prospective-payment-systems/acute-inpatient-pps |
| Hospital Value-Based Purchasing | 42 CFR 412.160-412.167 | Payment adjustments based on performance on quality measures | October 1, 2012 | https://www.cms.gov/medicare/payment/prospective-payment-systems/acute-inpatient-pps |

---

## 2.3 SKILLED NURSING FACILITY PPS (SNF PPS)

| Rule/Requirement | CFR Citation / Authority | Key Requirements | Effective Date | Source URL |
|------------------|-------------------------|------------------|----------------|------------|
| SNF PPS Per Diem Payment | Section 4432(a) BBA 1997; 42 CFR 413.337 | Per diem payment covering all Part A SNF services (routine, ancillary, capital) | July 1, 1998 | https://www.cms.gov/Outreach-and-Education/Medicare-Learning-Network-MLN/MLNProducts/EnrollmentResources/provider-resources/snf-billing-reference.html |
| Patient-Driven Payment Model (PDPM) | 42 CFR 413.337 | Case-mix classification based on patient characteristics; 5 case-mix components | October 1, 2019 | https://www.cms.gov/Outreach-and-Education/Medicare-Learning-Network-MLN/MLNProducts/EnrollmentResources/provider-resources/snf-billing-reference.html |
| Consolidated Billing | 42 CFR 411.15(p) | SNF bills all bundled services; most services provided during Part A stay billed to SNF | July 1, 1998 | https://www.cms.gov/Outreach-and-Education/Medicare-Learning-Network-MLN/MLNProducts/EnrollmentResources/provider-resources/snf-billing-reference.html |
| HIPPS Rate Codes | 42 CFR 412.60 | Health Insurance Prospect Payment System codes on claims must match submitted assessment | October 1, 1998 | https://www.cms.gov/Outreach-and-Education/Medicare-Learning-Network-MLN/MLNProducts/EnrollmentResources/provider-resources/snf-billing-reference.html |
| Required Assessments | 42 CFR 413.343 | MDS assessments required for payment; 5-day, 14-day, 30-day, 60-day, 90-day | October 1, 1998 | https://www.cms.gov/Outreach-and-Education/Medicare-Learning-Network-MLN/MLNProducts/EnrollmentResources/provider-resources/snf-billing-reference.html |
| Qualifying Hospital Stay | 42 CFR 409.30 | 3-consecutive-day qualifying hospital stay required for Part A SNF coverage | July 1, 1998 | https://www.cms.gov/Outreach-and-Education/Medicare-Learning-Network-MLN/MLNProducts/EnrollmentResources/provider-resources/snf-billing-reference.html |
| Place of Service Codes | CMS Claims Processing Manual | POS 31 for Part A SNF stay; POS 32 for non-covered SNF stay | Various | https://www.cms.gov/Outreach-and-Education/Medicare-Learning-Network-MLN/MLNProducts/EnrollmentResources/provider-resources/snf-billing-reference.html |
| Readmission Within 30 Days | 42 CFR 409.30 | Patient may resume using SNF benefit days without new qualifying stay if readmitted within 30 days | July 1, 1998 | https://www.cms.gov/Outreach-and-Education/Medicare-Learning-Network-MLN/MLNProducts/EnrollmentResources/provider-resources/snf-billing-reference.html |

---

## 2.4 HOME HEALTH PPS

| Rule/Requirement | CFR Citation / Authority | Key Requirements | Effective Date | Source URL |
|------------------|-------------------------|------------------|----------------|------------|
| HH PPS Episode Payment | BBA 1997; 42 CFR 484.220 | Payment for 30-day periods of care (changed from 60-day episodes) | October 1, 2000 (30-day: January 1, 2020) | https://www.cms.gov/medicare/payment/prospective-payment-systems/home-health |
| Patient-Driven Groupings Model (PDGM) | BBA 2018; 42 CFR 484.220 | Case-mix adjustment based on clinical characteristics, not therapy thresholds | January 1, 2020 | https://www.cms.gov/medicare/payment/prospective-payment-systems/home-health |
| Consolidated Billing | 42 CFR 484.220 | Payment for all services included in base rate; HHAs must provide services directly or under arrangement | October 1, 2000 | https://www.cms.gov/medicare/payment/prospective-payment-systems/home-health |
| Outlier Payments | 42 CFR 484.240 | Additional payment for high-cost cases exceeding fixed-loss threshold; capped at 10% of total PPS payments per HHA | October 1, 2000 | https://www.cms.gov/medicare/payment/prospective-payment-systems/home-health |
| Low Utilization Payment Adjustment (LUPA) | 42 CFR 484.205 | Fixed payment for episodes with 4 or fewer visits | October 1, 2000 | https://www.cms.gov/medicare/payment/prospective-payment-systems/home-health |
| Outlier Cap | 42 CFR 484.240 | Total national outlier payments limited to 2.5% of total HH PPS payments | October 1, 2000 | https://www.cms.gov/medicare/payment/prospective-payment-systems/home-health |
| PDGM Behavior Adjustments | CY 2026 Final Rule | Permanent adjustment: -1.023%; Temporary adjustment: -3.0% for CY 2026 | January 1, 2026 | https://www.cms.gov/newsroom/fact-sheets/calendar-year-cy-2026-home-health-prospective-payment-system-final-rule-cms-1828-f |
| OASIS Assessment Requirements | 42 CFR 484.250 | OASIS data collection required for all patients; determines payment classification | Various | https://www.cms.gov/medicare/payment/prospective-payment-systems/home-health |
| Quality Reporting Program | 42 CFR 484.250 | HHAs must report quality data; penalties for non-reporting | Various | https://www.cms.gov/medicare/payment/prospective-payment-systems/home-health |

---

## 2.5 REQUIRED DOCUMENTATION FOR CLAIMS

| Documentation Type | Requirement | Source | Effective Date | Source URL |
|-------------------|-------------|--------|----------------|------------|
| Medical Necessity | Documentation must support medical necessity of services provided | CMS Program Integrity Manual | Various | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals |
| Physician Orders | All services must be ordered by physician or other authorized practitioner | 42 CFR 410.32 | Various | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-B/part-410 |
| Certification/Recertification | Physician certification required for home health, hospice, SNF stays | 42 CFR 424.22 | Various | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-B/part-424 |
| Plan of Care | Written plan of care required for home health, hospice, outpatient therapy | 42 CFR 484.60, 418.58 | Various | https://www.ecfr.gov/current/title-42/chapter-IV |
| Progress Notes | Clinical documentation of patient progress and services provided | CMS Documentation Guidelines | Various | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals |
| Date of Service | Accurate dates of service for all claims | 42 CFR 424.32 | Various | https://www.ecfr.gov/current/title-42/chapter-IV/subchapter-B/part-424 |
| Diagnosis Codes | ICD-10-CM codes required for all claims | HIPAA Administrative Simplification | October 1, 2015 | https://www.cms.gov/medicare/coding-billing/icd-10-codes |
| Procedure Codes | CPT/HCPCS codes required for procedures and services | HIPAA Administrative Simplification | Various | https://www.cms.gov/medicare/coding-billing |
| Signature Requirements | All entries must be signed and dated by authorized provider | CMS Program Integrity Manual | Various | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals |
| Retention Requirements | Records retained for required periods (typically 5-7 years) | State laws, CMS requirements | Various | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals |

---

# SECTION 3: OIG COMPLIANCE PROGRAM GUIDANCE

## 3.1 GENERAL COMPLIANCE PROGRAM GUIDANCE (GCPG) - 2023

| Element | Description | Key Requirements | Effective Date | Source URL |
|---------|-------------|------------------|----------------|------------|
| Written Policies and Procedures | Comprehensive code of conduct | Document compliance strategy; duties and responsibilities; reporting workflows; regular review and updates | November 6, 2023 | https://oig.hhs.gov/documents/compliance-guidance/1135/HHS-OIG-GCPG-2023.pdf |
| Compliance Leadership and Oversight | Board and senior leadership commitment | Compliance officer with authority, stature, access, resources; reports to CEO or board; compliance committee | November 6, 2023 | https://oig.hhs.gov/documents/compliance-guidance/1135/HHS-OIG-GCPG-2023.pdf |
| Training and Education | Regular compliance education | Annual training for all staff; targeted training based on roles; accessible formats; documented attendance | November 6, 2023 | https://oig.hhs.gov/documents/compliance-guidance/1135/HHS-OIG-GCPG-2023.pdf |
| Effective Lines of Communication | Clear communication channels | Easy access to compliance officer; anonymous reporting mechanism; documented concern log | November 6, 2023 | https://oig.hhs.gov/documents/compliance-guidance/1135/HHS-OIG-GCPG-2023.pdf |
| Standards Enforcement | Consequences and incentives | Fair, equitable, consistent application; disciplinary actions for non-compliance; incentives for compliance | November 6, 2023 | https://oig.hhs.gov/documents/compliance-guidance/1135/HHS-OIG-GCPG-2023.pdf |
| Risk Assessment, Auditing, and Monitoring | Ongoing compliance oversight | Monthly exclusion list screening; regular licensure screening; annual policy review; data analytics | November 6, 2023 | https://oig.hhs.gov/documents/compliance-guidance/1135/HHS-OIG-GCPG-2023.pdf |
| Response and Corrective Action | Addressing detected offenses | Investigation procedures; corrective action plans; policy revisions; continuous improvement | November 6, 2023 | https://oig.hhs.gov/documents/compliance-guidance/1135/HHS-OIG-GCPG-2023.pdf |

---

## 3.2 HOSPITALS

| Guidance Document | Publication Date | Key Risk Areas | Source URL |
|-------------------|------------------|----------------|------------|
| Compliance Program Guidance for Hospitals | February 23, 1998 (63 Fed. Reg. 8987) | Billing and coding; cost reporting; physician relationships; joint ventures | https://oig.hhs.gov/compliance/compliance-guidance/ |
| Supplemental Compliance Program Guidance for Hospitals | January 31, 2005 (70 Fed. Reg. 4858) | Updated risk areas; quality of care; patient safety; HIPAA compliance | https://oig.hhs.gov/compliance/compliance-guidance/ |
| General Compliance Program Guidance | November 6, 2023 | Consolidated guidance applicable to all hospitals | https://oig.hhs.gov/documents/compliance-guidance/1135/HHS-OIG-GCPG-2023.pdf |

### Hospital-Specific Risk Areas:
| Risk Area | Description | Mitigation Strategies |
|-----------|-------------|----------------------|
| Billing and Coding | Incorrect coding; upcoding; unbundling; duplicate billing | Regular audits; coder training; compliance monitoring |
| Cost Reporting | Inflated costs; misallocated costs; improper exclusions | Internal audits; documentation review; cost report training |
| Physician Relationships | Stark Law violations; Anti-Kickback Statute violations | Structured arrangements; fair market value compensation; legal review |
| Quality of Care | Patient harm; medical errors; inadequate staffing | Quality improvement programs; incident reporting; peer review |

---

## 3.3 NURSING HOMES

| Guidance Document | Publication Date | Key Risk Areas | Source URL |
|-------------------|------------------|----------------|------------|
| Compliance Program Guidance for Nursing Facilities | March 16, 2000 (65 Fed. Reg. 14289) | Billing accuracy; quality of care; resident rights | https://oig.hhs.gov/compliance/compliance-guidance/ |
| Supplemental Compliance Program Guidance for Nursing Facilities | September 30, 2008 (73 Fed. Reg. 56832) | Updated risk areas; therapy services; MDS accuracy | https://oig.hhs.gov/compliance/compliance-guidance/ |
| Updated Nursing Facility Compliance Guidance | November 2024 | Medicare/Medicaid billing; quality of care; Anti-Kickback Statute | https://www.mcafeetaft.com/key-takeaways-from-oigs-compliance-guidance-for-nursing-facilities/ |
| General Compliance Program Guidance | November 6, 2023 | Consolidated guidance applicable to nursing facilities | https://oig.hhs.gov/documents/compliance-guidance/1135/HHS-OIG-GCPG-2023.pdf |

### Nursing Facility-Specific Risk Areas:
| Risk Area | Description | Mitigation Strategies |
|-----------|-------------|----------------------|
| Medicare/Medicaid Billing | PPS billing errors; therapy overbilling; MDS coding | Billing staff training; regular audits; compliance oversight |
| Quality of Care | Inadequate staffing; resident harm; medication errors | QAPI programs; staffing compliance; quality monitoring |
| Quality of Life | Resident rights violations; dignity issues | Staff training; resident council; grievance procedures |
| Anti-Kickback Compliance | Referral arrangements; vendor relationships | Safe harbor compliance; written agreements; legal review |

---

## 3.4 HOME HEALTH AGENCIES

| Guidance Document | Publication Date | Key Requirements | Source URL |
|-------------------|------------------|------------------|------------|
| Compliance Program Guidance for Home Health Agencies | August 7, 1998 (63 Fed. Reg. 42410) | Seven elements of compliance program specific to HHAs | https://oig.hhs.gov/compliance/compliance-guidance/ |
| General Compliance Program Guidance | November 6, 2023 | Consolidated guidance applicable to HHAs | https://oig.hhs.gov/documents/compliance-guidance/1135/HHS-OIG-GCPG-2023.pdf |

### HHA-Specific Risk Areas:
| Risk Area | Description | Mitigation Strategies |
|-----------|-------------|----------------------|
| Face-to-Face Requirements | Physician face-to-face documentation for certification | Verification of documentation; physician education |
| Therapy Services | Unnecessary therapy; overutilization; inappropriate billing | Clinical oversight; utilization review; compliance audits |
| Homebound Status | Incorrect determination of homebound status | Assessment training; documentation review; medical necessity verification |
| Aide Services | Inadequate supervision; billing for unskilled care | Supervision compliance; aide training; documentation requirements |

---

## 3.5 PHYSICIANS/PHYSICIAN GROUPS

| Guidance Document | Publication Date | Key Requirements | Source URL |
|-------------------|------------------|------------------|------------|
| Compliance Program Guidance for Individual and Small Group Physician Practices | October 5, 2000 | Seven elements adapted for small practices | https://oig.hhs.gov/compliance/compliance-guidance/ |
| General Compliance Program Guidance | November 6, 2023 | Consolidated guidance applicable to physician practices | https://oig.hhs.gov/documents/compliance-guidance/1135/HHS-OIG-GCPG-2023.pdf |

### Physician Practice Risk Areas:
| Risk Area | Description | Mitigation Strategies |
|-----------|-------------|----------------------|
| Documentation | Inadequate documentation; missing signatures; illegible records | Documentation training; EHR implementation; audit processes |
| Coding and Billing | Upcoding; unbundling; incorrect modifiers | Coder training; regular audits; compliance monitoring |
| E/M Services | Incorrect level selection; lack of medical necessity | E/M guidelines training; documentation templates |
| Referral Relationships | Stark Law; Anti-Kickback Statute compliance | Legal review of arrangements; fair market value analysis |

---

## 3.6 THIRD-PARTY BILLING COMPANIES

| Guidance Document | Publication Date | Key Requirements | Source URL |
|-------------------|------------------|------------------|------------|
| Compliance Program Guidance for Third-Party Medical Billing Companies | December 18, 1998 (63 Fed. Reg. 70138) | Seven elements specific to billing companies | https://oig.hhs.gov/compliance/compliance-guidance/ |
| General Compliance Program Guidance | November 6, 2023 | Consolidated guidance applicable to billing companies | https://oig.hhs.gov/documents/compliance-guidance/1135/HHS-OIG-GCPG-2023.pdf |

### Billing Company Risk Areas:
| Risk Area | Description | Mitigation Strategies |
|-----------|-------------|----------------------|
| Data Integrity | Accurate claim submission; proper coding | Quality checks; coder certification; claim scrubbing |
| Client Oversight | Verification of client billing authority | Client agreements; documentation requirements |
| Security | Protection of PHI; HIPAA compliance | Security protocols; business associate agreements |
| Refund Obligations | Identification and return of overpayments | Audit processes; refund procedures; compliance monitoring |

---

# SECTION 4: HIPAA ADMINISTRATIVE REQUIREMENTS

## 4.1 HIPAA PRIVACY RULE (45 CFR Parts 160 and 164)

| Requirement | CFR Citation | Key Elements | Effective Date | Source URL |
|-------------|--------------|--------------|----------------|------------|
| Covered Entities | 45 CFR 160.103 | Health plans, health care clearinghouses, health care providers who transmit electronic transactions | April 14, 2003 | https://www.hhs.gov/hipaa/for-professionals/privacy/laws-regulations/index.html |
| Protected Health Information (PHI) | 45 CFR 160.103 | Individually identifiable health information held or transmitted by covered entity | April 14, 2003 | https://www.hhs.gov/hipaa/for-professionals/privacy/laws-regulations/index.html |
| Minimum Necessary Standard | 45 CFR 164.502(b) | Reasonable efforts to use/disclose only minimum necessary PHI; does not apply to treatment | April 14, 2003 | https://www.hhs.gov/hipaa/for-professionals/privacy/laws-regulations/index.html |
| Notice of Privacy Practices | 45 CFR 164.520 | Written notice of privacy practices; provided at first encounter; posted prominently | April 14, 2003 | https://www.hhs.gov/hipaa/for-professionals/privacy/guidance/model-notices-privacy-practices/index.html |
| Patient Rights - Access | 45 CFR 164.524 | Right to access, inspect, and copy PHI; response within 30 days | April 14, 2003 | https://www.hhs.gov/hipaa/for-professionals/privacy/laws-regulations/index.html |
| Patient Rights - Amendment | 45 CFR 164.526 | Right to request amendment of PHI; response within 60 days | April 14, 2003 | https://www.hhs.gov/hipaa/for-professionals/privacy/laws-regulations/index.html |
| Patient Rights - Accounting | 45 CFR 164.528 | Right to accounting of disclosures; response within 60 days | April 14, 2003 | https://www.hhs.gov/hipaa/for-professionals/privacy/laws-regulations/index.html |
| Patient Rights - Restrictions | 45 CFR 164.522(a) | Right to request restrictions on uses/disclosures | April 14, 2003 | https://www.hhs.gov/hipaa/for-professionals/privacy/laws-regulations/index.html |
| Patient Rights - Confidential Communications | 45 CFR 164.522(b) | Right to request confidential communications | April 14, 2003 | https://www.hhs.gov/hipaa/for-professionals/privacy/laws-regulations/index.html |
| Authorization Requirements | 45 CFR 164.508 | Valid authorization required for most uses/disclosures not for TPO | April 14, 2003 | https://www.hhs.gov/hipaa/for-professionals/privacy/laws-regulations/index.html |
| Business Associate Agreements | 45 CFR 164.502(e) | Written contract required with business associates; specific elements required | April 14, 2003 | https://www.hhs.gov/hipaa/for-professionals/privacy/laws-regulations/index.html |
| Privacy Official | 45 CFR 164.530(a) | Designate privacy official responsible for privacy policies and procedures | April 14, 2003 | https://www.hhs.gov/hipaa/for-professionals/privacy/laws-regulations/index.html |
| Workforce Training | 45 CFR 164.530(b) | Train all workforce members on privacy policies and procedures | April 14, 2003 | https://www.hhs.gov/hipaa/for-professionals/privacy/laws-regulations/index.html |
| Safeguards | 45 CFR 164.530(c) | Administrative, technical, and physical safeguards to protect PHI | April 14, 2003 | https://www.hhs.gov/hipaa/for-professionals/privacy/laws-regulations/index.html |
| Complaint Procedures | 45 CFR 164.530(d) | Procedures for individuals to complain about compliance | April 14, 2003 | https://www.hhs.gov/hipaa/for-professionals/privacy/laws-regulations/index.html |
| Documentation and Retention | 45 CFR 164.530(j) | Maintain documentation for 6 years from creation or last effective date | April 14, 2003 | https://www.hhs.gov/hipaa/for-professionals/privacy/laws-regulations/index.html |

---

## 4.2 HIPAA SECURITY RULE (45 CFR Parts 160 and 164, Subparts A and C)

| Standard | CFR Citation | Implementation Specifications | Effective Date | Source URL |
|----------|--------------|------------------------------|----------------|------------|
| Security Management Process | 45 CFR 164.308(a)(1) | Risk Analysis (R); Risk Management (R); Sanction Policy (R); Information System Activity Review (R) | April 21, 2005 | https://www.hhs.gov/hipaa/for-professionals/security/index.html |
| Assigned Security Responsibility | 45 CFR 164.308(a)(2) | Identify security official responsible for policies and procedures | April 21, 2005 | https://www.hhs.gov/hipaa/for-professionals/security/index.html |
| Workforce Security | 45 CFR 164.308(a)(3) | Authorization/Supervision (A); Workforce Clearance (A); Termination Procedures (A) | April 21, 2005 | https://www.hhs.gov/hipaa/for-professionals/security/index.html |
| Information Access Management | 45 CFR 164.308(a)(4) | Isolating Clearinghouse Functions (R); Access Authorization (A); Access Establishment/Modification (A) | April 21, 2005 | https://www.hhs.gov/hipaa/for-professionals/security/index.html |
| Security Awareness and Training | 45 CFR 164.308(a)(5) | Security Reminders (A); Protection from Malicious Software (A); Log-in Monitoring (A); Password Management (A) | April 21, 2005 | https://www.hhs.gov/hipaa/for-professionals/security/index.html |
| Security Incident Procedures | 45 CFR 164.308(a)(6) | Response and Reporting (R) - Identify, respond to, report security incidents | April 21, 2005 | https://www.hhs.gov/hipaa/for-professionals/security/index.html |
| Contingency Plan | 45 CFR 164.308(a)(7) | Data Backup Plan (R); Disaster Recovery Plan (R); Emergency Mode Operation Plan (R); Testing (A); Applications/Data Criticality Analysis (A) | April 21, 2005 | https://www.hhs.gov/hipaa/for-professionals/security/index.html |
| Evaluation | 45 CFR 164.308(a)(8) | Periodic technical and nontechnical evaluation | April 21, 2005 | https://www.hhs.gov/hipaa/for-professionals/security/index.html |
| Business Associate Contracts | 45 CFR 164.308(b)(1) | Written contract or other arrangement with business associates | April 21, 2005 | https://www.hhs.gov/hipaa/for-professionals/security/index.html |
| Facility Access Controls | 45 CFR 164.310(a)(1) | Contingency Operations (A); Facility Security Plan (A); Access Control/Validation (A); Maintenance Records (A) | April 21, 2005 | https://www.hhs.gov/hipaa/for-professionals/security/index.html |
| Workstation Use | 45 CFR 164.310(b) | Policies/procedures for appropriate workstation use | April 21, 2005 | https://www.hhs.gov/hipaa/for-professionals/security/index.html |
| Workstation Security | 45 CFR 164.310(c) | Physical safeguards for workstations accessing ePHI | April 21, 2005 | https://www.hhs.gov/hipaa/for-professionals/security/index.html |
| Device and Media Controls | 45 CFR 164.310(d)(1) | Disposal (R); Media Re-use (R); Accountability (A); Data Backup/Storage (A) | April 21, 2005 | https://www.hhs.gov/hipaa/for-professionals/security/index.html |
| Access Control | 45 CFR 164.312(a)(1) | Unique User ID (R); Emergency Access (R); Automatic Logoff (A); Encryption/Decryption (A) | April 21, 2005 | https://www.hhs.gov/hipaa/for-professionals/security/index.html |
| Audit Controls | 45 CFR 164.312(b) | Hardware, software, procedural mechanisms to record/examine activity | April 21, 2005 | https://www.hhs.gov/hipaa/for-professionals/security/index.html |
| Integrity | 45 CFR 164.312(c)(1) | Mechanisms to authenticate ePHI; Electronic Signature (A) | April 21, 2005 | https://www.hhs.gov/hipaa/for-professionals/security/index.html |
| Person/Entity Authentication | 45 CFR 164.312(d) | Procedures to verify person/entity seeking access | April 21, 2005 | https://www.hhs.gov/hipaa/for-professionals/security/index.html |
| Transmission Security | 45 CFR 164.312(e)(1) | Integrity Controls (A); Encryption (A) | April 21, 2005 | https://www.hhs.gov/hipaa/for-professionals/security/index.html |

**Note:** (R) = Required implementation specification; (A) = Addressable implementation specification

---

## 4.3 HIPAA BREACH NOTIFICATION RULE (45 CFR 164.400-414)

| Requirement | CFR Citation | Key Elements | Effective Date | Source URL |
|-------------|--------------|--------------|----------------|------------|
| Breach Definition | 45 CFR 164.402 | Acquisition, access, use, or disclosure of unsecured PHI not permitted by HIPAA | September 23, 2009 | https://www.hhs.gov/hipaa/for-professionals/breach-notification/index.html |
| Unsecured PHI | 45 CFR 164.402 | PHI not rendered unusable, unreadable, or indecipherable to unauthorized persons | September 23, 2009 | https://www.hhs.gov/hipaa/for-professionals/breach-notification/index.html |
| Presumption of Breach | 45 CFR 164.402 | Impermissible use/disclosure presumed breach unless low probability of compromise demonstrated | September 23, 2009 | https://www.hhs.gov/hipaa/for-professionals/breach-notification/index.html |
| Risk Assessment Factors | 45 CFR 164.402 | Nature/extent of PHI; unauthorized person; whether PHI acquired/viewed; extent of mitigation | September 23, 2009 | https://www.hhs.gov/hipaa/for-professionals/breach-notification/index.html |
| Breach Exclusions | 45 CFR 164.402 | Good faith unintentional access; inadvertent disclosure to authorized person; good faith belief information not retained | September 23, 2009 | https://www.hhs.gov/hipaa/for-professionals/breach-notification/index.html |
| Individual Notification | 45 CFR 164.404 | Notify affected individuals without unreasonable delay; no later than 60 days from discovery | September 23, 2009 | https://www.hhs.gov/hipaa/for-professionals/breach-notification/index.html |
| Individual Notification Method | 45 CFR 164.404 | First class mail to last known address; email if authorized; substitute notice if contact unknown | September 23, 2009 | https://www.hhs.gov/hipaa/for-professionals/breach-notification/index.html |
| HHS Secretary Notification - 500+ | 45 CFR 164.408 | Notify HHS immediately for breaches affecting 500+ individuals; within 60 days | September 23, 2009 | https://www.hhs.gov/hipaa/for-professionals/breach-notification/index.html |
| HHS Secretary Notification - <500 | 45 CFR 164.408 | Notify HHS annually for breaches affecting fewer than 500; within 60 days of calendar year end | September 23, 2009 | https://www.hhs.gov/hipaa/for-professionals/breach-notification/index.html |
| Media Notification | 45 CFR 164.406 | Notify prominent media outlets for breaches affecting 500+ individuals in state/jurisdiction | September 23, 2009 | https://www.hhs.gov/hipaa/for-professionals/breach-notification/index.html |
| Substitute Notice - Website | 45 CFR 164.404 | Post substitute notice on website for 90 days if contact unknown for 10+ individuals | September 23, 2009 | https://www.hhs.gov/hipaa/for-professionals/breach-notification/index.html |
| Substitute Notice - Alternative | 45 CFR 164.404 | Written notice or telephone if contact unknown for fewer than 10 individuals | September 23, 2009 | https://www.hhs.gov/hipaa/for-professionals/breach-notification/index.html |
| Business Associate Notification | 45 CFR 164.410 | Business associate must notify covered entity without unreasonable delay; no later than 60 days | September 23, 2009 | https://www.hhs.gov/hipaa/for-professionals/breach-notification/index.html |
| Law Enforcement Delay | 45 CFR 164.412 | Notification may be delayed if law enforcement requests in writing | September 23, 2009 | https://www.hhs.gov/hipaa/for-professionals/breach-notification/index.html |

---

## 4.4 HIPAA ENFORCEMENT AND PENALTIES

| Violation Category | Penalty Range | Calendar Year Amounts | Source |
|-------------------|---------------|----------------------|--------|
| Tier 1: Unaware | $100 - $50,000 per violation | $137 - $68,928 (2024) | 42 U.S.C. 1320d-6 |
| Tier 2: Reasonable Cause | $1,000 - $50,000 per violation | $1,379 - $68,928 (2024) | 42 U.S.C. 1320d-6 |
| Tier 3: Willful Neglect (Corrected) | $10,000 - $50,000 per violation | $13,785 - $68,928 (2024) | 42 U.S.C. 1320d-6 |
| Tier 4: Willful Neglect (Not Corrected) | $50,000 per violation | $68,928 (2024) | 42 U.S.C. 1320d-6 |
| Annual Maximum (Same Provision) | $1,500,000 | $2,067,813 (2024) | 42 U.S.C. 1320d-6 |
| Criminal Penalties - Wrongful Disclosure | Up to $50,000 and 1 year imprisonment | - | 42 U.S.C. 1320d-6 |
| Criminal Penalties - False Pretenses | Up to $100,000 and 5 years imprisonment | - | 42 U.S.C. 1320d-6 |
| Criminal Penalties - Commercial Gain | Up to $250,000 and 10 years imprisonment | - | 42 U.S.C. 1320d-6 |

---

# APPENDIX: KEY COMPLIANCE RESOURCES

## Official Government Websites

| Resource | Description | URL |
|----------|-------------|-----|
| CMS Conditions of Participation | Official CoP requirements and guidance | https://www.cms.gov/Regulations-and-Guidance/Legislation/CFCsAndCoPs |
| eCFR | Electronic Code of Federal Regulations | https://www.ecfr.gov |
| Federal Register | Official daily publication for rules, proposed rules, notices | https://www.federalregister.gov |
| HHS Office of Inspector General | Compliance guidance, fraud alerts, advisory opinions | https://oig.hhs.gov |
| HHS Office for Civil Rights | HIPAA enforcement, guidance, breach reporting | https://www.hhs.gov/ocr |
| CMS Medicare Learning Network | Educational resources for providers | https://www.cms.gov/Outreach-and-Education/Medicare-Learning-Network-MLN |
| CMS State Operations Manual | Survey and certification guidance | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals |

---

## Document Control

| Element | Information |
|---------|-------------|
| Document Title | Federal Healthcare Compliance Database |
| Version | 1.0 |
| Compilation Date | March 2026 |
| Primary Sources | CMS.gov, HHS.gov, OIG.hhs.gov, Federal Register, eCFR |
| Disclaimer | This document is for informational purposes only and does not constitute legal advice. Consult qualified legal counsel for specific compliance questions. |

---

*END OF DOCUMENT*
