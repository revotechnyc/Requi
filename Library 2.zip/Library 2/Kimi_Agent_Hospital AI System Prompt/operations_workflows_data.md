# Healthcare Compliance Operations Workflows and Playbooks

**Document Version:** 1.0  
**Last Updated:** January 2025  
**Classification:** Operational Compliance Reference  

---

## Table of Contents

1. [Audit Preparation Playbooks](#section-1-audit-preparation-playbooks)
2. [Compliance Monitoring Workflows](#section-2-compliance-monitoring-workflows)
3. [Risk Assessment Methodology](#section-3-risk-assessment-methodology)
4. [Healthcare Marketing Compliance](#section-4-healthcare-marketing-compliance)
5. [Key Compliance Metrics/KPIs](#section-5-key-compliance-metricskpis)

---

# SECTION 1: AUDIT PREPARATION PLAYBOOKS

## 1.1 Pre-Survey Preparation (30-60 Days Before)

### Overview
CMS surveys are unannounced and can occur at any time. Healthcare organizations must maintain continuous readiness. This playbook outlines the 30-60 day preparation cycle to ensure survey readiness.

**Source:** CMS State Operations Manual Appendix A; Joint Commission Resources

---

### Phase 1: Documentation Review (Days 1-14)

| Task | Responsible Party | Deadline | Documentation |
|------|-------------------|----------|---------------|
| Review all Conditions of Participation (CoP) checklists | Compliance Officer | Day 3 | CoP Checklist Completion Log |
| Audit patient medical records for completeness | HIM Director | Day 7 | Record Review Findings Report |
| Verify all policies reflect current CMS guidelines | Policy Administrator | Day 10 | Policy Gap Analysis |
| Review infection control plan documentation | Infection Control Officer | Day 7 | IC Plan Review Checklist |
| Verify patient rights and grievance procedures | Patient Advocate | Day 10 | Patient Rights Audit |
| Review emergency preparedness documentation | Safety Officer | Day 14 | Emergency Plan Review |
| Check pharmaceutical services documentation | Pharmacy Director | Day 10 | Pharmacy Compliance Check |

**Key Documentation to Review:**
- Patient medical records (minimum 10 recent discharges per unit)
- Staff personnel files (licenses, certifications, training records)
- Policies and procedures (all must be within review cycle)
- Quality Assessment and Performance Improvement (QAPI) documentation
- Infection control plans and logs
- Patient grievance records and resolutions
- Incident reports and investigations
- Emergency preparedness plans and drill documentation

---

### Phase 2: Staff Training (Days 15-30)

| Task | Responsible Party | Deadline | Documentation |
|------|-------------------|----------|---------------|
| Conduct survey readiness training for all staff | HR/Training | Day 20 | Training Attendance Records |
| Train designated escorts on survey procedures | Compliance Officer | Day 18 | Escort Training Checklist |
| Educate staff on common survey questions | Department Managers | Day 25 | Staff Competency Verification |
| Review patient rights with all patient-facing staff | Patient Advocate | Day 22 | Training Documentation |
| Conduct mock interviews with key personnel | Compliance Officer | Day 28 | Mock Interview Feedback |

**Training Focus Areas:**
1. **Patient Rights** - Most frequently cited area
2. **Infection Control** - High survey focus area
3. **Emergency Procedures** - Required knowledge for all staff
4. **Quality Improvement** - QAPI participation expectations
5. **Documentation Standards** - Medical record requirements

---

### Phase 3: Mock Survey (Days 31-45)

| Task | Responsible Party | Deadline | Documentation |
|------|-------------------|----------|---------------|
| Schedule and conduct full mock survey | External Consultant | Day 35 | Mock Survey Schedule |
| Review mock survey findings with leadership | Compliance Officer | Day 38 | Findings Report |
| Develop corrective action plans for gaps | Department Managers | Day 42 | CAP Development Log |
| Implement immediate corrections | Responsible Parties | Day 45 | CAP Implementation Tracker |

**Mock Survey Components:**
- Tracer methodology (follow patient through care continuum)
- Environment of care rounds
- Medical record reviews
- Staff interviews
- Policy and procedure review
- Medication management assessment

---

### Phase 4: Policy Review (Days 46-55)

| Task | Responsible Party | Deadline | Documentation |
|------|-------------------|----------|---------------|
| Update outdated policies | Policy Committee | Day 50 | Policy Update Log |
| Obtain board approval for policy changes | Board Secretary | Day 52 | Board Minutes |
| Distribute updated policies to all staff | Compliance Officer | Day 54 | Distribution Confirmation |
| Verify staff acknowledgment of changes | Department Managers | Day 55 | Acknowledgment Records |

**Required Policy Review Areas:**
- Patient rights and grievance procedures
- Infection prevention and control
- Quality assessment and performance improvement
- Medical staff bylaws and rules
- Nursing service policies
- Pharmaceutical services
- Emergency preparedness

---

### Phase 5: Record Organization (Days 56-60)

| Task | Responsible Party | Deadline | Documentation |
|------|-------------------|----------|---------------|
| Create Survey Readiness Binder | Compliance Officer | Day 58 | Binder Index |
| Organize all required documentation | HIM Department | Day 59 | Organization Checklist |
| Prepare command station location | Facilities | Day 60 | Command Station Setup |
| Verify all areas are survey-ready | Department Managers | Day 60 | Area Readiness Checklist |

**Survey Readiness Binder Contents:**
1. Organization chart and key contact list
2. Current policies and procedures index
3. Staff roster with credentials
4. QAPI program documentation
5. Infection control plan
6. Emergency preparedness documentation
7. Patient rights materials
8. Recent survey history and corrective actions

---

## 1.2 During Survey Procedures

### Immediate Response Protocol

**Upon Surveyor Arrival:**

| Step | Action | Responsible Party | Timeline |
|------|--------|-------------------|----------|
| 1 | Verify surveyor identification at entrance | Front Desk/Security | Immediate |
| 2 | Notify Administrator and Compliance Officer | Designated Contact | Within 5 minutes |
| 3 | Alert all departments of survey presence | Communication Lead | Within 10 minutes |
| 4 | Activate command station | Compliance Officer | Within 15 minutes |
| 5 | Convene survey response team | Administrator | Within 20 minutes |

---

### Escort Procedures

| Task | Responsible Party | Requirements |
|------|-------------------|--------------|
| Primary Survey Escort | Designated Manager | Must know facility layout, remain with surveyors at all times |
| Documentation Runner | Administrative Staff | Retrieve requested documents within 15 minutes |
| Communication Liaison | Compliance Officer | Relay surveyor requests to appropriate departments |
| Area Escorts | Department Managers | Available to accompany surveyors to specific areas |

**Escort Best Practices:**
- Never leave surveyors unattended
- Answer questions honestly; if unsure, say "I'll find out"
- Do not volunteer information not requested
- Document all surveyor requests and observations
- Maintain professional, courteous demeanor

---

### Document Request Protocol

| Step | Action | Timeline | Documentation |
|------|--------|----------|---------------|
| 1 | Log all document requests | Command Station | Real-time |
| 2 | Assign request to appropriate department | Compliance Officer | Within 5 minutes |
| 3 | Retrieve and copy requested documents | Department Staff | Within 15 minutes |
| 4 | Review copy for completeness | Department Manager | Before delivery |
| 5 | Deliver to surveyors with log entry | Runner | Within 20 minutes total |

**Document Request Log Template:**
```
Date/Time: ___________
Requested By: ___________
Document Description: ___________
Requested For: ___________
Retrieved By: ___________
Delivered At: ___________
```

---

### Staff Interview Preparation

| Interview Type | Preparation Required | Key Points |
|----------------|---------------------|------------|
| Nursing Staff | Know patient rights, infection control, emergency procedures | Be specific, use examples |
| Medical Staff | Understand QAPI participation, medical staff bylaws | Know committee assignments |
| Support Staff | Understand role in patient care, safety procedures | Describe daily responsibilities |
| Administration | Know organizational structure, compliance program | Be prepared to discuss corrective actions |

**Interview Do's and Don'ts:**
- DO answer questions directly and honestly
- DO ask for clarification if question is unclear
- DO provide specific examples when possible
- DON'T speculate or guess
- DON'T volunteer information beyond the question
- DON'T speak negatively about the organization

---

### Immediate Correction Procedures

| Finding Type | Response | Timeline | Documentation |
|--------------|----------|----------|---------------|
| Minor deficiency | Implement correction immediately | Same day | Correction Log |
| Standard-level deficiency | Develop and implement CAP | 24-48 hours | CAP Documentation |
| Condition-level deficiency | Immediate leadership notification | Within 1 hour | Incident Report |
| Immediate Jeopardy | Emergency response protocol | Immediate | IJ Response Log |

**Immediate Correction Documentation:**
- Description of finding
- Root cause analysis
- Corrective action taken
- Person responsible for correction
- Date/time of correction
- Evidence of correction (photos, revised documents, etc.)

---

## 1.3 Post-Survey Response (Plan of Correction)

### Timeline Requirements

**CMS Plan of Correction Timeline:**

| Day | Action | Responsible Party |
|-----|--------|-------------------|
| Day 0 | Receipt of Form CMS-2567 (SOD) | Administrator |
| Day 1-3 | Review deficiencies, assign to departments | Compliance Officer |
| Day 4-7 | Develop corrective action plans | Department Managers |
| Day 8-9 | Compile and review complete POC | Compliance Officer |
| Day 10 | Submit POC to CMS/State Agency | Administrator |

**Source:** CMS Survey Resources Folder, Chapter 7, Section 7317

---

### Required POC Elements

| Element | Description | Example |
|---------|-------------|---------|
| **Specific Deficiency** | Cite exact regulatory requirement | "42 CFR 482.23(c) - Nursing services not sufficient to meet patient needs" |
| **Corrective Action** | What will be done to correct the deficiency | "Hire 3 additional FTE nurses; revise staffing matrix" |
| **Responsible Party** | Who will implement the correction | "CNO - Jane Smith, RN" |
| **Completion Date** | When correction will be complete | "March 15, 2025" |
| **Monitoring Plan** | How compliance will be sustained | "Monthly staffing audits; quarterly review" |

---

### Acceptable vs. Unacceptable POCs

| Acceptable POC | Unacceptable POC |
|----------------|------------------|
| Specific actions with measurable outcomes | Vague statements like "will improve" |
| Assigned responsibility with contact information | No named responsible party |
| Realistic completion dates | Unachievable timelines |
| Evidence-based monitoring | No plan for ongoing monitoring |
| Addresses root cause | Addresses symptoms only |
| Includes policy/procedure changes | Relies on "re-education" alone |

---

### POC Template

```
PLAN OF CORRECTION

Deficiency Tag: _______
Regulatory Citation: _______
Date of Finding: _______

1. CORRECTIVE ACTION:
   [Specific action to correct deficiency]

2. RESPONSIBLE PARTY:
   Name: _______
   Title: _______
   Contact: _______

3. COMPLETION DATE:
   [Specific date when correction will be complete]

4. EVIDENCE OF CORRECTION:
   [What documentation will demonstrate correction]

5. MONITORING PLAN:
   [How ongoing compliance will be ensured]

6. POLICY/PROCEDURE CHANGES:
   [Any updates to policies or procedures]

Submitted By: _______
Date Submitted: _______
```

---

### Follow-up Procedures

| Timeline | Action | Responsible Party |
|----------|--------|-------------------|
| 30 days post-POC | Verify all corrections implemented | Compliance Officer |
| 60 days post-POC | Conduct internal audit of corrected areas | Quality Department |
| 90 days post-POC | Submit evidence of sustained compliance | Compliance Officer |
| 6 months post-POC | Comprehensive re-audit of deficient areas | External Consultant |
| Annually | Include in annual compliance work plan | Compliance Officer |

---

# SECTION 2: COMPLIANCE MONITORING WORKFLOWS

## 2.1 Monthly Compliance Tasks

| Task | Responsible Party | Deadline | Documentation | Source Reference |
|------|-------------------|----------|---------------|------------------|
| OIG LEIE exclusion screening | Compliance Officer | 1st of month | Screening Log | OIG Guidance |
| State Medicaid exclusion screening | Compliance Officer | 1st of month | State Screening Log | State Requirements |
| SAM.gov exclusion screening | Compliance Officer | 1st of month | SAM Screening Log | Federal Requirements |
| Review OIG Work Plan updates | Compliance Officer | 15th of month | Work Plan Review | OIG Work Plan |
| Monitor PEPPER report data | Revenue Cycle Director | Monthly | PEPPER Analysis | CMS PEPPER Program |
| Coding audit sample review | HIM Director | Monthly | Coding Audit Report | OIG Compliance Guidance |
| Training completion tracking | HR/Training | Monthly | Training Dashboard | OIG Element 5 |
| Incident report review | Risk Manager | Monthly | Incident Analysis | Risk Management Standards |
| Privacy breach log review | Privacy Officer | Monthly | Breach Log Review | HIPAA Requirements |
| Vendor contract compliance review | Compliance Officer | Monthly | Vendor Review Log | OIG Element 7 |

---

## 2.2 Quarterly Compliance Tasks

| Task | Responsible Party | Deadline | Documentation | Source Reference |
|------|-------------------|----------|---------------|------------------|
| Compliance Committee meeting | Compliance Officer | Quarterly | Meeting Minutes | OIG Element 1 |
| Board compliance report | Compliance Officer | Quarterly | Board Report | Governance Requirements |
| Risk assessment update | Compliance Officer | End of Quarter | Risk Assessment Update | OIG Element 6 |
| Policy and procedure review | Policy Committee | Quarterly | Policy Review Log | OIG Element 2 |
| Billing compliance audit | Revenue Cycle Director | Quarterly | Billing Audit Report | OIG Element 6 |
| Medical record documentation audit | HIM Director | Quarterly | Documentation Audit | CoP Requirements |
| Credentialing file audit | Medical Staff Office | Quarterly | Credentialing Audit | Medical Staff Bylaws |
| Equipment maintenance compliance | Facilities | Quarterly | PM Compliance Report | Life Safety Code |
| Pharmacy controlled substance audit | Pharmacy Director | Quarterly | CS Audit Report | DEA Requirements |
| Security risk assessment | Security/IT | Quarterly | Security Assessment | HIPAA Security Rule |
| HIPAA privacy audit | Privacy Officer | Quarterly | Privacy Audit Report | HIPAA Privacy Rule |
| Quality metrics review | Quality Director | Quarterly | Quality Dashboard | QAPI Requirements |

---

## 2.3 Annual Compliance Tasks

| Task | Responsible Party | Deadline | Documentation | Source Reference |
|------|-------------------|----------|---------------|------------------|
| Comprehensive compliance risk assessment | Compliance Officer | Q1 | Risk Assessment Report | OIG Element 6 |
| Annual compliance work plan development | Compliance Officer | Q1 | Annual Work Plan | OIG Guidance |
| Enterprise-wide compliance audit | External Auditor | Q2 | Audit Report | OIG Element 6 |
| Compliance program effectiveness evaluation | Compliance Officer | Q2 | Program Evaluation | OIG GCPG |
| Code of Conduct review and update | Compliance Officer | Q1 | Updated Code | OIG Element 2 |
| Annual compliance training | HR/Training | Q1 | Training Records | OIG Element 5 |
| Conflict of interest disclosure collection | Compliance Officer | Q1 | COI Disclosures | OIG Element 2 |
| Business associate agreement review | Privacy Officer | Q2 | BAA Inventory | HIPAA Requirements |
| State licensure compliance review | Administration | Q2 | Licensure Report | State Requirements |
| Corporate Integrity Agreement review (if applicable) | Compliance Officer | Ongoing | CIA Compliance Report | OIG CIA Requirements |
| Compliance budget review | CFO/Compliance | Q4 | Budget Proposal | Resource Planning |
| Compliance Committee charter review | Compliance Officer | Q4 | Updated Charter | Governance |

---

## 2.4 Compliance Calendar Template

```
JANUARY
- Monthly exclusion screening (1st)
- Annual compliance work plan due
- Annual compliance training begins
- Conflict of interest disclosures due

FEBRUARY
- Monthly exclusion screening (1st)
- OIG Work Plan review (15th)

MARCH
- Monthly exclusion screening (1st)
- Q1 Compliance Committee meeting
- Q1 Board compliance report
- Comprehensive risk assessment due
- Quarterly billing audit

APRIL
- Monthly exclusion screening (1st)
- OIG Work Plan review (15th)
- Annual enterprise audit begins

MAY
- Monthly exclusion screening (1st)
- BAA review
- State licensure compliance review

JUNE
- Monthly exclusion screening (1st)
- OIG Work Plan review (15th)
- Q2 Compliance Committee meeting
- Q2 Board compliance report
- Quarterly billing audit
- Program effectiveness evaluation due

JULY
- Monthly exclusion screening (1st)
- Mid-year compliance work plan review

AUGUST
- Monthly exclusion screening (1st)
- OIG Work Plan review (15th)

SEPTEMBER
- Monthly exclusion screening (1st)
- Q3 Compliance Committee meeting
- Q3 Board compliance report
- Quarterly billing audit

OCTOBER
- Monthly exclusion screening (1st)
- OIG Work Plan review (15th)
- Compliance budget review begins

NOVEMBER
- Monthly exclusion screening (1st)
- Compliance Committee charter review

DECEMBER
- Monthly exclusion screening (1st)
- OIG Work Plan review (15th)
- Q4 Compliance Committee meeting
- Q4 Board compliance report
- Annual compliance report to board
- Quarterly billing audit
- Year-end compliance metrics compilation
```

---

# SECTION 3: RISK ASSESSMENT METHODOLOGY

## 3.1 Risk Identification Framework

### Risk Categories

| Category | Description | Examples |
|----------|-------------|----------|
| **Regulatory/Compliance** | Violations of laws, regulations, CoPs | CMS citations, HIPAA breaches |
| **Financial** | Revenue loss, billing errors, penalties | Claim denials, overpayments |
| **Operational** | Process failures, staffing issues | Medication errors, falls |
| **Reputational** | Public trust, media exposure | Patient complaints, negative publicity |
| **Clinical Quality** | Patient safety, care outcomes | Hospital-acquired conditions |
| **Cybersecurity** | Data breaches, system outages | Ransomware, PHI exposure |
| **Third-Party** | Vendor failures, BA breaches | Vendor non-compliance |

---

### Risk Identification Process

| Step | Action | Responsible Party | Output |
|------|--------|-------------------|--------|
| 1 | Review OIG Work Plan and enforcement priorities | Compliance Officer | Risk Identification List |
| 2 | Analyze PEPPER data for outlier patterns | Revenue Cycle | Financial Risk Areas |
| 3 | Review survey history and trends | Quality Department | Historical Risk Patterns |
| 4 | Conduct staff interviews and surveys | Department Managers | Frontline Risk Input |
| 5 | Analyze incident and complaint data | Risk Manager | Incident-Based Risks |
| 6 | Review audit findings and recommendations | Compliance Officer | Audit-Identified Risks |
| 7 | Assess vendor and third-party risks | Compliance Officer | Third-Party Risk Profile |

---

## 3.2 Risk Scoring Methodology

### Risk Matrix Framework

**Likelihood Scale:**

| Score | Level | Definition |
|-------|-------|------------|
| 1 | Rare | May occur only in exceptional circumstances (<5% probability) |
| 2 | Unlikely | Could occur at some time (5-20% probability) |
| 3 | Possible | Might occur at some time (20-50% probability) |
| 4 | Likely | Will probably occur in most circumstances (50-80% probability) |
| 5 | Almost Certain | Expected to occur in most circumstances (>80% probability) |

**Impact/Severity Scale:**

| Score | Level | Definition |
|-------|-------|------------|
| 1 | Insignificant | Minimal impact, easily corrected |
| 2 | Minor | Limited impact, some resources required |
| 3 | Moderate | Significant impact, management attention needed |
| 4 | Major | Major impact, significant resources required |
| 5 | Catastrophic | Severe impact, could threaten organization survival |

**Risk Score Calculation:**
```
Risk Score = Likelihood Score x Impact Score
```

### Risk Priority Matrix

| Risk Score | Priority Level | Response Time | Approval Required |
|------------|----------------|---------------|-------------------|
| 1-4 | Low | 90 days | Department Manager |
| 5-9 | Medium | 60 days | Director Level |
| 10-16 | High | 30 days | VP/C-Suite |
| 17-25 | Critical | Immediate | CEO/Board |

---

### Risk Scoring Example

| Risk | Likelihood | Impact | Score | Priority |
|------|------------|--------|-------|----------|
| HIPAA breach from phishing | 4 (Likely) | 4 (Major) | 16 | HIGH |
| CMS Condition-level deficiency | 3 (Possible) | 5 (Catastrophic) | 15 | HIGH |
| Coding error leading to overpayment | 4 (Likely) | 3 (Moderate) | 12 | HIGH |
| Vendor exclusion violation | 2 (Unlikely) | 4 (Major) | 8 | MEDIUM |
| Training non-compliance | 3 (Possible) | 2 (Minor) | 6 | MEDIUM |

---

## 3.3 Corrective Action Prioritization

### Prioritization Framework

| Priority | Criteria | Timeline | Resources |
|----------|----------|----------|-----------|
| **P1 - Immediate** | Immediate jeopardy; legal/regulatory deadline; patient safety | 0-7 days | Unlimited; escalate to CEO |
| **P2 - Urgent** | High risk score; potential Condition-level deficiency | 8-30 days | Significant; VP approval |
| **P3 - Important** | Medium risk; process improvement opportunity | 31-60 days | Moderate; Director approval |
| **P4 - Planned** | Low risk; continuous improvement | 61-90 days | Standard; Manager approval |

---

### Corrective Action Plan Template

```
CORRECTIVE ACTION PLAN

Risk ID: _______
Risk Description: _______
Risk Score: _______
Priority Level: _______
Date Identified: _______

ROOT CAUSE ANALYSIS:
[Describe root cause of the risk]

CORRECTIVE ACTIONS:
1. [Action item]
   Responsible: _______
   Due Date: _______
   
2. [Action item]
   Responsible: _______
   Due Date: _______

PREVENTIVE ACTIONS:
[Actions to prevent recurrence]

MONITORING PLAN:
[How effectiveness will be measured]

APPROVALS:
Prepared By: _______ Date: _______
Reviewed By: _______ Date: _______
Approved By: _______ Date: _______
```

---

## 3.4 Effectiveness Monitoring

| Monitoring Method | Frequency | Responsible Party | Documentation |
|-------------------|-----------|-------------------|---------------|
| KPI tracking | Monthly | Compliance Officer | Risk Dashboard |
| Control testing | Quarterly | Internal Audit | Control Testing Report |
| Trend analysis | Quarterly | Quality Department | Trend Analysis Report |
| Follow-up audits | Per schedule | Compliance Officer | Follow-up Audit Report |
| Staff feedback | Ongoing | Department Managers | Feedback Log |

---

# SECTION 4: HEALTHCARE MARKETING COMPLIANCE

## 4.1 Stark Law Compliance

### Stark Law Overview

The Stark Law (42 U.S.C. § 1395nn) prohibits physicians from referring Medicare and Medicaid patients for designated health services (DHS) to entities with which the physician or immediate family member has a financial relationship, unless an exception applies.

**Key Points:**
- Strict liability statute (no intent required)
- Applies only to physician referrals
- Covers Medicare and Medicaid patients
- Prohibits entity from billing for services based on prohibited referral

---

### Designated Health Services (DHS)

| Service Category | Examples |
|------------------|----------|
| Clinical Laboratory Services | Lab tests, pathology |
| Physical Therapy | PT services |
| Occupational Therapy | OT services |
| Radiology Services | MRI, CT, X-ray, ultrasound |
| Radiation Therapy | Oncology treatment |
| DME | Wheelchairs, oxygen, etc. |
| Home Health Services | Skilled nursing, therapy |
| Outpatient Prescription Drugs | Dispensed medications |
| Inpatient/Outpatient Hospital Services | Hospital admissions |

---

### Stark Law Exceptions (Safe Harbors)

| Exception | Key Requirements |
|-----------|------------------|
| **In-Office Ancillary Services** | Services furnished personally by referring physician; same building; billing by physician |
| **Fair Market Value Compensation** | Set in advance; consistent with FMV; not based on volume/value |
| **Rental of Office Space** | Written agreement; set in advance; FMV; not based on referrals |
| **Rental of Equipment** | Written agreement; set in advance; FMV; commercially reasonable |
| **Bona Fide Employment** | Identifiable services; FMV compensation; not based on referrals |
| **Personal Services Arrangements** | Written agreement; set in advance; FMV; commercially reasonable |
| **Group Practice** | Unified group; centralized decision-making; overhead allocation |
| **Academic Medical Centers** | Compensation from AMC; bona fide employment |

---

### Stark Compliance Checklist

| Element | Requirement | Documentation Needed |
|---------|-------------|---------------------|
| Written Agreement | All financial arrangements in writing | Signed contracts |
| FMV Determination | Compensation at fair market value | FMV analysis/review |
| Commercially Reasonable | Arrangement makes business sense | Business justification |
| Set in Advance | Terms established before services | Dated agreements |
| No Volume/Value | Not based on referrals | Compensation methodology |
| Term | Minimum 1 year for certain exceptions | Contract terms |

---

## 4.2 Anti-Kickback Statute (AKS) Compliance

### AKS Overview

The Anti-Kickback Statute (42 U.S.C. § 1320a-7b(b)) prohibits the knowing and willful payment of remuneration to induce or reward patient referrals or generation of business involving any item or service payable by federal healthcare programs.

**Key Points:**
- Criminal statute requiring intent
- Broader than Stark (applies to anyone)
- Covers all federal healthcare programs
- Violations can trigger False Claims Act liability

---

### AKS Safe Harbors

| Safe Harbor | Key Requirements |
|-------------|------------------|
| **Investment Interests** | 60/40 rule; no active solicitation; terms offered to all |
| **Space Rental** | Written lease; set in advance; FMV; no percentage of revenue |
| **Equipment Rental** | Written lease; set in advance; FMV; commercially reasonable |
| **Personal Services** | Written agreement; set in advance; FMV; aggregate compensation |
| **Sale of Practice** | 1-year restrictive covenant; FMV; no future referrals |
| **Referral Services** | Fees not from providers; fees set in advance; assessed equally |
| **Warranties** | Standard warranties; not used to induce |
| **Discounts** | Properly disclosed and reflected in claims |
| **Group Purchasing** | 5% cap on payments; commercially reasonable |
| **Waiver of Beneficiary Coinsurance** | Good faith; financial need; not routine |

---

### AKS Compliance Checklist

| Risk Area | Compliance Measure | Documentation |
|-----------|-------------------|---------------|
| Referral Relationships | Document legitimate business purpose | Business justification memo |
| Compensation Arrangements | FMV analysis; set in advance | FMV reports; signed agreements |
| Marketing Payments | Review for inducement risk | Marketing compliance review |
| Gifts/Entertainment | Track against limits | Gift log |
| Discounts | Proper disclosure | Discount disclosure documentation |

---

## 4.3 Permissible vs. Prohibited Practices

### Permissible Marketing Practices

| Practice | Requirements |
|----------|--------------|
| **General Advertising** | Truthful; not misleading; no patient testimonials with PHI |
| **Community Education** | Educational purpose; no inducement |
| **Physician Liaison Programs** | No compensation based on referrals |
| **Patient Satisfaction Surveys** | Voluntary; no remuneration for responses |
| **Health Fairs** | Educational; no individual inducements |
| **Website/Social Media** | HIPAA-compliant; accurate information |

### Prohibited Practices

| Practice | Violation Risk |
|----------|----------------|
| **Paying for Referrals** | Direct AKS violation |
| **Free Services to Induce** | Remuneration violation |
| **Waiving Copays Routinely** | AKS and False Claims Act |
| **Gift Cards for Referrals** | Clear AKS violation |
| **Revenue-Based Compensation** | Stark and AKS violation |
| **Splitting Fees** | AKS violation |

---

## 4.4 Marketing Compliance Review Process

| Step | Action | Responsible Party |
|------|--------|-------------------|
| 1 | Submit marketing materials for review | Marketing Department |
| 2 | Review for Stark/AKS compliance | Compliance Officer |
| 3 | Review for HIPAA compliance | Privacy Officer |
| 4 | Review for truthfulness/accuracy | Legal Department |
| 5 | Approve or request modifications | Compliance Officer |
| 6 | Maintain approval documentation | Marketing Department |

---

# SECTION 5: KEY COMPLIANCE METRICS/KPIs

## 5.1 Compliance Program Effectiveness Metrics

| Metric | Calculation | Benchmark | Frequency | Source |
|--------|-------------|-----------|-----------|--------|
| **Training Completion Rate** | (Completed / Assigned) x 100 | >95% | Monthly | OIG Element 5 |
| **Policy Acknowledgment Rate** | (Acknowledged / Required) x 100 | 100% | Quarterly | OIG Element 2 |
| **Hotline Report Rate** | Reports per 100 FTEs | >2.0 | Quarterly | OIG Element 4 |
| **Investigation Closure Rate** | (Closed / Opened) x 100 | >90% | Quarterly | OIG Element 7 |
| **CAP On-Time Completion** | (On-Time / Total) x 100 | >95% | Monthly | OIG Element 7 |

---

## 5.2 Exclusion Screening Metrics

| Metric | Calculation | Benchmark | Frequency | Source |
|--------|-------------|-----------|-----------|--------|
| **Monthly Exclusion Screening** | % of employees/contractors screened | 100% | Monthly | OIG Guidance |
| **Exclusion Match Resolution Time** | Average days to resolve | <5 days | Ongoing | OIG Guidance |
| **New Hire Screening** | % screened before start date | 100% | Ongoing | OIG Guidance |
| **Vendor Screening** | % of vendors screened | 100% | Quarterly | OIG Element 7 |

---

## 5.3 Audit and Monitoring Metrics

| Metric | Calculation | Benchmark | Frequency | Source |
|--------|-------------|-----------|-----------|--------|
| **Internal Audit Completion** | (Completed / Planned) x 100 | 100% | Quarterly | OIG Element 6 |
| **Finding Resolution Rate** | (Resolved / Identified) x 100 | >95% | Quarterly | OIG Element 7 |
| **Repeat Finding Rate** | (Repeat / Total Findings) x 100 | <5% | Annually | OIG Element 6 |
| **Risk Assessment Update** | On-time completion | 100% | Annually | OIG Element 6 |

---

## 5.4 Revenue Cycle Compliance Metrics

| Metric | Calculation | Benchmark | Frequency | Source |
|--------|-------------|-----------|-----------|--------|
| **Claim Denial Rate** | (Denied / Submitted) x 100 | <5% | Monthly | Industry Standard |
| **Clean Claim Rate** | (Clean / Submitted) x 100 | >95% | Monthly | Industry Standard |
| **DNFB (Discharged Not Final Billed)** | Average days | <3 days | Weekly | Industry Standard |
| **AR Days** | Average days in AR | <45 days | Monthly | Industry Standard |
| **Coding Accuracy Rate** | (Accurate / Audited) x 100 | >95% | Quarterly | OIG Guidance |
| **Medical Necessity Denial Rate** | (MN Denied / Submitted) x 100 | <2% | Monthly | CMS Guidelines |

---

## 5.5 Quality and Safety Metrics

| Metric | Calculation | Benchmark | Frequency | Source |
|--------|-------------|-----------|-----------|--------|
| **Patient Fall Rate** | Falls per 1,000 patient days | <3.0 | Monthly | NDNQI |
| **Hospital-Aquired Infection Rate** | Infections per 1,000 device days | Per NHSN | Monthly | CDC NHSN |
| **Medication Error Rate** | Errors per 1,000 doses | <5.0 | Monthly | ISMP |
| **Readmission Rate** | (Readmissions / Discharges) x 100 | Per CMS | Quarterly | CMS |
| **Patient Satisfaction Score** | HCAHPS composite | >75th percentile | Quarterly | CMS HCAHPS |

---

## 5.6 Documentation Compliance Metrics

| Metric | Calculation | Benchmark | Frequency | Source |
|--------|-------------|-----------|-----------|--------|
| **Medical Record Completion Rate** | (Complete / Total) x 100 | >98% | Monthly | CoP Requirements |
| **Delinquent Record Rate** | (Delinquent / Total) x 100 | <2% | Monthly | Medical Staff Bylaws |
| **Physician Query Response Rate** | (Responded / Sent) x 100 | >90% | Monthly | CDI Standards |
| **Documentation Query Rate** | Queries per 100 records | 15-25 | Monthly | CDI Standards |

---

## 5.7 Compliance Dashboard Template

```
COMPLIANCE DASHBOARD - [MONTH/YEAR]

TRAINING & EDUCATION
- Training Completion Rate: ___% (Target: >95%)
- Overdue Trainings: ____
- Policy Acknowledgments: ___%

EXCLUSION SCREENING
- Employees Screened: ___%
- Vendors Screened: ___%
- Matches Resolved: ___%
- Avg Resolution Time: ___ days

AUDIT & MONITORING
- Audits Completed: ___/___
- Findings Identified: ____
- CAPs On-Time: ___%
- Repeat Findings: ___%

REVENUE CYCLE
- Claim Denial Rate: ___%
- Clean Claim Rate: ___%
- AR Days: ____
- Coding Accuracy: ___%

QUALITY & SAFETY
- Patient Falls: ___/1,000
- HAI Rate: ___/1,000
- Medication Errors: ___/1,000
- Readmission Rate: ___%

DOCUMENTATION
- Record Completion: ___%
- Delinquent Records: ___%
- Query Response: ___%

HOTLINE & REPORTS
- Reports Received: ____
- Investigations Open: ____
- Investigations Closed: ____
- Avg Investigation Time: ___ days
```

---

## 5.8 Benchmarking Sources

| Metric Category | Benchmark Source | Contact/Access |
|-----------------|------------------|----------------|
| General Healthcare | ASHE (American Society for Healthcare Engineering) | www.ashe.org |
| Quality Metrics | CMS Hospital Compare | hospitalcompare.hhs.gov |
| Patient Safety | NDNQI (National Database of Nursing Quality Indicators) | www.ndnqi.org |
| Infection Control | CDC NHSN | www.cdc.gov/nhsn |
| Coding Quality | AHIMA/AAPC Benchmarks | www.ahima.org |
| Compliance Program | OIG Compliance Program Guidance | oig.hhs.gov |
| Revenue Cycle | HFMA MAP Keys | www.hfma.org |

---

# APPENDIX A: Quick Reference Guides

## A.1 Survey Response Quick Reference

**When Surveyors Arrive:**
1. Verify ID
2. Notify Administrator immediately
3. Activate command station
4. Alert all departments
5. Assign escorts

**During Survey:**
- Be honest and direct
- Don't volunteer extra information
- Document all requests
- Provide requested documents within 15 minutes
- Escort surveyors at all times

**After Survey:**
- Debrief with team
- Begin POC development immediately
- Submit POC within 10 calendar days
- Implement corrections promptly

---

## A.2 Compliance Contact Directory Template

| Role | Name | Phone | Email | Backup Contact |
|------|------|-------|-------|----------------|
| Chief Compliance Officer | | | | |
| Privacy Officer | | | | |
| Security Officer | | | | |
| Quality Director | | | | |
| Risk Manager | | | | |
| HIM Director | | | | |
| Legal Counsel | | | | |
| State Survey Agency | | | | |
| CMS Regional Office | | | | |
| OIG Hotline | 1-800-HHS-TIPS | | | |

---

## A.3 Regulatory Reference Quick Links

| Resource | URL |
|----------|-----|
| CMS State Operations Manual | cms.gov/Regulations-and-Guidance/Guidance/Manuals/Downloads/som107c01.pdf |
| OIG Compliance Program Guidance | oig.hhs.gov/compliance/compliance-program-guidance/index.asp |
| OIG Work Plan | oig.hhs.gov/reports-and-publications/workplan/index.asp |
| OIG LEIE | oig.hhs.gov/exclusions/index.asp |
| SAM.gov Exclusions | sam.gov |
| HIPAA Guidance | hhs.gov/hipaa |
| Stark Law Regulations | ecfr.gov/current/title-42/chapter-IV/subchapter-G/part-411 |

---

# Document Control

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | January 2025 | Compliance Department | Initial Release |

---

**Sources Cited:**
- CMS State Operations Manual Appendix A
- OIG General Compliance Program Guidance (GCPG)
- OIG Compliance Program Guidance for Hospitals
- 42 CFR Part 482 - Conditions of Participation for Hospitals
- 42 CFR Part 411 - Stark Law Regulations
- 42 U.S.C. § 1320a-7b(b) - Anti-Kickback Statute
- Joint Commission Standards
- ASHE Healthcare Facility Management Survey 2024

---

*This document is intended for internal use only and should be reviewed by legal counsel before implementation. Healthcare regulations change frequently; verify all requirements with current official sources.*
