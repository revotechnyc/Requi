# Comprehensive Healthcare Forms and Documentation Catalog

## Table of Contents
1. [Federal CMS Forms](#section-1-federal-cms-forms)
2. [State Medicaid Forms](#section-2-state-medicaid-forms)
3. [Nursing Home Forms](#section-3-nursing-home-forms)
4. [Hospital Forms](#section-4-hospital-forms)
5. [Incident Report Templates](#section-5-incident-report-templates)
6. [Additional Supporting Forms](#section-6-additional-supporting-forms)

---

# SECTION 1: FEDERAL CMS FORMS

## Medicare Enrollment Applications

| Form Number | Form Name | Purpose | Who Must File | When to File | How to File | Official Link |
|-------------|-----------|---------|---------------|--------------|-------------|---------------|
| CMS-855A | Medicare Enrollment Application - Institutional Providers | Enroll as Medicare institutional provider; initial enrollment, revalidation, changes | Hospitals, SNFs, HHAs, Hospice, FQHCs, RHCs, CMHCs, ESRD facilities, Opioid Treatment Programs | Initial enrollment, revalidation (every 5 years), changes within 30-90 days | PECOS (online) or paper to MAC | https://www.cms.gov/medicare/cms-forms/cms-forms/downloads/cms855a.pdf |
| CMS-855B | Medicare Enrollment Application - Clinics/Group Practices | Enroll clinics, group practices, and certain suppliers | Group practices, clinics, independent labs, portable x-ray suppliers, OT/PT groups | Initial enrollment, revalidation (every 5 years), changes within 30-90 days | PECOS (online) or paper to MAC | https://www.cms.gov/medicare/cms-forms/cms-forms/downloads/cms855b.pdf |
| CMS-855I | Medicare Enrollment Application - Individual Physicians/Practitioners | Enroll individual physicians and non-physician practitioners | Physicians, NPs, PAs, CNS, clinical psychologists, clinical social workers | Initial enrollment, revalidation (every 5 years), changes within 30-90 days | PECOS (online) or paper to MAC | https://www.cms.gov/medicare/cms-forms/cms-forms/downloads/cms855i.pdf |
| CMS-855O | Medicare Enrollment Application - Ordering/Certifying Physicians | Enroll providers who solely order/certify (no billing) | Physicians, NPs, PAs, CNS who order/certify items/services but don't bill Medicare | Initial enrollment, revalidation | PECOS (online) or paper to MAC | https://www.cms.gov/regulations-and-guidance/guidance/manuals/downloads/pim83attachment855o.pdf |
| CMS-855S | Medicare Enrollment Application - DMEPOS Suppliers | Enroll Durable Medical Equipment, Prosthetics, Orthotics, Supplies suppliers | DMEPOS suppliers, pharmacies, medical supply companies | Initial enrollment, revalidation (every 5 years), changes within 30 days | PECOS (online) or paper to NPE contractor | https://www.cms.gov/medicare/cms-forms/cms-forms/downloads/cms855s.pdf |
| CMS-20134 | Medicare Enrollment Application - MDPP Suppliers | Enroll Medicare Diabetes Prevention Program suppliers | MDPP suppliers with CDC DPRP recognition | Initial enrollment, revalidation (every 5 years) | PECOS (online) or paper to MAC | https://www.cms.gov/medicare/cms-forms/cms-forms/downloads/cms20134.pdf |

## Claims and Billing Forms

| Form Number | Form Name | Purpose | Who Must File | When to File | How to File | Official Link |
|-------------|-----------|---------|---------------|--------------|-------------|---------------|
| CMS-1500 | Health Insurance Claim Form | Submit professional claims for Medicare Part B services | Physicians, practitioners, suppliers billing Medicare Part B | Per claim (within 12 months of service) | Electronic (required) or paper with ASCA waiver | https://www.cms.gov/medicare/billing/electronicbillingeditrans/1500 |
| CMS-1450 (UB-04) | Uniform Bill | Submit institutional claims for Medicare Part A services | Hospitals, SNFs, HHAs, hospices, other institutional providers | Per claim (within 12 months of service) | Electronic (required) | https://www.cms.gov/regulations-and-guidance/guidance/manuals/downloads/clm104c25.pdf |

## Survey and Compliance Forms

| Form Number | Form Name | Purpose | Who Must File | When to File | How to File | Official Link |
|-------------|-----------|---------|---------------|--------------|-------------|---------------|
| CMS-2567 | Statement of Deficiencies and Plan of Correction | Report survey deficiencies and corrective actions | All Medicare/Medicaid certified providers after survey | Within 10 days of receiving statement of deficiencies | To State Survey Agency | https://www.cms.gov/medicare/cms-forms/cms-forms/downloads/cms2567.pdf |
| CMS-1539 | Long-Term Care Facility Application for Medicare and Medicaid | Apply for Medicare/Medicaid certification as LTC facility | Nursing facilities, skilled nursing facilities seeking certification | Initial certification, change of ownership | To State Survey Agency | https://www.cms.gov/medicare/provider-enrollment-and-certification/surveycertificationgeninfo/downloads/form-cms-1539.pdf |

## Supporting Enrollment Forms

| Form Number | Form Name | Purpose | Who Must File | When to File | How to File | Official Link |
|-------------|-----------|---------|---------------|--------------|-------------|---------------|
| CMS-588 | Electronic Funds Transfer (EFT) Authorization Agreement | Authorize Medicare payments via direct deposit | All Medicare providers/suppliers receiving payments | With initial enrollment, when banking changes | Upload to PECOS or mail to MAC | https://www.cms.gov/medicare/cms-forms/cms-forms/downloads/cms588.pdf |
| CMS-460 | Medicare Participating Physician or Supplier Agreement | Agree to accept assignment for all Medicare services | Physicians/suppliers choosing PAR status | During open enrollment (Nov-Dec) or within 90 days of enrollment | Mail to MAC (NOT to CMS) | https://www.cms.gov/medicare/cms-forms/cms-forms/downloads/cms460.pdf |

---

# SECTION 2: STATE MEDICAID FORMS

## California Medicaid (Medi-Cal) Forms

| Form Number | Form Name | Purpose | Who Must File | When to File | How to File | Official Link |
|-------------|-----------|---------|---------------|--------------|-------------|---------------|
| DHCS 6216 | Medi-Cal Rendering Provider Application/Disclosure Statement/Agreement | Enroll as rendering provider in Medi-Cal | Physicians, allied health providers, dental providers | Initial enrollment, revalidation | Mail to DHCS Provider Enrollment Division | https://www.medi-cal.ca.gov |

**Key Requirements:**
- NPI registration with CMS/NPPES required
- Must attach CMS/NPPES confirmation for each NPI
- Original signatures required
- Application fee may apply

## Texas Medicaid Forms

| Form Number | Form Name | Purpose | Who Must File | When to File | How to File | Official Link |
|-------------|-----------|---------|---------------|--------------|-------------|---------------|
| TMHP Provider Enrollment Application | Texas Medicaid Provider Enrollment Application | Enroll as Texas Medicaid provider | All provider types seeking Texas Medicaid enrollment | Initial enrollment, revalidation (every 5 years) | Mail to TMHP Provider Enrollment or online via PEP | https://www.tmhp.com |
| PIF-1 | Provider Information Form | Provide detailed provider information | All individual providers | With enrollment application | Included in enrollment packet | https://www.tmhp.com |
| PIF-2 | Principal Information Form | Provide ownership/principal information | All providers (except performing providers) | With enrollment application | Included in enrollment packet | https://www.tmhp.com |

**Key Requirements:**
- Medicare enrollment prerequisite for most providers
- $586 application fee (unless exempt)
- HHSC Medicaid Provider Agreement required
- IRS W-9 Form required
- Disclosure of Ownership and Control Interest Statement
- Fingerprint background checks for high-risk providers

## New York Medicaid Forms

| Form Number | Form Name | Purpose | Who Must File | When to File | How to File | Official Link |
|-------------|-----------|---------|---------------|--------------|-------------|---------------|
| EMEDNY-436801 | NYS Medicaid Enrollment Form - Practitioners | Enroll individual practitioners in NYS Medicaid | Physicians, NPs, PAs, other practitioners | Initial enrollment, revalidation | Mail to eMedNY or online via PSP | https://www.emedny.org |
| EMEDNY-426401 | NYS Medicaid Enrollment Form - Groups | Enroll group practices in NYS Medicaid | Group practices, clinics | Initial enrollment, revalidation | Mail to eMedNY or online via PSP | https://www.emedny.org |

**Key Requirements:**
- Mandatory compliance program certification (if applicable)
- Unannounced site visits may be required
- Criminal background checks including fingerprinting for owners (5%+ interest)
- Immediate notification required for any changes

## Florida Medicaid Forms

| Form Number | Form Name | Purpose | Who Must File | When to File | How to File | Official Link |
|-------------|-----------|---------|---------------|--------------|-------------|---------------|
| Florida Medicaid Web Portal | Online Enrollment Wizard | Enroll as Florida Medicaid provider | All provider types | Initial enrollment, revalidation | Online via Florida Medicaid Web Portal | https://ahca.myflorida.com |

**Key Requirements:**
- Review Provider General Handbook Chapter 2
- Determine enrollment type (fully enrolled, limited enrolled, order/referring)
- Interactive Enrollment Checklist available
- Credential verification and site visit may be required
- Florida Medicaid ID and PIN issued upon approval

---

# SECTION 3: NURSING HOME FORMS

## Resident Assessment and Census Forms

| Form Number | Form Name | Purpose | Who Must File | When to File | How to File | Official Link |
|-------------|-----------|---------|---------------|--------------|-------------|---------------|
| MDS 3.0 | Minimum Data Set 3.0 Resident Assessment Instrument | Comprehensive resident assessment for care planning and Medicare/Medicaid payment | All Medicare/Medicaid certified nursing homes | Admission, quarterly, annually, significant change, discharge | Electronic submission to iQIES | https://www.cms.gov/files/document/finalmds-30-rai-manual-v1191october2024.pdf |
| CMS-672 | Resident Census and Conditions of Residents | Report resident census and conditions at time of survey | All Medicare/Medicaid certified nursing homes | At time of survey | Manual completion (no federal automation requirement) | https://www.cms.gov/Research-Statistics-Data-and-Systems/Computer-Data-and-Systems/MinimumDataSets20/downloads/HCFA672Instructions.pdf |

## MDS 3.0 Assessment Types and Timeframes

| Assessment Type | Trigger | Completion Window | Submission Deadline |
|-----------------|---------|-------------------|---------------------|
| Admission Assessment | New admission to facility | By end of Day 14 | Within 14 days |
| Annual Assessment | 366 days since last comprehensive | Days 1-14 after due date | Within 14 days |
| Quarterly Assessment | 92 days since last assessment | Days 1-14 after due date | Within 14 days |
| Significant Change Assessment | Major decline/improvement in status | Within 14 days of determination | Within 14 days |
| Discharge Assessment | Discharge from facility | On day of discharge | Within 14 days |
| Entry Tracking Record | New admission or re-entry | On day of entry | Within 7 days |
| Death in Facility Tracking | Resident death | On day of death | Within 7 days |

## MDS 3.0 Components

| Component | Description |
|-----------|-------------|
| Minimum Data Set (MDS) | Core set of screening, clinical, and functional status data elements |
| Care Area Assessment (CAA) Process | Systematic interpretation of MDS information; triggered care areas |
| RAI Utilization Guidelines | Instructions for assessment timing, completion, and use |

## Key Nursing Home Reporting Requirements

| Requirement | Regulation | Timeframe |
|-------------|------------|-----------|
| Abuse/Neglect Allegations | 42 CFR 483.12 | Immediate, no later than 2 hours (serious injury) or 24 hours (other) |
| Investigation Results | 42 CFR 483.12 | Within 5 working days |
| Crime Suspicion (Elder Justice Act) | Section 1150B SSA | Immediate, no later than 2 hours (serious bodily injury) or 24 hours |
| CMS-2567 Plan of Correction | CMS requirements | Within 10 days of receiving statement of deficiencies |

---

# SECTION 4: HOSPITAL FORMS

## Hospital Cost Report Forms

| Form Number | Form Name | Purpose | Who Must File | When to File | How to File | Official Link |
|-------------|-----------|---------|---------------|--------------|-------------|---------------|
| CMS-2552-10 | Hospital Cost Report | Annual cost report for Medicare payment determination | All Medicare-certified hospitals, CAHs, IPFs, IRFs | Within 5 months after fiscal year end | Electronic submission to MAC | https://www.cms.gov/data-research/statistics-trends-and-reports/cost-reports/hospital-2552-2010-form |

## CMS-2552-10 Cost Report Components

| Worksheet | Content |
|-----------|---------|
| Worksheet S | Hospital identification and statistical data |
| Worksheet A | Cost center allocation |
| Worksheet B | Cost allocation and apportionment |
| Worksheet C | Computation of inpatient operating costs |
| Worksheet D | Computation of capital costs |
| Worksheet E | Calculation of Medicare reimbursement |

## Other Provider Cost Report Forms

| Form Number | Form Name | Provider Type | Official Link |
|-------------|-----------|---------------|---------------|
| CMS-2540-10 | SNF Cost Report | Skilled Nursing Facilities | https://www.cms.gov/data-research/statistics-trends-and-reports/cost-reports |
| CMS-1728-20 | HHA Cost Report | Home Health Agencies | https://www.cms.gov/data-research/statistics-trends-and-reports/cost-reports |
| CMS-1984-14 | Hospice Cost Report | Hospice Providers | https://www.cms.gov/data-research/statistics-trends-and-reports/cost-reports |
| CMS-265-11 | Renal Facility Cost Report | Renal Dialysis Facilities | https://www.cms.gov/data-research/statistics-trends-and-reports/cost-reports |
| CMS-224-14 | FQHC Cost Report | Federally Qualified Health Centers | https://www.cms.gov/data-research/statistics-trends-and-reports/cost-reports |
| CMS-222-17 | RHC Cost Report | Rural Health Clinics | https://www.cms.gov/data-research/statistics-trends-and-reports/cost-reports |
| CMS-2088-17 | CMHC Cost Report | Community Mental Health Centers | https://www.cms.gov/data-research/statistics-trends-and-reports/cost-reports |

---

# SECTION 5: INCIDENT REPORT TEMPLATES

## Federal Incident Reporting Requirements

### Reportable Incidents (42 CFR 483.12)

| Incident Type | Definition | Reporting Timeframe |
|---------------|------------|---------------------|
| Abuse | Intentional infliction of injury, intimidation, punishment | Immediate, no later than 2 hours (serious) or 24 hours |
| Neglect | Failure to provide necessary care/services | Immediate, no later than 2 hours (serious) or 24 hours |
| Exploitation | Illegal use of resident's funds, property, assets | Immediate, no later than 24 hours |
| Mistreatment | Inappropriate care, treatment, or handling | Immediate, no later than 24 hours |
| Injury of Unknown Source | Injury where cause cannot be explained | Immediate, no later than 24 hours |
| Misappropriation of Resident Property | Theft or unauthorized use of resident property | Immediate, no later than 24 hours |

### Elder Justice Act Crime Reporting (Section 1150B)

| Severity | Timeframe | Recipients |
|----------|-----------|------------|
| Serious Bodily Injury | No later than 2 hours | State Survey Agency AND law enforcement |
| All Other Crimes | No later than 24 hours | State Survey Agency AND law enforcement |

## Required Incident Report Elements

| Element | Description |
|---------|-------------|
| Resident Information | Name, identifier, date of birth |
| Date/Time of Incident | When the incident occurred |
| Date/Time of Discovery | When the incident was discovered |
| Location | Where the incident occurred |
| Incident Description | Detailed description of what occurred |
| Witnesses | Names of any witnesses |
| Immediate Actions Taken | Steps taken to protect resident |
| Notifications Made | Who was notified and when |
| Investigator Information | Name of person conducting investigation |

## Investigation Requirements

| Requirement | Timeframe | Documentation |
|-------------|-----------|---------------|
| Initiate Investigation | Immediately upon discovery | Written record |
| Protect Resident During Investigation | Ongoing | Documentation of protective measures |
| Complete Investigation | Within 5 working days | Written findings |
| Report Results | Within 5 working days | To administrator and State officials |
| Implement Corrective Actions | If allegation verified | Documented in plan of correction |

## State Variations

| State | Additional Requirements |
|-------|------------------------|
| New York | Report to NYS DOH; maintain investigation records |
| California | Report to CDPH; specific forms may be required |
| Texas | Report to HHSC; follow state-specific protocols |
| Florida | Report to AHCA; online reporting may be available |

---

# SECTION 6: ADDITIONAL SUPPORTING FORMS

## Medicare Administrative Contractor (MAC) Contact Information

| Resource | Link |
|----------|------|
| Find Your MAC | https://www.cms.gov/medicare/medicare-contracting/medicare-administrative-contractors/mac-website-links |
| Medicare Provider Enrollment | https://www.cms.gov/medicare/enrollment-renewal/providers-suppliers |
| PECOS Online Enrollment | https://pecos.cms.hhs.gov |

## National Provider Identifier (NPI)

| Resource | Link |
|----------|------|
| NPI Registry | https://npiregistry.cms.hhs.gov |
| NPPES Application | https://nppes.cms.hhs.gov |

## CMS Manuals and Guidance

| Manual | Link |
|--------|------|
| State Operations Manual (SOM) | https://www.cms.gov/regulations-and-guidance/guidance/manuals/downloads/som107c00.pdf |
| Medicare Claims Processing Manual | https://www.cms.gov/regulations-and-guidance/guidance/manuals/downloads/clm104c00.pdf |
| Provider Reimbursement Manual | https://www.cms.gov/regulations-and-guidance/guidance/manuals/downloads/pim15c00.pdf |

---

## Document Information

| Field | Value |
|-------|-------|
| Catalog Version | 1.0 |
| Last Updated | January 2025 |
| Compiled By | Healthcare Forms and Documentation Specialist |
| Source | CMS.gov, State Medicaid Agencies, Federal Regulations |

## Disclaimer

This catalog is for informational purposes only. Always verify current forms and requirements with official CMS and state agency sources before submitting any applications or documentation. Form versions and requirements are subject to change.
