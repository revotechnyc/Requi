# State Healthcare Regulatory Database
## Comprehensive 50-State Healthcare Licensing and Compliance Guide

**Document Version:** 1.0  
**Last Updated:** 2025  
**Compiled by:** State Healthcare Regulatory Specialist

---

## Table of Contents

1. [Priority States (1-15)](#priority-states)
   - California, Texas, Florida, New York, Pennsylvania
   - Illinois, Ohio, Georgia, North Carolina, Michigan
   - New Jersey, Virginia, Washington, Arizona, Massachusetts
2. [Remaining States (16-50)](#remaining-states)

---

# PRIORITY STATES

---

## STATE: CALIFORNIA

| Field | Details |
|-------|---------|
| **Licensing Authority** | California Department of Public Health (CDPH) - Licensing and Certification Program  
Website: https://www.cdph.ca.gov/Programs/CHCQ/LCP/Pages/LandCProgramHome.aspx |
| **Hospital License Requirements** | General Acute Care Hospitals require state license under California Health and Safety Code. Applications require ownership disclosure, financial capacity documentation, and compliance with Title 22 regulations.  
Link: https://www.cdph.ca.gov/Programs/CHCQ/LCP/Pages/Hospitals.aspx |
| **Nursing Home License Requirements** | Skilled Nursing Facilities (SNF) require CDPH licensure. AB 1502 (2023) expanded requirements including 90-day financial capacity demonstration and 120-day advance notice for Change of Ownership (CHOW).  
Link: https://www.cdph.ca.gov/Programs/CHCQ/LCP/Pages/SNF.aspx |
| **Home Health License Requirements** | Home Health Agencies require state license and Medicare certification. Must comply with state staffing and training requirements.  
Link: https://www.cdph.ca.gov/Programs/CHCQ/LCP/Pages/HomeHealth.aspx |
| **Inspection Frequency** | Annual surveys for nursing homes; complaint-driven and routine inspections for hospitals. CDPH conducts approximately 10,000 surveys annually across all facility types. |
| **Required State Forms** | - Initial License Application (varies by facility type)  
- Change of Ownership (CHOW) forms  
- SNF Application Forms: https://www.cdph.ca.gov/Programs/CHCQ/LCP/Pages/SNFForms.aspx |
| **Incident Reporting Rules** | Facilities must report incidents within specified timeframes. SNFs must report changes in ownership information within 10 calendar days. |
| **State Medicaid Agency** | California Department of Health Care Services (DHCS)  
Website: https://www.dhcs.ca.gov/ |
| **State-Specific Notes** | - AB 1502 requires 120-day advance approval for SNF ownership changes  
- Automatic disqualification for applicants with certain felony convictions or prior enforcement actions  
- Civil penalties: $500-$2,000 for Class B violations; up to $10,000 for material violations |

---

## STATE: TEXAS

| Field | Details |
|-------|---------|
| **Licensing Authority** | Texas Health and Human Services Commission (HHSC) - Health Care Facilities Regulation  
Website: https://www.hhs.texas.gov/providers/health-care-facilities-regulation |
| **Hospital License Requirements** | Hospitals must be licensed under Texas Health and Safety Code Chapter 241. Applications require architectural review, life safety compliance, and proof of financial capacity.  
Link: https://www.dshs.texas.gov/regional-local-health-operations |
| **Nursing Home License Requirements** | Nursing facilities licensed by HHSC Long-term Care Licensing. Requirements include administrator licensing, staffing ratios, and compliance with 26 TAC Chapter 554.  
Link: https://www.hhs.texas.gov/business/licensing-credentialing-regulation |
| **Home Health License Requirements** | Home and community support services agencies (HCSSA) must be licensed. Includes home health, hospice, and personal assistance services.  
Link: https://www.hhs.texas.gov/business/licensing-credentialing-regulation |
| **Inspection Frequency** | Annual inspections for most facilities; nursing homes surveyed every 9-15 months for Medicare/Medicaid certification. |
| **Required State Forms** | - ASC Licensing Application: https://www.texasascsociety.org/dshs  
- Hospital License Forms  
- Nursing Facility Administrator Licensing through TULIP system |
| **Incident Reporting Rules** | Facilities must report incidents according to HHSC guidelines. Complaint hotline: 1-800-458-9858 |
| **State Medicaid Agency** | Texas Health and Human Services Commission - Medicaid/CHIP  
Website: https://www.hhs.texas.gov/services/medicaid |
| **State-Specific Notes** | - Six zone offices for facility licensing and compliance  
- Contact: infohflc@dshs.texas.gov or (512) 834-6646  
- Assisted living facilities have specific construction requirements for floodplains (counties >3.3M residents) |

---

## STATE: FLORIDA

| Field | Details |
|-------|---------|
| **Licensing Authority** | Florida Agency for Health Care Administration (AHCA)  
Website: https://ahca.myflorida.com/ |
| **Hospital License Requirements** | Hospitals licensed under Florida Statutes Chapter 395. Requires Certificate of Need (CON) for new facilities and bed additions.  
Link: https://ahca.myflorida.com/ |
| **Nursing Home License Requirements** | Nursing homes licensed under Florida Statutes Chapter 400. Must comply with federal Medicare/Medicaid requirements and state standards.  
Link: https://ahca.myflorida.com/ |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. Must meet staffing and service requirements under Chapter 400. |
| **Inspection Frequency** | Annual licensure inspections; complaint investigations as needed. Nursing homes surveyed annually for Medicare/Medicaid. |
| **Required State Forms** | - Hospital License Application  
- Nursing Home License Application  
- Forms available at: https://ahca.myflorida.com/ |
| **Incident Reporting Rules** | Incident reporting required per Florida Administrative Code. Facilities must report certain events within 24 hours. |
| **State Medicaid Agency** | Florida Agency for Health Care Administration - Medicaid  
Website: https://ahca.myflorida.com/Medicaid/ |
| **State-Specific Notes** | - CON required for most new facilities and expansions  
- Section 163.211 prohibits local governments from adding licensing requirements  
- AHCA regulates over 2,000 facilities statewide |

---

## STATE: NEW YORK

| Field | Details |
|-------|---------|
| **Licensing Authority** | New York State Department of Health - Division of Health Facility Planning  
Website: https://www.health.ny.gov/facilities/ |
| **Hospital License Requirements** | Hospitals require state operating certificate under Public Health Law Article 28. Certificate of Need (CON) required for new facilities and major expansions.  
Link: https://www.health.ny.gov/facilities/hospital/ |
| **Nursing Home License Requirements** | Nursing homes licensed by NYSDOH. Must comply with state and federal regulations. CON required for new facilities and bed additions.  
Link: https://www.health.ny.gov/facilities/nursing_home/ |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. LHCSA (Licensed Home Care Services Agency) licensing required. |
| **Inspection Frequency** | Annual surveys for nursing homes; routine and complaint-driven inspections for hospitals. |
| **Required State Forms** | - Hospital Operating Certificate Application  
- Nursing Home License Application  
- CON Application Forms: https://www.health.ny.gov/facilities/ |
| **Incident Reporting Rules** | Incident reporting required under NYCRR. Facilities must report deaths, injuries, and other incidents within specified timeframes. |
| **State Medicaid Agency** | New York State Department of Health - Medicaid  
Website: https://www.health.ny.gov/health_care/medicaid/ |
| **State-Specific Notes** | - Certificate of Need (CON) required for most health care facility projects  
- Clinical laboratories require separate NYS permit in addition to CLIA  
- Adult Care Facilities regulated separately by Division of Adult Care |

---

## STATE: PENNSYLVANIA

| Field | Details |
|-------|---------|
| **Licensing Authority** | Pennsylvania Department of Health - Division of Acute and Ambulatory Care  
Website: https://www.pa.gov/agencies/health/facilities.html |
| **Hospital License Requirements** | Hospitals licensed under the Health Care Facilities Act (35 P.S. § 448.101 et seq.). Requires compliance with 28 Pa. Code regulations.  
Link: https://www.pa.gov/agencies/health/facilities/in-patient-healthcare-facilities/hospitals |
| **Nursing Home License Requirements** | Nursing homes licensed by PA Department of Health. Must comply with state regulations and federal Medicare/Medicaid requirements.  
Link: https://www.pa.gov/agencies/health/facilities/long-term-care-facilities/nursing-homes |
| **Home Health License Requirements** | Home health agencies require state license. Must meet staffing and service requirements under state regulations. |
| **Inspection Frequency** | Annual inspections; complaint investigations as needed. |
| **Required State Forms** | - Hospital License Application  
- DAAC Notification Guidance forms  
- Act 60 Deeming Letter (for accreditation in lieu of licensure)  
Link: https://www.pa.gov/agencies/health/facilities |
| **Incident Reporting Rules** | Act 43 of 2023 requires fentanyl/xylazine testing in emergency departments with reporting to Department of Health. |
| **State Medicaid Agency** | Pennsylvania Department of Human Services - Medicaid  
Website: https://www.dhs.pa.gov/ |
| **State-Specific Notes** | - Certificate of Need expired December 18, 1996 (no longer required)  
- Contact: RA-DAAC@pa.gov  
- Hospital registration transitioned to licensure as of September 30, 2024 |

---

## STATE: ILLINOIS

| Field | Details |
|-------|---------|
| **Licensing Authority** | Illinois Department of Public Health (IDPH) - Bureau of Long-term Care  
Website: https://dph.illinois.gov/topics-services/health-care-regulation |
| **Hospital License Requirements** | Hospitals licensed under Illinois Hospital Licensing Act. Must comply with IDPH regulations and building codes.  
Link: https://dph.illinois.gov/ |
| **Nursing Home License Requirements** | Nursing homes licensed under Nursing Home Care Act (210 ILCS 45/). Approximately 1,200 facilities regulated. Annual surveys conducted.  
Link: https://dph.illinois.gov/topics-services/health-care-regulation/nursing-homes |
| **Home Health License Requirements** | Home health agencies require state license. Must meet staffing and service requirements. |
| **Inspection Frequency** | Approximately 10,000 surveys conducted annually including licensure inspections, complaint investigations, and reinspections. |
| **Required State Forms** | - Nursing Home License Application  
- Assisted Living/Shared Housing Application (210 ILCS 9/)  
Link: https://dph.illinois.gov/ |
| **Incident Reporting Rules** | 24-hour Nursing Home Hotline: 800-252-4343. Complaints investigated by IDPH surveyors. |
| **State Medicaid Agency** | Illinois Department of Healthcare and Family Services - Medicaid  
Website: https://www2.illinois.gov/hfs/ |
| **State-Specific Notes** | - IDPH certifies facilities for Medicare/Medicaid participation  
- Assisted Living and Shared Housing Act (210 ILCS 9/) governs ALFs  
- Nearly 19,000 calls received annually by Nursing Home Hotline |

---

## STATE: OHIO

| Field | Details |
|-------|---------|
| **Licensing Authority** | Ohio Department of Health (ODH) - Bureau of Regulatory Operations  
Website: https://odh.ohio.gov/ |
| **Hospital License Requirements** | Hospitals licensed under Ohio Revised Code Chapter 3722 (transitioned from registration to licensure September 30, 2024).  
Link: https://odh.ohio.gov/know-our-programs/hospitals |
| **Nursing Home License Requirements** | Nursing homes/facilities licensed by ODH Bureau of Regulatory Operations. Approximately 960 facilities regulated.  
Link: https://odh.ohio.gov/know-our-programs/nursing-homes-facilities |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | Unannounced surveys every 9-15 months for nursing homes; annual inspections for hospitals. |
| **Required State Forms** | - Hospital License Application  
- Nursing Home License Application  
- Health Care Facilities Initial License Packet  
Link: https://odh.ohio.gov/know-our-programs/health-care-facilities |
| **Incident Reporting Rules** | Complaint hotline: 1-800-342-0553. Online complaint filing available. |
| **State Medicaid Agency** | Ohio Department of Medicaid  
Website: https://medicaid.ohio.gov/ |
| **State-Specific Notes** | - Governor's Nursing Home Quality and Accountability Task Force established  
- Bureau of Survey and Certification conducts Medicare/Medicaid certification surveys  
- Enforcement includes civil monetary penalties, denial of payment, and license revocation |

---

## STATE: GEORGIA

| Field | Details |
|-------|---------|
| **Licensing Authority** | Georgia Department of Community Health - Healthcare Facility Regulation Division (HFRD)  
Website: https://dch.georgia.gov/divisionsoffices/hfrd |
| **Hospital License Requirements** | Hospitals licensed by HFRD. Must comply with state regulations and federal Medicare/Medicaid requirements.  
Link: https://dch.georgia.gov/divisionsoffices/hfrd |
| **Nursing Home License Requirements** | Long-term care facilities (nursing homes/skilled nursing) licensed by HFRD LTC Division. 357 facilities serving 40,000+ residents.  
Link: https://dch.georgia.gov/divisionsoffices/hfrd/facilities-provider-information/ltc |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | Recertification surveys every 12-15 months; Special Focus Facilities surveyed every 6 months. |
| **Required State Forms** | - Assisted Living Community Application Package  
- Nursing Home License Application  
Email: kadams@dch.ga.gov |
| **Incident Reporting Rules** | Facilities must report incidents according to HFRD guidelines. |
| **State Medicaid Agency** | Georgia Department of Community Health - Medicaid  
Website: https://medicaid.georgia.gov/ |
| **State-Specific Notes** | - 2 Peachtree Street, NW Suite 31-447, Atlanta, GA 30303-3142  
- Interpretive Guidelines available on HFRD website  
- Facility permits not transferable to new owners or locations |

---

## STATE: NORTH CAROLINA

| Field | Details |
|-------|---------|
| **Licensing Authority** | North Carolina Department of Health and Human Services - Division of Health Service Regulation (DHSR)  
Website: https://info.ncdhhs.gov/dhsr/ |
| **Hospital License Requirements** | Hospitals licensed by DHSR Acute and Home Care Licensure and Certification Section.  
Link: https://info.ncdhhs.gov/dhsr/ahc/licensure.html |
| **Nursing Home License Requirements** | Nursing facilities licensed and surveyed by DHSR. Medicare/Medicaid certification available.  
Link: https://info.ncdhhs.gov/dhsr/ |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | Annual surveys for nursing homes; routine inspections for hospitals. |
| **Required State Forms** | - Adult Care Home Initial License Application (PDF)  
- Family Care Home Application  
Link: https://info.ncdhhs.gov/dhsr/acls/licenseinfo.html |
| **Incident Reporting Rules** | Facility closure requires 30-day written notice to DHSR, county DSS, and residents. |
| **State Medicaid Agency** | North Carolina Department of Health and Human Services - Medicaid  
Website: https://medicaid.ncdhhs.gov/ |
| **State-Specific Notes** | - Adult Care Homes (7+ beds) and Family Care Homes (2-6 beds) separately licensed  
- Multi-unit Assisted Housing with Services (MUAHS) registration required  
- ACLS Star Rating Certificate Program available |

---

## STATE: MICHIGAN

| Field | Details |
|-------|---------|
| **Licensing Authority** | Michigan Department of Licensing and Regulatory Affairs (LARA) - Bureau of Community and Health Systems  
Website: https://www.michigan.gov/lara/bureau-list/bchs |
| **Hospital License Requirements** | Hospitals licensed under Michigan Public Health Code. New license fee: $2,500 plus $10/bed. Certificate of Need required.  
Link: https://www.michigan.gov/lara/bureau-list/bchs/providers/hospital |
| **Nursing Home License Requirements** | Nursing homes licensed by LARA. Annual renewal required. Fee: $500 plus $10/bed.  
Contact: 877-458-2757 |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | At least one visit every 3 years for survey and evaluation. Waivers available for accredited facilities. |
| **Required State Forms** | - LARA-SLACR-101 (State Licensure Application)  
- Renewal through eLicense portal  
Link: https://www.michigan.gov/lara/bureau-list/bchs |
| **Incident Reporting Rules** | Complaints: 800-882-6006 (Health Facilities) |
| **State Medicaid Agency** | Michigan Department of Health and Human Services - Medicaid  
Website: https://www.michigan.gov/mdhhs/ |
| **State-Specific Notes** | - Certificate of Need required for new facilities and bed increases  
- Health Facilities Engineering Section reviews construction plans  
- Licenses must be renewed by July 31st annually |

---

## STATE: NEW JERSEY

| Field | Details |
|-------|---------|
| **Licensing Authority** | New Jersey Department of Health - Division of Health Facilities Evaluation and Licensing  
Website: https://www.nj.gov/health/healthfacilities/ |
| **Hospital License Requirements** | Hospitals require Certificate of Need (CON) and state license. Licensed under NJSA 26:2H-1 et seq.  
Link: https://www.nj.gov/health/healthfacilities/ |
| **Nursing Home License Requirements** | Nursing homes require CON and state license. Annual fee: $1,500 plus $15/bed.  
Link: https://www.nj.gov/health/healthfacilities/ |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | Annual surveys for nursing homes; routine inspections for hospitals. |
| **Required State Forms** | - CON Application Forms  
- Long-Term Care Facility License Application (LCS-9)  
Link: https://www.nj.gov/health/healthfacilities/certificate-need/ |
| **Incident Reporting Rules** | Facilities must report incidents according to NJDOH guidelines. |
| **State Medicaid Agency** | New Jersey Department of Human Services - Medicaid  
Website: https://www.nj.gov/humanservices/dmahs/ |
| **State-Specific Notes** | - CON required for most health care facility projects  
- Contact: (609) 292-7228  
- Licensing fees capped at $4,000 per facility  
- Track record evaluation required for applicants |

---

## STATE: VIRGINIA

| Field | Details |
|-------|---------|
| **Licensing Authority** | Virginia Department of Health - Office of Licensure and Certification  
Website: https://www.vdh.virginia.gov/ |
| **Hospital License Requirements** | Hospitals licensed under Virginia Code Title 32.1. Must comply with state regulations and federal Medicare/Medicaid requirements.  
Link: https://www.vdh.virginia.gov/ |
| **Nursing Home License Requirements** | Nursing homes licensed by Virginia Department of Health. Must comply with state and federal regulations.  
Link: https://www.vdh.virginia.gov/ |
| **Home Health License Requirements** | Home health organizations require state license under 12 VAC 5-381. Annual fee: $1,404. |
| **Inspection Frequency** | Annual surveys for nursing homes; routine inspections for hospitals. |
| **Required State Forms** | - Hospital License Application  
- Nursing Home License Application  
Link: https://www.vdh.virginia.gov/ |
| **Incident Reporting Rules** | Facilities must report incidents according to VDH guidelines. |
| **State Medicaid Agency** | Virginia Department of Medical Assistance Services  
Website: https://www.dmas.virginia.gov/ |
| **State-Specific Notes** | - Certificate of Public Need (COPN) required for certain projects  
- Licensing and Certification oversees Medicare/Medicaid certification |

---

## STATE: WASHINGTON

| Field | Details |
|-------|---------|
| **Licensing Authority** | Washington State Department of Health - Health Facility Licensing  
Website: https://doh.wa.gov/licenses-permits-and-certificates/facilities |
| **Hospital License Requirements** | Three types licensed: Acute Care, Alcohol/Chemical Dependency, and Private Psychiatric Hospitals.  
Link: https://doh.wa.gov/licenses-permits-and-certificates/facilities-z/hospitals |
| **Nursing Home License Requirements** | Nursing homes licensed by Washington State DOH. Must comply with state and federal regulations. |
| **Home Health License Requirements** | Home health agencies require state license. In-home services application required.  
Link: https://hcaw.org/doh-licensing-home-care-agencies/ |
| **Inspection Frequency** | Routine inspections conducted; complaint investigations as needed. |
| **Required State Forms** | - License Application Packet (PDF)  
- FTE Worksheet  
Link: https://doh.wa.gov/ |
| **Incident Reporting Rules** | Complaints: (360) 236-4700 |
| **State Medicaid Agency** | Washington State Health Care Authority - Medicaid  
Website: https://www.hca.wa.gov/ |
| **State-Specific Notes** | - HELMS (Healthcare Enforcement and Licensing Management System) launched 2025  
- Digital certificates and renewal notices now standard  
- Emergency rule filed January 2025 for COVID-19 compliance |

---

## STATE: ARIZONA

| Field | Details |
|-------|---------|
| **Licensing Authority** | Arizona Department of Health Services (ADHS) - Bureau of Medical Facilities Licensing  
Website: https://www.azdhs.gov/licensing/medical-facilities/ |
| **Hospital License Requirements** | General, rural general, and special hospitals licensed by ADHS. Architectural review required.  
Link: https://www.azdhs.gov/licensing/medical-facilities/ |
| **Nursing Home License Requirements** | Nursing homes licensed by ADHS Long Term Care Facilities Licensing.  
Contact: 602-364-3030 |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | Routine inspections conducted; complaint investigations as needed. |
| **Required State Forms** | - Facility Licensing Portal: https://facility-licensing.azdhs.gov/  
- Medical Facilities Licensing Forms |
| **Incident Reporting Rules** | Facilities must report incidents according to ADHS guidelines. |
| **State Medicaid Agency** | Arizona Health Care Cost Containment System (AHCCCS)  
Website: https://www.azahcccs.gov/ |
| **State-Specific Notes** | - 150 North 18th Avenue, Phoenix, AZ 85007  
- Multiple facility types licensed including ASCs, dialysis centers, and behavioral health facilities |

---

## STATE: MASSACHUSETTS

| Field | Details |
|-------|---------|
| **Licensing Authority** | Massachusetts Department of Public Health - Division of Health Care Facility Licensure and Certification  
Website: https://www.mass.gov/orgs/division-of-health-care-facility-licensure-and-certification |
| **Hospital License Requirements** | Hospitals require state license before providing services. Must comply with Massachusetts General Laws and regulations.  
Link: https://www.mass.gov/lists/health-care-facility-licensure-regulations |
| **Nursing Home License Requirements** | Long-term care facilities licensed by DPH. Medicare/Medicaid certification available.  
Link: https://www.mass.gov/long-term-care-facility-licensure |
| **Home Health License Requirements** | Home health agencies do not require DPH license but may become Medicare/Medicaid certified. |
| **Inspection Frequency** | Routine surveys conducted; complaint investigations as needed. |
| **Required State Forms** | - Hospital Licensure Forms  
- Nursing Home Licensure Forms  
Link: https://www.mass.gov/orgs/division-of-health-care-facility-licensure-and-certification |
| **Incident Reporting Rules** | Health care facility reporting requirements in place. |
| **State Medicaid Agency** | Massachusetts Executive Office of Health and Human Services - MassHealth  
Website: https://www.mass.gov/masshealth |
| **State-Specific Notes** | - 67 Forest St., Marlborough, MA 01752  
- Contact: (617) 753-8000  
- Home health agencies not licensed by DPH (certification only) |

---

# REMAINING STATES

---

## STATE: INDIANA

| Field | Details |
|-------|---------|
| **Licensing Authority** | Indiana Department of Health - Division of Acute Care  
Website: https://www.in.gov/health/ |
| **Hospital License Requirements** | Hospitals licensed under Indiana Code. Must comply with state regulations. |
| **Nursing Home License Requirements** | Nursing homes licensed by Indiana Department of Health. Must comply with federal and state regulations. |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | Annual surveys for nursing homes; routine inspections for hospitals. |
| **Required State Forms** | - Hospital License Application  
- Nursing Home License Application |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | Indiana Family and Social Services Administration - Medicaid  
Website: https://www.in.gov/medicaid/ |
| **State-Specific Notes** | - Certificate of Need required for certain projects |

---

## STATE: TENNESSEE

| Field | Details |
|-------|---------|
| **Licensing Authority** | Tennessee Department of Health - Board for Licensing Health Care Facilities  
Website: https://www.tn.gov/health/article/hcf-about |
| **Hospital License Requirements** | Hospitals licensed under Tennessee Code. Must comply with state regulations.  
Link: https://www.tn.gov/health/article/hcf-about |
| **Nursing Home License Requirements** | Nursing homes licensed by Tennessee Department of Health. Must comply with federal and state regulations. |
| **Home Health License Requirements** | Home health agencies require state license under Tenn. Comp. R. & Regs. 0720-27-.02. Annual fee: $1,404.  
Contact: (615) 741-7221 |
| **Inspection Frequency** | Annual surveys for nursing homes; routine inspections for hospitals. |
| **Required State Forms** | - Home Care Organization Application  
- Health Care Facility License Forms |
| **Incident Reporting Rules** | Complaint hotline available. |
| **State Medicaid Agency** | Tennessee Department of Finance and Administration - TennCare  
Website: https://www.tn.gov/tenncare.html |
| **State-Specific Notes** | - Division of Licensure and Regulation, Office of Health Care Facilities  
- 665 Mainstream Drive, Nashville, TN 37228-1254 |

---

## STATE: MISSOURI

| Field | Details |
|-------|---------|
| **Licensing Authority** | Missouri Department of Health and Senior Services - Section for Long-Term Care Regulation  
Website: https://health.mo.gov/seniors/nursinghomes/ |
| **Hospital License Requirements** | Hospitals inspected annually by Missouri Department of Health and Senior Services.  
Link: https://health.mo.gov/safety/ |
| **Nursing Home License Requirements** | Approximately 1,111 long-term care facilities with 80,000+ beds licensed. Includes SNF, ICF, ALF, and RCF.  
Link: https://health.mo.gov/seniors/nursinghomes/licensecert.php |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | Annual inspections for nursing homes and hospitals. |
| **Required State Forms** | - Application for Licensure for Long Term Care Facility (MO 580-2631)  
- Alzheimer's Special Care Services Disclosure (MO 580-2637) |
| **Incident Reporting Rules** | Complaints investigated by state surveyors. |
| **State Medicaid Agency** | Missouri Department of Social Services - Medicaid  
Website: https://dss.mo.gov/mhd/ |
| **State-Specific Notes** | - Certificate of Need quarterly surveys required  
- License fees: $100 (3-24 beds), $300 (25-100 beds), $600 (100+ beds) |

---

## STATE: MARYLAND

| Field | Details |
|-------|---------|
| **Licensing Authority** | Maryland Department of Health - Office of Health Care Quality (OHCQ)  
Website: https://health.maryland.gov/ohcq/ |
| **Hospital License Requirements** | Hospitals licensed by OHCQ. Must comply with COMAR regulations.  
Link: https://health.maryland.gov/ohcq/ |
| **Nursing Home License Requirements** | Nursing homes licensed by OHCQ. Must comply with COMAR Title 10 regulations.  
Contact: (410) 402-8018 |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | As of July 1, 2025, OHCQ oversees 23,095 providers in 47 industries. |
| **Required State Forms** | - Licensing Procedure Forms (COMAR 10.07.02.04)  
- Application for License |
| **Incident Reporting Rules** | Incident reporting required per COMAR. |
| **State Medicaid Agency** | Maryland Department of Health - Medicaid  
Website: https://health.maryland.gov/mmcp/ |
| **State-Specific Notes** | - 7120 Samuel Morse Drive, Second Floor, Columbia, MD 21046  
- Toll Free: (877) 402-8218 |

---

## STATE: WISCONSIN

| Field | Details |
|-------|---------|
| **Licensing Authority** | Wisconsin Department of Health Services - Division of Quality Assurance  
Website: https://www.dhs.wisconsin.gov/ |
| **Hospital License Requirements** | Hospitals must be licensed by state and CMS. Application requires letter of intent, Certificate of Approval Application (F-62092), and $18/bed fee.  
Link: https://www.dhs.wisconsin.gov/regulations/hospital/ |
| **Nursing Home License Requirements** | Nursing homes licensed by DHS. Must comply with state and federal regulations. |
| **Home Health License Requirements** | Home health agencies require state license. Contact: Thomas Rylander, 608-266-7297 |
| **Inspection Frequency** | Routine inspections conducted; complaint investigations as needed. |
| **Required State Forms** | - Hospital Certificate of Approval Application (F-62092)  
- Renewal forms available through DHS |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | Wisconsin Department of Health Services - Medicaid  
Website: https://www.dhs.wisconsin.gov/medicaid/ |
| **State-Specific Notes** | - CHAP accreditation accepted for hospice licensure  
- Lisa Imhof: Hospice contact, 608-266-2702 |

---

## STATE: COLORADO

| Field | Details |
|-------|---------|
| **Licensing Authority** | Colorado Department of Public Health and Environment (CDPHE) - Health Facilities Division  
Website: https://www.colorado.gov/cdphe |
| **Hospital License Requirements** | Hospitals licensed by CDPHE. Must comply with state regulations. |
| **Nursing Home License Requirements** | Nursing homes licensed by CDPHE. Must comply with federal and state regulations. |
| **Home Health License Requirements** | Home health agencies require state license. Accreditation accepted in lieu of renewal survey per HB1294. |
| **Inspection Frequency** | Routine inspections conducted; complaint investigations as needed. |
| **Required State Forms** | - Health Facility License Application  
Link: https://www.colorado.gov/cdphe |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | Colorado Department of Health Care Policy and Financing - Medicaid  
Website: https://www.colorado.gov/hcpf/ |
| **State-Specific Notes** | - 4300 Cherry Creek Drive South, Denver, CO 80246  
- Licensure and Certification: 303-692-2836  
- Email: cdphe.healthfacilities@state.co.us |

---

## STATE: MINNESOTA

| Field | Details |
|-------|---------|
| **Licensing Authority** | Minnesota Department of Health - Health Regulation Division  
Website: https://www.health.state.mn.us/facilities/regulation/ |
| **Hospital License Requirements** | Hospitals and Critical Access Hospitals licensed by MDH.  
Link: https://www.health.state.mn.us/facilities/regulation/ |
| **Nursing Home License Requirements** | Nursing homes licensed by MDH. Must comply with state and federal regulations. |
| **Home Health License Requirements** | Home care providers require state license. |
| **Inspection Frequency** | Routine inspections conducted; complaint investigations as needed. |
| **Required State Forms** | - Facility License Applications  
Link: https://www.health.state.mn.us/facilities/regulation/ |
| **Incident Reporting Rules** | Complaint filing available online. |
| **State Medicaid Agency** | Minnesota Department of Human Services - Medicaid  
Website: https://mn.gov/dhs/ |
| **State-Specific Notes** | - Assisted Living Licensure available  
- Nurse Aide Registry maintained by MDH |

---

## STATE: SOUTH CAROLINA

| Field | Details |
|-------|---------|
| **Licensing Authority** | South Carolina Department of Health and Environmental Control (DHEC) - Health Licensing  
Website: https://dph.sc.gov/ |
| **Hospital License Requirements** | Hospitals licensed by DHEC. Certificate of Need required (sunsets January 1, 2027).  
Link: https://dph.sc.gov/professionals/healthcare-quality/licensed-facilities-professionals/hospital-licensure |
| **Nursing Home License Requirements** | Nursing facilities licensed and surveyed by SCDHEC. CON still required for nursing homes.  
Link: https://www.scdhhs.gov/resources/programs-and-initiatives/long-term-living/nursing-facilities |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | Routine inspections conducted; complaint investigations as needed. |
| **Required State Forms** | - Hospital Licensure Forms (DPH 3312, DPH 3288)  
Link: https://dph.sc.gov/professionals/healthcare-quality/applications-licensure/forms-healthcare-facilities-licensing |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | South Carolina Department of Health and Human Services - Medicaid  
Website: https://www.scdhhs.gov/ |
| **State-Specific Notes** | - CON law overhauled May 2023 (S.164)  
- CON no longer required for most facilities except nursing homes and hospitals (until 2027) |

---

## STATE: ALABAMA

| Field | Details |
|-------|---------|
| **Licensing Authority** | Alabama Department of Public Health - Bureau of Health Provider Standards  
Website: https://www.alabamapublichealth.gov/providerstandards/ |
| **Hospital License Requirements** | Hospitals licensed under Alabama Code Section 22-21-20. Must comply with Chapter 420-5-22 regulations.  
Link: https://www.adph.org/facmgmt/ |
| **Nursing Home License Requirements** | Nursing homes licensed by ADPH Division of Health Care Facilities. Annual renewal required.  
Link: https://www.alabamapublichealth.gov/providerstandards/ |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | Annual license renewal period: October 1 - December 31. |
| **Required State Forms** | - Online License Renewal  
- Health Care Facility Licensure Application Materials |
| **Incident Reporting Rules** | Complaints: (334) 206-5175 |
| **State Medicaid Agency** | Alabama Medicaid Agency  
Website: https://medicaid.alabama.gov/ |
| **State-Specific Notes** | - Provider Services Unit: (334) 206-5175  
- Independent Clinical Laboratories require state license effective October 1, 2020 |

---

## STATE: LOUISIANA

| Field | Details |
|-------|---------|
| **Licensing Authority** | Louisiana Department of Health (LDH) - Health Standards Section  
Website: https://ldh.la.gov/health-standards-section |
| **Hospital License Requirements** | Hospitals licensed under RS:40:2102. Facilities under 10 beds cannot be licensed as hospitals.  
Link: https://ldh.la.gov/health-standards-section/hospitals |
| **Nursing Home License Requirements** | Nursing homes licensed by LDH Health Standards Section. |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | Full license issued for up to 12 months; provisional license up to 6 months if not in substantial compliance. |
| **Required State Forms** | - Hospital License Application  
- Life Safety Code Inspection required |
| **Incident Reporting Rules** | Facilities must notify LDH of deficiencies corrections in writing. |
| **State Medicaid Agency** | Louisiana Department of Health - Medicaid  
Website: https://ldh.la.gov/ |
| **State-Specific Notes** | - Office of State Fire Marshal approval required  
- Change of ownership requires new license application within 15 working days |

---

## STATE: KENTUCKY

| Field | Details |
|-------|---------|
| **Licensing Authority** | Kentucky Cabinet for Health and Family Services - Office of Inspector General  
Website: https://chfs.ky.gov/ |
| **Hospital License Requirements** | Hospitals licensed by CHFS. Must comply with state regulations. |
| **Nursing Home License Requirements** | Nursing homes licensed by CHFS. Must comply with federal and state regulations. |
| **Home Health License Requirements** | Home health agencies require state license. |
| **Inspection Frequency** | Routine inspections conducted; complaint investigations as needed. |
| **Required State Forms** | - Form OIG 003 (Hospital License Application)  
- Form OIG 006 (Long Term Care Facility)  
Link: 902 KAR 20:008 |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | Kentucky Cabinet for Health and Family Services - Medicaid  
Website: https://chfs.ky.gov/agencies/dms/ |
| **State-Specific Notes** | - Division of Behavioral Health oversees mental health/substance use facilities  
- Office of Inspector General: 275 East Main Street, Frankfort, KY 40621 |

---

## STATE: OREGON

| Field | Details |
|-------|---------|
| **Licensing Authority** | Oregon Health Authority - Health Facility Licensing & Certification Program  
Website: https://www.oregon.gov/oha/ph/licensingcertification/ |
| **Hospital License Requirements** | Hospitals licensed under ORS Chapter 441. Must obtain license from Oregon Health Authority.  
Link: https://www.oregon.gov/oha/ph/providerpartnerresources/healthcareprovidersfacilities |
| **Nursing Home License Requirements** | Nursing homes licensed by Oregon Health Authority. Must comply with federal and state regulations. |
| **Home Health License Requirements** | Home health agencies require state license. |
| **Inspection Frequency** | Routine federal Medicare certification surveys and state licensure surveys conducted. |
| **Required State Forms** | - Health Facility Licensing Forms  
Link: https://www.oregon.gov/oha/ph/providerpartnerresources/healthcareprovidersfacilities |
| **Incident Reporting Rules** | Complaint investigations conducted. |
| **State Medicaid Agency** | Oregon Health Authority - Medicaid  
Website: https://www.oregon.gov/oha/hsd/ohp/pages/index.aspx |
| **State-Specific Notes** | - Health Licensing Office (HLO) for certain facility types  
- Listserv available for program updates |

---

## STATE: OKLAHOMA

| Field | Details |
|-------|---------|
| **Licensing Authority** | Oklahoma State Department of Health - Medical Facilities Service  
Website: https://oklahoma.gov/health.html |
| **Hospital License Requirements** | Hospitals licensed by OSDH Medical Facilities Service.  
Contact: (405) 426-8470 |
| **Nursing Home License Requirements** | Nursing facilities licensed by OSDH Health Facility Systems. Certificate of Need required.  
Link: https://oklahoma.gov/health/services/licensing-inspections/long-term-care-service |
| **Home Health License Requirements** | Home health agencies require state license. CHAP accreditation accepted in lieu of state survey.  
Contact: medicalfacilities@health.ok.gov |
| **Inspection Frequency** | Routine inspections conducted; complaint investigations as needed. |
| **Required State Forms** | - Licensure Applications and Forms  
Link: https://oklahoma.gov/health/services/licensing-inspections/medical-facilities-service |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | Oklahoma Health Care Authority - Medicaid  
Website: https://okhca.org/ |
| **State-Specific Notes** | - 123 Robert S. Kerr Ave., Oklahoma City, OK 73102  
- No CON required for home health or hospice |

---

## STATE: CONNECTICUT

| Field | Details |
|-------|---------|
| **Licensing Authority** | Connecticut Department of Public Health - Facility Licensing and Investigations Section (FLIS)  
Website: https://portal.ct.gov/dph |
| **Hospital License Requirements** | General Hospitals (GH) and specialty hospitals licensed by DPH.  
Link: https://portal.ct.gov/dph/facility-licensing--investigations |
| **Nursing Home License Requirements** | Chronic & Convalescent Nursing Homes (CCNH) licensed by DPH.  
Contact: DPH.FLISLPU@ct.gov |
| **Home Health License Requirements** | Home Health Care (HHC) and Homemaker Home Health Aide Agencies (HHHA) licensed by DPH. |
| **Inspection Frequency** | FLIS licenses, tracks, investigates, and regulates over 1,900 licensed facilities. |
| **Required State Forms** | - Facility Licensing Forms  
- Renewals through CT eLicense Portal |
| **Incident Reporting Rules** | Complaints: (860) 509-7400 |
| **State Medicaid Agency** | Connecticut Department of Social Services - Medicaid  
Website: https://portal.ct.gov/dss/ |
| **State-Specific Notes** | - 410 Capitol Avenue, Hartford, CT 06134  
- Certificate of Need program administered by Office of Health Care Access |

---

## STATE: UTAH

| Field | Details |
|-------|---------|
| **Licensing Authority** | Utah Department of Health and Human Services - Bureau of Health Facility Licensing, Certification, and Resident Assessment  
Website: https://dlbc.utah.gov/ |
| **Hospital License Requirements** | Hospitals licensed by DHHS. Must comply with state regulations. |
| **Nursing Home License Requirements** | Nursing facilities licensed by DHHS. Must complete CMS certification for Medicare/Medicaid.  
Link: https://dlbc.utah.gov/home/office-of-licensing/health-facilities/ |
| **Home Health License Requirements** | Home health agencies require state license. Deemed status available for accredited facilities. |
| **Inspection Frequency** | Routine inspections conducted; complaint investigations as needed. |
| **Required State Forms** | - Health Facility Forms  
Link: https://dlbc.utah.gov/home/office-of-licensing/health-facilities/health-facilities-applications-and-renewals/ |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | Utah Department of Health and Human Services - Medicaid  
Website: https://medicaid.utah.gov/ |
| **State-Specific Notes** | - Division of Licensing and Background Checks (DLBC)  
- 195 North 1950 West, Salt Lake City, UT 84116  
- Contact: (801) 538-4242 |

---

## STATE: NEVADA

| Field | Details |
|-------|---------|
| **Licensing Authority** | Nevada Department of Health and Human Services - Bureau of Health Care Quality and Compliance  
Website: https://dpbh.nv.gov/ |
| **Hospital License Requirements** | Hospitals licensed under NRS Chapter 449. Must comply with state regulations. |
| **Nursing Home License Requirements** | Skilled Nursing Facilities licensed by DHHS. |
| **Home Health License Requirements** | Home Health Agencies licensed by DHHS. |
| **Inspection Frequency** | Unannounced compliance surveys conducted on specified timeframes (annually, biannually, etc.). |
| **Required State Forms** | - ALiS Online Licensing System: https://nvdpbh.aithent.com/  
Email: pbhlicensing@nvha.nv.gov |
| **Incident Reporting Rules** | Complaint investigations conducted for all licensed/certified facilities. |
| **State Medicaid Agency** | Nevada Department of Health and Human Services - Medicaid  
Website: https://dhhs.nv.gov/ |
| **State-Specific Notes** | - Licenses over 30 different facility types  
- Contact: 775-684-1030  
- Also certifies 7 facility types for CMS |

---

## STATE: IOWA

| Field | Details |
|-------|---------|
| **Licensing Authority** | Iowa Department of Inspections and Appeals - Health Facilities Division  
Website: https://dia.iowa.gov/ |
| **Hospital License Requirements** | Hospitals licensed by Iowa DIA. Must comply with state regulations. |
| **Nursing Home License Requirements** | Nursing homes licensed by Iowa DIA. Must comply with federal and state regulations. |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | Annual surveys for nursing homes; routine inspections for hospitals. |
| **Required State Forms** | - Hospital License Application  
- Nursing Home License Application |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | Iowa Department of Health and Human Services - Medicaid  
Website: https://hhs.iowa.gov/medicaid |
| **State-Specific Notes** | - Certificate of Need required for certain projects |

---

## STATE: ARKANSAS

| Field | Details |
|-------|---------|
| **Licensing Authority** | Arkansas Department of Human Services - Division of Aging, Adult and Behavioral Health Services (DAABHS)  
Website: https://humanservices.arkansas.gov/ |
| **Hospital License Requirements** | Hospitals licensed by Arkansas DHS. Must comply with state regulations. |
| **Nursing Home License Requirements** | Nursing homes licensed by Arkansas DHS. Must comply with federal and state regulations. |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | Routine inspections conducted; complaint investigations as needed. |
| **Required State Forms** | - Behavioral Health Facility License Application |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | Arkansas Department of Human Services - Medicaid  
Website: https://humanservices.arkansas.gov/ |
| **State-Specific Notes** | - No Certificate of Need required for most behavioral health services  
- DAABHS oversees substance use and mental health facilities |

---

## STATE: MISSISSIPPI

| Field | Details |
|-------|---------|
| **Licensing Authority** | Mississippi State Department of Health - Division of Health Facilities Licensure and Certification  
Website: https://msdh.ms.gov/ |
| **Hospital License Requirements** | Hospitals licensed by MSDH. Must comply with state regulations.  
Link: https://msdh.ms.gov/msdhsite/index.cfm/30,2004,83,html |
| **Nursing Home License Requirements** | Nursing homes licensed by MSDH. Must comply with federal and state regulations. |
| **Home Health License Requirements** | Home health agencies licensed by MSDH. |
| **Inspection Frequency** | Routine surveys conducted; follow-up visits for cited deficiencies. |
| **Required State Forms** | - Health Facilities Licensure Forms  
- Facility Reported Incidents: FacilityReportedIncidents@msdh.ms.gov |
| **Incident Reporting Rules** | Complaint hotline: 1-800-227-7308 |
| **State Medicaid Agency** | Mississippi Division of Medicaid  
Website: https://medicaid.ms.gov/ |
| **State-Specific Notes** | - Fire Safety and Construction staff review architectural plans  
- Rural Emergency Hospital conversion available |

---

## STATE: KANSAS

| Field | Details |
|-------|---------|
| **Licensing Authority** | Kansas Department of Health and Environment - Health Facility Surveys  
Website: https://www.kdhe.ks.gov/ |
| **Hospital License Requirements** | Hospitals licensed by KDHE. Must comply with state regulations. |
| **Nursing Home License Requirements** | Nursing homes licensed by KDHE. Must comply with federal and state regulations. |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | Annual surveys for nursing homes; routine inspections for hospitals. |
| **Required State Forms** | - Hospital License Application  
- Nursing Home License Application |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | Kansas Department of Health and Environment - Medicaid  
Website: https://www.kdhe.ks.gov/ |
| **State-Specific Notes** | - Certificate of Need required for certain projects |

---

## STATE: NEW MEXICO

| Field | Details |
|-------|---------|
| **Licensing Authority** | New Mexico Health Care Authority - Division of Health Improvement (DHI)  
Website: https://www.hca.nm.gov/division-of-health-improvement/ |
| **Hospital License Requirements** | Hospitals licensed by DHI. Fee: $12.00 per bed annually.  
Link: https://www.hca.nm.gov/health-facility-licensing-and-certification/ |
| **Nursing Home License Requirements** | Nursing homes licensed by DHI. Must comply with federal and state regulations. |
| **Home Health License Requirements** | Home health agencies require state license. |
| **Inspection Frequency** | Health and safety surveys conducted for all licensed facilities. |
| **Required State Forms** | - Health Facility License Application  
Email: Facility.License@hca.nm.gov |
| **Incident Reporting Rules** | Abuse/Neglect/Exploitation investigations conducted. |
| **State Medicaid Agency** | New Mexico Human Services Department - Medicaid  
Website: https://www.hsd.state.nm.us/ |
| **State-Specific Notes** | - Caregivers Criminal History Screening Program (CCHSP)  
- Employee Abuse Registry (EAR)  
- Certified Nurse Aide Registry maintained |

---

## STATE: NEBRASKA

| Field | Details |
|-------|---------|
| **Licensing Authority** | Nebraska Department of Health and Human Services - Division of Behavioral Health / Licensure  
Website: https://dhhs.ne.gov/ |
| **Hospital License Requirements** | Hospitals licensed by Nebraska DHHS. Must comply with state regulations. |
| **Nursing Home License Requirements** | Nursing homes licensed by Nebraska DHHS. Must comply with federal and state regulations. |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | Routine inspections conducted; complaint investigations as needed. |
| **Required State Forms** | - Facility License Applications |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | Nebraska Department of Health and Human Services - Medicaid  
Website: https://dhhs.ne.gov/pages/medicaid.aspx |
| **State-Specific Notes** | - Division of Behavioral Health oversees mental health/substance use facilities |

---

## STATE: IDAHO

| Field | Details |
|-------|---------|
| **Licensing Authority** | Idaho Department of Health and Welfare - Bureau of Facility Standards  
Website: https://healthandwelfare.idaho.gov/ |
| **Hospital License Requirements** | Hospitals licensed under Idaho Statute. As of July 1, 2025, licenses have no expiration date; updated only when facility changes.  
Link: https://healthandwelfare.idaho.gov/providers/acute-and-continuing-care/hospitals |
| **Nursing Home License Requirements** | Nursing homes licensed by Idaho DHW. Must comply with federal and state regulations. |
| **Home Health License Requirements** | Home health agencies require state license. |
| **Inspection Frequency** | All surveys unannounced except initial surveys. |
| **Required State Forms** | - Residential Assisted Living Licensing Portal: http://assistedliving.dhw.idaho.gov  
- Policy and Procedure Checklist required |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | Idaho Department of Health and Welfare - Medicaid  
Website: https://healthandwelfare.idaho.gov/medicaid |
| **State-Specific Notes** | - Fire Life Safety (FLS) evaluation required  
- Facility Fire Safety and Construction requirements must be met |

---

## STATE: HAWAII

| Field | Details |
|-------|---------|
| **Licensing Authority** | Hawaii State Department of Health - Office of Health Care Assurance  
Website: https://health.hawaii.gov/ |
| **Hospital License Requirements** | Hospitals require Certificate of Need (CON) from State Health Planning and Development Agency (SHPDA) and state license.  
Link: https://health.hawaii.gov/ohca/ |
| **Nursing Home License Requirements** | Nursing homes licensed by Hawaii DOH. Must comply with federal and state regulations. |
| **Home Health License Requirements** | Home health agencies require state license. |
| **Inspection Frequency** | Initial on-site survey arranged after documentation acceptable. |
| **Required State Forms** | - General Health Care Facility License Application  
- CON Application (if applicable) |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | Hawaii Department of Human Services - Medicaid  
Website: https://humanservices.hawaii.gov/ |
| **State-Specific Notes** | - 601 Kamokila Boulevard, Room 395, Kapolei, HI 96707  
- SHPDA issues CON or letter indicating CON not needed |

---

## STATE: NEW HAMPSHIRE

| Field | Details |
|-------|---------|
| **Licensing Authority** | New Hampshire Department of Health and Human Services - Health Facilities Administration  
Website: https://www.dhhs.nh.gov/doing-business-dhhs/licensing-certification/health-facilities-administration |
| **Hospital License Requirements** | Hospitals (General, CAH, Psychiatric, Rehabilitation) licensed by NH DHHS. Fee: $25/bed.  
Link: https://www.dhhs.nh.gov/ |
| **Nursing Home License Requirements** | Nursing Homes licensed by NH DHHS. Fee: $25/bed. |
| **Home Health License Requirements** | Home Health Care Providers licensed. Fee: $250. |
| **Inspection Frequency** | Routine inspections conducted; complaint investigations as needed. |
| **Required State Forms** | - Health Facilities License Application  
- Local Approval Form required for most facilities |
| **Incident Reporting Rules** | Complaints: (603) 271-9039 (Licensed), (603) 271-9049 (Certified) |
| **State Medicaid Agency** | New Hampshire Department of Health and Human Services - Medicaid  
Website: https://www.dhhs.nh.gov/ |
| **State-Specific Notes** | - 129 Pleasant Street, Concord, NH 03301  
- Email: HFA-Licensing@dhhs.nh.gov  
- CARES tool used for resident needs assessment |

---

## STATE: MAINE

| Field | Details |
|-------|---------|
| **Licensing Authority** | Maine Department of Health and Human Services - Division of Licensing and Certification  
Website: https://www.maine.gov/dhhs/dlc |
| **Hospital License Requirements** | Hospitals licensed by Maine DHHS. Must comply with state regulations.  
Link: https://www.maine.gov/dhhs/dlc/licensing-certification |
| **Nursing Home License Requirements** | Nursing homes licensed by Maine DHHS. Must comply with federal and state regulations. |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | Routine inspections conducted; complaint investigations as needed. |
| **Required State Forms** | - Medical Facilities License Applications  
- Behavioral Health Agency License Applications |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | Maine Department of Health and Human Services - MaineCare  
Website: https://www.maine.gov/dhhs/ |
| **State-Specific Notes** | - 41 Anthony Ave, 11 State House Station, Augusta, ME 04333  
- Maine Background Check Center available  
- CNA Registry maintained |

---

## STATE: RHODE ISLAND

| Field | Details |
|-------|---------|
| **Licensing Authority** | Rhode Island Department of Health - Center for Health Facilities Regulation  
Website: https://health.ri.gov/ |
| **Hospital License Requirements** | Hospitals licensed under Rhode Island General Laws. Must comply with state regulations. |
| **Nursing Home License Requirements** | Nursing homes licensed by RIDOH. Renewal notices sent 60 days before expiration.  
Link: https://health.ri.gov/licensing/nursing-homes |
| **Home Health License Requirements** | Home health agencies require state license. |
| **Inspection Frequency** | Routine inspections conducted; complaint investigations as needed. |
| **Required State Forms** | - License Application through online portal: https://healthri.mylicense.com/  
Email: doh.elicense@health.ri.gov |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | Rhode Island Executive Office of Health and Human Services - Medicaid  
Website: https://eohhs.ri.gov/ |
| **State-Specific Notes** | - Online license verification available  
- License 2000 database updated daily |

---

## STATE: MONTANA

| Field | Details |
|-------|---------|
| **Licensing Authority** | Montana Department of Public Health and Human Services - Licensure Bureau  
Website: https://dphhs.mt.gov/ |
| **Hospital License Requirements** | Hospitals licensed by Montana DPHHS. Fee: $20.00.  
Link: https://dphhs.mt.gov/ |
| **Nursing Home License Requirements** | Nursing homes licensed by Montana DPHHS. Must comply with federal and state regulations. |
| **Home Health License Requirements** | Home health agencies require state license. No CON required. |
| **Inspection Frequency** | License valid up to 3 years when standards met. |
| **Required State Forms** | - Health Care Facility License Application  
Address: 2401 Colonial Drive, P.O. Box 202953, Helena, MT 59620-2953 |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | Montana Department of Public Health and Human Services - Medicaid  
Website: https://dphhs.mt.gov/ |
| **State-Specific Notes** | - Assisted Living Facilities categorized A, B, or C based on resident needs  
- Adult Foster Care homes separately licensed |

---

## STATE: DELAWARE

| Field | Details |
|-------|---------|
| **Licensing Authority** | Delaware Department of Health and Social Services - Division of Health Care Quality (DHCQ)  
Website: https://dhss.delaware.gov/dhcq/ |
| **Hospital License Requirements** | Hospitals licensed by DHCQ. Must comply with state regulations. |
| **Nursing Home License Requirements** | Nursing homes licensed by DHSS Division of Long Term Care Residents Protection.  
Link: https://dhss.delaware.gov/dltcrp/ |
| **Home Health License Requirements** | Home health agencies require state license. |
| **Inspection Frequency** | Annual license term. |
| **Required State Forms** | - Long Term Care Facility License Application  
Contact: Robert.Smith@delaware.gov, (302) 421-7400 |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | Delaware Department of Health and Social Services - Medicaid  
Website: https://dhss.delaware.gov/dhss/dmma/ |
| **State-Specific Notes** | - No Certificate of Need required for behavioral health facilities  
- Division of Long Term Care Residents Protection oversees nursing homes |

---

## STATE: VERMONT

| Field | Details |
|-------|---------|
| **Licensing Authority** | Vermont Department of Health - Division of Licensing and Protection  
Website: https://www.healthvermont.gov/ |
| **Hospital License Requirements** | Hospitals licensed by Vermont DOH. Must comply with state regulations. |
| **Nursing Home License Requirements** | Nursing homes licensed by Vermont DOH. Must comply with federal and state regulations. |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | Annual surveys for nursing homes; routine inspections for hospitals. |
| **Required State Forms** | - Hospital License Application  
- Nursing Home License Application |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | Vermont Department of Vermont Health Access - Medicaid  
Website: https://dvha.vermont.gov/ |
| **State-Specific Notes** | - Certificate of Need required for certain projects |

---

## STATE: ALASKA

| Field | Details |
|-------|---------|
| **Licensing Authority** | Alaska Department of Health - Division of Health Care Services  
Website: https://health.alaska.gov/ |
| **Hospital License Requirements** | Hospitals licensed by Alaska DHSS. Must comply with state regulations. |
| **Nursing Home License Requirements** | Nursing homes licensed by Alaska DHSS. Must comply with federal and state regulations. |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | Annual surveys for nursing homes; routine inspections for hospitals. |
| **Required State Forms** | - Hospital License Application  
- Nursing Home License Application |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | Alaska Department of Health - Medicaid  
Website: https://health.alaska.gov/ |
| **State-Specific Notes** | - Certificate of Need required for certain projects |

---

## STATE: NORTH DAKOTA

| Field | Details |
|-------|---------|
| **Licensing Authority** | North Dakota Department of Health and Human Services - Health Facilities  
Website: https://www.hhs.nd.gov/ |
| **Hospital License Requirements** | Hospitals licensed by ND HHS. Must comply with state regulations. |
| **Nursing Home License Requirements** | Nursing homes licensed by ND HHS. Must comply with federal and state regulations. |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | Annual surveys for nursing homes; routine inspections for hospitals. |
| **Required State Forms** | - Hospital License Application  
- Nursing Home License Application |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | North Dakota Department of Health and Human Services - Medicaid  
Website: https://www.hhs.nd.gov/ |
| **State-Specific Notes** | - Certificate of Need required for certain projects |

---

## STATE: SOUTH DAKOTA

| Field | Details |
|-------|---------|
| **Licensing Authority** | South Dakota Department of Health - Health Care Facilities  
Website: https://doh.sd.gov/ |
| **Hospital License Requirements** | Hospitals licensed by South Dakota DOH. Must comply with state regulations. |
| **Nursing Home License Requirements** | Nursing homes licensed by South Dakota DOH. Must comply with federal and state regulations. |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | Annual surveys for nursing homes; routine inspections for hospitals. |
| **Required State Forms** | - Hospital License Application  
- Nursing Home License Application |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | South Dakota Department of Social Services - Medicaid  
Website: https://dss.sd.gov/ |
| **State-Specific Notes** | - Certificate of Need required for certain projects |

---

## STATE: WYOMING

| Field | Details |
|-------|---------|
| **Licensing Authority** | Wyoming Department of Health - Healthcare Licensing and Surveys  
Website: https://health.wyo.gov/ |
| **Hospital License Requirements** | Hospitals licensed by Wyoming DOH. Must comply with state regulations. |
| **Nursing Home License Requirements** | Nursing homes licensed by Wyoming DOH. Must comply with federal and state regulations. |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | Annual surveys for nursing homes; routine inspections for hospitals. |
| **Required State Forms** | - Hospital License Application  
- Nursing Home License Application |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | Wyoming Department of Health - Medicaid  
Website: https://health.wyo.gov/ |
| **State-Specific Notes** | - Certificate of Need required for certain projects |

---

## STATE: WEST VIRGINIA

| Field | Details |
|-------|---------|
| **Licensing Authority** | West Virginia Department of Health and Human Resources - Office of Health Facility Licensure and Certification  
Website: https://dhhr.wv.gov/ |
| **Hospital License Requirements** | Hospitals licensed by WV DHHR. Must comply with state regulations. |
| **Nursing Home License Requirements** | Nursing homes licensed by WV DHHR. Must comply with federal and state regulations. |
| **Home Health License Requirements** | Home health agencies require state license and Medicare certification. |
| **Inspection Frequency** | Annual surveys for nursing homes; routine inspections for hospitals. |
| **Required State Forms** | - Hospital License Application  
- Nursing Home License Application |
| **Incident Reporting Rules** | Incident reporting required per state guidelines. |
| **State Medicaid Agency** | West Virginia Department of Health and Human Resources - Medicaid  
Website: https://dhhr.wv.gov/ |
| **State-Specific Notes** | - Certificate of Need required for certain projects |

---

## DOCUMENT INFORMATION

### Data Sources
- Official State Department of Health websites
- State administrative codes and regulations
- State Medicaid agency publications
- Official state licensing portals
- Centers for Medicare & Medicaid Services (CMS) state survey agency information

### Disclaimer
This database is compiled from publicly available information and official state sources. Regulations and requirements change frequently. Always verify current requirements directly with the appropriate state licensing authority before making compliance decisions.

### Contact for Updates
For corrections or updates to this database, contact the appropriate state licensing authority listed in each state entry.

---

*End of State Healthcare Regulatory Database*
