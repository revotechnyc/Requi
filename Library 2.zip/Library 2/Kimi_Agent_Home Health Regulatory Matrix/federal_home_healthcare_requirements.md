# U.S. Federal Requirements for Starting and Operating a Home Healthcare Business

## Research Summary
This document compiles ALL official U.S. federal government requirements for starting and operating a home healthcare business, sourced exclusively from official .gov websites.

**Research Date:** 2025
**Sources:** Official federal government websites only (.gov domains)

---

## Table of Contents
1. [CMS (Centers for Medicare & Medicaid Services) Requirements](#1-cms-requirements)
2. [HHS/OIG (Office of Inspector General) Requirements](#2-hhsoig-requirements)
3. [HIPAA/OCR (Office for Civil Rights) Requirements](#3-hipaaocr-requirements)
4. [IRS (Internal Revenue Service) Requirements](#4-irs-requirements)
5. [Department of Labor Requirements](#5-department-of-labor-requirements)
6. [OSHA (Occupational Safety and Health Administration) Requirements](#6-osha-requirements)
7. [Other Federal Requirements](#7-other-federal-requirements)

---

## 1. CMS REQUIREMENTS

### 1.1 Medicare Enrollment for Home Health Agencies

| Field | Details |
|-------|---------|
| **Agency** | CMS (Centers for Medicare & Medicaid Services) |
| **Source Title** | Medicare Program Integrity Manual - Provider Enrollment |
| **Source URL** | https://www.cms.gov/regulations-and-guidance/guidance/manuals/downloads/pim83c10.pdf |
| **Category** | Enrollment/Registration |
| **Summary** | Home Health Agencies must enroll in Medicare using Form CMS-855A or the internet-based PECOS system to receive a Medicare billing number. Institutional providers must complete this application to enroll in Medicare. |
| **Required** | Yes (for Medicare participation) |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | No |
| **Medicaid Provider** | Varies by state |
| **Evidence Strength** | High |

---

### 1.2 CMS-855A Enrollment Application

| Field | Details |
|-------|---------|
| **Agency** | CMS |
| **Source Title** | CMS-855A Medicare Enrollment Application |
| **Source URL** | https://www.cms.gov/medicare/cms-forms/cms-forms/downloads/cms855a.pdf |
| **Category** | Enrollment/Registration |
| **Summary** | Home Health Agencies must complete Form CMS-855A to initiate Medicare enrollment. Requires Type 2 NPI, disclosure of all persons with 5%+ ownership interest, organizational structure diagram, and various supporting documentation. |
| **Required** | Yes (for Medicare participation) |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | No |
| **Medicaid Provider** | Varies by state |
| **Notes** | Per Section 125 of CAA 2021, an action plan is required with enrollment application |
| **Evidence Strength** | High |

---

### 1.3 Conditions of Participation (CoP) for Home Health Agencies

| Field | Details |
|-------|---------|
| **Agency** | CMS |
| **Source Title** | State Operations Manual - Home Health Agencies Appendix B |
| **Source URL** | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_b_hha.pdf |
| **Category** | Licensing/Certification |
| **Summary** | Home Health Agencies must meet ALL Conditions of Participation under 42 CFR Part 484 including: patient rights, comprehensive assessment, care planning, quality improvement, infection control, clinical records, and personnel qualifications. |
| **Required** | Yes (for Medicare participation) |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | No |
| **Medicaid Provider** | Varies by state |
| **Evidence Strength** | High |

---

### 1.4 HHA Administrator Qualifications

| Field | Details |
|-------|---------|
| **Agency** | CMS |
| **Source Title** | 42 CFR 484.115 - Personnel Qualifications |
| **Source URL** | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_b_hha.pdf |
| **Category** | Personnel Requirements |
| **Summary** | For administrators beginning employment ON OR AFTER January 13, 2018: Must be a licensed physician, registered nurse, OR hold an undergraduate degree AND have training/experience in health service administration AND at least 1 year of supervisory administrative experience in home health care or related health care program. |
| **Required** | Yes |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | No |
| **Medicaid Provider** | Varies by state |
| **Evidence Strength** | High |

---

### 1.5 OASIS Data Reporting Requirements

| Field | Details |
|-------|---------|
| **Agency** | CMS |
| **Source Title** | 42 CFR 484.45 - Reporting OASIS Information |
| **Source URL** | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_b_hha.pdf |
| **Category** | Data Reporting |
| **Summary** | HHAs must electronically report ALL OASIS data collected. Must encode and electronically transmit each completed OASIS assessment to CMS within 30 days of completing the assessment. Data must be transmitted using software compliant with FIPS 140-2. |
| **Required** | Yes |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | No |
| **Medicaid Provider** | Varies by state |
| **Evidence Strength** | High |

---

### 1.6 Patient Rights Requirements

| Field | Details |
|-------|---------|
| **Agency** | CMS |
| **Source Title** | 42 CFR 484.50 - Condition of Participation: Patient Rights |
| **Source URL** | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_b_hha.pdf |
| **Category** | Patient Rights |
| **Summary** | HHA must provide patient and representative with rights information during initial evaluation visit, in advance of furnishing care. Must protect and promote exercise of these rights. Must advise patient of extent to which payment may be expected from Medicare or other sources. |
| **Required** | Yes |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | No |
| **Medicaid Provider** | Varies by state |
| **Evidence Strength** | High |

---

### 1.7 Clinical Records Requirements

| Field | Details |
|-------|---------|
| **Agency** | CMS |
| **Source Title** | 42 CFR 484.110 - Condition of Participation: Clinical Records |
| **Source URL** | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_b_hha.pdf |
| **Category** | Recordkeeping |
| **Summary** | HHA must maintain clinical records on all patients. Records must be protected against loss, unauthorized use, and safeguarded. Patient's clinical record must be made available to patient free of charge upon request at next home visit or within 4 business days (whichever comes first). |
| **Required** | Yes |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | No |
| **Medicaid Provider** | Varies by state |
| **Evidence Strength** | High |

---

### 1.8 Compliance with Federal, State, and Local Laws

| Field | Details |
|-------|---------|
| **Agency** | CMS |
| **Source Title** | 42 CFR 484.100 - Compliance with Federal, State, and Local Laws |
| **Source URL** | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_b_hha.pdf |
| **Category** | Legal Compliance |
| **Summary** | HHA and its staff must operate and furnish services in compliance with ALL applicable federal, state, and local laws and regulations related to health and safety of patients. If state or local law provides licensing of HHAs, the HHA must be licensed. |
| **Required** | Yes |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | No |
| **Medicaid Provider** | Varies by state |
| **Evidence Strength** | High |

---

### 1.9 Disclosure of Ownership and Management Information

| Field | Details |
|-------|---------|
| **Agency** | CMS |
| **Source Title** | 42 CFR 484.100(a) - Disclosure Requirements |
| **Source URL** | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_b_hha.pdf |
| **Category** | Disclosure/Transparency |
| **Summary** | HHA must disclose to state survey agency at time of initial certification request, for each survey, and at time of any change in ownership or management: (1) Names/addresses of all persons with ownership/controlling interest; (2) Names/addresses of all officers, directors, agents, managing employees; (3) Name/business address of corporation responsible for management. |
| **Required** | Yes |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | No |
| **Medicaid Provider** | Varies by state |
| **Evidence Strength** | High |

---

### 1.10 Infection Prevention and Control Program

| Field | Details |
|-------|---------|
| **Agency** | CMS |
| **Source Title** | 42 CFR 484.70 - Condition of Participation: Infection Prevention and Control |
| **Source URL** | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_b_hha.pdf |
| **Category** | Infection Control |
| **Summary** | HHA must maintain and document an infection control program with the goal of preventing and controlling infections and communicable diseases. |
| **Required** | Yes |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | No |
| **Medicaid Provider** | Varies by state |
| **Evidence Strength** | High |

---

### 1.11 Quality Assessment and Performance Improvement (QAPI)

| Field | Details |
|-------|---------|
| **Agency** | CMS |
| **Source Title** | 42 CFR 484.65 - Condition of Participation: QAPI |
| **Source URL** | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_b_hha.pdf |
| **Category** | Quality Improvement |
| **Summary** | Governing body must assume overall responsibility for ensuring QAPI program reflects complexity of HHA and its services, involves all services, focuses on indicators related to improved outcomes, and takes actions addressing HHA's performance. Must appropriately address any findings of fraud or waste. |
| **Required** | Yes |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | No |
| **Medicaid Provider** | Varies by state |
| **Evidence Strength** | High |

---

### 1.12 Home Health Aide Services Requirements

| Field | Details |
|-------|---------|
| **Agency** | CMS |
| **Source Title** | 42 CFR 484.80 - Condition of Participation: Home Health Aide Services |
| **Source URL** | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_b_hha.pdf |
| **Category** | Personnel/Services |
| **Summary** | HHA must ensure home health aides are competent and meet specific training requirements. Two standards apply to beneficiaries who receive non-skilled services only: 484.80(h)(2) and 484.80(i). |
| **Required** | Yes |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Partial (two specific standards apply) |
| **Medicaid Provider** | Varies by state |
| **Evidence Strength** | High |

---

### 1.13 Initial Certification Survey Requirements

| Field | Details |
|-------|---------|
| **Agency** | CMS |
| **Source Title** | State Operations Manual - Initial Certification Survey |
| **Source URL** | https://www.cms.gov/Regulations-and-Guidance/Guidance/Manuals/downloads/som107ap_b_hha.pdf |
| **Category** | Certification |
| **Summary** | Before initial certification survey, prospective HHA must: (1) Obtain MAC approval of CMS-855A application; (2) Provide skilled nursing and at least one other therapeutic service; (3) Have provided care to minimum of 10 skilled patients (7 receiving skilled care at time of survey). May be reduced to 5 patients in medically underserved areas. |
| **Required** | Yes (for initial Medicare participation) |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | No |
| **Medicaid Provider** | Varies by state |
| **Evidence Strength** | High |

---

### 1.14 Change of Ownership (CHOW) Requirements

| Field | Details |
|-------|---------|
| **Agency** | CMS |
| **Source Title** | 42 CFR 424.550(b) - Change of Ownership Requirements |
| **Source URL** | https://www.cms.gov/Regulations-and-Guidance/Guidance/Transmittals/downloads/R125SOMA.pdf |
| **Category** | Ownership Changes |
| **Summary** | HHAs that undergo change in majority ownership by sale within 3 years of initial Medicare enrollment or within 3 years of most recent change in majority ownership must enroll as NEW HHA provider (initial certification) unless an exception applies. Must undergo initial certification survey. |
| **Required** | Yes (when applicable) |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | No |
| **Medicaid Provider** | Varies by state |
| **Evidence Strength** | High |

---

### 1.15 Medicare Parts C and D Fraud, Waste, and Abuse Training

| Field | Details |
|-------|---------|
| **Agency** | CMS |
| **Source Title** | Medicare Managed Care Manual - FWA Training Requirements |
| **Source URL** | https://www.cms.gov/regulations-and-guidance/guidance/manuals/downloads/mc86c21.pdf |
| **Category** | Compliance Training |
| **Summary** | Employees (including temporary workers and volunteers), governing body members, and FDR employees who have involvement in administration or delivery of Parts C and D benefits must receive FWA training within 90 days of initial hiring and annually thereafter. |
| **Required** | Yes (for Medicare Advantage/Part D organizations) |
| **Medical Home Health** | Yes (if participating in MA/Part D) |
| **Non-Medical Home Care** | No |
| **Medicaid Provider** | Varies by state |
| **Evidence Strength** | High |

---

## 2. HHS/OIG REQUIREMENTS

### 2.1 Compliance Program Guidance for Home Health Agencies

| Field | Details |
|-------|---------|
| **Agency** | HHS OIG (Office of Inspector General) |
| **Source Title** | Compliance Program Guidance for Home Health Agencies |
| **Source URL** | https://oig.hhs.gov/documents/compliance-guidance/807/cpghome.pdf |
| **Category** | Compliance Program |
| **Summary** | OIG guidance for home health agencies to develop effective internal controls promoting adherence to applicable Federal and State law. Seven elements: (1) written policies/procedures; (2) compliance officer designation; (3) training/education; (4) hotline/complaint procedures; (5) internal audits; (6) disciplinary standards; (7) corrective action. |
| **Required** | Voluntary but strongly recommended |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes (recommended) |
| **Medicaid Provider** | Yes |
| **Notes** | While voluntary, existence of effective compliance program is viewed as mitigating factor in fraud/abuse cases |
| **Evidence Strength** | High |

---

### 2.2 OIG Exclusion Screening (LEIE)

| Field | Details |
|-------|---------|
| **Agency** | HHS OIG |
| **Source Title** | Exclusions FAQs - LEIE (List of Excluded Individuals and Entities) |
| **Source URL** | https://oig.hhs.gov/faqs/exclusions-faq/ |
| **Category** | Exclusion Screening |
| **Summary** | Healthcare providers should screen employees and contractors against OIG's LEIE to ensure they are not employing excluded individuals. LEIE provides information on individuals/entities excluded from Medicare, Medicaid, and all Federal health care programs. Available as online searchable database or downloadable database. |
| **Required** | Yes (to avoid CMP liability) |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes (if billing federal programs) |
| **Medicaid Provider** | Yes |
| **Notes** | Payment for items/services furnished by excluded persons may result in CMPs. LEIE updated monthly. |
| **Evidence Strength** | High |

---

### 2.3 Provider Self-Disclosure Protocol

| Field | Details |
|-------|---------|
| **Agency** | HHS OIG |
| **Source Title** | Self-Disclosure Information |
| **Source URL** | https://oig.hhs.gov/compliance/self-disclosure-info/ |
| **Category** | Self-Disclosure |
| **Summary** | Health care providers can use Provider Self-Disclosure Protocol to voluntarily disclose self-discovered evidence of potential fraud. Self-disclosure gives providers opportunity to avoid costs/disruptions of Government-directed investigation and litigation. Providers who cooperate fully generally not required to enter Corporate Integrity Agreement. |
| **Required** | Voluntary |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes (if applicable) |
| **Medicaid Provider** | Yes |
| **Notes** | Common issues disclosed: billing for items/services by excluded individuals, E/M upcoding, duplicate billing, kickbacks/Stark violations |
| **Evidence Strength** | High |

---

### 2.4 Corporate Integrity Agreements (CIA)

| Field | Details |
|-------|---------|
| **Agency** | HHS OIG |
| **Source Title** | Compliance - Corporate Integrity Agreements |
| **Source URL** | https://oig.hhs.gov/compliance/ |
| **Category** | Compliance Enforcement |
| **Summary** | A Corporate Integrity Agreement is an agreement between an entity and OIG that outlines obligations to improve compliance and prevent fraud, often as part of civil settlement. Providers who self-disclose and cooperate fully generally NOT required to enter CIA. |
| **Required** | Only if imposed as part of settlement |
| **Medical Home Health** | Yes (when applicable) |
| **Non-Medical Home Care** | Yes (when applicable) |
| **Medicaid Provider** | Yes (when applicable) |
| **Evidence Strength** | High |

---

### 2.5 General Compliance Program Guidance (GCPG)

| Field | Details |
|-------|---------|
| **Agency** | HHS OIG |
| **Source Title** | General Compliance Program Guidance |
| **Source URL** | https://oig.hhs.gov/compliance/compliance-guidance/ |
| **Category** | Compliance Program |
| **Summary** | GCPG is reference guide for health care compliance community providing information about relevant Federal laws, compliance program infrastructure, OIG resources. Applies to all individuals and entities involved in health care industry. |
| **Required** | Voluntary guidance |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes |
| **Medicaid Provider** | Yes |
| **Evidence Strength** | High |

---

## 3. HIPAA/OCR REQUIREMENTS

### 3.1 HIPAA Privacy Rule Compliance

| Field | Details |
|-------|---------|
| **Agency** | HHS OCR (Office for Civil Rights) |
| **Source Title** | Summary of the HIPAA Privacy Rule |
| **Source URL** | https://www.hhs.gov/hipaa/for-professionals/privacy/laws-regulations/index.html |
| **Category** | Privacy Protection |
| **Summary** | Covered entities must comply with HIPAA Privacy Rule standards addressing use and disclosure of protected health information (PHI). Must develop written privacy policies, designate privacy official, train workforce, maintain safeguards, provide privacy practices notice to patients, and comply with individual rights requirements. |
| **Required** | Yes |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes (if transmitting health information electronically) |
| **Medicaid Provider** | Yes |
| **Notes** | Home Health Agencies are covered entities under HIPAA |
| **Evidence Strength** | High |

---

### 3.2 HIPAA Security Rule Compliance

| Field | Details |
|-------|---------|
| **Agency** | HHS OCR |
| **Source Title** | HIPAA Security Rule NPRM and Guidance |
| **Source URL** | https://www.hhs.gov/hipaa/for-professionals/security/hipaa-security-rule-nprm/index.html |
| **Category** | Security Protection |
| **Summary** | Covered entities and business associates must implement administrative, physical, and technical safeguards to ensure confidentiality, integrity, and availability of electronic protected health information (ePHI). Must conduct risk assessments, implement security measures, and document policies/procedures. |
| **Required** | Yes |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes (if handling ePHI) |
| **Medicaid Provider** | Yes |
| **Notes** | OCR has seen 102% increase in large breach reports from 2018-2023 |
| **Evidence Strength** | High |

---

### 3.3 Business Associate Agreements

| Field | Details |
|-------|---------|
| **Agency** | HHS OCR |
| **Source Title** | Business Associate Contracts - 45 CFR 164.504(e) |
| **Source URL** | https://www.hhs.gov/hipaa/for-professionals/privacy/guidance/business-associates/index.html |
| **Category** | Business Associate Requirements |
| **Summary** | Covered entities must have written contracts with business associates that: describe permitted uses of PHI; prohibit unauthorized use/disclosure; require appropriate safeguards; require reporting of breaches; ensure subcontractors agree to same restrictions; and authorize termination for material violations. |
| **Required** | Yes |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes (if applicable) |
| **Medicaid Provider** | Yes |
| **Evidence Strength** | High |

---

### 3.4 Sample Business Associate Agreement Provisions

| Field | Details |
|-------|---------|
| **Agency** | HHS OCR |
| **Source Title** | Sample Business Associate Agreement Provisions |
| **Source URL** | https://www.hhs.gov/hipaa/for-professionals/covered-entities/sample-business-associate-agreement-provisions/index.html |
| **Category** | Business Associate Requirements |
| **Summary** | OCR provides sample provisions for business associate contracts including: definitions, obligations and activities of business associate, permitted uses and disclosures, provisions for return/destruction of PHI at termination, and breach notification procedures. |
| **Required** | Voluntary (sample provided for guidance) |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes (if applicable) |
| **Medicaid Provider** | Yes |
| **Evidence Strength** | High |

---

### 3.5 Remote Use of ePHI Guidance

| Field | Details |
|-------|---------|
| **Agency** | HHS OCR |
| **Source Title** | HIPAA Security - Remote Use Guidance |
| **Source URL** | https://www.hhs.gov/sites/default/files/ocr/privacy/hipaa/administrative/securityrule/remoteuse.pdf |
| **Category** | Security Protection |
| **Summary** | Covered entities must establish policies for securing ePHI being transmitted over electronic communications networks. Should prohibit transmission via open networks where appropriate, use secure connections (SSL, HTTPS), implement encryption, and install virus protection on portable devices. |
| **Required** | Yes (as part of Security Rule compliance) |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes (if applicable) |
| **Medicaid Provider** | Yes |
| **Evidence Strength** | High |

---

### 3.6 Notice of Privacy Practices

| Field | Details |
|-------|---------|
| **Agency** | HHS OCR |
| **Source Title** | Model Notice of Privacy Practices for HIPAA Covered Health Care Provider |
| **Source URL** | https://www.hhs.gov/hipaa/for-professionals/privacy/guidance/privacy-practices-health-care-provider/index.html |
| **Category** | Privacy Protection |
| **Summary** | Covered entities must provide Notice of Privacy Practices explaining how PHI is used and disclosed, patient rights, and how to file complaints. Must make good faith effort to obtain written acknowledgment of receipt. Model notice provided by OCR. |
| **Required** | Yes |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes (if applicable) |
| **Medicaid Provider** | Yes |
| **Evidence Strength** | High |

---

## 4. IRS REQUIREMENTS

### 4.1 Employer Identification Number (EIN)

| Field | Details |
|-------|---------|
| **Agency** | IRS (Internal Revenue Service) |
| **Source Title** | Instructions for Form SS-4 - Application for Employer Identification Number |
| **Source URL** | https://www.irs.gov/instructions/iss4 |
| **Category** | Tax Registration |
| **Summary** | Businesses must obtain an EIN using Form SS-4. Can apply online (preferred method for U.S. applicants), by telephone (international only), by fax, or by mail. Principal officer must have valid SSN, EIN, or ITIN. Online EIN available at IRS.gov/EIN. |
| **Required** | Yes |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes |
| **Medicaid Provider** | Yes |
| **Notes** | Free service; beware of websites charging for this |
| **Evidence Strength** | High |

---

### 4.2 Understanding Your EIN

| Field | Details |
|-------|---------|
| **Agency** | IRS |
| **Source Title** | Publication 1635 - Understanding Your EIN |
| **Source URL** | https://www.irs.gov/pub/irs-pdf/p1635.pdf |
| **Category** | Tax Registration |
| **Summary** | If you have one or more employees, you are generally required to withhold federal income tax from wages and may be subject to FICA (Social Security/Medicare) and FUTA (federal unemployment) taxes. An EIN is required to report employment taxes. |
| **Required** | Yes (if have employees) |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes |
| **Medicaid Provider** | Yes |
| **Evidence Strength** | High |

---

### 4.3 Employment Tax Obligations

| Field | Details |
|-------|---------|
| **Agency** | IRS |
| **Source Title** | Publication 1635 - Employment Taxes |
| **Source URL** | https://www.irs.gov/pub/irs-pdf/p1635.pdf |
| **Category** | Tax Obligations |
| **Summary** | Employers must withhold federal income tax from employee wages. Subject to FICA taxes (Social Security and Medicare). Subject to FUTA (Federal Unemployment Tax Act). Must file required employment tax returns (Forms 941, 940, W-2, W-3). |
| **Required** | Yes (if have employees) |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes |
| **Medicaid Provider** | Yes |
| **Evidence Strength** | High |

---

## 5. DEPARTMENT OF LABOR REQUIREMENTS

### 5.1 Fair Labor Standards Act (FLSA) Minimum Wage and Overtime

| Field | Details |
|-------|---------|
| **Agency** | DOL Wage and Hour Division |
| **Source Title** | Handy Reference Guide to the Fair Labor Standards Act |
| **Source URL** | https://www.dol.gov/agencies/whd/compliance-assistance/handy-reference-guide-flsa |
| **Category** | Wage and Hour |
| **Summary** | Covered employers must pay nonexempt employees at least federal minimum wage ($7.25/hour) for all hours worked and overtime pay (time-and-one-half) for hours worked over 40 in a workweek. Hospitals and institutions primarily engaged in care of sick, aged, or mentally ill are covered employers. |
| **Required** | Yes |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes |
| **Medicaid Provider** | Yes |
| **Evidence Strength** | High |

---

### 5.2 Home Health Care and Companionship Services Exemption

| Field | Details |
|-------|---------|
| **Agency** | DOL Wage and Hour Division |
| **Source Title** | Fact Sheet #25: Home Health Care and the Companionship Services Exemption |
| **Source URL** | https://www.dol.gov/agencies/whd/fact-sheets/25-flsa-home-healthcare |
| **Category** | Wage and Hour |
| **Summary** | Companionship services exemption may apply for employees providing companionship services to aged/infirm individuals. However, if employee spends more than 20% of time doing general household work, must be paid minimum wage and overtime. Must pay minimum wage and overtime for care of non-infirm children. |
| **Required** | Yes (if applicable) |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes |
| **Medicaid Provider** | Yes |
| **Notes** | Narrow exemption; most home health workers entitled to minimum wage and overtime |
| **Evidence Strength** | High |

---

### 5.3 Nurses and Professional Exemptions

| Field | Details |
|-------|---------|
| **Agency** | DOL Wage and Hour Division |
| **Source Title** | Fact Sheet #17N: Nurses and the Part 541 Exemptions |
| **Source URL** | https://www.dol.gov/agencies/whd/fact-sheets/17n-overtime-nurses |
| **Category** | Wage and Hour |
| **Summary** | Registered nurses paid on hourly basis must receive overtime. RNs registered by state examining board generally meet learned professional exemption duties requirements and, if paid salary of at least $684/week, may be classified as exempt. LPNs generally do NOT qualify as exempt learned professionals. |
| **Required** | Yes (if applicable) |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes |
| **Medicaid Provider** | Yes |
| **Evidence Strength** | High |

---

### 5.4 Health Care Industry Overtime Calculations

| Field | Details |
|-------|---------|
| **Agency** | DOL Wage and Hour Division |
| **Source Title** | The Health Care Industry and Calculating Overtime Pay |
| **Source URL** | https://www.dol.gov/agencies/whd/fact-sheets/54-healthcare-overtime |
| **Category** | Wage and Hour |
| **Summary** | Nonexempt employees must be paid at least time-and-one-half their "regular rate" of pay for hours over 40. Regular rate includes hourly rate plus value of bonuses and shift differentials. Common errors: failure to include bonuses/shift differentials in regular rate; errors calculating regular rate when employee works two+ jobs. |
| **Required** | Yes |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes |
| **Medicaid Provider** | Yes |
| **Evidence Strength** | High |

---

### 5.5 Family and Medical Leave Act (FMLA)

| Field | Details |
|-------|---------|
| **Agency** | DOL Wage and Hour Division |
| **Source Title** | Employer's Guide to the Family and Medical Leave Act |
| **Source URL** | https://www.dol.gov/sites/dolgov/files/WHD/legacy/files/employerguide.pdf |
| **Category** | Leave Requirements |
| **Summary** | Covered employers (50+ employees within 75 miles) must provide up to 12 workweeks unpaid leave per year for qualifying reasons, up to 26 workweeks military caregiver leave, job protection, and benefit protection. Must post FMLA notice, provide eligibility notice, rights/responsibilities notice, and designation notice. |
| **Required** | Yes (if covered employer) |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes |
| **Medicaid Provider** | Yes |
| **Evidence Strength** | High |

---

### 5.6 FMLA Poster and Notice Requirements

| Field | Details |
|-------|---------|
| **Agency** | DOL Wage and Hour Division |
| **Source Title** | FMLA General Guidance - Notice Requirements |
| **Source URL** | https://www.dol.gov/agencies/whd/fmla/general-guidance |
| **Category** | Notice Requirements |
| **Summary** | Every covered employer must display FMLA poster in plain view where employees can see it. Must also include general notice in employee handbook or distribute to new employees upon hire. Must provide eligibility notice within 5 business days of leave request. |
| **Required** | Yes (if covered employer) |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes |
| **Medicaid Provider** | Yes |
| **Notes** | Willful violation of posting requirement may result in civil money penalty |
| **Evidence Strength** | High |

---

### 5.7 Worker Classification - Employee vs Independent Contractor

| Field | Details |
|-------|---------|
| **Agency** | DOL Wage and Hour Division |
| **Source Title** | FAQs - Employee or Independent Contractor Classification Under the FLSA |
| **Source URL** | https://www.dol.gov/agencies/whd/flsa/misclassification/rulemaking/faqs |
| **Category** | Worker Classification |
| **Summary** | Under economic reality test, no single factor automatically determines worker status. Factors are weighed to assess whether worker is economically dependent on potential employer. Misclassification as independent contractor is common violation in care industry. |
| **Required** | Yes (proper classification required) |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes |
| **Medicaid Provider** | Yes |
| **Evidence Strength** | High |

---

### 5.8 Common Violations in Care Industry

| Field | Details |
|-------|---------|
| **Agency** | DOL Wage and Hour Division |
| **Source Title** | An Overview of the Fair Labor Standards Act (FLSA) for Care Workers |
| **Source URL** | https://www.dol.gov/sites/dolgov/files/WHD/ewep/EWEP-Initiative-Care-Workers.pdf |
| **Category** | Compliance |
| **Summary** | Common violations: failure to pay proper overtime (including salaried workers), improper deductions for meal breaks not taken, unpaid travel time, unpaid training time, unpaid on-call hours, pre/post-shift work, misclassification as independent contractor. |
| **Required** | N/A (informational) |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes |
| **Medicaid Provider** | Yes |
| **Evidence Strength** | High |

---

## 6. OSHA REQUIREMENTS

### 6.1 Bloodborne Pathogens Standard

| Field | Details |
|-------|---------|
| **Agency** | OSHA |
| **Source Title** | 29 CFR 1910.1030 - Bloodborne Pathogens Standard |
| **Source URL** | https://www.osha.gov/laws-regs/regulations/standardnumber/1910/1910.1030 |
| **Category** | Workplace Safety |
| **Summary** | Employers with workers who have occupational exposure to blood or OPIM must implement exposure control plan including: engineering/work practice controls, PPE, hepatitis B vaccination, post-exposure follow-up, hazard communication, training, and recordkeeping. Must use safer medical devices where available. |
| **Required** | Yes |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes (if exposure risk exists) |
| **Medicaid Provider** | Yes |
| **Evidence Strength** | High |

---

### 6.2 Bloodborne Pathogens Training Requirements

| Field | Details |
|-------|---------|
| **Agency** | OSHA |
| **Source Title** | Bloodborne Pathogens Standard - Training Requirements |
| **Source URL** | https://www.osha.gov/laws-regs/regulations/standardnumber/1910/1910.1030 |
| **Category** | Training |
| **Summary** | Training must include: regulatory text explanation, epidemiology/symptoms of bloodborne diseases, modes of transmission, exposure control plan explanation, recognizing tasks involving exposure, use/limitations of prevention methods, PPE information, hepatitis B vaccine information, emergency procedures, post-exposure follow-up, signs/labels, and interactive Q&A opportunity. |
| **Required** | Yes |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes (if exposure risk exists) |
| **Medicaid Provider** | Yes |
| **Evidence Strength** | High |

---

### 6.3 Sharps Injury Log

| Field | Details |
|-------|---------|
| **Agency** | OSHA |
| **Source Title** | Bloodborne Pathogens Standard - Sharps Injury Log |
| **Source URL** | https://www.osha.gov/bloodborne-pathogens/quick-reference |
| **Category** | Recordkeeping |
| **Summary** | Employers required to maintain OSHA injury/illness log must also establish and maintain sharps injury log for recording percutaneous injuries from contaminated sharps. Must contain: type/brand of device, department/work area, explanation of how incident occurred. Must protect confidentiality of injured worker. |
| **Required** | Yes (if required to maintain OSHA 300 log) |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes (if required) |
| **Medicaid Provider** | Yes |
| **Notes** | Medical/dental offices with <10 employees exempt from sharps injury log |
| **Evidence Strength** | High |

---

### 6.4 Hazard Communication Standard

| Field | Details |
|-------|---------|
| **Agency** | OSHA |
| **Source Title** | 29 CFR 1910.1200 - Hazard Communication Standard |
| **Source URL** | https://www.osha.gov/complianceassistance/quickstarts/health-care |
| **Category** | Workplace Safety |
| **Summary** | Employers with employees exposed to hazardous chemicals must prepare and implement written Hazard Communication Program. Must ensure employees know about hazardous chemicals and how to protect themselves. Includes requirements for Safety Data Sheets (SDS) and labeling. |
| **Required** | Yes (if hazardous chemicals present) |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes (if hazardous chemicals present) |
| **Medicaid Provider** | Yes |
| **Evidence Strength** | High |

---

### 6.5 Injury and Illness Recordkeeping

| Field | Details |
|-------|---------|
| **Agency** | OSHA |
| **Source Title** | 29 CFR Part 1904 - Recording and Reporting Occupational Injuries and Illnesses |
| **Source URL** | https://www.osha.gov/recordkeeping |
| **Category** | Recordkeeping |
| **Summary** | Employers with >10 employees must keep records of work-related injuries/illnesses using OSHA Forms 300, 300A, and 301. Must record within 7 calendar days. Must post Summary 300A by February 1 and keep posted until April 30. Keep logs for 5 years. |
| **Required** | Yes (if >10 employees) |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes (if >10 employees) |
| **Medicaid Provider** | Yes |
| **Notes** | Certain industries exempt; all employers must report fatalities (8 hours) and severe injuries (24 hours) |
| **Evidence Strength** | High |

---

### 6.6 Severe Injury Reporting

| Field | Details |
|-------|---------|
| **Agency** | OSHA |
| **Source Title** | Updates to OSHA's Recordkeeping Rule - Reporting Fatalities and Severe Injuries |
| **Source URL** | https://www.osha.gov/recordkeeping |
| **Category** | Reporting |
| **Summary** | ALL employers must report to OSHA: work-related fatalities within 8 hours; work-related inpatient hospitalizations, amputations, and losses of an eye within 24 hours. Can report by phone to nearest OSHA office, 24-hour hotline (1-800-321-OSHA), or online. |
| **Required** | Yes (all employers) |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes |
| **Medicaid Provider** | Yes |
| **Evidence Strength** | High |

---

### 6.7 Personal Protective Equipment (PPE) Standard

| Field | Details |
|-------|---------|
| **Agency** | OSHA |
| **Source Title** | 29 CFR 1910.132 - Personal Protective Equipment |
| **Source URL** | https://www.osha.gov/healthcare/infectious-diseases |
| **Category** | Workplace Safety |
| **Summary** | Employers must provide appropriate PPE to protect workers from hazards. Includes requirements for hazard assessment, equipment selection, training, and maintenance. Applies to protection against infectious diseases in healthcare settings. |
| **Required** | Yes |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes (if hazards present) |
| **Medicaid Provider** | Yes |
| **Evidence Strength** | High |

---

### 6.8 Respiratory Protection Standard

| Field | Details |
|-------|---------|
| **Agency** | OSHA |
| **Source Title** | 29 CFR 1910.134 - Respiratory Protection |
| **Source URL** | https://www.osha.gov/healthcare/infectious-diseases |
| **Category** | Workplace Safety |
| **Summary** | When respiratory protection is required, employers must establish and maintain respiratory protection program including: worksite-specific procedures, medical evaluations, fit testing, proper use, cleaning/disinfection, maintenance, and training. |
| **Required** | Yes (when respiratory protection required) |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes (when required) |
| **Medicaid Provider** | Yes |
| **Evidence Strength** | High |

---

## 7. OTHER FEDERAL REQUIREMENTS

### 7.1 Form I-9 Employment Eligibility Verification

| Field | Details |
|-------|---------|
| **Agency** | USCIS (U.S. Citizenship and Immigration Services) |
| **Source Title** | Handbook for Employers M-274 - Form I-9 Requirements |
| **Source URL** | https://www.uscis.gov/i-9-central/form-i-9-resources/handbook-for-employers-m-274/10-why-employers-must-verify-employment-authorization-and-identity-of-new-employees |
| **Category** | Employment Verification |
| **Summary** | ALL U.S. employers must verify identity and employment authorization of each person hired after November 6, 1986. Must complete and retain Form I-9 for each employee. Must examine acceptable documents to verify identity and work authorization. Must not discriminate based on national origin, citizenship, or immigration status. |
| **Required** | Yes (all employers) |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes |
| **Medicaid Provider** | Yes |
| **Evidence Strength** | High |

---

### 7.2 Form I-9 Current Version Requirements

| Field | Details |
|-------|---------|
| **Agency** | USCIS |
| **Source Title** | I-9, Employment Eligibility Verification |
| **Source URL** | https://www.uscis.gov/i-9 |
| **Category** | Employment Verification |
| **Summary** | Must use current version of Form I-9. Employee completes Section 1. Employer examines employee's documents and completes Section 2 within 3 business days of employee's first day of employment. Must retain for 3 years after hire date or 1 year after employment ends, whichever is later. |
| **Required** | Yes |
| **Medical Home Health** | Yes |
| **Non-Medical Home Care** | Yes |
| **Medicaid Provider** | Yes |
| **Evidence Strength** | High |

---

## SUMMARY MATRIX

| Requirement | Agency | Medical HHA | Non-Medical | Medicaid | Required |
|-------------|--------|-------------|-------------|----------|----------|
| Medicare Enrollment (CMS-855A) | CMS | Yes | No | Varies | For Medicare |
| Conditions of Participation | CMS | Yes | Partial | Varies | For Medicare |
| Administrator Qualifications | CMS | Yes | No | Varies | Yes |
| OASIS Reporting | CMS | Yes | No | Varies | Yes |
| Patient Rights | CMS | Yes | No | Varies | Yes |
| Clinical Records | CMS | Yes | No | Varies | Yes |
| State Licensure | CMS | Yes | Varies | Varies | Yes |
| Infection Control Program | CMS | Yes | No | Varies | Yes |
| QAPI Program | CMS | Yes | No | Varies | Yes |
| Compliance Program | OIG | Yes | Recommended | Yes | Voluntary |
| LEIE Exclusion Screening | OIG | Yes | Yes* | Yes | Yes |
| Self-Disclosure Protocol | OIG | Yes | Yes | Yes | Voluntary |
| HIPAA Privacy Rule | OCR | Yes | Yes* | Yes | Yes |
| HIPAA Security Rule | OCR | Yes | Yes* | Yes | Yes |
| Business Associate Agreements | OCR | Yes | Yes* | Yes | Yes |
| Notice of Privacy Practices | OCR | Yes | Yes* | Yes | Yes |
| EIN | IRS | Yes | Yes | Yes | Yes |
| Employment Taxes | IRS | Yes | Yes | Yes | Yes |
| FLSA Minimum Wage/Overtime | DOL | Yes | Yes | Yes | Yes |
| FMLA | DOL | Yes | Yes | Yes | If 50+ employees |
| Worker Classification | DOL | Yes | Yes | Yes | Yes |
| Bloodborne Pathogens | OSHA | Yes | Yes* | Yes | Yes |
| Sharps Injury Log | OSHA | Yes | Yes* | Yes | If >10 employees |
| Hazard Communication | OSHA | Yes | Yes* | Yes | If chemicals present |
| Injury/Illness Recordkeeping | OSHA | Yes | Yes | Yes | If >10 employees |
| Severe Injury Reporting | OSHA | Yes | Yes | Yes | All employers |
| PPE Standard | OSHA | Yes | Yes* | Yes | Yes |
| Respiratory Protection | OSHA | Yes | Yes* | Yes | When required |
| Form I-9 | USCIS | Yes | Yes | Yes | Yes |

*Applies if providing services that involve exposure risk or handling PHI

---

## DISCLAIMER

This document is compiled from official U.S. federal government sources (.gov domains) as of the research date. Requirements may change, and this document should not be considered legal advice. Always consult:
- Current federal regulations in the Code of Federal Regulations (CFR)
- Official agency guidance and manuals
- Legal counsel for specific compliance questions
- State and local authorities for additional requirements

**Federal requirements are minimum standards. States may have additional, more stringent requirements.**

---

*Document compiled from official federal sources including: CMS.gov, HHS.gov, OIG.HHS.gov, OSHA.gov, DOL.gov, IRS.gov, and USCIS.gov*
