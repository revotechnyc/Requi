# LOCAL GOVERNMENT REQUIREMENTS FOR HOME HEALTHCARE BUSINESSES
## Research Report: 10 Major Metropolitan Areas

**Research Date:** January 2025
**Research Scope:** Local business license requirements, zoning/occupancy requirements, fire inspection requirements, local tax registration, local health permits, city/county operating permits, home occupation restrictions, and local employer registration requirements.

**Important Note:** Home healthcare businesses are primarily regulated at the state level (state health department licensing). This report focuses ONLY on local government requirements (city/county/municipality) that are in addition to state requirements.

---

## 1. NEW YORK CITY, NY

### Summary
New York City does not issue a specific local business license for home healthcare agencies. Home healthcare is primarily regulated by New York State Department of Health (NYSDOH). However, NYC has specific requirements for businesses operating within the city.

### Requirements Found:

#### Local Business License
- **jurisdiction_type:** City
- **jurisdiction_name:** New York City
- **state:** NY
- **agency_name:** NYC Department of Consumer and Worker Protection (DCWP)
- **official_source_title:** Business License Requirements
- **official_source_url:** https://www.nyc.gov/site/dca/businesses/business-licenses.page
- **requirement_category:** Business License
- **requirement_summary:** No general business license required for home healthcare; state-regulated profession exempt from local licensing
- **whether_required:** No
- **notes:** Home healthcare agencies are licensed by NY State Department of Health, not NYC
- **evidence_strength:** High

#### Home Occupation Zoning
- **jurisdiction_type:** City
- **jurisdiction_name:** New York City
- **state:** NY
- **agency_name:** NYC Department of City Planning / NYC Department of Buildings
- **official_source_title:** Zoning Resolution - Home Occupations
- **official_source_url:** https://zr.planning.nyc.gov/article-xiv/chapter-3/143-12
- **requirement_category:** Zoning/Home Occupation
- **requirement_summary:** Home occupations limited to 25% of residence or 500 sq ft (whichever is less); 1 employee allowed (up to 3 in certain districts). Medical uses generally prohibited as home occupations.
- **whether_required:** Yes (restrictions apply)
- **notes:** Home healthcare AGENCIES (administrative offices) may operate from home under home occupation rules, but clinical services must be provided at client homes
- **evidence_strength:** High

#### Local Health Requirements
- **jurisdiction_type:** City
- **jurisdiction_name:** New York City
- **state:** NY
- **agency_name:** NYC Department of Health and Mental Hygiene (DOHMH)
- **official_source_title:** Permits and Licenses - NYC Health
- **official_source_url:** https://www.nyc.gov/site/doh/business/permits-licenses.page
- **requirement_category:** Health Permit
- **requirement_summary:** Home care workers must have initial physical exam including TB test and drug screen, plus annual exams
- **whether_required:** Yes
- **notes:** Applies to DFTA-funded home care programs; workers must pass health screenings per DOHMH requirements
- **evidence_strength:** High

#### State Licensing (Reference)
- **jurisdiction_type:** State
- **jurisdiction_name:** New York State
- **state:** NY
- **agency_name:** NYS Department of Health
- **official_source_title:** Certified Home Health Agency (CHHA) Operating Certificate
- **official_source_url:** https://nyc-business.nyc.gov/nycbusiness/description/certified-home-health-agency-chha-operating-certificate
- **requirement_category:** State Operating Certificate
- **requirement_summary:** CHHA operating certificate required from NYSDOH; moratorium on new applications until 2020 (check current status)
- **whether_required:** Yes
- **notes:** This is STATE requirement, not local
- **evidence_strength:** High

### Requirements NOT Found:
- No NYC-specific fire inspection requirements found for home healthcare businesses
- No NYC-specific local tax registration beyond general business taxes
- No NYC-specific employer registration beyond state/federal requirements

---

## 2. LOS ANGELES COUNTY, CA

### Summary
Los Angeles County requires a business license for businesses operating in unincorporated areas and certain contract cities. Home healthcare businesses are subject to county business licensing requirements.

### Requirements Found:

#### Local Business License
- **jurisdiction_type:** County
- **jurisdiction_name:** Los Angeles County
- **state:** CA
- **agency_name:** Los Angeles County Treasurer and Tax Collector
- **official_source_title:** Obtaining a Business License
- **official_source_url:** https://blc.lacounty.gov/obtaining-a-business-license/
- **requirement_category:** Business License
- **requirement_summary:** Business license required if conducting business in unincorporated areas of LA County or contract cities (Malibu, Santa Clarita, Westlake Village)
- **whether_required:** Yes
- **notes:** Contact (213) 974-2011 or visit ttc.lacounty.gov; applications may be filed in person at Business License Offices
- **evidence_strength:** High

#### Fire Inspection
- **jurisdiction_type:** County
- **jurisdiction_name:** Los Angeles County
- **state:** CA
- **agency_name:** Los Angeles County Fire Department
- **official_source_title:** Form 30-C Notice to Prospective Businesses
- **official_source_url:** https://fire.lacounty.gov/wp-content/uploads/2019/08/Form_30C_01-01-18_1.pdf
- **requirement_category:** Fire Inspection/Permit
- **requirement_summary:** Fire inspection may be required depending on business type and occupancy; Form 30-C Statement of Intended Use must be submitted
- **whether_required:** Unclear
- **notes:** Home healthcare businesses operating from commercial locations may require fire inspection; home-based operations typically exempt
- **evidence_strength:** Medium

#### Zoning/Home Occupation
- **jurisdiction_type:** County
- **jurisdiction_name:** Los Angeles County
- **state:** CA
- **agency_name:** LA County Planning
- **official_source_title:** Land Use and Zoning
- **official_source_url:** https://planning.lacounty.gov/land-use-zoning/
- **requirement_category:** Zoning
- **requirement_summary:** Residential zones allow home-based occupations as accessory use when operated by resident; must comply with specific restrictions
- **whether_required:** Yes (restrictions apply)
- **notes:** Home-based businesses must not change residential character of neighborhood
- **evidence_strength:** High

#### Public Health Permit
- **jurisdiction_type:** County
- **jurisdiction_name:** Los Angeles County
- **state:** CA
- **agency_name:** Los Angeles County Department of Public Health
- **official_source_title:** Get a Public Health Permit/License
- **official_source_url:** http://publichealth.lacounty.gov/eh/about/permit.htm
- **requirement_category:** Health Permit
- **requirement_summary:** Public Health Permit required for certain business types; contact EHPermits@ph.lacounty.gov or (888) 700-9995
- **whether_required:** Unclear
- **notes:** Home healthcare may not require public health permit unless providing specific regulated services
- **evidence_strength:** Low

### Requirements NOT Found:
- No specific LA County local tax registration found beyond business license
- No specific employer registration requirements found beyond state/federal

---

## 3. COOK COUNTY (CHICAGO), IL

### Summary
Chicago requires business licenses for most business activities. Cook County has a General Business License for unincorporated areas. Home healthcare businesses must comply with city/county licensing requirements.

### Requirements Found:

#### City Business License (Chicago)
- **jurisdiction_type:** City
- **jurisdiction_name:** Chicago
- **state:** IL
- **agency_name:** Chicago Department of Business Affairs and Consumer Protection (BACP)
- **official_source_title:** Applying for a Business License
- **official_source_url:** https://www.chicago.gov/city/en/sites/chicago-business-licensing/home/applyingforabusinesslicense.html
- **requirement_category:** Business License
- **requirement_summary:** Business license required for most business activities in Chicago; certain state-regulated professions exempt
- **whether_required:** Yes
- **notes:** Call 312-74-GOBIZ (744-6249); application steps include zoning approval, document submission, payment, and inspections
- **evidence_strength:** High

#### Home Occupation License (Chicago)
- **jurisdiction_type:** City
- **jurisdiction_name:** Chicago
- **state:** IL
- **agency_name:** Chicago Department of Business Affairs and Consumer Protection
- **official_source_title:** Home Based Business
- **official_source_url:** https://www.chicago.gov/city/en/sites/chicago-business-licensing/home/homebasedbusiness.html
- **requirement_category:** Home Occupation License
- **requirement_summary:** Home occupation license required for businesses operated from home; medical uses PROHIBITED as home occupations
- **whether_required:** Yes (if operating from home)
- **notes:** Medical uses explicitly prohibited as home occupations; home healthcare administrative offices may qualify but clinical services cannot be provided from home
- **evidence_strength:** High

#### County General Business License (Cook County Unincorporated)
- **jurisdiction_type:** County
- **jurisdiction_name:** Cook County
- **state:** IL
- **agency_name:** Cook County Department of Revenue
- **official_source_title:** Steps to Obtain a General Business License
- **official_source_url:** https://www.cookcountyil.gov/sites/g/files/ywwepo161/files/documents/2022-03/Steps%20to%20obtain%20a%20general%20business%20license.pdf
- **requirement_category:** Business License
- **requirement_summary:** General Business License required for businesses in unincorporated Cook County; $40 fee for 2-year license
- **whether_required:** Yes (in unincorporated areas)
- **notes:** Apply online at https://revenue.cookcountyil.gov/gbl/; multiple locations require separate licenses
- **evidence_strength:** High

#### Zoning Approval (Chicago)
- **jurisdiction_type:** City
- **jurisdiction_name:** Chicago
- **state:** IL
- **agency_name:** Chicago Department of Business Affairs and Consumer Protection
- **official_source_title:** Business License Application Steps
- **official_source_url:** https://www.chicago.gov/city/en/sites/chicago-business-licensing/home/license-application-requirements.html
- **requirement_category:** Zoning Approval
- **requirement_summary:** Every new business license application reviewed for zoning compliance; must ensure proposed business activity is allowed at location
- **whether_required:** Yes
- **notes:** Do not enter financial commitment until City confirms zoning compliance
- **evidence_strength:** High

#### Inspections (Chicago)
- **jurisdiction_type:** City
- **jurisdiction_name:** Chicago
- **state:** IL
- **agency_name:** Chicago Department of Business Affairs and Consumer Protection
- **official_source_title:** Business License Application Steps
- **official_source_url:** https://www.chicago.gov/city/en/sites/chicago-business-licensing/home/license-application-requirements.html
- **requirement_category:** Inspections
- **requirement_summary:** Inspections may include: Debt Check, Health Inspection, Department of Buildings Inspection, Fire Inspection, Fingerprint-Based Criminal History Investigation
- **whether_required:** Depends on license type
- **notes:** Specific inspections vary by business type; fire inspection required for some business types
- **evidence_strength:** High

#### Cook County Tax Registration
- **jurisdiction_type:** County
- **jurisdiction_name:** Cook County
- **state:** IL
- **agency_name:** Cook County Department of Revenue
- **official_source_title:** Home Rule Tax Registration Application
- **official_source_url:** https://www.cookcountyil.gov/sites/g/files/ywwepo161/files/service/registration-form.pdf
- **requirement_category:** Tax Registration
- **requirement_summary:** Registration required for various county taxes including amusement, parking, tobacco, etc.
- **whether_required:** Depends on business activities
- **notes:** Contact (312) 603-6328 or taxregistration@cookcountyil.gov
- **evidence_strength:** Medium

### Requirements NOT Found:
- No specific Chicago/Cook County health permit found for home healthcare
- No specific employer registration beyond state/federal

---

## 4. HARRIS COUNTY (HOUSTON), TX

### Summary
Houston (in Harris County) does not have a general business license requirement. However, businesses must register with the county and comply with various state requirements.

### Requirements Found:

#### Business Name Registration (DBA)
- **jurisdiction_type:** County
- **jurisdiction_name:** Harris County
- **state:** TX
- **agency_name:** Harris County Clerk
- **official_source_title:** Four Main Business Requirements for a Business to Legally Operate in Houston
- **official_source_url:** https://www.houstontx.gov/obo/solutionscenter/four_main_business_requirements.html
- **requirement_category:** Business Name Registration
- **requirement_summary:** Sole Proprietorship/General Partnership doing business under a name other than owner's name requires DBA Certificate with county
- **whether_required:** Yes
- **notes:** Harris County Clerk: 201 Caroline St., Suite 330, Houston, TX 77002; Phone: 713-755-6436; www.cclerk.hctx.net
- **evidence_strength:** High

#### Commercial Permitting
- **jurisdiction_type:** City
- **jurisdiction_name:** Houston
- **state:** TX
- **agency_name:** City of Houston Administration and Regulatory Affairs (ARA)
- **official_source_title:** Handyman Repair - Start A Business
- **official_source_url:** https://www.houstontx.gov/business/start/handyman-repair.html
- **requirement_category:** Commercial Permitting
- **requirement_summary:** Permits issued yearly for various business types; contact ARA for specific requirements
- **whether_required:** Depends on business type
- **notes:** Phone: 832-394-8801; Web: https://www.houstontx.gov/ara/regaffairs/commercialpermitting
- **evidence_strength:** Medium

#### Property Tax Rendition
- **jurisdiction_type:** County
- **jurisdiction_name:** Harris County
- **state:** TX
- **agency_name:** Harris County Appraisal District (HCAD)
- **official_source_title:** Four Main Business Requirements for a Business to Legally Operate in Houston
- **official_source_url:** https://www.houstontx.gov/obo/solutionscenter/four_main_business_requirements.html
- **requirement_category:** Property Tax
- **requirement_summary:** All businesses must file rendition listing business personal property assets; filing open January 1 - April 15
- **whether_required:** Yes
- **notes:** HCAD: 13013 Northwest Freeway, Houston, Texas 77040; Phone: 713-957-7800; www.hcad.org
- **evidence_strength:** High

### Requirements NOT Found:
- No general business license required in Houston
- No specific zoning requirements found for home healthcare
- No specific fire inspection requirements found for home healthcare
- No specific local health permit found for home healthcare
- No specific local employer registration found

---

## 5. MARICOPA COUNTY (PHOENIX), AZ

### Summary
Phoenix (in Maricopa County) does not have a general business license. Only certain regulated activities require a license. The city has specific zoning requirements for home occupations.

### Requirements Found:

#### No General Business License
- **jurisdiction_type:** City
- **jurisdiction_name:** Phoenix
- **state:** AZ
- **agency_name:** City of Phoenix
- **official_source_title:** License Services
- **official_source_url:** https://www.phoenix.gov/administration/departments/cityclerk/programs-services/license-services.html
- **requirement_category:** Business License
- **requirement_summary:** City of Phoenix does not have or issue a general business license; only certain activities regulated
- **whether_required:** No
- **notes:** Home healthcare businesses generally do not require city business license
- **evidence_strength:** High

#### Home Occupation Zoning
- **jurisdiction_type:** City
- **jurisdiction_name:** Phoenix
- **state:** AZ
- **agency_name:** City of Phoenix Planning and Development Department
- **official_source_title:** Frequently Asked Zoning Questions
- **official_source_url:** https://www.phoenix.gov/content/dam/phoenix/pddsite/documents/planning-zoning-pz/pdd_pz_pdf_00006.pdf
- **requirement_category:** Zoning/Home Occupation
- **requirement_summary:** Home occupations permitted in residential districts with restrictions: no outside employees, no exterior signage, no odor/dust/noise/vibration beyond lot boundary, no business activity 10 PM - 7 AM, max 25% of roofed area for business
- **whether_required:** Yes (restrictions apply)
- **notes:** Prohibited home occupations include: barber shops/salons, vet offices, dog grooming, massage parlors, restaurants
- **evidence_strength:** High

#### Certificate of Occupancy
- **jurisdiction_type:** City
- **jurisdiction_name:** Phoenix
- **state:** AZ
- **agency_name:** City of Phoenix Planning and Development Department
- **official_source_title:** Certificate of Occupancy
- **official_source_url:** https://www.phoenix.gov/administration/departments/pdd/residential-building/resident-plan-reviews/certificate-of-occupancy.html
- **requirement_category:** Certificate of Occupancy
- **requirement_summary:** Certificate of Occupancy may be required for certain uses; contact PDD Ombudsman at pdd.ombudsman@phoenix.gov
- **whether_required:** Depends on use
- **notes:** Submit Public Records Request to determine if CofO exists for property
- **evidence_strength:** Medium

#### Transaction Privilege Tax License
- **jurisdiction_type:** City
- **jurisdiction_name:** Phoenix
- **state:** AZ
- **agency_name:** City of Phoenix Finance Department
- **official_source_title:** Transaction Privilege and Use Tax Licenses
- **official_source_url:** https://www.phoenix.gov/administration/departments/finance/privilege-sales-use-tax/privilege-tax-license.html
- **requirement_category:** Tax Registration
- **requirement_summary:** TPT license required for certain business activities; $50 license fee; renewal due January 1
- **whether_required:** Depends on business activities
- **notes:** Contact: tax@phoenix.gov or 602-262-6785; centralized through Arizona Department of Revenue
- **evidence_strength:** High

### Requirements NOT Found:
- No specific fire inspection requirements found for home healthcare
- No specific local health permit found for home healthcare (state regulated)
- No specific employer registration found beyond state/federal

---

## 6. PHILADELPHIA, PA

### Summary
Philadelphia requires a Commercial Activity License for all businesses operating in the city. Home healthcare businesses must comply with city licensing and tax requirements.

### Requirements Found:

#### Commercial Activity License
- **jurisdiction_type:** City
- **jurisdiction_name:** Philadelphia
- **state:** PA
- **agency_name:** Philadelphia Department of Licenses and Inspections (L&I)
- **official_source_title:** Register a business
- **official_source_url:** https://www.phila.gov/services/business-self-employment/register-a-business/
- **requirement_category:** Business License
- **requirement_summary:** All businesses operating in Philadelphia must apply for Commercial Activity License (CAL); requires City business tax account number
- **whether_required:** Yes
- **notes:** Apply through eCLIPSE system; must have Philadelphia Tax Account ID
- **evidence_strength:** High

#### Business Licensing Portal
- **jurisdiction_type:** City
- **jurisdiction_name:** Philadelphia
- **state:** PA
- **agency_name:** Philadelphia Department of Licenses and Inspections
- **official_source_title:** Use eCLIPSE to apply for licenses
- **official_source_url:** https://www.phila.gov/services/permits-violations-licenses/get-a-license/use-eclipse-to-apply-for-licenses/
- **requirement_category:** Business License Application
- **requirement_summary:** eCLIPSE system used to apply for business licenses, pay for licenses, link to user profile
- **whether_required:** Yes
- **notes:** Must register for eCLIPSE account; must be current on all City taxes to renew
- **evidence_strength:** High

#### Mobile Medical Services Permit (if applicable)
- **jurisdiction_type:** City
- **jurisdiction_name:** Philadelphia
- **state:** PA
- **agency_name:** Philadelphia Department of Public Health
- **official_source_title:** Get a permit for mobile medical services
- **official_source_url:** https://www.phila.gov/services/permits-violations-licenses/apply-for-a-permit/permits-for-mobile-service-providers/get-a-permit-for-mobile-medical-services/
- **requirement_category:** Health Permit
- **requirement_summary:** Mobile medical services permit required for diagnosing, preventing, or treating diseases on/from a vehicle; supervised by healthcare practitioner
- **whether_required:** Only for mobile services
- **notes:** Valid for one year; submit new application annually; email health.mobilepermit@phila.gov
- **evidence_strength:** High

#### Zoning and Building Inspections
- **jurisdiction_type:** City
- **jurisdiction_name:** Philadelphia
- **state:** PA
- **agency_name:** Philadelphia Department of Licenses and Inspections
- **official_source_title:** Department of Licenses and Inspections Homepage
- **official_source_url:** https://www.phila.gov/departments/department-of-licenses-and-inspections/
- **requirement_category:** Zoning/Building Inspection
- **requirement_summary:** L&I inspects construction projects, higher-risk properties for fire codes; issues trade and business licenses
- **whether_required:** Depends on business type
- **notes:** Phone: 311 or (215) 686-8686
- **evidence_strength:** High

### Requirements NOT Found:
- No specific fire inspection requirements found for home healthcare businesses
- No specific home occupation restrictions found beyond general zoning
- No specific employer registration found beyond state/federal

---

## 7. SAN ANTONIO, TX

### Summary
San Antonio does not have a general business license requirement. Only specific business types require licenses or permits. The city has detailed home occupation regulations.

### Requirements Found:

#### No General Business License
- **jurisdiction_type:** City
- **jurisdiction_name:** San Antonio
- **state:** TX
- **agency_name:** City of San Antonio Economic Development Department
- **official_source_title:** Small Business Resource Guide
- **official_source_url:** http://www.sanantonio.gov/Portals/0/Files/EDD/Small-Business-Resource-Guide.pdf
- **requirement_category:** Business License
- **requirement_summary:** No "General Business License" requirement in San Antonio; type of permit/license needed based on specific business type
- **whether_required:** No
- **notes:** Small Business Liaison: (210) 207-3903; SBEDAinfo@sanantonio.gov
- **evidence_strength:** High

#### Home Occupation Regulations
- **jurisdiction_type:** City
- **jurisdiction_name:** San Antonio
- **state:** TX
- **agency_name:** City of San Antonio Development Services Department
- **official_source_title:** Small Business Resource Guide - Home Occupation
- **official_source_url:** http://www.sanantonio.gov/Portals/0/Files/EDD/Small-Business-Resource-Guide.pdf
- **requirement_category:** Home Occupation
- **requirement_summary:** Home occupation defined as activity for gain conducted as accessory use in dwelling unit. Restrictions: no altered appearance, no outdoor display/storage, no advertising signs (except nameplate under 1 sq ft), conducted solely by residents, max 25% of dwelling area, no accessory building use
- **whether_required:** Yes (restrictions apply)
- **notes:** No certificate of occupancy required for home occupation
- **evidence_strength:** High

#### Prohibited Home Occupations
- **jurisdiction_type:** City
- **jurisdiction_name:** San Antonio
- **state:** TX
- **agency_name:** City of San Antonio Development Services Department
- **official_source_title:** Small Business Resource Guide - Prohibited Uses
- **official_source_url:** http://www.sanantonio.gov/Portals/0/Files/EDD/Small-Business-Resource-Guide.pdf
- **requirement_category:** Home Occupation Restrictions
- **requirement_summary:** Prohibited: vehicle painting/repair, barber/beauty shops (without specific use permit), animal hospitals/kennels, restaurants/catering, furniture repair/upholstering, teaching classes to more than 2 students at once
- **whether_required:** Yes
- **notes:** Hospitals are listed as prohibited home occupation; home healthcare administrative office may qualify but not clinical services
- **evidence_strength:** High

#### Fire Inspections and Permits
- **jurisdiction_type:** City
- **jurisdiction_name:** San Antonio
- **state:** TX
- **agency_name:** San Antonio Fire Department Office of the Fire Marshal
- **official_source_title:** Small Business Resource Guide - Fire Inspections
- **official_source_url:** http://www.sanantonio.gov/Portals/0/Files/EDD/Small-Business-Resource-Guide.pdf
- **requirement_category:** Fire Inspection
- **requirement_summary:** Fire Marshal conducts inspections for new/existing buildings, reviews fire protection systems, enforces fire/building codes, issues permits for combustible materials
- **whether_required:** Depends on business type
- **notes:** Location: 1901 S. Alamo St.; Phone: (210) 207-8410
- **evidence_strength:** High

#### Business Name Registration (DBA)
- **jurisdiction_type:** County
- **jurisdiction_name:** Bexar County
- **state:** TX
- **agency_name:** Bexar County Clerk
- **official_source_title:** Small Business Resource Guide - Business Name Registration
- **official_source_url:** http://www.sanantonio.gov/Portals/0/Files/EDD/Small-Business-Resource-Guide.pdf
- **requirement_category:** Business Name Registration
- **requirement_summary:** Assumed Name Certificate (DBA) required for sole proprietorship/partnership for each name used; filed with county clerk
- **whether_required:** Yes
- **notes:** Bexar County Clerk: Paul Elizondo Tower, 101 W. Nueva St., Suite 120; (210) 335-2223
- **evidence_strength:** High

#### Care Facilities Permit
- **jurisdiction_type:** City
- **jurisdiction_name:** San Antonio
- **state:** TX
- **agency_name:** San Antonio Metropolitan Health District
- **official_source_title:** Small Business Resource Guide - Care Facilities Permit
- **official_source_url:** http://www.sanantonio.gov/Portals/0/Files/EDD/Small-Business-Resource-Guide.pdf
- **requirement_category:** Health Permit
- **requirement_summary:** Care Facilities Permit issued by Metropolitan Health District
- **whether_required:** Depends on facility type
- **notes:** Phone: (210) 207-0135; www.sanantonio.gov/health
- **evidence_strength:** Medium

### Requirements NOT Found:
- No specific local tax registration found beyond state requirements
- No specific employer registration found beyond state/federal

---

## 8. SAN DIEGO COUNTY, CA

### Summary
San Diego County and City of San Diego have business tax certificate requirements. Home healthcare businesses must comply with city business tax and county health requirements.

### Requirements Found:

#### Business Tax Certificate (City of San Diego)
- **jurisdiction_type:** City
- **jurisdiction_name:** San Diego
- **state:** CA
- **agency_name:** City of San Diego Office of the City Treasurer
- **official_source_title:** Apply for a Business Tax Certificate
- **official_source_url:** https://www.sandiego.gov/treasurer/taxesfees/btax/btaxhow
- **requirement_category:** Business Tax Certificate
- **requirement_summary:** All businesses operating in San Diego must obtain Business Tax Certificate; includes home-based businesses, self-employed, independent contractors
- **whether_required:** Yes
- **notes:** Fee: $34 for 12 employees or fewer; $125 + $5/employee for 13+; one-time $17 Zoning Use Clearance fee
- **evidence_strength:** High

#### Zoning Self-Certification
- **jurisdiction_type:** City
- **jurisdiction_name:** San Diego
- **state:** CA
- **agency_name:** City of San Diego Office of the City Treasurer
- **official_source_title:** Business Tax Frequently Asked Questions
- **official_source_url:** https://www.sandiego.gov/treasurer/taxesfees/btax/btaxfaq
- **requirement_category:** Zoning
- **requirement_summary:** Businesses must self-certify that business is allowed in zone where activity conducted; use Development Services Department Zoning Webpage
- **whether_required:** Yes
- **notes:** Certificate does not authorize illegal business or activities requiring other permits/licenses
- **evidence_strength:** High

#### Fire Inspection
- **jurisdiction_type:** City
- **jurisdiction_name:** San Diego
- **state:** CA
- **agency_name:** City of San Diego Fire Department
- **official_source_title:** 10 Key Steps to Starting a Business
- **official_source_url:** https://www.sandiego.gov/sites/default/files/10_key_steps_to_starting_a_business_2022_1.pdf
- **requirement_category:** Fire Inspection
- **requirement_summary:** Fire inspection and permit may be required depending on business type
- **whether_required:** Depends on business type
- **notes:** Contact City Fire Department for specific requirements
- **evidence_strength:** Low

#### Board and Care/Nursing Home Exemption
- **jurisdiction_type:** City
- **jurisdiction_name:** San Diego
- **state:** CA
- **agency_name:** City of San Diego Office of the City Treasurer
- **official_source_title:** Business Tax Exemptions
- **official_source_url:** https://www.sandiego.gov/treasurer/taxesfees/btax/btaxexemptions
- **requirement_category:** Business Tax Exemption
- **requirement_summary:** Residential/community care facility serving 6 or fewer persons exempt from business tax assessment; copy of state license required
- **whether_required:** Exemption available
- **notes:** Reference: Health and Safety Code Sections §1566.2 & §1567.8
- **evidence_strength:** High

#### County Environmental Health
- **jurisdiction_type:** County
- **jurisdiction_name:** San Diego County
- **state:** CA
- **agency_name:** San Diego County Department of Environmental Health and Quality (DEHQ)
- **official_source_title:** On-Line Services
- **official_source_url:** https://www.sandiegocounty.gov/content/sdc/deh/doing_business/on_line.html
- **requirement_category:** Health Permit
- **requirement_summary:** DEHQ offers various permits and online services; contact (858) 505-6700 or dehinbox@sdcounty.ca.gov
- **whether_required:** Depends on services provided
- **notes:** Home healthcare may not require county health permit
- **evidence_strength:** Low

### Requirements NOT Found:
- No specific San Diego County business license found (city handles business tax)
- No specific employer registration found beyond state/federal

---

## 9. DALLAS COUNTY, TX

### Summary
Dallas (in Dallas County) does not have a general business license requirement. Dallas County focuses on supplier registration for county contracts. Specific business activities may require permits.

### Requirements Found:

#### No General Business License (City of Dallas)
- **jurisdiction_type:** City
- **jurisdiction_name:** Dallas
- **state:** TX
- **agency_name:** City of Dallas
- **official_source_title:** Special Collections - Licenses & Liens
- **official_source_url:** https://dallascityhall.com/departments/waterutilities/special_collections/Pages/special_collections_licenses.aspx
- **requirement_category:** Business License
- **requirement_summary:** Dallas does not have general business license; only specific activities regulated (coin-operated machines, dance halls, precious metal vendors, sexually oriented businesses)
- **whether_required:** No
- **notes:** Home healthcare businesses generally do not require city business license
- **evidence_strength:** High

#### Assumed Name Registration (Dallas County)
- **jurisdiction_type:** County
- **jurisdiction_name:** Dallas County
- **state:** TX
- **agency_name:** Dallas County Clerk
- **official_source_title:** Recording Division - Assumed Names/DBA Procedures
- **official_source_url:** https://www.dallascounty.org/government/county-clerk/recording/assumed-names/assumed-names-procedures.php
- **requirement_category:** Business Name Registration
- **requirement_summary:** Assumed Name (DBA) filed with County Clerk; filing fee $23 + $0.50 per additional partner; $2 acknowledgment fee
- **whether_required:** Yes (for sole proprietorship/partnership using assumed name)
- **notes:** Walk-in or mail-in accepted; mail to: John F. Warren, County Clerk, Recording Division, 500 Elm Street STE. 2100, Dallas, Texas 75202
- **evidence_strength:** High

#### Fire Alarm Permit (if applicable)
- **jurisdiction_type:** City
- **jurisdiction_name:** Dallas
- **state:** TX
- **agency_name:** City of Dallas Sustainable Development and Construction - Building Inspection
- **official_source_title:** Fire Alarm FAQ
- **official_source_url:** https://dallascityhall.com/departments/sustainabledevelopment/buildinginspection/lists/fire%20alarm%20faq/allitems.aspx
- **requirement_category:** Fire Permit
- **requirement_summary:** Fire alarm plan review/permitting required for any change, addition, alteration, or replacement to fire alarm system
- **whether_required:** Only if installing/modifying fire alarm systems
- **notes:** Fees based on number of devices; range from $75 to $300
- **evidence_strength:** High

#### Supplier Registration (Dallas County)
- **jurisdiction_type:** County
- **jurisdiction_name:** Dallas County
- **state:** TX
- **agency_name:** Dallas County Purchasing
- **official_source_title:** Supplier Online Registration
- **official_source_url:** https://www.dallascounty.org/services/supplier-registration/
- **requirement_category:** Supplier Registration
- **requirement_summary:** Supplier registration required to do business with Dallas County; no cost to register
- **whether_required:** Only for county contracts
- **notes:** Requires W-9, sales tax permit if applicable, bank account info for direct deposit
- **evidence_strength:** High

### Requirements NOT Found:
- No general business license required in Dallas
- No specific zoning requirements found for home healthcare
- No specific local health permit found for home healthcare
- No specific employer registration found beyond state/federal

---

## 10. SAN JOSE, CA

### Summary
San Jose requires a Business Tax Certificate for all businesses operating in the city. Home healthcare businesses must comply with city business tax registration.

### Requirements Found:

#### Business Tax Certificate
- **jurisdiction_type:** City
- **jurisdiction_name:** San Jose
- **state:** CA
- **agency_name:** City of San Jose Finance Department
- **official_source_title:** Register for a business tax certificate
- **official_source_url:** https://www.sanjoseca.gov/business/register-business-or-rental
- **requirement_category:** Business Tax Certificate
- **requirement_summary:** Every person or company conducting business in San Jose must register for Business Tax Certificate; payment due within 90 days of starting business
- **whether_required:** Yes
- **notes:** Need: start date, Tax ID (FEIN/SSN/TIN), Driver's License, ownership info, business addresses, email
- **evidence_strength:** High

#### Getting Started in San Jose
- **jurisdiction_type:** City
- **jurisdiction_name:** San Jose
- **state:** CA
- **agency_name:** City of San Jose
- **official_source_title:** Getting Started in San Jose
- **official_source_url:** https://www.sanjoseca.gov/business/getting-started-in-san-jos
- **requirement_category:** Business Registration
- **requirement_summary:** Business registration available online; every person/company conducting business must register
- **whether_required:** Yes
- **notes:** Contact BusinessTax@sanjoseca.gov or (408) 535-7055
- **evidence_strength:** High

#### Residential Occupancy Permit
- **jurisdiction_type:** City
- **jurisdiction_name:** San Jose
- **state:** CA
- **agency_name:** City of San Jose Planning, Building & Code Enforcement
- **official_source_title:** Residential Occupancy Permit
- **official_source_url:** https://www.sanjoseca.gov/your-government/departments-offices/planning-building-code-enforcement/code-enforcement/multiple-housing-inspection-program/residential-occupancy-permit
- **requirement_category:** Occupancy Permit
- **requirement_summary:** Residential occupancy permit program for rental properties; fees based on tier system
- **whether_required:** For rental properties
- **notes:** May apply if business operates from rental property
- **evidence_strength:** Medium

### Requirements NOT Found:
- No specific zoning requirements found for home healthcare businesses
- No specific fire inspection requirements found for home healthcare
- No specific local health permit found for home healthcare (state regulated)
- No specific employer registration found beyond state/federal

---

## SUMMARY TABLE

| Jurisdiction | General Business License | Home Occupation Restrictions | Fire Inspection | Local Tax Registration | Local Health Permit |
|--------------|-------------------------|------------------------------|-----------------|----------------------|---------------------|
| New York City | No | Yes (25% or 500 sq ft) | Not Found | Not Found | Yes (worker health) |
| Los Angeles County | Yes (unincorporated) | Yes | May be required | Not Found | May be required |
| Chicago | Yes | Yes (medical prohibited) | May be required | Yes (Cook County) | Not Found |
| Houston/Harris County | No | Not Found | Not Found | Property Tax Rendition | Not Found |
| Phoenix/Maricopa County | No | Yes (25% max) | Not Found | Yes (TPT) | Not Found |
| Philadelphia | Yes (CAL) | Not Found | Not Found | Yes | Mobile only |
| San Antonio | No | Yes (hospitals prohibited) | May be required | Not Found | Care Facilities Permit |
| San Diego | Yes (Tax Certificate) | Yes (self-certify) | May be required | Yes | Not Found |
| Dallas | No | Not Found | Fire Alarm only | Not Found | Not Found |
| San Jose | Yes (Tax Certificate) | Not Found | Not Found | Yes | Not Found |

---

## KEY FINDINGS

1. **No jurisdiction requires a specific "home healthcare business license" at the local level.** Home healthcare is primarily regulated at the STATE level through state health departments.

2. **General Business License/Tax Certificate:**
   - Required: Chicago, Philadelphia, San Diego, San Jose, Los Angeles County (unincorporated)
   - Not Required: New York City, Houston, Phoenix, San Antonio, Dallas

3. **Home Occupation Restrictions:**
   - All jurisdictions that allow home-based businesses have restrictions
   - Most restrict home occupations to 25% of dwelling area
   - Chicago explicitly prohibits medical uses as home occupations
   - San Antonio explicitly prohibits hospitals as home occupations

4. **Fire Inspections:**
   - May be required for commercial locations
   - Generally not required for home-based businesses

5. **Local Health Permits:**
   - NYC requires health screenings for home care workers
   - Most home healthcare services are state-regulated, not locally

6. **Local Tax Registration:**
   - Varies by jurisdiction
   - Some cities have specific business taxes (San Diego, San Jose, Phoenix)

---

## IMPORTANT DISCLAIMERS

1. This research focuses ONLY on local (city/county) requirements. STATE licensing requirements for home healthcare agencies are separate and typically more extensive.

2. Home healthcare businesses MUST obtain appropriate state licenses (usually from state department of health) BEFORE operating.

3. Zoning compliance should always be verified with the local planning/zoning department before establishing a business location.

4. Requirements may change; always verify current requirements with official local government sources.

---

**Report Generated:** January 2025
**Sources:** Official city/county government websites only (.gov domains)
