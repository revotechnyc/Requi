// REQUI PWA Types

// User
export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  organizationId: string;
  role: 'admin' | 'compliance_officer' | 'analyst' | 'viewer';
}

// Organization
export interface Organization {
  id: string;
  name: string;
  type: 'provider' | 'mso' | 'payer';
  states: string[];
}

// Task
export interface Task {
  id: string;
  title: string;
  description?: string;
  status: 'pending' | 'in_progress' | 'complete' | 'overdue';
  priority: 'critical' | 'high' | 'medium' | 'low';
  dueDate: string;
  assignee?: User;
  requirementId?: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
}

// Requirement
export interface Requirement {
  id: string;
  description: string;
  category: 'HIPAA' | 'FWA' | 'Reporting' | 'Quality' | 'Claims' | 'General';
  source: 'federal' | 'state' | 'contract';
  priority: 'critical' | 'high' | 'medium' | 'low';
  obligationType: string;
  frequency?: string;
}

// Gap
export interface Gap {
  id: string;
  requirementId: string;
  type: 'missing' | 'partial' | 'untracked' | 'overdue';
  severity: 'critical' | 'high' | 'medium' | 'low';
  reason: string;
  recommendedAction: string;
}

// Score
export interface Score {
  compliance: number;
  risk: number;
  audit: number;
  updatedAt: string;
}

// AI Response
export interface AIResponse {
  answer: string;
  requirements: Requirement[];
  gaps: Gap[];
  tasks: Task[];
  riskScore: number;
  confidence: 'high' | 'medium' | 'low';
}

// Document
export interface Document {
  id: string;
  name: string;
  type: 'contract' | 'policy' | 'report';
  status: 'processing' | 'complete' | 'error';
  uploadedAt: string;
  size: number;
}

// PWA State
export interface PWAState {
  isInstallable: boolean;
  isInstalled: boolean;
  isStandalone: boolean;
}

// Navigation
export type NavTab = 'dashboard' | 'intelligence' | 'tasks' | 'profile';

// Onboarding
export interface OnboardingStep {
  id: number;
  title: string;
  description: string;
  fields: OnboardingField[];
}

export interface OnboardingField {
  name: string;
  label: string;
  type: 'text' | 'select' | 'multiselect';
  options?: string[];
  required: boolean;
}

// Pricing Plan
export interface PricingPlan {
  id: string;
  name: string;
  price: number;
  period: 'month' | 'year';
  description: string;
  features: string[];
  highlighted?: boolean;
  cta: string;
}
