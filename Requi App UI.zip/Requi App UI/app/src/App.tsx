import { useState, useEffect } from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';

// Pages
import Landing from './pages/Landing';
import Login from './pages/Login';
import Onboarding from './pages/Onboarding';
import Intelligence from './pages/Intelligence';
import Dashboard from './pages/Dashboard';
import Tasks from './pages/Tasks';
import TaskDetail from './pages/TaskDetail';
import Documents from './pages/Documents';
import Profile from './pages/Profile';
import Pricing from './pages/Pricing';
import Product from './pages/Product';
import Solutions from './pages/Solutions';
import Company from './pages/Company';
import Contact from './pages/Contact';
import Privacy from './pages/Privacy';
import Terms from './pages/Terms';

// Components
import BottomNav from './components/layout/BottomNav';
import InstallPrompt from './components/InstallPrompt';

// Hooks
import { useAuth } from './hooks/useAuth';

// Types
interface PageTransitionProps {
  children: React.ReactNode;
}

const PageTransition = ({ children }: PageTransitionProps) => (
  <motion.div
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -10 }}
    transition={{ duration: 0.25, ease: [0.25, 0.1, 0.25, 1] }}
    className="min-h-screen"
  >
    {children}
  </motion.div>
);

function App() {
  const { isAuthenticated, isLoading } = useAuth();
  const location = useLocation();
  const [showNav, setShowNav] = useState(false);

  // Show bottom nav only on main app pages
  useEffect(() => {
    const navRoutes = ['/intelligence', '/dashboard', '/tasks', '/documents', '/profile'];
    setShowNav(navRoutes.some(route => location.pathname.startsWith(route)));
  }, [location]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#F8F8F8] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#C3ACFF] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8F8F8] text-[#121212]">
      <AnimatePresence mode="wait">
        <Routes location={location} key={location.pathname}>
          {/* Public Routes */}
          <Route path="/" element={<PageTransition><Landing /></PageTransition>} />
          <Route path="/login" element={<PageTransition><Login /></PageTransition>} />
          <Route path="/pricing" element={<PageTransition><Pricing /></PageTransition>} />
          <Route path="/product" element={<PageTransition><Product /></PageTransition>} />
          <Route path="/solutions" element={<PageTransition><Solutions /></PageTransition>} />
          <Route path="/company" element={<PageTransition><Company /></PageTransition>} />
          <Route path="/contact" element={<PageTransition><Contact /></PageTransition>} />
          <Route path="/privacy" element={<PageTransition><Privacy /></PageTransition>} />
          <Route path="/terms" element={<PageTransition><Terms /></PageTransition>} />

          {/* Onboarding */}
          <Route 
            path="/onboarding" 
            element={
              isAuthenticated ? (
                <PageTransition><Onboarding /></PageTransition>
              ) : (
                <Navigate to="/login" replace />
              )
            } 
          />

          {/* Protected Routes */}
          <Route 
            path="/intelligence" 
            element={
              isAuthenticated ? (
                <PageTransition><Intelligence /></PageTransition>
              ) : (
                <Navigate to="/login" replace />
              )
            } 
          />
          <Route 
            path="/dashboard" 
            element={
              isAuthenticated ? (
                <PageTransition><Dashboard /></PageTransition>
              ) : (
                <Navigate to="/login" replace />
              )
            } 
          />
          <Route 
            path="/tasks" 
            element={
              isAuthenticated ? (
                <PageTransition><Tasks /></PageTransition>
              ) : (
                <Navigate to="/login" replace />
              )
            } 
          />
          <Route 
            path="/tasks/:id" 
            element={
              isAuthenticated ? (
                <PageTransition><TaskDetail /></PageTransition>
              ) : (
                <Navigate to="/login" replace />
              )
            } 
          />
          <Route 
            path="/documents" 
            element={
              isAuthenticated ? (
                <PageTransition><Documents /></PageTransition>
              ) : (
                <Navigate to="/login" replace />
              )
            } 
          />
          <Route 
            path="/profile" 
            element={
              isAuthenticated ? (
                <PageTransition><Profile /></PageTransition>
              ) : (
                <Navigate to="/login" replace />
              )
            } 
          />

          {/* Fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AnimatePresence>

      {/* Bottom Navigation */}
      {showNav && <BottomNav />}

      {/* PWA Install Prompt */}
      <InstallPrompt />
    </div>
  );
}

export default App;
