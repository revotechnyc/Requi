import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Brain, Shield, FileText, Zap, BarChart3, Users, ArrowRight } from 'lucide-react';
import MobileHeader from '@/components/layout/MobileHeader';

const FEATURES = [
  {
    icon: Brain,
    title: 'AI Contract Analysis',
    description: 'Upload any contract and our AI extracts compliance obligations, deadlines, and requirements instantly.',
  },
  {
    icon: Shield,
    title: 'Gap Detection',
    description: 'Automatically identify missing compliance elements before they become violations.',
  },
  {
    icon: FileText,
    title: 'Requirement Tracking',
    description: 'Every obligation from federal, state, and contractual sources in one place.',
  },
  {
    icon: Zap,
    title: 'Smart Task Generation',
    description: 'Convert gaps into actionable tasks with priorities and due dates automatically.',
  },
  {
    icon: BarChart3,
    title: 'Compliance Scoring',
    description: 'Real-time compliance, risk, and audit readiness scores at a glance.',
  },
  {
    icon: Users,
    title: 'Team Collaboration',
    description: 'Assign tasks, track progress, and collaborate with your compliance team.',
  },
];

export default function Product() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#0f0f23] pb-8">
      <MobileHeader showBack title="Product" />

      <div className="px-4 py-6">
        {/* Hero */}
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold text-white mb-3">
            Compliance, <span className="gradient-text">automated</span>
          </h1>
          <p className="text-gray-400">
            Everything you need to manage healthcare compliance in one platform
          </p>
        </div>

        {/* Features Grid */}
        <div className="space-y-4">
          {FEATURES.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-[#1a1a3e] border border-white/5 rounded-xl p-5"
            >
              <div className="w-12 h-12 rounded-xl bg-[#6366f1]/20 flex items-center justify-center mb-4">
                <feature.icon size={24} className="text-[#6366f1]" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">{feature.title}</h3>
              <p className="text-gray-400 text-sm leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="mt-10"
        >
          <button
            onClick={() => navigate('/login')}
            className="w-full py-4 bg-[#6366f1] text-white font-medium rounded-xl flex items-center justify-center gap-2"
          >
            Start Free Trial
            <ArrowRight size={18} />
          </button>
        </motion.div>
      </div>
    </div>
  );
}
