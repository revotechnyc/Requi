import { useState } from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle, Calendar, CheckCircle, FileText, ChevronRight, TrendingUp } from 'lucide-react';
import MobileHeader from '@/components/layout/MobileHeader';
import ScoreRing from '@/components/dashboard/ScoreRing';
import { useTasks } from '@/hooks/useTasks';
import type { Score } from '@/types';

// Mock score data
const MOCK_SCORE: Score = {
  compliance: 73,
  risk: 72,
  audit: 62,
  updatedAt: new Date().toISOString(),
};

// Mock insights
const INSIGHTS = [
  {
    id: 1,
    type: 'warning' as const,
    icon: AlertTriangle,
    message: '3 gaps need attention',
    action: 'View',
  },
  {
    id: 2,
    type: 'info' as const,
    icon: Calendar,
    message: '2 deadlines this week',
    action: 'See all',
  },
  {
    id: 3,
    type: 'success' as const,
    icon: CheckCircle,
    message: '5 tasks completed today',
    action: null,
  },
];

// Mock recent activity
const RECENT_ACTIVITY = [
  {
    id: 1,
    action: 'Contract uploaded',
    detail: 'Service Agreement 2026',
    time: '2h ago',
    icon: FileText,
  },
  {
    id: 2,
    action: 'Task completed',
    detail: 'HIPAA Training Module 1',
    time: '5h ago',
    icon: CheckCircle,
  },
  {
    id: 3,
    action: 'Gap resolved',
    detail: 'Privacy Policy Update',
    time: '1d ago',
    icon: TrendingUp,
  },
];

export default function Dashboard() {
  const { stats } = useTasks();
  const [score] = useState<Score>(MOCK_SCORE);

  return (
    <div className="min-h-screen bg-[#F8F8F8] pb-24">
      <MobileHeader showNotification />

      <div className="px-4 py-4 space-y-6">
        {/* Scores Section */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-[#121212]">Your Scores</h2>
            <span className="text-xs text-[#9CA3AF]">
              Updated {new Date(score.updatedAt).toLocaleDateString()}
            </span>
          </div>

          <div className="flex justify-around items-center">
            <ScoreRing score={score.compliance} label="Compliance" color="#10b981" />
            <ScoreRing score={score.risk} label="Risk" color="#ef4444" />
            <ScoreRing score={score.audit} label="Audit" color="#C3ACFF" />
          </div>
        </section>

        {/* Quick Stats */}
        <section className="grid grid-cols-2 gap-3">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white border border-gray-100 rounded-xl p-4"
          >
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg bg-red-100 flex items-center justify-center">
                <AlertTriangle size={16} className="text-red-500" />
              </div>
              <span className="text-2xl font-bold text-[#121212]">{stats.critical}</span>
            </div>
            <p className="text-xs text-[#6B7280]">Critical items</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white border border-gray-100 rounded-xl p-4"
          >
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg bg-orange-100 flex items-center justify-center">
                <Calendar size={16} className="text-orange-500" />
              </div>
              <span className="text-2xl font-bold text-[#121212]">{stats.overdue}</span>
            </div>
            <p className="text-xs text-[#6B7280]">Overdue tasks</p>
          </motion.div>
        </section>

        {/* Insights */}
        <section>
          <h2 className="text-lg font-semibold text-[#121212] mb-4">Insights</h2>
          <div className="space-y-3">
            {INSIGHTS.map((insight, i) => (
              <motion.div
                key={insight.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + i * 0.1 }}
                className="flex items-center gap-3 p-4 bg-white border border-gray-100 rounded-xl"
              >
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                  insight.type === 'warning' ? 'bg-red-100' :
                  insight.type === 'success' ? 'bg-green-100' : 'bg-blue-100'
                }`}>
                  <insight.icon size={18} className={
                    insight.type === 'warning' ? 'text-red-500' :
                    insight.type === 'success' ? 'text-green-500' : 'text-blue-500'
                  } />
                </div>
                <div className="flex-1">
                  <p className="text-sm text-[#121212]">{insight.message}</p>
                </div>
                {insight.action && (
                  <button className="text-xs text-[#A88BFF] font-medium flex items-center gap-1">
                    {insight.action}
                    <ChevronRight size={14} />
                  </button>
                )}
              </motion.div>
            ))}
          </div>
        </section>

        {/* Recent Activity */}
        <section>
          <h2 className="text-lg font-semibold text-[#121212] mb-4">Recent Activity</h2>
          <div className="space-y-3">
            {RECENT_ACTIVITY.map((activity, i) => (
              <motion.div
                key={activity.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 + i * 0.1 }}
                className="flex items-center gap-3 p-4 bg-white border border-gray-100 rounded-xl"
              >
                <div className="w-10 h-10 rounded-lg bg-gray-100 flex items-center justify-center">
                  <activity.icon size={18} className="text-[#6B7280]" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-[#121212]">{activity.action}</p>
                  <p className="text-xs text-[#6B7280] truncate">{activity.detail}</p>
                </div>
                <span className="text-xs text-[#9CA3AF] flex-shrink-0">{activity.time}</span>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Trend */}
        <section className="bg-gradient-to-r from-[#C3ACFF]/30 to-[#CBD5FF]/30 border border-[#C3ACFF]/40 rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#C3ACFF]/40 flex items-center justify-center">
              <TrendingUp size={18} className="text-[#A88BFF]" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-[#121212] font-medium">Compliance trending up</p>
              <p className="text-xs text-[#6B7280]">+5% from last month</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
