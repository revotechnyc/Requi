import { motion } from 'framer-motion';
import { Target, Users, Shield, Award } from 'lucide-react';
import MobileHeader from '@/components/layout/MobileHeader';

const VALUES = [
  {
    icon: Target,
    title: 'Mission',
    description: 'Make healthcare compliance simple, accessible, and stress-free for every organization.',
  },
  {
    icon: Shield,
    title: 'Security First',
    description: 'Enterprise-grade security with HIPAA compliance built into everything we do.',
  },
  {
    icon: Users,
    title: 'Customer Obsessed',
    description: 'We work hand-in-hand with compliance teams to build what they actually need.',
  },
  {
    icon: Award,
    title: 'Excellence',
    description: 'We hold ourselves to the highest standards because healthcare deserves nothing less.',
  },
];

const TEAM = [
  { name: 'Angelo Senat', role: 'CEO & Founder', initials: 'AS' },
  { name: 'Sarah Chen', role: 'Head of Product', initials: 'SC' },
  { name: 'Michael Torres', role: 'CTO', initials: 'MT' },
  { name: 'Emily Watson', role: 'Head of Compliance', initials: 'EW' },
];

export default function Company() {
  return (
    <div className="min-h-screen bg-[#0f0f23] pb-8">
      <MobileHeader showBack title="Company" />

      <div className="px-4 py-6">
        {/* Hero */}
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold text-white mb-3">
            Our <span className="gradient-text">Story</span>
          </h1>
          <p className="text-gray-400 leading-relaxed">
            REQUI was born from a simple observation: healthcare compliance is too complex, 
            too manual, and too stressful. We're changing that with AI.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mb-10">
          {[
            { value: '500+', label: 'Customers' },
            { value: '10M+', label: 'Tasks Managed' },
            { value: '99.9%', label: 'Uptime' },
          ].map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.1 }}
              className="bg-[#1a1a3e] border border-white/5 rounded-xl p-4 text-center"
            >
              <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
              <div className="text-xs text-gray-400">{stat.label}</div>
            </motion.div>
          ))}
        </div>

        {/* Values */}
        <div className="mb-10">
          <h2 className="text-xl font-bold text-white mb-4">Our Values</h2>
          <div className="space-y-3">
            {VALUES.map((value, i) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
                className="flex items-start gap-4 bg-[#1a1a3e] border border-white/5 rounded-xl p-4"
              >
                <div className="w-10 h-10 rounded-lg bg-[#6366f1]/20 flex items-center justify-center flex-shrink-0">
                  <value.icon size={20} className="text-[#6366f1]" />
                </div>
                <div>
                  <h3 className="text-white font-medium mb-1">{value.title}</h3>
                  <p className="text-gray-400 text-sm">{value.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Team */}
        <div>
          <h2 className="text-xl font-bold text-white mb-4">Leadership</h2>
          <div className="grid grid-cols-2 gap-3">
            {TEAM.map((member, i) => (
              <motion.div
                key={member.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 + i * 0.1 }}
                className="bg-[#1a1a3e] border border-white/5 rounded-xl p-4 text-center"
              >
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[#6366f1] to-[#8b5cf6] flex items-center justify-center mx-auto mb-3">
                  <span className="text-white font-bold">{member.initials}</span>
                </div>
                <h3 className="text-white font-medium text-sm">{member.name}</h3>
                <p className="text-gray-500 text-xs">{member.role}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
