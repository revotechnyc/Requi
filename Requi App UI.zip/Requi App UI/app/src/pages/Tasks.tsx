import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Filter, Plus, Search } from 'lucide-react';
import MobileHeader from '@/components/layout/MobileHeader';
import TaskCard from '@/components/tasks/TaskCard';
import { useTasks } from '@/hooks/useTasks';

const filters = [
  { id: 'all', label: 'All', count: null },
  { id: 'pending', label: 'To Do', count: null },
  { id: 'overdue', label: 'Overdue', count: null },
  { id: 'complete', label: 'Done', count: null },
] as const;

export default function Tasks() {
  const { tasks, filter, setFilter, completeTask, snoozeTask, stats } = useTasks();
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredTasks = tasks.filter(task =>
    searchQuery === '' ||
    task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    task.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const filterCounts = {
    all: stats.total,
    pending: stats.pending,
    overdue: stats.overdue,
    complete: stats.complete,
  };

  return (
    <div className="min-h-screen bg-[#F8F8F8] pb-24">
      <MobileHeader 
        title="Tasks" 
        showNotification
        rightAction={
          <button 
            onClick={() => setShowSearch(!showSearch)}
            className={`w-10 h-10 flex items-center justify-center rounded-xl transition-colors ${
              showSearch ? 'bg-[#C3ACFF] text-[#121212]' : 'bg-gray-100 text-[#6B7280]'
            }`}
          >
            <Search size={18} />
          </button>
        }
      />

      {/* Search bar */}
      <AnimatePresence>
        {showSearch && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="px-4 py-3 border-b border-gray-100">
              <div className="relative">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search tasks..."
                  autoFocus
                  className="w-full bg-white border border-gray-200 rounded-xl py-2.5 pl-10 pr-4 text-sm text-[#121212] placeholder-[#9CA3AF] focus:outline-none focus:border-[#C3ACFF]"
                />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Filter tabs */}
      <div className="px-4 py-3 border-b border-gray-100">
        <div className="flex gap-2 overflow-x-auto hide-scrollbar">
          {filters.map((f) => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                filter === f.id
                  ? 'bg-[#C3ACFF] text-[#121212]'
                  : 'bg-white text-[#6B7280] hover:bg-gray-50 border border-gray-200'
              }`}
            >
              {f.label}
              <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                filter === f.id ? 'bg-[#121212]/20' : 'bg-gray-100'
              }`}>
                {filterCounts[f.id]}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Task list */}
      <div className="px-4 py-4">
        {filteredTasks.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="w-16 h-16 rounded-2xl bg-gray-100 flex items-center justify-center mb-4">
              <Filter size={24} className="text-[#9CA3AF]" />
            </div>
            <h3 className="text-[#121212] font-medium mb-1">No tasks found</h3>
            <p className="text-sm text-[#6B7280]">
              {searchQuery ? 'Try a different search' : 'All caught up!'}
            </p>
          </div>
        ) : (
          <div className="space-y-1">
            {filteredTasks.map((task, i) => (
              <motion.div
                key={task.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <TaskCard
                  task={task}
                  onComplete={completeTask}
                  onSnooze={snoozeTask}
                />
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* FAB for new task */}
      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        whileTap={{ scale: 0.95 }}
        className="fixed bottom-24 right-4 w-14 h-14 bg-[#C3ACFF] rounded-full shadow-lg shadow-purple-200 flex items-center justify-center z-40"
      >
        <Plus size={24} className="text-[#121212]" />
      </motion.button>
    </div>
  );
}
