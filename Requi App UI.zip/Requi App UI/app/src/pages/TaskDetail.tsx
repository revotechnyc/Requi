import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Calendar, Tag, User, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import MobileHeader from '@/components/layout/MobileHeader';
import { useTasks } from '@/hooks/useTasks';

const priorityColors = {
  critical: 'text-red-500 bg-red-50 border-red-200',
  high: 'text-orange-500 bg-orange-50 border-orange-200',
  medium: 'text-yellow-600 bg-yellow-50 border-yellow-200',
  low: 'text-green-500 bg-green-50 border-green-200',
};

const statusConfig = {
  pending: { icon: Clock, label: 'To Do', color: 'text-gray-400' },
  'in_progress': { icon: Clock, label: 'In Progress', color: 'text-blue-500' },
  complete: { icon: CheckCircle, label: 'Complete', color: 'text-green-500' },
  overdue: { icon: AlertCircle, label: 'Overdue', color: 'text-red-500' },
};

export default function TaskDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getTaskById, completeTask } = useTasks();
  const task = getTaskById(id || '');

  if (!task) {
    return (
      <div className="min-h-screen bg-[#F8F8F8] flex flex-col">
        <MobileHeader showBack title="Task Not Found" />
        <div className="flex-1 flex flex-col items-center justify-center p-4">
          <div className="w-16 h-16 rounded-2xl bg-gray-100 flex items-center justify-center mb-4">
            <AlertCircle size={28} className="text-[#9CA3AF]" />
          </div>
          <h2 className="text-[#121212] font-medium mb-2">Task not found</h2>
          <button
            onClick={() => navigate('/tasks')}
            className="text-[#A88BFF] text-sm font-medium"
          >
            Back to tasks
          </button>
        </div>
      </div>
    );
  }

  const StatusIcon = statusConfig[task.status].icon;
  const isComplete = task.status === 'complete';

  const handleComplete = () => {
    completeTask(task.id);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  return (
    <div className="min-h-screen bg-[#F8F8F8] pb-8">
      <MobileHeader showBack title="Task Details" />

      <div className="px-4 py-4 space-y-4">
        {/* Status & Priority */}
        <div className="flex items-center gap-3">
          <span className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border ${priorityColors[task.priority]}`}>
            {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)} Priority
          </span>
          <span className={`flex items-center gap-1.5 text-sm ${statusConfig[task.status].color}`}>
            <StatusIcon size={16} />
            {statusConfig[task.status].label}
          </span>
        </div>

        {/* Title */}
        <h1 className={`text-2xl font-bold text-[#121212] ${isComplete ? 'line-through text-[#9CA3AF]' : ''}`}>
          {task.title}
        </h1>

        {/* Description */}
        {task.description && (
          <div className="bg-white border border-gray-100 rounded-xl p-4">
            <h3 className="text-sm font-medium text-[#6B7280] mb-2">Description</h3>
            <p className="text-[#121212] leading-relaxed">{task.description}</p>
          </div>
        )}

        {/* Details grid */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white border border-gray-100 rounded-xl p-4">
            <div className="flex items-center gap-2 text-[#6B7280] mb-1">
              <Calendar size={16} />
              <span className="text-xs">Due Date</span>
            </div>
            <p className={`text-sm font-medium ${task.status === 'overdue' ? 'text-red-500' : 'text-[#121212]'}`}>
              {formatDate(task.dueDate)}
            </p>
          </div>

          <div className="bg-white border border-gray-100 rounded-xl p-4">
            <div className="flex items-center gap-2 text-[#6B7280] mb-1">
              <User size={16} />
              <span className="text-xs">Assigned</span>
            </div>
            <p className="text-sm font-medium text-[#121212]">
              {task.assignee?.name || 'Unassigned'}
            </p>
          </div>
        </div>

        {/* Tags */}
        {task.tags.length > 0 && (
          <div className="bg-white border border-gray-100 rounded-xl p-4">
            <div className="flex items-center gap-2 text-[#6B7280] mb-3">
              <Tag size={16} />
              <span className="text-xs">Tags</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {task.tags.map((tag, i) => (
                <span
                  key={i}
                  className="px-3 py-1 bg-gray-100 text-[#6B7280] text-sm rounded-full"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Activity */}
        <div className="bg-white border border-gray-100 rounded-xl p-4">
          <h3 className="text-sm font-medium text-[#6B7280] mb-3">Activity</h3>
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-[#C3ACFF] mt-1.5" />
              <div>
                <p className="text-sm text-[#121212]">Task created</p>
                <p className="text-xs text-[#9CA3AF]">{formatDate(task.createdAt)}</p>
              </div>
            </div>
            {task.status !== 'pending' && (
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-blue-400 mt-1.5" />
                <div>
                  <p className="text-sm text-[#121212]">Status changed to {statusConfig[task.status].label}</p>
                  <p className="text-xs text-[#9CA3AF]">{formatDate(task.updatedAt)}</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="pt-4 space-y-3">
          {!isComplete && (
            <motion.button
              whileTap={{ scale: 0.98 }}
              onClick={handleComplete}
              className="w-full py-4 bg-[#C3ACFF] text-[#121212] font-medium rounded-xl flex items-center justify-center gap-2 active:bg-[#B8C5FF] transition-colors"
            >
              <CheckCircle size={20} />
              Mark Complete
            </motion.button>
          )}

          <div className="flex gap-3">
            <button className="flex-1 py-3 bg-white text-[#6B7280] font-medium rounded-xl border border-gray-200 active:bg-gray-50 transition-colors">
              Snooze
            </button>
            <button className="flex-1 py-3 bg-white text-[#6B7280] font-medium rounded-xl border border-gray-200 active:bg-gray-50 transition-colors">
              Reassign
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
