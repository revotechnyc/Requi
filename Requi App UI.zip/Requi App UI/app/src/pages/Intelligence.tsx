import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Paperclip, FileText, HelpCircle, BarChart3, Check, AlertCircle, Plus } from 'lucide-react';
import MobileHeader from '@/components/layout/MobileHeader';
import { useAIQuery } from '@/hooks/useAIQuery';
import type { Requirement, Gap, Task } from '@/types';

export default function Intelligence() {
  const [input, setInput] = useState('');
  const [hasInteracted, setHasInteracted] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const { query, isLoading, response } = useAIQuery();

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [response, isLoading]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    setHasInteracted(true);
    await query(input);
    setInput('');
  };

  const quickActions = [
    { icon: FileText, label: 'Upload', action: () => {} },
    { icon: HelpCircle, label: 'Ask', action: () => setInput('What do I need to report?') },
    { icon: BarChart3, label: 'Check', action: () => setInput('Show my compliance status') },
  ];

  return (
    <div className="min-h-screen bg-[#F8F8F8] flex flex-col">
      <MobileHeader showNotification />

      {/* Main content */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto px-4 pb-32 pt-4"
      >
        {!hasInteracted ? (
          // Welcome state
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center min-h-[60vh] text-center"
          >
            {/* AI Avatar */}
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#C3ACFF] to-[#CBD5FF] flex items-center justify-center mb-6 shadow-lg shadow-purple-200">
              <svg viewBox="0 0 24 24" className="w-10 h-10 text-[#121212]" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
              </svg>
            </div>

            <h1 className="text-2xl font-bold text-[#121212] mb-2">
              What can I help you with?
            </h1>
            <p className="text-[#6B7280] text-sm max-w-xs">
              Ask about compliance, upload contracts, or check your status
            </p>

            {/* Quick actions */}
            <div className="flex gap-3 mt-8">
              {quickActions.map((action, i) => (
                <motion.button
                  key={action.label}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  onClick={action.action}
                  className="flex flex-col items-center gap-2"
                >
                  <div className="w-14 h-14 rounded-xl bg-white border border-gray-200 flex items-center justify-center active:bg-gray-50 transition-colors">
                    <action.icon size={22} className="text-[#A88BFF]" />
                  </div>
                  <span className="text-xs text-[#6B7280]">{action.label}</span>
                </motion.button>
              ))}
            </div>
          </motion.div>
        ) : (
          // Chat state
          <AnimatePresence mode="wait">
            {isLoading ? (
              <motion.div
                key="loading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center justify-center py-20"
              >
                <div className="w-10 h-10 border-2 border-[#C3ACFF] border-t-transparent rounded-full animate-spin" />
                <p className="text-[#6B7280] text-sm mt-4">Analyzing...</p>
              </motion.div>
            ) : response ? (
              <motion.div
                key="response"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-4"
              >
                {/* Answer */}
                <div className="bg-white border border-gray-100 rounded-xl p-4">
                  <p className="text-[#121212] leading-relaxed">{response.answer}</p>
                </div>

                {/* Requirements */}
                {response.requirements.length > 0 && (
                  <div className="bg-white border border-gray-100 rounded-xl p-4">
                    <h3 className="text-sm font-semibold text-[#6B7280] mb-3 flex items-center gap-2">
                      <FileText size={16} className="text-[#A88BFF]" />
                      Requirements ({response.requirements.length})
                    </h3>
                    <div className="space-y-2">
                      {response.requirements.map((req, i) => (
                        <RequirementItem key={i} requirement={req} />
                      ))}
                    </div>
                  </div>
                )}

                {/* Gaps */}
                {response.gaps.length > 0 && (
                  <div className="bg-white border border-gray-100 rounded-xl p-4">
                    <h3 className="text-sm font-semibold text-[#6B7280] mb-3 flex items-center gap-2">
                      <AlertCircle size={16} className="text-red-500" />
                      Gaps ({response.gaps.length})
                    </h3>
                    <div className="space-y-2">
                      {response.gaps.map((gap, i) => (
                        <GapItem key={i} gap={gap} />
                      ))}
                    </div>
                  </div>
                )}

                {/* Tasks */}
                {response.tasks.length > 0 && (
                  <div className="bg-white border border-gray-100 rounded-xl p-4">
                    <h3 className="text-sm font-semibold text-[#6B7280] mb-3 flex items-center gap-2">
                      <Check size={16} className="text-green-500" />
                      Suggested Tasks ({response.tasks.length})
                    </h3>
                    <div className="space-y-2">
                      {response.tasks.map((task, i) => (
                        <TaskSuggestion key={i} task={task} />
                      ))}
                    </div>
                  </div>
                )}

                {/* Risk Score */}
                <div className="flex items-center justify-between bg-white border border-gray-100 rounded-xl p-4">
                  <span className="text-sm text-[#6B7280]">Risk Score</span>
                  <span className={`text-lg font-bold ${
                    response.riskScore > 75 ? 'text-red-500' :
                    response.riskScore > 50 ? 'text-orange-500' :
                    response.riskScore > 25 ? 'text-yellow-500' : 'text-green-500'
                  }`}>
                    {response.riskScore}/100
                  </span>
                </div>
              </motion.div>
            ) : null}
          </AnimatePresence>
        )}
      </div>

      {/* Input area */}
      <div className="fixed bottom-16 left-0 right-0 px-4 pb-4 safe-bottom">
        <form onSubmit={handleSubmit} className="relative">
          <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-2xl p-2 shadow-lg">
            <button
              type="button"
              className="w-10 h-10 flex items-center justify-center rounded-xl bg-gray-100 text-[#6B7280] hover:text-[#121212] transition-colors"
            >
              <Paperclip size={20} />
            </button>
            
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask anything..."
              className="flex-1 bg-transparent text-[#121212] placeholder-[#9CA3AF] text-sm py-2 focus:outline-none"
            />
            
            <button
              type="submit"
              disabled={!input.trim() || isLoading}
              className="w-10 h-10 flex items-center justify-center rounded-xl bg-[#C3ACFF] text-[#121212] disabled:opacity-50 disabled:cursor-not-allowed active:scale-95 transition-transform"
            >
              <Send size={18} />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// Sub-components
function RequirementItem({ requirement }: { requirement: Requirement }) {
  const categoryColors: Record<string, string> = {
    HIPAA: 'text-purple-500',
    FWA: 'text-red-500',
    Reporting: 'text-blue-500',
    Quality: 'text-green-500',
    Claims: 'text-yellow-500',
    General: 'text-gray-500',
  };

  return (
    <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
      <span className={`text-xs font-medium ${categoryColors[requirement.category] || 'text-gray-500'}`}>
        {requirement.category}
      </span>
      <p className="text-sm text-[#6B7280] flex-1">{requirement.description}</p>
    </div>
  );
}

function GapItem({ gap }: { gap: Gap }) {
  const severityColors = {
    critical: 'text-red-500 border-red-200 bg-red-50',
    high: 'text-orange-500 border-orange-200 bg-orange-50',
    medium: 'text-yellow-500 border-yellow-200 bg-yellow-50',
    low: 'text-green-500 border-green-200 bg-green-50',
  };

  return (
    <div className={`p-3 rounded-lg border ${severityColors[gap.severity]}`}>
      <div className="flex items-center gap-2 mb-1">
        <AlertCircle size={14} />
        <span className="text-xs font-medium uppercase">{gap.type}</span>
      </div>
      <p className="text-sm text-[#6B7280]">{gap.reason}</p>
      <p className="text-xs text-[#9CA3AF] mt-1">{gap.recommendedAction}</p>
    </div>
  );
}

function TaskSuggestion({ task }: { task: Task }) {
  return (
    <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
      <div className="w-8 h-8 rounded-lg bg-[#C3ACFF]/30 flex items-center justify-center flex-shrink-0">
        <Plus size={16} className="text-[#A88BFF]" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm text-[#121212] truncate">{task.title}</p>
        <p className="text-xs text-[#6B7280]">{task.description}</p>
      </div>
      <button className="px-3 py-1.5 bg-[#C3ACFF] text-[#121212] text-xs font-medium rounded-lg active:scale-95 transition-transform">
        Add
      </button>
    </div>
  );
}
