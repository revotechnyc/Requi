import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Building2, HeartPulse, Stethoscope, ArrowRight, Check } from 'lucide-react';
import MobileHeader from '@/components/layout/MobileHeader';

const SOLUTIONS = [
  {
    icon: Building2,
    title: 'Health Systems',
    description: 'Enterprise-grade compliance for large healthcare organizations with complex regulatory requirements.',
    features: ['Multi-entity support', 'Custom integrations', 'Dedicated success manager'],
  },
  {
    icon: HeartPulse,
    title: 'Health Plans',
    description: 'Stay compliant with CMS, state Medicaid, and commercial payer requirements.',
    features: ['CMS reporting', 'State compliance', 'Risk adjustment'],
  },
  {
    icon: Stethoscope,
    title: 'Provider Groups',
    description: 'Simplify compliance for medical practices, clinics, and specialty groups.',
    features: ['HIPAA compliance', 'Quality reporting', 'Staff training'],
  },
];

export default function Solutions() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#0f0f23] pb-8">
      <MobileHeader showBack title="Solutions" />

      <div className="px-4 py-6">
        {/* Header */}
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold text-white mb-3">
            Built for <span className="gradient-text">healthcare</span>
          </h1>
          <p className="text-gray-400">
            Tailored solutions for every type of healthcare organization
          </p>
        </div>

        {/* Solutions */}
        <div className="space-y-4">
          {SOLUTIONS.map((solution, i) => (
            <motion.div
              key={solution.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-[#1a1a3e] border border-white/5 rounded-xl p-5"
            >
              <div className="w-12 h-12 rounded-xl bg-[#6366f1]/20 flex items-center justify-center mb-4">
                <solution.icon size={24} className="text-[#6366f1]" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">{solution.title}</h3>
              <p className="text-gray-400 text-sm mb-4">{solution.description}</p>
              
              <ul className="space-y-2">
                {solution.features.map((feature, j) => (
                  <li key={j} className="flex items-center gap-2 text-sm text-gray-300">
                    <Check size={14} className="text-[#6366f1]" />
                    {feature}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mt-10 bg-gradient-to-br from-[#6366f1]/20 to-[#8b5cf6]/20 border border-[#6366f1]/30 rounded-2xl p-6 text-center"
        >
          <h3 className="text-xl font-bold text-white mb-2">Not sure which fits?</h3>
          <p className="text-gray-400 text-sm mb-4">Our team can help you find the right solution</p>
          <button
            onClick={() => navigate('/contact')}
            className="w-full py-3 bg-[#6366f1] text-white font-medium rounded-xl flex items-center justify-center gap-2"
          >
            Talk to Sales
            <ArrowRight size={18} />
          </button>
        </motion.div>
      </div>
    </div>
  );
}
