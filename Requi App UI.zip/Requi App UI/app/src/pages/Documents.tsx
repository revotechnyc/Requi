import { useState } from 'react';
import { motion } from 'framer-motion';
import { Upload, FileText, MoreVertical, Search, X } from 'lucide-react';
import MobileHeader from '@/components/layout/MobileHeader';
import type { Document } from '@/types';

const MOCK_DOCUMENTS: Document[] = [
  {
    id: 'doc-1',
    name: 'Service Agreement 2026.pdf',
    type: 'contract',
    status: 'complete',
    uploadedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    size: 2457600,
  },
  {
    id: 'doc-2',
    name: 'HIPAA Policy v3.pdf',
    type: 'policy',
    status: 'complete',
    uploadedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    size: 1024000,
  },
  {
    id: 'doc-3',
    name: 'Q1 Compliance Report.pdf',
    type: 'report',
    status: 'processing',
    uploadedAt: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
    size: 5120000,
  },
  {
    id: 'doc-4',
    name: 'Medicaid Contract.pdf',
    type: 'contract',
    status: 'complete',
    uploadedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
    size: 1892000,
  },
];

const formatFileSize = (bytes: number) => {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
};

const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  const now = new Date();
  const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
  
  if (diffDays === 0) return 'Today';
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return `${diffDays} days ago`;
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
};

export default function Documents() {
  const [documents] = useState<Document[]>(MOCK_DOCUMENTS);
  const [searchQuery, setSearchQuery] = useState('');
  const [showUpload, setShowUpload] = useState(false);

  const filteredDocs = documents.filter(doc =>
    doc.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleUpload = () => {
    setShowUpload(true);
    setTimeout(() => setShowUpload(false), 2000);
  };

  return (
    <div className="min-h-screen bg-[#F8F8F8] pb-24">
      <MobileHeader 
        title="Documents" 
        showNotification
        rightAction={
          <button 
            onClick={handleUpload}
            className="w-10 h-10 flex items-center justify-center rounded-xl bg-[#C3ACFF] text-[#121212]"
          >
            <Upload size={18} />
          </button>
        }
      />

      {/* Upload overlay */}
      {showUpload && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center"
        >
          <div className="text-center bg-white rounded-2xl p-8">
            <div className="w-16 h-16 border-2 border-[#C3ACFF] border-t-transparent rounded-full animate-spin mx-auto mb-4" />
            <p className="text-[#121212]">Uploading...</p>
          </div>
        </motion.div>
      )}

      <div className="px-4 py-4">
        {/* Search */}
        <div className="relative mb-4">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search documents..."
            className="w-full bg-white border border-gray-200 rounded-xl py-3 pl-10 pr-10 text-sm text-[#121212] placeholder-[#9CA3AF] focus:outline-none focus:border-[#C3ACFF]"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]"
            >
              <X size={16} />
            </button>
          )}
        </div>

        {/* Document list */}
        <div className="space-y-3">
          {filteredDocs.map((doc, i) => (
            <motion.div
              key={doc.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="bg-white border border-gray-100 rounded-xl p-4"
            >
              <div className="flex items-center gap-3">
                {/* Icon */}
                <div className="w-12 h-12 rounded-xl bg-[#C3ACFF]/30 flex items-center justify-center flex-shrink-0">
                  <FileText size={24} className="text-[#A88BFF]" />
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <h3 className="text-[#121212] font-medium truncate">{doc.name}</h3>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="text-xs text-[#9CA3AF]">{formatFileSize(doc.size)}</span>
                    <span className="text-xs text-[#9CA3AF]">{formatDate(doc.uploadedAt)}</span>
                    {doc.status === 'processing' && (
                      <span className="text-xs text-[#A88BFF]">Processing...</span>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <button className="w-8 h-8 flex items-center justify-center text-[#9CA3AF]">
                  <MoreVertical size={18} />
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        {filteredDocs.length === 0 && (
          <div className="text-center py-16">
            <div className="w-16 h-16 rounded-2xl bg-gray-100 flex items-center justify-center mx-auto mb-4">
              <FileText size={28} className="text-[#9CA3AF]" />
            </div>
            <h3 className="text-[#121212] font-medium mb-1">No documents found</h3>
            <p className="text-[#6B7280] text-sm">Upload your first document to get started</p>
          </div>
        )}

        {/* Upload hint */}
        <div className="mt-6 p-4 bg-gradient-to-br from-[#C3ACFF]/20 to-[#CBD5FF]/20 border border-[#C3ACFF]/30 rounded-xl">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#C3ACFF]/30 flex items-center justify-center flex-shrink-0">
              <Upload size={20} className="text-[#A88BFF]" />
            </div>
            <div>
              <h3 className="text-[#121212] font-medium mb-1">Upload contracts</h3>
              <p className="text-[#6B7280] text-sm">
                Our AI will analyze your documents and extract compliance requirements automatically.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
