import { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { 
  User, Building2, Bell, Shield, HelpCircle, 
  ChevronRight, LogOut, Moon, Smartphone 
} from 'lucide-react';
import MobileHeader from '@/components/layout/MobileHeader';
import { useAuth } from '@/hooks/useAuth';

const MENU_ITEMS = [
  { id: 'account', icon: User, label: 'Account Settings', path: '/profile/account' },
  { id: 'notifications', icon: Bell, label: 'Notifications', path: '/profile/notifications' },
  { id: 'security', icon: Shield, label: 'Security', path: '/profile/security' },
  { id: 'help', icon: HelpCircle, label: 'Help & Support', path: '/contact' },
];

export default function Profile() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [darkMode, setDarkMode] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-[#F8F8F8] pb-8">
      <MobileHeader title="Profile" />

      <div className="px-4 py-4">
        {/* User Card */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-br from-[#C3ACFF]/30 to-[#CBD5FF]/30 border border-[#C3ACFF]/40 rounded-2xl p-6 mb-6"
        >
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#C3ACFF] to-[#CBD5FF] flex items-center justify-center">
              <span className="text-[#121212] font-bold text-xl">
                {user?.name.split(' ').map(n => n[0]).join('')}
              </span>
            </div>
            <div>
              <h2 className="text-xl font-bold text-[#121212]">{user?.name}</h2>
              <p className="text-[#6B7280] text-sm">{user?.email}</p>
              <span className="inline-block mt-1 px-2 py-0.5 bg-[#C3ACFF]/30 rounded text-xs text-[#6B7280]">
                {user?.role.replace('_', ' ')}
              </span>
            </div>
          </div>
        </motion.div>

        {/* Organization */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white border border-gray-100 rounded-xl p-4 mb-6"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#C3ACFF]/30 flex items-center justify-center">
              <Building2 size={20} className="text-[#A88BFF]" />
            </div>
            <div className="flex-1">
              <p className="text-xs text-[#9CA3AF]">Organization</p>
              <p className="text-[#121212] font-medium">Acme Healthcare</p>
            </div>
            <ChevronRight size={18} className="text-[#9CA3AF]" />
          </div>
        </motion.div>

        {/* Settings */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-6"
        >
          <h3 className="text-sm font-medium text-[#6B7280] mb-3">Settings</h3>
          <div className="bg-white border border-gray-100 rounded-xl overflow-hidden">
            {MENU_ITEMS.map((item, i) => (
              <button
                key={item.id}
                onClick={() => navigate(item.path)}
                className={`w-full flex items-center gap-3 p-4 hover:bg-gray-50 transition-colors ${
                  i !== MENU_ITEMS.length - 1 ? 'border-b border-gray-100' : ''
                }`}
              >
                <div className="w-10 h-10 rounded-lg bg-gray-100 flex items-center justify-center">
                  <item.icon size={18} className="text-[#6B7280]" />
                </div>
                <span className="flex-1 text-left text-[#121212]">{item.label}</span>
                <ChevronRight size={18} className="text-[#9CA3AF]" />
              </button>
            ))}
          </div>
        </motion.div>

        {/* Preferences */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-6"
        >
          <h3 className="text-sm font-medium text-[#6B7280] mb-3">Preferences</h3>
          <div className="bg-white border border-gray-100 rounded-xl overflow-hidden">
            {/* Dark Mode */}
            <div className="flex items-center justify-between p-4 border-b border-gray-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-gray-100 flex items-center justify-center">
                  <Moon size={18} className="text-[#6B7280]" />
                </div>
                <span className="text-[#121212]">Dark Mode</span>
              </div>
              <button
                onClick={() => setDarkMode(!darkMode)}
                className={`w-12 h-6 rounded-full transition-colors relative ${
                  darkMode ? 'bg-[#C3ACFF]' : 'bg-gray-300'
                }`}
              >
                <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform ${
                  darkMode ? 'left-7' : 'left-1'
                }`} />
              </button>
            </div>

            {/* App Version */}
            <div className="flex items-center justify-between p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-gray-100 flex items-center justify-center">
                  <Smartphone size={18} className="text-[#6B7280]" />
                </div>
                <span className="text-[#121212]">App Version</span>
              </div>
              <span className="text-[#9CA3AF] text-sm">1.0.0</span>
            </div>
          </div>
        </motion.div>

        {/* Logout */}
        <motion.button
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          onClick={handleLogout}
          className="w-full flex items-center justify-center gap-2 p-4 bg-red-50 border border-red-100 rounded-xl text-red-500 font-medium"
        >
          <LogOut size={18} />
          Sign Out
        </motion.button>
      </div>
    </div>
  );
}
