import { useState } from 'react';
import { Search } from 'lucide-react';
import MobileHeader from '@/components/layout/MobileHeader';

const SECTIONS = [
  {
    id: 'acceptance',
    title: 'Acceptance of Terms',
    content: `By accessing or using REQUI's services, you agree to be bound by these Terms of Service. 
    If you do not agree to these terms, you may not access or use our services.
    
    You must be at least 18 years old and have the authority to bind your organization to these terms.`,
  },
  {
    id: 'account',
    title: 'Account Registration',
    content: `To use our services, you must create an account. You agree to:
    • Provide accurate and complete information
    • Keep your password secure
    • Notify us immediately of any unauthorized access
    • Be responsible for all activity under your account
    
    We reserve the right to suspend or terminate accounts that violate these terms.`,
  },
  {
    id: 'use',
    title: 'Acceptable Use',
    content: `You agree not to:
    • Use our services for any illegal purpose
    • Upload malicious software or content
    • Attempt to gain unauthorized access to our systems
    • Interfere with other users' access to the service
    • Reverse engineer or decompile our software
    
    You are responsible for all content you upload to our platform.`,
  },
  {
    id: 'payment',
    title: 'Payment Terms',
    content: `Subscription fees are billed in advance on a monthly or annual basis. 
    
    • Payments are non-refundable except as required by law
    • We may change pricing with 30 days notice
    • Failed payments may result in service suspension
    • You are responsible for all applicable taxes`,
  },
  {
    id: 'ip',
    title: 'Intellectual Property',
    content: `REQUI retains all rights to our software, trademarks, and content. 
    
    You retain ownership of content you upload, but grant us a license to use it solely 
    to provide our services to you. We will not use your content to train AI models without 
    your explicit consent.`,
  },
  {
    id: 'termination',
    title: 'Termination',
    content: `You may cancel your subscription at any time. Upon cancellation:
    • Your access will continue until the end of your billing period
    • We may retain your data for a reasonable period
    • You may request deletion of your data
    
    We may terminate your access for violations of these terms.`,
  },
  {
    id: 'warranty',
    title: 'Disclaimer of Warranties',
    content: `Our services are provided "as is" without warranties of any kind. We do not guarantee:
    • That the service will be uninterrupted or error-free
    • That defects will be corrected
    • That the service is free of viruses or harmful components
    
    You use our services at your own risk.`,
  },
  {
    id: 'liability',
    title: 'Limitation of Liability',
    content: `To the maximum extent permitted by law, REQUI shall not be liable for:
    • Indirect, incidental, or consequential damages
    • Loss of profits, data, or goodwill
    • Damages exceeding the amount you paid in the 12 months prior
    
    Some jurisdictions do not allow these limitations.`,
  },
  {
    id: 'changes',
    title: 'Changes to Terms',
    content: `We may modify these terms at any time. We will notify you of material changes via email 
    or through our platform. Your continued use after changes constitutes acceptance.`,
  },
  {
    id: 'contact',
    title: 'Contact Information',
    content: `Questions about these terms? Contact us:
    
    Email: legal@requi.com
    Address: REQUI Inc., 123 Compliance Street, San Francisco, CA 94105`,
  },
];

export default function Terms() {
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedSection, setExpandedSection] = useState<string | null>('acceptance');

  const filteredSections = SECTIONS.filter(section =>
    section.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    section.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#0f0f23] pb-8">
      <MobileHeader showBack title="Terms of Service" />

      <div className="px-4 py-6">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-white mb-2">Terms of Service</h1>
          <p className="text-gray-400 text-sm">Last updated: April 16, 2026</p>
        </div>

        {/* Search */}
        <div className="relative mb-6">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search this document..."
            className="w-full bg-[#1a1a3e] border border-white/10 rounded-xl py-3 pl-10 pr-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#6366f1]"
          />
        </div>

        {/* Table of Contents */}
        {!searchQuery && (
          <div className="mb-6">
            <h2 className="text-sm font-medium text-gray-400 mb-3">Contents</h2>
            <div className="flex flex-wrap gap-2">
              {SECTIONS.map((section) => (
                <button
                  key={section.id}
                  onClick={() => setExpandedSection(section.id)}
                  className={`px-3 py-1.5 text-xs rounded-full border transition-colors ${
                    expandedSection === section.id
                      ? 'bg-[#6366f1]/20 border-[#6366f1] text-white'
                      : 'bg-white/5 border-white/10 text-gray-400 hover:bg-white/10'
                  }`}
                >
                  {section.title}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Sections */}
        <div className="space-y-3">
          {filteredSections.map((section) => (
            <div
              key={section.id}
              className="bg-[#1a1a3e] border border-white/5 rounded-xl overflow-hidden"
            >
              <button
                onClick={() => setExpandedSection(expandedSection === section.id ? null : section.id)}
                className="w-full flex items-center justify-between p-4 text-left"
              >
                <h3 className="font-medium text-white">{section.title}</h3>
                <span className="text-gray-500">
                  {expandedSection === section.id ? '−' : '+'}
                </span>
              </button>
              
              {expandedSection === section.id && (
                <div className="px-4 pb-4">
                  <div className="pt-2 border-t border-white/5">
                    <p className="text-gray-400 text-sm whitespace-pre-line leading-relaxed">
                      {section.content}
                    </p>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {filteredSections.length === 0 && (
          <div className="text-center py-8">
            <p className="text-gray-500">No results found</p>
          </div>
        )}
      </div>
    </div>
  );
}
