import { useState } from 'react';
// import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Send, CheckCircle } from 'lucide-react';
import MobileHeader from '@/components/layout/MobileHeader';

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-[#0f0f23]">
        <MobileHeader showBack title="Contact" />
        <div className="flex flex-col items-center justify-center px-4 py-20 text-center">
          <div className="w-20 h-20 rounded-full bg-green-500/20 flex items-center justify-center mb-6">
            <CheckCircle size={40} className="text-green-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Message sent!</h2>
          <p className="text-gray-400">We'll get back to you within 24 hours</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0f0f23] pb-8">
      <MobileHeader showBack title="Contact" />

      <div className="px-4 py-6">
        {/* Contact Info */}
        <div className="space-y-4 mb-8">
          <div className="flex items-center gap-4 bg-[#1a1a3e] border border-white/5 rounded-xl p-4">
            <div className="w-10 h-10 rounded-lg bg-[#6366f1]/20 flex items-center justify-center">
              <Mail size={20} className="text-[#6366f1]" />
            </div>
            <div>
              <p className="text-xs text-gray-400">Email</p>
              <p className="text-white">hello@requi.com</p>
            </div>
          </div>

          <div className="flex items-center gap-4 bg-[#1a1a3e] border border-white/5 rounded-xl p-4">
            <div className="w-10 h-10 rounded-lg bg-[#6366f1]/20 flex items-center justify-center">
              <Phone size={20} className="text-[#6366f1]" />
            </div>
            <div>
              <p className="text-xs text-gray-400">Phone</p>
              <p className="text-white">1-800-REQUI-01</p>
            </div>
          </div>

          <div className="flex items-center gap-4 bg-[#1a1a3e] border border-white/5 rounded-xl p-4">
            <div className="w-10 h-10 rounded-lg bg-[#6366f1]/20 flex items-center justify-center">
              <MapPin size={20} className="text-[#6366f1]" />
            </div>
            <div>
              <p className="text-xs text-gray-400">Office</p>
              <p className="text-white">San Francisco, CA</p>
            </div>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm text-gray-400 mb-2">Name</label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full bg-[#1a1a3e] border border-white/10 rounded-xl py-3.5 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#6366f1]"
              placeholder="Your name"
            />
          </div>

          <div>
            <label className="block text-sm text-gray-400 mb-2">Email</label>
            <input
              type="email"
              required
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full bg-[#1a1a3e] border border-white/10 rounded-xl py-3.5 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#6366f1]"
              placeholder="you@company.com"
            />
          </div>

          <div>
            <label className="block text-sm text-gray-400 mb-2">Company</label>
            <input
              type="text"
              value={formData.company}
              onChange={(e) => setFormData({ ...formData, company: e.target.value })}
              className="w-full bg-[#1a1a3e] border border-white/10 rounded-xl py-3.5 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#6366f1]"
              placeholder="Your organization"
            />
          </div>

          <div>
            <label className="block text-sm text-gray-400 mb-2">Message</label>
            <textarea
              required
              rows={4}
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              className="w-full bg-[#1a1a3e] border border-white/10 rounded-xl py-3.5 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#6366f1] resize-none"
              placeholder="How can we help?"
            />
          </div>

          <button
            type="submit"
            className="w-full py-4 bg-[#6366f1] text-white font-medium rounded-xl flex items-center justify-center gap-2"
          >
            <Send size={18} />
            Send Message
          </button>
        </form>
      </div>
    </div>
  );
}
