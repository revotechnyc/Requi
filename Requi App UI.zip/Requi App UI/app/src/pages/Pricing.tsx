import { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Check, ArrowRight, Sparkles } from 'lucide-react';
import MobileHeader from '@/components/layout/MobileHeader';

const PLANS = [
  {
    id: 'starter',
    name: 'Starter',
    description: 'For small teams getting started',
    monthlyPrice: 99,
    yearlyPrice: 79,
    features: [
      'Up to 50 users',
      'Basic AI queries',
      'Task management',
      'Email support',
      'Standard reporting',
    ],
    cta: 'Start Free Trial',
    highlighted: false,
  },
  {
    id: 'professional',
    name: 'Professional',
    description: 'For growing organizations',
    monthlyPrice: 299,
    yearlyPrice: 239,
    features: [
      'Unlimited users',
      'Advanced AI analysis',
      'CLM integrations',
      'Priority support',
      'Custom reporting',
      'API access',
    ],
    cta: 'Start Free Trial',
    highlighted: true,
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    description: 'For large healthcare systems',
    monthlyPrice: null,
    yearlyPrice: null,
    features: [
      'Everything in Pro',
      'Custom integrations',
      'Dedicated support',
      'SLA guarantee',
      'On-premise option',
      'Training & onboarding',
    ],
    cta: 'Contact Sales',
    highlighted: false,
  },
];

export default function Pricing() {
  const navigate = useNavigate();
  const [isYearly, setIsYearly] = useState(true);

  return (
    <div className="min-h-screen bg-[#0f0f23] pb-8">
      <MobileHeader showBack title="Pricing" />

      <div className="px-4 py-6">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold text-white mb-2">Simple, transparent pricing</h1>
          <p className="text-gray-400">Choose the plan that fits your organization</p>
        </div>

        {/* Toggle */}
        <div className="flex justify-center mb-8">
          <div className="inline-flex bg-[#1a1a3e] border border-white/10 rounded-full p-1">
            <button
              onClick={() => setIsYearly(false)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                !isYearly ? 'bg-[#6366f1] text-white' : 'text-gray-400'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setIsYearly(true)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors flex items-center gap-2 ${
                isYearly ? 'bg-[#6366f1] text-white' : 'text-gray-400'
              }`}
            >
              Yearly
              <span className="text-xs bg-green-500/20 text-green-400 px-1.5 py-0.5 rounded">Save 20%</span>
            </button>
          </div>
        </div>

        {/* Plans */}
        <div className="space-y-4">
          {PLANS.map((plan, i) => (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className={`rounded-2xl border p-5 ${
                plan.highlighted
                  ? 'bg-gradient-to-br from-[#6366f1]/20 to-[#8b5cf6]/20 border-[#6366f1]/50'
                  : 'bg-[#1a1a3e] border-white/5'
              }`}
            >
              {plan.highlighted && (
                <div className="flex items-center gap-1 text-[#818cf8] text-xs font-medium mb-3">
                  <Sparkles size={12} />
                  MOST POPULAR
                </div>
              )}

              <div className="mb-4">
                <h3 className="text-xl font-bold text-white mb-1">{plan.name}</h3>
                <p className="text-sm text-gray-400">{plan.description}</p>
              </div>

              <div className="mb-6">
                {plan.monthlyPrice ? (
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl font-bold text-white">
                      ${isYearly ? plan.yearlyPrice : plan.monthlyPrice}
                    </span>
                    <span className="text-gray-400">/mo</span>
                  </div>
                ) : (
                  <div className="text-3xl font-bold text-white">Custom</div>
                )}
                {plan.monthlyPrice && isYearly && (
                  <p className="text-xs text-gray-500 mt-1">
                    Billed annually (${plan.yearlyPrice! * 12}/year)
                  </p>
                )}
              </div>

              <ul className="space-y-3 mb-6">
                {plan.features.map((feature, j) => (
                  <li key={j} className="flex items-center gap-3 text-sm text-gray-300">
                    <Check size={16} className="text-[#6366f1] flex-shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>

              <button
                onClick={() => navigate('/login')}
                className={`w-full py-3 rounded-xl font-medium flex items-center justify-center gap-2 ${
                  plan.highlighted
                    ? 'bg-[#6366f1] text-white'
                    : 'bg-white/5 text-white border border-white/10'
                }`}
              >
                {plan.cta}
                <ArrowRight size={16} />
              </button>
            </motion.div>
          ))}
        </div>

        {/* FAQ teaser */}
        <div className="mt-8 text-center">
          <p className="text-gray-400 text-sm mb-2">Have questions?</p>
          <button 
            onClick={() => navigate('/contact')}
            className="text-[#6366f1] text-sm font-medium"
          >
            Contact our team →
          </button>
        </div>
      </div>
    </div>
  );
}
