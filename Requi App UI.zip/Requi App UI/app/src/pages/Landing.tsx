import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Shield, Brain, Zap, Check, Menu, X } from 'lucide-react';
import { useState } from 'react';

const FEATURES = [
  {
    icon: Brain,
    title: 'AI-Powered Analysis',
    description: 'Upload contracts and get instant compliance insights',
  },
  {
    icon: Shield,
    title: 'Gap Detection',
    description: 'Never miss a regulatory requirement again',
  },
  {
    icon: Zap,
    title: 'Task Automation',
    description: 'Convert gaps into actionable tasks automatically',
  },
];

const TESTIMONIALS = [
  {
    quote: "Requi Health transformed how we handle compliance. What used to take days now takes minutes.",
    author: "Sarah Chen",
    role: "Compliance Officer",
    org: "Metro Health Systems",
  },
  {
    quote: "The AI understands healthcare regulations better than most consultants.",
    author: "Dr. Michael Torres",
    role: "Medical Director",
    org: "Pacific Care Group",
  },
];

export default function Landing() {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#F8F8F8]">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 safe-top">
        <div className="glass-strong border-b border-gray-100">
          <div className="flex items-center justify-between h-14 px-4">
            {/* Logo */}
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#C3ACFF] to-[#CBD5FF] flex items-center justify-center">
                <span className="text-[#121212] font-bold text-sm">R</span>
              </div>
              <div className="flex items-baseline gap-1">
                <span className="font-semibold text-[#121212]">Requi</span>
                <span className="text-sm text-[#6B7280]">Health</span>
              </div>
            </div>

            {/* Desktop nav - hidden on mobile */}
            <div className="hidden md:flex items-center gap-6">
              <button onClick={() => navigate('/product')} className="text-sm text-[#6B7280] hover:text-[#121212]">Product</button>
              <button onClick={() => navigate('/solutions')} className="text-sm text-[#6B7280] hover:text-[#121212]">Solutions</button>
              <button onClick={() => navigate('/pricing')} className="text-sm text-[#6B7280] hover:text-[#121212]">Pricing</button>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-3">
              <button 
                onClick={() => navigate('/login')}
                className="hidden sm:block text-sm text-[#6B7280] hover:text-[#121212]"
              >
                Sign In
              </button>
              <button 
                onClick={() => navigate('/login')}
                className="px-4 py-2 bg-[#C3ACFF] text-[#121212] text-sm font-medium rounded-lg hover:bg-[#B8C5FF] transition-colors"
              >
                Get Started
              </button>
              <button 
                onClick={() => setMenuOpen(!menuOpen)}
                className="md:hidden w-10 h-10 flex items-center justify-center text-[#121212]"
              >
                {menuOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="md:hidden glass-strong border-b border-gray-100 px-4 py-4 space-y-3"
          >
            <button onClick={() => { navigate('/product'); setMenuOpen(false); }} className="block w-full text-left py-2 text-[#6B7280]">Product</button>
            <button onClick={() => { navigate('/solutions'); setMenuOpen(false); }} className="block w-full text-left py-2 text-[#6B7280]">Solutions</button>
            <button onClick={() => { navigate('/pricing'); setMenuOpen(false); }} className="block w-full text-left py-2 text-[#6B7280]">Pricing</button>
            <button onClick={() => { navigate('/company'); setMenuOpen(false); }} className="block w-full text-left py-2 text-[#6B7280]">Company</button>
          </motion.div>
        )}
      </nav>

      {/* Hero */}
      <section className="pt-24 pb-16 px-4">
        <div className="max-w-md mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-[#C3ACFF]/20 border border-[#C3ACFF]/40 rounded-full mb-6">
              <span className="w-2 h-2 bg-[#C3ACFF] rounded-full animate-pulse" />
              <span className="text-xs text-[#A88BFF] font-medium">AI-Powered Compliance</span>
            </div>

            <h1 className="text-4xl font-bold text-[#121212] mb-4 leading-tight">
              Healthcare compliance,{' '}
              <span className="gradient-text">simplified</span>
            </h1>
            
            <p className="text-[#6B7280] text-lg mb-8">
              Upload contracts. Ask questions. Stay compliant. AI does the rest.
            </p>

            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <button 
                onClick={() => navigate('/login')}
                className="px-6 py-4 bg-[#C3ACFF] text-[#121212] font-medium rounded-xl flex items-center justify-center gap-2 hover:bg-[#B8C5FF] transition-colors"
              >
                Start Free Trial
                <ArrowRight size={18} />
              </button>
              <button 
                onClick={() => navigate('/product')}
                className="px-6 py-4 bg-white text-[#121212] font-medium rounded-xl border border-gray-200 hover:bg-gray-50 transition-colors"
              >
                See How It Works
              </button>
            </div>

            {/* Trust badges */}
            <div className="mt-8 pt-8 border-t border-gray-200">
              <p className="text-xs text-[#9CA3AF] mb-4">Trusted by healthcare organizations</p>
              <div className="flex justify-center gap-6 opacity-40">
                <div className="w-20 h-8 bg-[#121212]/10 rounded" />
                <div className="w-20 h-8 bg-[#121212]/10 rounded" />
                <div className="w-20 h-8 bg-[#121212]/10 rounded" />
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-md mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-[#121212] mb-2">Everything you need</h2>
            <p className="text-[#6B7280]">AI-powered tools for modern compliance teams</p>
          </div>

          <div className="space-y-4">
            {FEATURES.map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="bg-[#F8F8F8] border border-gray-100 rounded-xl p-5"
              >
                <div className="w-12 h-12 rounded-xl bg-[#C3ACFF]/30 flex items-center justify-center mb-4">
                  <feature.icon size={24} className="text-[#A88BFF]" />
                </div>
                <h3 className="text-lg font-semibold text-[#121212] mb-2">{feature.title}</h3>
                <p className="text-[#6B7280] text-sm">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-16 px-4">
        <div className="max-w-md mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-[#121212] mb-2">How it works</h2>
            <p className="text-[#6B7280]">Three steps to compliance clarity</p>
          </div>

          <div className="space-y-6">
            {[
              { step: '1', title: 'Upload', desc: 'Upload contracts or ask questions' },
              { step: '2', title: 'Analyze', desc: 'AI extracts requirements & detects gaps' },
              { step: '3', title: 'Act', desc: 'Get tasks, track progress, stay compliant' },
            ].map((item, i) => (
              <motion.div
                key={item.step}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
                className="flex items-center gap-4"
              >
                <div className="w-10 h-10 rounded-full bg-[#C3ACFF] flex items-center justify-center flex-shrink-0">
                  <span className="text-[#121212] font-bold">{item.step}</span>
                </div>
                <div>
                  <h3 className="text-[#121212] font-medium">{item.title}</h3>
                  <p className="text-[#6B7280] text-sm">{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-md mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-[#121212] mb-2">Loved by teams</h2>
            <p className="text-[#6B7280]">See what compliance officers say</p>
          </div>

          <div className="space-y-4">
            {TESTIMONIALS.map((t, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="bg-[#F8F8F8] border border-gray-100 rounded-xl p-5"
              >
                <p className="text-[#121212] mb-4">"{t.quote}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#C3ACFF] to-[#CBD5FF]" />
                  <div>
                    <p className="text-[#121212] font-medium text-sm">{t.author}</p>
                    <p className="text-[#9CA3AF] text-xs">{t.role}, {t.org}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 px-4">
        <div className="max-w-md mx-auto">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-gradient-to-br from-[#C3ACFF]/30 to-[#CBD5FF]/30 border border-[#C3ACFF]/40 rounded-2xl p-8 text-center"
          >
            <h2 className="text-2xl font-bold text-[#121212] mb-2">Ready to simplify compliance?</h2>
            <p className="text-[#6B7280] mb-6">Start your free 14-day trial today</p>
            
            <div className="flex flex-col gap-3">
              <button 
                onClick={() => navigate('/login')}
                className="w-full py-4 bg-[#C3ACFF] text-[#121212] font-medium rounded-xl hover:bg-[#B8C5FF] transition-colors"
              >
                Get Started Free
              </button>
              <div className="flex items-center justify-center gap-4 text-xs text-[#9CA3AF]">
                <span className="flex items-center gap-1"><Check size={12} /> No credit card</span>
                <span className="flex items-center gap-1"><Check size={12} /> 14-day trial</span>
                <span className="flex items-center gap-1"><Check size={12} /> Cancel anytime</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-gray-200">
        <div className="max-w-md mx-auto">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded bg-gradient-to-br from-[#C3ACFF] to-[#CBD5FF] flex items-center justify-center">
                <span className="text-[#121212] font-bold text-xs">R</span>
              </div>
              <div className="flex items-baseline gap-0.5">
                <span className="text-[#121212] font-medium text-sm">Requi</span>
                <span className="text-xs text-[#6B7280]">Health</span>
              </div>
            </div>
            <div className="flex gap-4">
              <button onClick={() => navigate('/privacy')} className="text-xs text-[#9CA3AF] hover:text-[#6B7280]">Privacy</button>
              <button onClick={() => navigate('/terms')} className="text-xs text-[#9CA3AF] hover:text-[#6B7280]">Terms</button>
            </div>
          </div>
          <p className="text-xs text-[#9CA3AF] text-center">
            © 2026 Requi Health. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
