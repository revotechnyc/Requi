import { useState } from 'react';
import { Search } from 'lucide-react';
import MobileHeader from '@/components/layout/MobileHeader';

const SECTIONS = [
  {
    id: 'collection',
    title: 'Information We Collect',
    content: `We collect information you provide directly to us, such as when you create an account, 
    upload documents, or communicate with us. This includes your name, email address, organization 
    information, and any content you upload to our platform.
    
    We also automatically collect certain information about your device and how you interact with 
    our services, including IP address, browser type, and usage patterns.`,
  },
  {
    id: 'use',
    title: 'How We Use Information',
    content: `We use the information we collect to:
    • Provide, maintain, and improve our services
    • Process and complete transactions
    • Send you technical notices and support messages
    • Respond to your comments and questions
    • Develop new products and services
    • Monitor and analyze trends and usage`,
  },
  {
    id: 'sharing',
    title: 'Data Sharing',
    content: `We do not sell your personal information. We may share information with:
    • Service providers who perform services on our behalf
    • Professional advisors, such as lawyers and accountants
    • Government authorities when required by law
    • In connection with a merger, acquisition, or sale of assets`,
  },
  {
    id: 'security',
    title: 'Security',
    content: `We take reasonable measures to help protect your personal information from loss, theft, 
    misuse, unauthorized access, disclosure, alteration, and destruction. These measures include 
    encryption, access controls, and regular security assessments.
    
    However, no security system is impenetrable, and we cannot guarantee the security of our systems.`,
  },
  {
    id: 'rights',
    title: 'Your Rights',
    content: `Depending on your location, you may have certain rights regarding your personal information, including:
    • Access to your personal information
    • Correction of inaccurate information
    • Deletion of your information
    • Restriction of processing
    • Data portability
    
    To exercise these rights, please contact us at privacy@requi.com.`,
  },
  {
    id: 'retention',
    title: 'Data Retention',
    content: `We retain your personal information for as long as necessary to provide our services and 
    fulfill the purposes outlined in this Privacy Policy. When we no longer need your information, 
    we will securely delete or anonymize it.
    
    Uploaded documents are retained according to your organization's data retention policies.`,
  },
  {
    id: 'changes',
    title: 'Changes to This Policy',
    content: `We may update this Privacy Policy from time to time. We will notify you of any changes by 
    posting the new policy on this page and updating the effective date. We encourage you to review 
    this policy periodically.`,
  },
  {
    id: 'contact',
    title: 'Contact Us',
    content: `If you have any questions about this Privacy Policy or our data practices, please contact us at:
    
    Email: privacy@requi.com
    Address: REQUI Inc., 123 Compliance Street, San Francisco, CA 94105`,
  },
];

export default function Privacy() {
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedSection, setExpandedSection] = useState<string | null>('collection');

  const filteredSections = SECTIONS.filter(section =>
    section.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    section.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#0f0f23] pb-8">
      <MobileHeader showBack title="Privacy Policy" />

      <div className="px-4 py-6">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-white mb-2">Privacy Policy</h1>
          <p className="text-gray-400 text-sm">Last updated: April 16, 2026</p>
        </div>

        {/* Search */}
        <div className="relative mb-6">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search this document..."
            className="w-full bg-[#1a1a3e] border border-white/10 rounded-xl py-3 pl-10 pr-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#6366f1]"
          />
        </div>

        {/* Table of Contents */}
        {!searchQuery && (
          <div className="mb-6">
            <h2 className="text-sm font-medium text-gray-400 mb-3">Contents</h2>
            <div className="flex flex-wrap gap-2">
              {SECTIONS.map((section) => (
                <button
                  key={section.id}
                  onClick={() => setExpandedSection(section.id)}
                  className={`px-3 py-1.5 text-xs rounded-full border transition-colors ${
                    expandedSection === section.id
                      ? 'bg-[#6366f1]/20 border-[#6366f1] text-white'
                      : 'bg-white/5 border-white/10 text-gray-400 hover:bg-white/10'
                  }`}
                >
                  {section.title}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Sections */}
        <div className="space-y-3">
          {filteredSections.map((section) => (
            <div
              key={section.id}
              className="bg-[#1a1a3e] border border-white/5 rounded-xl overflow-hidden"
            >
              <button
                onClick={() => setExpandedSection(expandedSection === section.id ? null : section.id)}
                className="w-full flex items-center justify-between p-4 text-left"
              >
                <h3 className="font-medium text-white">{section.title}</h3>
                <span className="text-gray-500">
                  {expandedSection === section.id ? '−' : '+'}
                </span>
              </button>
              
              {expandedSection === section.id && (
                <div className="px-4 pb-4">
                  <div className="pt-2 border-t border-white/5">
                    <p className="text-gray-400 text-sm whitespace-pre-line leading-relaxed">
                      {section.content}
                    </p>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {filteredSections.length === 0 && (
          <div className="text-center py-8">
            <p className="text-gray-500">No results found</p>
          </div>
        )}
      </div>
    </div>
  );
}
