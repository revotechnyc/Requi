import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, Check, Building2, Shield, FileCheck, Sparkles } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const STEPS = [
  {
    id: 'welcome',
    title: 'Welcome to Requi Health',
    description: 'AI-powered compliance for healthcare teams',
  },
  {
    id: 'organization',
    title: 'Your Organization',
    description: 'Tell us about your healthcare organization',
  },
  {
    id: 'compliance',
    title: 'Compliance Focus',
    description: 'Select your key compliance areas',
  },
  {
    id: 'ready',
    title: "You're All Set",
    description: 'Start managing compliance with AI',
  },
];

const ORG_TYPES = [
  { id: 'provider', label: 'Healthcare Provider', icon: Building2 },
  { id: 'mso', label: 'MSO', icon: Building2 },
  { id: 'payer', label: 'Health Plan', icon: Building2 },
];

const COMPLIANCE_AREAS = [
  { id: 'hipaa', label: 'HIPAA', description: 'Privacy & Security' },
  { id: 'fwa', label: 'FWA', description: 'Fraud, Waste & Abuse' },
  { id: 'quality', label: 'Quality', description: 'Quality Reporting' },
  { id: 'claims', label: 'Claims', description: 'Claims Compliance' },
];

export default function Onboarding() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(0);
  const [orgType, setOrgType] = useState('');
  const [orgName, setOrgName] = useState('');
  const [selectedAreas, setSelectedAreas] = useState<string[]>(['hipaa', 'fwa']);

  const handleNext = () => {
    if (currentStep < STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      navigate('/intelligence');
    }
  };

  const handleSkip = () => {
    navigate('/intelligence');
  };

  const toggleArea = (id: string) => {
    setSelectedAreas(prev =>
      prev.includes(id)
        ? prev.filter(a => a !== id)
        : [...prev, id]
    );
  };

  const canProceed = () => {
    switch (currentStep) {
      case 1:
        return orgType && orgName.length > 0;
      case 2:
        return selectedAreas.length > 0;
      default:
        return true;
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F8F8] flex flex-col">
      {/* Progress */}
      <div className="px-6 pt-6 pb-4">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm text-[#6B7280]">
            Step {currentStep + 1} of {STEPS.length}
          </span>
          <button onClick={handleSkip} className="text-sm text-[#6B7280] hover:text-[#121212]">
            Skip
          </button>
        </div>
        <div className="flex gap-2">
          {STEPS.map((_, i) => (
            <div
              key={i}
              className={`h-1 flex-1 rounded-full transition-colors ${
                i <= currentStep ? 'bg-[#C3ACFF]' : 'bg-gray-200'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col px-6 py-4">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="flex-1 flex flex-col"
          >
            {/* Header */}
            <div className="text-center mb-8">
              {currentStep === 0 && (
                <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#C3ACFF] to-[#CBD5FF] flex items-center justify-center mx-auto mb-6">
                  <Sparkles size={36} className="text-[#121212]" />
                </div>
              )}
              {currentStep === 1 && (
                <div className="w-20 h-20 rounded-2xl bg-[#C3ACFF]/30 flex items-center justify-center mx-auto mb-6">
                  <Building2 size={36} className="text-[#A88BFF]" />
                </div>
              )}
              {currentStep === 2 && (
                <div className="w-20 h-20 rounded-2xl bg-[#C3ACFF]/30 flex items-center justify-center mx-auto mb-6">
                  <Shield size={36} className="text-[#A88BFF]" />
                </div>
              )}
              {currentStep === 3 && (
                <div className="w-20 h-20 rounded-2xl bg-green-100 flex items-center justify-center mx-auto mb-6">
                  <FileCheck size={36} className="text-green-500" />
                </div>
              )}
              
              <h1 className="text-2xl font-bold text-[#121212] mb-2">
                {STEPS[currentStep].title}
              </h1>
              <p className="text-[#6B7280]">
                {STEPS[currentStep].description}
              </p>
            </div>

            {/* Step content */}
            <div className="flex-1">
              {currentStep === 0 && (
                <div className="space-y-4">
                  <div className="bg-white border border-gray-100 rounded-xl p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-[#C3ACFF]/30 flex items-center justify-center">
                        <Sparkles size={20} className="text-[#A88BFF]" />
                      </div>
                      <div>
                        <p className="text-[#121212] font-medium">AI-Powered Analysis</p>
                        <p className="text-sm text-[#6B7280]">Upload contracts, get instant insights</p>
                      </div>
                    </div>
                  </div>
                  <div className="bg-white border border-gray-100 rounded-xl p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-[#C3ACFF]/30 flex items-center justify-center">
                        <Shield size={20} className="text-[#A88BFF]" />
                      </div>
                      <div>
                        <p className="text-[#121212] font-medium">Gap Detection</p>
                        <p className="text-sm text-[#6B7280]">Never miss a compliance requirement</p>
                      </div>
                    </div>
                  </div>
                  <div className="bg-white border border-gray-100 rounded-xl p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-[#C3ACFF]/30 flex items-center justify-center">
                        <FileCheck size={20} className="text-[#A88BFF]" />
                      </div>
                      <div>
                        <p className="text-[#121212] font-medium">Task Management</p>
                        <p className="text-sm text-[#6B7280]">Track and complete compliance tasks</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {currentStep === 1 && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm text-[#6B7280] mb-2">Organization Name</label>
                    <input
                      type="text"
                      value={orgName}
                      onChange={(e) => setOrgName(e.target.value)}
                      placeholder="e.g., Acme Healthcare"
                      className="w-full bg-white border border-gray-200 rounded-xl py-3.5 px-4 text-[#121212] placeholder-[#9CA3AF] focus:outline-none focus:border-[#C3ACFF]"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm text-[#6B7280] mb-2">Organization Type</label>
                    <div className="grid grid-cols-1 gap-2">
                      {ORG_TYPES.map((type) => (
                        <button
                          key={type.id}
                          onClick={() => setOrgType(type.id)}
                          className={`flex items-center gap-3 p-4 rounded-xl border transition-colors ${
                            orgType === type.id
                              ? 'bg-[#C3ACFF]/20 border-[#C3ACFF]'
                              : 'bg-white border-gray-200 hover:bg-gray-50'
                          }`}
                        >
                          <type.icon size={20} className={orgType === type.id ? 'text-[#A88BFF]' : 'text-[#6B7280]'} />
                          <span className={orgType === type.id ? 'text-[#121212]' : 'text-[#6B7280]'}>{type.label}</span>
                          {orgType === type.id && <Check size={18} className="text-[#A88BFF] ml-auto" />}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {currentStep === 2 && (
                <div className="space-y-3">
                  {COMPLIANCE_AREAS.map((area) => (
                    <button
                      key={area.id}
                      onClick={() => toggleArea(area.id)}
                      className={`w-full flex items-center gap-3 p-4 rounded-xl border transition-colors ${
                        selectedAreas.includes(area.id)
                          ? 'bg-[#C3ACFF]/20 border-[#C3ACFF]'
                          : 'bg-white border-gray-200 hover:bg-gray-50'
                      }`}
                    >
                      <div className={`w-5 h-5 rounded border flex items-center justify-center ${
                        selectedAreas.includes(area.id)
                          ? 'bg-[#C3ACFF] border-[#C3ACFF]'
                          : 'border-gray-300'
                      }`}>
                        {selectedAreas.includes(area.id) && <Check size={14} className="text-[#121212]" />}
                      </div>
                      <div className="text-left">
                        <p className={selectedAreas.includes(area.id) ? 'text-[#121212]' : 'text-[#6B7280]'}>{area.label}</p>
                        <p className="text-xs text-[#9CA3AF]">{area.description}</p>
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {currentStep === 3 && (
                <div className="text-center space-y-6">
                  <div className="w-24 h-24 rounded-full bg-green-100 flex items-center justify-center mx-auto">
                    <Check size={48} className="text-green-500" />
                  </div>
                  <div>
                    <p className="text-[#121212] mb-2">Your account is ready!</p>
                    <p className="text-[#6B7280] text-sm">Start by uploading a contract or asking a question</p>
                  </div>
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="mt-8">
              {currentStep === 3 ? (
                <div className="space-y-3">
                  <button
                    onClick={() => navigate('/documents')}
                    className="w-full py-4 bg-[#C3ACFF] text-[#121212] font-medium rounded-xl flex items-center justify-center gap-2"
                  >
                    <FileCheck size={18} />
                    Upload Contract
                  </button>
                  <button
                    onClick={() => navigate('/intelligence')}
                    className="w-full py-4 bg-white text-[#121212] font-medium rounded-xl border border-gray-200"
                  >
                    Ask a Question
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleNext}
                  disabled={!canProceed()}
                  className="w-full py-4 bg-[#C3ACFF] text-[#121212] font-medium rounded-xl flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Continue
                  <ChevronRight size={18} />
                </button>
              )}
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
