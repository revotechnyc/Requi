import { useState, useCallback, useMemo } from 'react';
import type { Task } from '@/types';

// Mock tasks data
const MOCK_TASKS: Task[] = [
  {
    id: 'task-1',
    title: 'Complete FWA Training',
    description: 'Annual mandatory training for all staff members on fraud, waste, and abuse detection.',
    status: 'overdue',
    priority: 'critical',
    dueDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    tags: ['FWA', 'Training', 'Mandatory'],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'task-2',
    title: 'HIPAA Security Assessment',
    description: 'Quarterly security risk assessment and documentation review.',
    status: 'pending',
    priority: 'high',
    dueDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString(),
    tags: ['HIPAA', 'Security', 'Quarterly'],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'task-3',
    title: 'Update Privacy Policies',
    description: 'Review and update patient privacy policies to reflect latest regulations.',
    status: 'in_progress',
    priority: 'medium',
    dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(),
    tags: ['HIPAA', 'Policy', 'Privacy'],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'task-4',
    title: 'Quality Metrics Report',
    description: 'Compile and submit monthly quality performance metrics.',
    status: 'pending',
    priority: 'medium',
    dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
    tags: ['Quality', 'Reporting', 'Monthly'],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'task-5',
    title: 'Staff Compliance Training',
    description: 'Schedule and conduct compliance training for new staff members.',
    status: 'complete',
    priority: 'low',
    dueDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    tags: ['Training', 'Onboarding'],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'task-6',
    title: 'Encounter Data Submission',
    description: 'Submit monthly encounter data to state Medicaid program.',
    status: 'pending',
    priority: 'critical',
    dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
    tags: ['Claims', 'Medicaid', 'Monthly'],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

export const useTasks = () => {
  const [tasks, setTasks] = useState<Task[]>(MOCK_TASKS);
  const [filter, setFilter] = useState<'all' | 'pending' | 'overdue' | 'complete'>('all');

  const filteredTasks = useMemo(() => {
    switch (filter) {
      case 'pending':
        return tasks.filter(t => t.status === 'pending' || t.status === 'in_progress');
      case 'overdue':
        return tasks.filter(t => t.status === 'overdue');
      case 'complete':
        return tasks.filter(t => t.status === 'complete');
      default:
        return tasks;
    }
  }, [tasks, filter]);

  const updateTaskStatus = useCallback((taskId: string, status: Task['status']) => {
    setTasks(prev => prev.map(task => 
      task.id === taskId 
        ? { ...task, status, updatedAt: new Date().toISOString() }
        : task
    ));
  }, []);

  const completeTask = useCallback((taskId: string) => {
    updateTaskStatus(taskId, 'complete');
  }, [updateTaskStatus]);

  const snoozeTask = useCallback((taskId: string, days: number = 1) => {
    setTasks(prev => prev.map(task => {
      if (task.id !== taskId) return task;
      const newDueDate = new Date(task.dueDate);
      newDueDate.setDate(newDueDate.getDate() + days);
      return {
        ...task,
        dueDate: newDueDate.toISOString(),
        status: 'pending' as const,
        updatedAt: new Date().toISOString(),
      };
    }));
  }, []);

  const getTaskById = useCallback((id: string) => {
    return tasks.find(t => t.id === id);
  }, [tasks]);

  const stats = useMemo(() => ({
    total: tasks.length,
    pending: tasks.filter(t => t.status === 'pending' || t.status === 'in_progress').length,
    overdue: tasks.filter(t => t.status === 'overdue').length,
    complete: tasks.filter(t => t.status === 'complete').length,
    critical: tasks.filter(t => t.priority === 'critical' && t.status !== 'complete').length,
  }), [tasks]);

  return {
    tasks: filteredTasks,
    allTasks: tasks,
    filter,
    setFilter,
    updateTaskStatus,
    completeTask,
    snoozeTask,
    getTaskById,
    stats,
  };
};
