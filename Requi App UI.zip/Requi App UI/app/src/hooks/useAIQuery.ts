import { useState, useCallback } from 'react';
import type { AIResponse } from '@/types';

// Mock AI responses for demo
const MOCK_RESPONSES: Record<string, AIResponse> = {
  default: {
    answer: "I've analyzed your compliance posture. You have 3 active requirements and 2 gaps that need attention.",
    requirements: [
      {
        id: 'req-1',
        description: 'Quarterly HIPAA Security Assessment',
        category: 'HIPAA',
        source: 'federal',
        priority: 'high',
        obligationType: 'reporting',
      },
      {
        id: 'req-2',
        description: 'Annual Fraud, Waste & Abuse Training',
        category: 'FWA',
        source: 'federal',
        priority: 'critical',
        obligationType: 'training',
      },
      {
        id: 'req-3',
        description: 'Quality Metrics Reporting',
        category: 'Quality',
        source: 'contract',
        priority: 'medium',
        obligationType: 'reporting',
      },
    ],
    gaps: [
      {
        id: 'gap-1',
        requirementId: 'req-2',
        type: 'overdue',
        severity: 'critical',
        reason: 'Training deadline passed 5 days ago',
        recommendedAction: 'Schedule immediate training session',
      },
      {
        id: 'gap-2',
        requirementId: 'req-1',
        type: 'missing',
        severity: 'high',
        reason: 'No documentation found for Q1 assessment',
        recommendedAction: 'Complete security assessment and upload documentation',
      },
    ],
    tasks: [
      {
        id: 'task-1',
        title: 'Complete FWA Training',
        description: 'Annual mandatory training for all staff',
        status: 'overdue',
        priority: 'critical',
        dueDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        tags: ['FWA', 'Training'],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'task-2',
        title: 'HIPAA Security Assessment',
        description: 'Quarterly security risk assessment',
        status: 'pending',
        priority: 'high',
        dueDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString(),
        tags: ['HIPAA', 'Security'],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ],
    riskScore: 72,
    confidence: 'high',
  },
  contract: {
    answer: "I've analyzed your uploaded contract and extracted 5 compliance obligations. 2 require immediate attention.",
    requirements: [
      {
        id: 'req-contract-1',
        description: 'Monthly Encounter Data Submission',
        category: 'Claims',
        source: 'contract',
        priority: 'critical',
        obligationType: 'reporting',
        frequency: 'monthly',
      },
      {
        id: 'req-contract-2',
        description: 'Quarterly Quality Report',
        category: 'Quality',
        source: 'contract',
        priority: 'high',
        obligationType: 'reporting',
        frequency: 'quarterly',
      },
    ],
    gaps: [
      {
        id: 'gap-contract-1',
        requirementId: 'req-contract-1',
        type: 'missing',
        severity: 'critical',
        reason: 'No encounter data submission process established',
        recommendedAction: 'Set up monthly data collection and submission workflow',
      },
    ],
    tasks: [
      {
        id: 'task-contract-1',
        title: 'Set up encounter data submission',
        description: 'Establish monthly workflow for encounter data',
        status: 'pending',
        priority: 'critical',
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        tags: ['Contract', 'Data'],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ],
    riskScore: 65,
    confidence: 'high',
  },
};

export const useAIQuery = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [response, setResponse] = useState<AIResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  const query = useCallback(async (_input: string, documentText?: string) => {
    setIsLoading(true);
    setError(null);

    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Return mock response based on input
      const mockResponse = documentText 
        ? MOCK_RESPONSES.contract 
        : MOCK_RESPONSES.default;

      setResponse(mockResponse);
      return mockResponse;
    } catch (err) {
      setError('Failed to process your request. Please try again.');
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const clearResponse = useCallback(() => {
    setResponse(null);
    setError(null);
  }, []);

  return {
    query,
    isLoading,
    response,
    error,
    clearResponse,
  };
};
