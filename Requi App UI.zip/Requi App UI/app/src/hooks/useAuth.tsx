import { useState, useEffect, createContext, useContext } from 'react';
import type { User } from '@/types';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  signup: (email: string, password: string, name: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

// Mock auth for demo
const MOCK_USER: User = {
  id: '1',
  email: 'demo@requi.com',
  name: 'Demo User',
  organizationId: 'org-1',
  role: 'compliance_officer',
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    // Return default values for when provider isn't available
    return {
      user: MOCK_USER,
      isAuthenticated: true,
      isLoading: false,
      login: async () => {},
      logout: () => {},
      signup: async () => {},
    };
  }
  return context;
};

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for stored auth
    const stored = localStorage.getItem('requi_auth');
    if (stored) {
      setUser(JSON.parse(stored));
    }
    setIsLoading(false);
  }, []);

  const login = async (_email: string, _password: string) => {
    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    setUser(MOCK_USER);
    localStorage.setItem('requi_auth', JSON.stringify(MOCK_USER));
    setIsLoading(false);
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('requi_auth');
  };

  const signup = async (_email: string, _password: string, name: string) => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    const newUser = { ...MOCK_USER, email: _email, name };
    setUser(newUser);
    localStorage.setItem('requi_auth', JSON.stringify(newUser));
    setIsLoading(false);
  };

  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated: !!user,
      isLoading,
      login,
      logout,
      signup,
    }}>
      {children}
    </AuthContext.Provider>
  );
};
