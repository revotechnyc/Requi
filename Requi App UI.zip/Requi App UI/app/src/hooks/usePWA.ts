import { useState, useEffect } from 'react';

interface PWAState {
  isInstallable: boolean;
  isInstalled: boolean;
  isStandalone: boolean;
  deferredPrompt: any;
}

export const usePWA = () => {
  const [state, setState] = useState<PWAState>({
    isInstallable: false,
    isInstalled: false,
    isStandalone: false,
    deferredPrompt: null,
  });

  useEffect(() => {
    // Check if already installed
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches 
      || (window.navigator as any).standalone === true;
    
    setState(prev => ({ ...prev, isStandalone, isInstalled: isStandalone }));

    // Listen for install prompt
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setState(prev => ({ 
        ...prev, 
        deferredPrompt: e, 
        isInstallable: true 
      }));
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    // Listen for app installed
    window.addEventListener('appinstalled', () => {
      setState(prev => ({ 
        ...prev, 
        isInstalled: true, 
        isInstallable: false,
        deferredPrompt: null 
      }));
    });

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const promptInstall = async () => {
    if (!state.deferredPrompt) return;
    
    state.deferredPrompt.prompt();
    const { outcome } = await state.deferredPrompt.userChoice;
    
    if (outcome === 'accepted') {
      setState(prev => ({ 
        ...prev, 
        isInstalled: true,
        isInstallable: false,
        deferredPrompt: null 
      }));
    }
  };

  const dismissPrompt = () => {
    setState(prev => ({ ...prev, isInstallable: false }));
  };

  return {
    ...state,
    promptInstall,
    dismissPrompt,
  };
};
