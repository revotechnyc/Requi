import { useState } from 'react';
import { motion, useMotionValue, useTransform, type PanInfo } from 'framer-motion';
import { Check, Clock, AlertCircle, Calendar, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import type { Task } from '@/types';

interface TaskCardProps {
  task: Task;
  onComplete: (id: string) => void;
  onSnooze: (id: string) => void;
}

const priorityColors = {
  critical: 'bg-red-500',
  high: 'bg-orange-500',
  medium: 'bg-yellow-500',
  low: 'bg-green-500',
};

const priorityLabels = {
  critical: 'Critical',
  high: 'High',
  medium: 'Medium',
  low: 'Low',
};

const statusIcons = {
  pending: null,
  'in_progress': Clock,
  complete: Check,
  overdue: AlertCircle,
};

const statusColors = {
  pending: 'text-gray-400',
  'in_progress': 'text-blue-500',
  complete: 'text-green-500',
  overdue: 'text-red-500',
};

export default function TaskCard({ task, onComplete, onSnooze }: TaskCardProps) {
  const navigate = useNavigate();
  const [isDragging, setIsDragging] = useState(false);
  
  const x = useMotionValue(0);
  const background = useTransform(
    x,
    [-100, 0, 100],
    ['rgba(16, 185, 129, 0.15)', 'rgba(255, 255, 255, 1)', 'rgba(195, 172, 255, 0.2)']
  );

  const handleDragEnd = (_: unknown, info: PanInfo) => {
    setIsDragging(false);
    
    if (info.offset.x > 80) {
      // Swiped right - snooze
      onSnooze(task.id);
    } else if (info.offset.x < -80) {
      // Swiped left - complete
      onComplete(task.id);
    }
  };

  const formatDueDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffDays = Math.ceil((date.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) return `${Math.abs(diffDays)}d overdue`;
    if (diffDays === 0) return 'Due today';
    if (diffDays === 1) return 'Due tomorrow';
    return `Due ${diffDays}d`;
  };

  const StatusIcon = statusIcons[task.status];

  return (
    <motion.div
      style={{ background, x }}
      drag="x"
      dragConstraints={{ left: 0, right: 0 }}
      dragElastic={0.3}
      onDragStart={() => setIsDragging(true)}
      onDragEnd={handleDragEnd}
      className="relative mb-3"
    >
      {/* Swipe indicators */}
      <div className="absolute inset-0 flex items-center justify-between px-4 pointer-events-none">
        <div className="flex items-center gap-2 text-green-500 opacity-0" style={{ opacity: x.get() > 20 ? 1 : 0 }}>
          <Check size={20} />
          <span className="text-sm font-medium">Complete</span>
        </div>
        <div className="flex items-center gap-2 text-[#A88BFF] opacity-0" style={{ opacity: x.get() < -20 ? 1 : 0 }}>
          <span className="text-sm font-medium">Snooze</span>
          <Clock size={20} />
        </div>
      </div>

      {/* Card content */}
      <motion.div
        onClick={() => !isDragging && navigate(`/tasks/${task.id}`)}
        className="relative bg-white border border-gray-100 rounded-xl p-4 cursor-pointer active:scale-[0.98] transition-transform"
      >
        <div className="flex items-start gap-3">
          {/* Priority indicator */}
          <div className={`w-1.5 h-1.5 rounded-full ${priorityColors[task.priority]} mt-2 flex-shrink-0`} />
          
          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <h3 className={`font-medium text-[#121212] truncate ${task.status === 'complete' ? 'line-through text-[#9CA3AF]' : ''}`}>
                {task.title}
              </h3>
              <ChevronRight size={18} className="text-[#9CA3AF] flex-shrink-0 mt-0.5" />
            </div>
            
            {/* Meta row */}
            <div className="flex items-center gap-3 mt-2 flex-wrap">
              {/* Priority badge */}
              <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full bg-gray-100 ${
                task.priority === 'critical' ? 'text-red-500' :
                task.priority === 'high' ? 'text-orange-500' :
                task.priority === 'medium' ? 'text-yellow-600' : 'text-green-500'
              }`}>
                {priorityLabels[task.priority]}
              </span>
              
              {/* Due date */}
              <span className={`flex items-center gap-1 text-xs ${
                task.status === 'overdue' ? 'text-red-500' : 'text-[#6B7280]'
              }`}>
                <Calendar size={12} />
                {formatDueDate(task.dueDate)}
              </span>
              
              {/* Status */}
              {StatusIcon && (
                <span className={`flex items-center gap-1 text-xs ${statusColors[task.status]}`}>
                  <StatusIcon size={12} />
                  {task.status === 'in_progress' ? 'In Progress' : 
                   task.status === 'overdue' ? 'Overdue' : 'Done'}
                </span>
              )}
            </div>

            {/* Tags */}
            {task.tags.length > 0 && (
              <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                {task.tags.slice(0, 3).map((tag, i) => (
                  <span key={i} className="text-[10px] text-[#6B7280] bg-gray-100 px-2 py-0.5 rounded">
                    {tag}
                  </span>
                ))}
                {task.tags.length > 3 && (
                  <span className="text-[10px] text-[#6B7280]">+{task.tags.length - 3}</span>
                )}
              </div>
            )}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
