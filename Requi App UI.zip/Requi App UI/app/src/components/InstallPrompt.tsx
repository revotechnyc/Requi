import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Download } from 'lucide-react';
import { usePWA } from '@/hooks/usePWA';

export default function InstallPrompt() {
  const { isInstallable, isInstalled, promptInstall } = usePWA();
  const [visible, setVisible] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    // Show prompt after 5 seconds if installable
    if (isInstallable && !isInstalled && !dismissed) {
      const timer = setTimeout(() => {
        setVisible(true);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [isInstallable, isInstalled, dismissed]);

  const handleDismiss = () => {
    setVisible(false);
    setDismissed(true);
  };

  const handleInstall = async () => {
    await promptInstall();
    setVisible(false);
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 100 }}
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
          className="fixed bottom-20 left-4 right-4 z-50"
        >
          <div className="bg-white border border-gray-100 rounded-2xl p-4 shadow-2xl shadow-gray-200">
            <div className="flex items-start gap-3">
              {/* App Icon */}
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#C3ACFF] to-[#CBD5FF] flex items-center justify-center flex-shrink-0">
                <span className="text-[#121212] font-bold text-xl">R</span>
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="font-semibold text-[#121212]">Add Requi Health to Home Screen</h3>
                    <p className="text-sm text-[#6B7280] mt-0.5">
                      Install for quick access and offline support
                    </p>
                  </div>
                  <button
                    onClick={handleDismiss}
                    className="w-8 h-8 flex items-center justify-center rounded-lg bg-gray-100 hover:bg-gray-200 transition-colors flex-shrink-0"
                  >
                    <X size={16} className="text-[#6B7280]" />
                  </button>
                </div>

                {/* Actions */}
                <div className="flex gap-2 mt-4">
                  <button
                    onClick={handleDismiss}
                    className="flex-1 py-2.5 px-4 rounded-xl border border-gray-200 text-[#6B7280] font-medium text-sm hover:bg-gray-50 transition-colors"
                  >
                    Not now
                  </button>
                  <button
                    onClick={handleInstall}
                    className="flex-1 py-2.5 px-4 rounded-xl bg-[#C3ACFF] text-[#121212] font-medium text-sm hover:bg-[#B8C5FF] transition-colors flex items-center justify-center gap-2"
                  >
                    <Download size={16} />
                    Install
                  </button>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
