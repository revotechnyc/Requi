import { useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Home, MessageSquare, PlusCircle, ClipboardList, User } from 'lucide-react';

interface NavItem {
  id: string;
  icon: React.ElementType;
  label: string;
  path: string;
}

const navItems: NavItem[] = [
  { id: 'dashboard', icon: Home, label: 'Home', path: '/dashboard' },
  { id: 'intelligence', icon: MessageSquare, label: 'AI', path: '/intelligence' },
  { id: 'upload', icon: PlusCircle, label: 'Add', path: '/documents' },
  { id: 'tasks', icon: ClipboardList, label: 'Tasks', path: '/tasks' },
  { id: 'profile', icon: User, label: 'Profile', path: '/profile' },
];

export default function BottomNav() {
  const location = useLocation();
  const navigate = useNavigate();
  
  const activeTab = navItems.find(item => 
    location.pathname.startsWith(item.path)
  )?.id || 'dashboard';

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 safe-bottom">
      <div className="glass-strong border-t border-gray-100">
        <div className="flex items-center justify-around h-16 px-2 max-w-lg mx-auto">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            const Icon = item.icon;
            
            return (
              <button
                key={item.id}
                onClick={() => navigate(item.path)}
                className="relative flex flex-col items-center justify-center w-14 h-14 rounded-xl transition-colors"
              >
                {isActive && (
                  <motion.div
                    layoutId="bottomNavIndicator"
                    className="absolute inset-0 bg-[#C3ACFF]/30 rounded-xl"
                    transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                  />
                )}
                
                <Icon 
                  size={22}
                  className={`relative z-10 transition-colors ${
                    isActive ? 'text-[#A88BFF]' : 'text-gray-400'
                  }`}
                  strokeWidth={isActive ? 2.5 : 2}
                />
                
                <span 
                  className={`relative z-10 text-[10px] mt-1 font-medium transition-colors ${
                    isActive ? 'text-[#A88BFF]' : 'text-gray-400'
                  }`}
                >
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
