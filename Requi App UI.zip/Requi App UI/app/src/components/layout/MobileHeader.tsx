import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Bell, Settings } from 'lucide-react';

interface MobileHeaderProps {
  title?: string;
  showBack?: boolean;
  showNotification?: boolean;
  showSettings?: boolean;
  onBack?: () => void;
  rightAction?: React.ReactNode;
}

export default function MobileHeader({
  title,
  showBack = false,
  showNotification = false,
  showSettings = false,
  onBack,
  rightAction,
}: MobileHeaderProps) {
  const navigate = useNavigate();

  const handleBack = () => {
    if (onBack) {
      onBack();
    } else {
      navigate(-1);
    }
  };

  return (
    <header className="sticky top-0 z-40 safe-top">
      <div className="glass-strong border-b border-gray-100">
        <div className="flex items-center justify-between h-14 px-4">
          {/* Left */}
          <div className="flex items-center gap-3 flex-1">
            {showBack && (
              <button
                onClick={handleBack}
                className="w-10 h-10 flex items-center justify-center rounded-xl bg-gray-100 active:bg-gray-200 transition-colors"
              >
                <ArrowLeft size={20} className="text-[#6B7280]" />
              </button>
            )}
            
            {title ? (
              <h1 className="text-lg font-semibold text-[#121212] truncate">{title}</h1>
            ) : (
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#C3ACFF] to-[#CBD5FF] flex items-center justify-center">
                  <span className="text-[#121212] font-bold text-sm">R</span>
                </div>
                <div className="flex items-baseline gap-1">
                  <span className="font-semibold text-[#121212]">Requi</span>
                  <span className="text-sm text-[#6B7280]">Health</span>
                </div>
              </div>
            )}
          </div>

          {/* Right */}
          <div className="flex items-center gap-2">
            {showNotification && (
              <button className="relative w-10 h-10 flex items-center justify-center rounded-xl bg-gray-100 active:bg-gray-200 transition-colors">
                <Bell size={20} className="text-[#6B7280]" />
                <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full" />
              </button>
            )}
            
            {showSettings && (
              <button 
                onClick={() => navigate('/profile')}
                className="w-10 h-10 flex items-center justify-center rounded-xl bg-gray-100 active:bg-gray-200 transition-colors"
              >
                <Settings size={20} className="text-[#6B7280]" />
              </button>
            )}
            
            {rightAction}
          </div>
        </div>
      </div>
    </header>
  );
}
