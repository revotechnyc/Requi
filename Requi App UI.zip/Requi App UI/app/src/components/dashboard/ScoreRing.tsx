import { motion } from 'framer-motion';

interface ScoreRingProps {
  score: number;
  label: string;
  size?: number;
  strokeWidth?: number;
  color?: string;
}

export default function ScoreRing({
  score,
  label,
  size = 100,
  strokeWidth = 8,
  color = '#C3ACFF',
}: ScoreRingProps) {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (score / 100) * circumference;

  // Determine color based on score
  const getScoreColor = (s: number) => {
    if (s >= 80) return '#10b981'; // Green
    if (s >= 60) return '#C3ACFF'; // Lavender
    if (s >= 40) return '#f59e0b'; // Yellow
    return '#ef4444'; // Red
  };

  const scoreColor = color || getScoreColor(score);

  return (
    <div className="flex flex-col items-center">
      <div className="relative" style={{ width: size, height: size }}>
        {/* Background circle */}
        <svg
          width={size}
          height={size}
          className="transform -rotate-90"
        >
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="#E5E7EB"
            strokeWidth={strokeWidth}
          />
          <motion.circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={scoreColor}
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset: offset }}
            transition={{ duration: 1, ease: 'easeOut' }}
          />
        </svg>

        {/* Score text */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.span
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3, duration: 0.3 }}
            className="text-2xl font-bold text-[#121212]"
          >
            {score}
          </motion.span>
          <span className="text-xs text-[#9CA3AF]">/100</span>
        </div>
      </div>

      {/* Label */}
      <span className="mt-2 text-sm font-medium text-[#6B7280]">{label}</span>
    </div>
  );
}
