# REQUI — Mobile PWA Specification
## Enterprise Healthcare Compliance AI — Mobile Interface Layer

**Version:** 1.0  
**Date:** April 16, 2026  
**Author:** Product Architecture Team  
**Classification:** Technical Specification — Developer Ready

---

## 1. PWA Architecture Plan

### 1.1 Separation Strategy

The REQUI mobile PWA exists as a **completely separate, self-contained application layer** that communicates with the same backend API as the desktop version. This ensures:

- **Zero interference** with existing desktop codebase
- **Independent deployment** cycles
- **Mobile-optimized** build pipeline
- **PWA-specific** optimizations (caching, offline, install)

```
┌─────────────────────────────────────────────────────────────────┐
│                      REQUI PLATFORM                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────────────┐      ┌─────────────────────────────┐  │
│  │   DESKTOP APP       │      │      MOBILE PWA             │  │
│  │   (Existing)        │      │      (New - Separate)       │  │
│  │                     │      │                             │  │
│  │  • React/Web        │      │  • React + Vite             │  │
│  │  • Full dashboards  │      │  • PWA-optimized            │  │
│  │  • Complex layouts  │      │  • Mobile-first UX          │  │
│  │  • Desktop-first    │      │  • Touch-optimized          │  │
│  │                     │      │  • Installable              │  │
│  └──────────┬──────────┘      └──────────────┬──────────────┘  │
│             │                                 │                 │
│             └────────────────┬────────────────┘                 │
│                              │                                  │
│                    ┌─────────▼──────────┐                      │
│                    │   SHARED BACKEND   │                      │
│                    │   REST API + WS    │                      │
│                    └────────────────────┘                      │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### 1.2 Communication Layer

Both apps communicate with the **same backend API endpoints**:

| Endpoint | Desktop | Mobile PWA |
|----------|---------|------------|
| `/ai/query` | ✅ | ✅ |
| `/documents/upload` | ✅ | ✅ (camera + files) |
| `/tasks` | ✅ | ✅ (swipe actions) |
| `/scores/{id}` | ✅ | ✅ (simplified view) |
| `/auth/*` | ✅ | ✅ |

**Mobile-specific API adaptations:**
- File upload supports camera capture
- Real-time updates via WebSocket for task changes
- Optimized payload sizes for mobile networks

### 1.3 Build & Deployment

```
Desktop Build:          Mobile PWA Build:
─────────────           ────────────────
/src/desktop/*          /pwa-mobile/*
build: vite             build: vite + pwa
output: /dist           output: /pwa-dist
deploy: static host     deploy: static host + CDN
```

**Deployment options:**
1. **Subdomain:** `mobile.requi.com` → `/pwa-dist`
2. **Subpath:** `requi.com/mobile` → `/pwa-dist`
3. **Separate domain:** `requi.app` → `/pwa-dist`

---

## 2. File Structure

```
/mnt/okcomputer/output/requi-pwa/
├── public/
│   ├── manifest.json              # PWA manifest
│   ├── icons/
│   │   ├── icon-72x72.png
│   │   ├── icon-96x96.png
│   │   ├── icon-128x128.png
│   │   ├── icon-144x144.png
│   │   ├── icon-152x152.png
│   │   ├── icon-192x192.png
│   │   ├── icon-384x384.png
│   │   └── icon-512x512.png
│   └── favicon.ico
│
├── src/
│   ├── main.tsx                   # App entry
│   ├── App.tsx                    # Root component
│   ├── index.css                  # Global styles
│   │
│   ├── components/                # Shared components
│   │   ├── ui/                    # shadcn/ui components
│   │   ├── layout/
│   │   │   ├── MobileHeader.tsx   # Top navigation
│   │   │   ├── BottomNav.tsx      # Bottom tab bar
│   │   │   └── PageWrapper.tsx    # Page container
│   │   ├── intelligence/
│   │   │   ├── ChatInput.tsx      # AI input field
│   │   │   ├── ResponseCard.tsx   # AI response display
│   │   │   ├── RequirementItem.tsx
│   │   │   ├── GapAlert.tsx
│   │   │   └── ActionButton.tsx
│   │   ├── tasks/
│   │   │   ├── TaskCard.tsx       # Monday.com style
│   │   │   ├── TaskList.tsx
│   │   │   ├── StatusBadge.tsx
│   │   │   ├── PriorityTag.tsx
│   │   │   └── SwipeActions.tsx
│   │   ├── dashboard/
│   │   │   ├── ScoreRing.tsx      # Circular progress
│   │   │   ├── MetricCard.tsx
│   │   │   └── InsightCard.tsx
│   │   └── onboarding/
│   │       ├── StepIndicator.tsx
│   │       ├── ProgressBar.tsx
│   │       └── SkipButton.tsx
│   │
│   ├── pages/                     # Route pages
│   │   ├── Landing.tsx            # Marketing landing
│   │   ├── Login.tsx              # Auth
│   │   ├── Onboarding.tsx         # New user flow
│   │   ├── Intelligence.tsx       # AI interface (main)
│   │   ├── Dashboard.tsx          # Scores & insights
│   │   ├── Tasks.tsx              # Task management
│   │   ├── TaskDetail.tsx         # Single task view
│   │   ├── Documents.tsx          # Document list
│   │   ├── Profile.tsx            # User settings
│   │   ├── Pricing.tsx            # Plans & pricing
│   │   ├── Product.tsx            # Product info
│   │   ├── Solutions.tsx          # Solutions
│   │   ├── Company.tsx            # About
│   │   ├── Contact.tsx            # Contact form
│   │   ├── Privacy.tsx            # Privacy policy
│   │   ├── Terms.tsx              # Terms of service
│   │   └── InstallPrompt.tsx      # PWA install UI
│   │
│   ├── hooks/                     # Custom hooks
│   │   ├── useAuth.ts
│   │   ├── useAIQuery.ts          # AI orchestration
│   │   ├── useTasks.ts
│   │   ├── useScores.ts
│   │   ├── useDocuments.ts
│   │   ├── usePWA.ts              # PWA install detection
│   │   ├── useOffline.ts          # Offline status
│   │   └── useSwipe.ts            # Swipe gestures
│   │
│   ├── lib/                       # Utilities
│   │   ├── api.ts                 # API client
│   │   ├── utils.ts
│   │   ├── constants.ts
│   │   └── copy-reduction.ts      # Mobile copy optimizer
│   │
│   ├── store/                     # State management
│   │   ├── authStore.ts
│   │   ├── intelligenceStore.ts
│   │   ├── taskStore.ts
│   │   └── uiStore.ts
│   │
│   ├── types/                     # TypeScript types
│   │   ├── index.ts
│   │   ├── api.ts
│   │   └── pwa.ts
│   │
│   └── styles/
│       ├── variables.css          # CSS variables
│       ├── animations.css         # Transitions
│       └── mobile-optimizations.css
│
├── sw/                            # Service Worker
│   ├── service-worker.ts          # Main SW
│   └── cache-strategy.ts          # Caching logic
│
├── index.html                     # HTML entry
├── vite.config.ts                 # Vite + PWA config
├── tsconfig.json
├── tailwind.config.ts
└── package.json
```

---

## 3. Mobile UX System

### 3.1 Navigation Architecture

**Bottom Navigation (Primary)** — 5 tabs maximum

```
┌─────────────────────────────────────────┐
│              [Header]                   │
│         (Logo + Actions)                │
├─────────────────────────────────────────┤
│                                         │
│                                         │
│              [CONTENT]                  │
│                                         │
│                                         │
├─────────────────────────────────────────┤
│  🏠    💬    ➕    📋    👤            │
│ Home   AI   Add   Tasks  Profile       │
└─────────────────────────────────────────┘
```

| Tab | Icon | Destination | Purpose |
|-----|------|-------------|---------|
| Home | 🏠 | `/dashboard` | Scores, quick insights |
| AI | 💬 | `/intelligence` | Primary AI interface |
| Add | ➕ | `/upload` | Quick document upload |
| Tasks | 📋 | `/tasks` | Task management |
| Profile | 👤 | `/profile` | Settings, account |

**Header Variants:**

| Screen | Header Style |
|--------|--------------|
| Intelligence | Minimal (logo only) |
| Dashboard | Standard (logo + notification bell) |
| Tasks | Standard + filter button |
| Detail Pages | Back arrow + title |

### 3.2 Layout System

**Safe Areas & Spacing:**

```css
/* Mobile-first spacing scale */
--space-xs: 4px;    /* Micro spacing */
--space-sm: 8px;    /* Tight */
--space-md: 16px;   /* Standard */
--space-lg: 24px;   /* Relaxed */
--space-xl: 32px;   /* Section breaks */
--space-2xl: 48px;  /* Major sections */

/* Touch targets */
--tap-min: 44px;    /* Minimum tap target */
--tap-comfortable: 48px; /* Comfortable tap */

/* Content width */
--content-max: 100%;
--content-padding: 16px;
```

**Page Structure:**

```tsx
<PageWrapper>
  <MobileHeader variant="standard" />
  <ScrollArea className="flex-1">
    <main className="px-4 py-4">
      {/* Page content */}
    </main>
  </ScrollArea>
  <BottomNav activeTab="intelligence" />
</PageWrapper>
```

### 3.3 Interaction Patterns

**Swipe Gestures:**

| Gesture | Action | Screen |
|---------|--------|--------|
| Swipe left on task | Reveal "Complete" action | Tasks list |
| Swipe right on task | Reveal "Snooze" action | Tasks list |
| Pull down | Refresh content | All lists |
| Long press | Context menu | Task cards |

**Transitions:**

| Transition | Duration | Easing |
|------------|----------|--------|
| Page slide | 300ms | ease-out-cubic |
| Modal appear | 250ms | spring(1, 0.8, 10) |
| Button press | 100ms | ease-in-out |
| List item enter | 150ms | ease-out |

**Loading States:**

```tsx
// Skeleton for lists
<TaskSkeleton count={5} />

// Shimmer for AI response
<AIResponseSkeleton />

// Inline spinner for buttons
<Button loading={isLoading}>
```

---

## 4. Copy Reduction Strategy

### 4.1 Principles

| Desktop Approach | Mobile Approach | Example |
|-----------------|-----------------|---------|
| Full sentences | Short phrases | "Upload your contract" → "Upload contract" |
| Explanatory text | Labels + icons | "Click to add a new task" → "+ New task" |
| Paragraphs | Bullet points | Paragraph → 2-3 bullets |
| Formal tone | Direct tone | "Please select an option" → "Choose" |
| Redundant info | Single mention | Remove duplicate labels |

### 4.2 Section-by-Section Reduction

**Intelligence Response:**

```
DESKTOP:
"Based on your contract analysis, we have identified the following 
compliance requirements that need your attention. These requirements 
are derived from federal regulations and your specific contractual 
obligations."

MOBILE:
"3 requirements found"
```

**Task Cards:**

```
DESKTOP:
Title: "Quarterly HIPAA Compliance Report"
Description: "Submit the required quarterly report to demonstrate 
compliance with HIPAA security rule requirements."
Due: "Due Date: March 31, 2026"
Priority: "Priority Level: High"

MOBILE:
Title: "HIPAA Quarterly Report"
Due: "Due Mar 31"
Priority: [HIGH badge]
```

**Dashboard Metrics:**

```
DESKTOP:
"Your current compliance score is 73 out of 100. This represents 
a 5% improvement from last month. You have 3 high-priority gaps 
that require immediate attention."

MOBILE:
"Compliance: 73% ↑5%"
"3 gaps need attention"
```

### 4.3 Copy Reduction Function

```typescript
// lib/copy-reduction.ts

export const reduceForMobile = (desktopCopy: string, maxChars: number = 60): string => {
  const reductions: Record<string, string> = {
    "Please select": "Choose",
    "Click to": "",
    "Tap to": "",
    "Your current": "",
    "Based on your analysis": "Found",
    "we have identified": "",
    "that need your attention": "",
    "requires immediate attention": "urgent",
  };
  
  let mobile = desktopCopy;
  Object.entries(reductions).forEach(([from, to]) => {
    mobile = mobile.replace(new RegExp(from, 'gi'), to);
  });
  
  // Trim to max chars with ellipsis
  if (mobile.length > maxChars) {
    mobile = mobile.slice(0, maxChars - 3) + '...';
  }
  
  return mobile.trim();
};
```

---

## 5. Page-by-Page Mobile Adaptation

### 5.1 Intelligence (Primary Screen)

**Purpose:** AI-first interface — the main interaction point

**Layout:**

```
┌─────────────────────────────────────────┐
│  [Logo]              [History] [Profile]│
├─────────────────────────────────────────┤
│                                         │
│         ┌─────────────────────┐         │
│         │   🤖                │         │
│         │                     │         │
│         │  What can I help    │         │
│         │  you with today?    │         │
│         └─────────────────────┘         │
│                                         │
│  ┌─────────────────────────────────┐   │
│  │  Ask anything...          [📎]  │   │
│  └─────────────────────────────────┘   │
│                                         │
│  Quick actions:                         │
│  [📄 Upload] [❓ Ask] [📊 Check]       │
│                                         │
├─────────────────────────────────────────┤
│  🏠    💬    ➕    📋    👤            │
└─────────────────────────────────────────┘
```

**Mobile Optimizations:**

| Element | Desktop | Mobile |
|---------|---------|--------|
| Input | Full-width, centered | Bottom-fixed, thumb-friendly |
| Quick actions | Horizontal scroll | 3 large tap targets |
| Response | Full page | Scrollable cards |
| File upload | Drag & drop | Camera + gallery |

**AI Response Cards:**

```tsx
// Mobile-optimized response structure
<ResponseCard>
  <Answer text={shortened} />
  <RequirementsList collapsible />
  <GapAlerts swipeable />
  <ActionButtons oneTap />
</ResponseCard>
```

### 5.2 Dashboard

**Purpose:** At-a-glance compliance health

**Layout:**

```
┌─────────────────────────────────────────┐
│  [Logo]                    [🔔] [👤]   │
├─────────────────────────────────────────┤
│                                         │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐ │
│  │   73%   │  │   72    │  │   62%   │ │
│  │Compliance│  │  Risk   │  │  Audit  │ │
│  └─────────┘  └─────────┘  └─────────┘ │
│                                         │
│  ── Insights ─────────────────────────  │
│                                         │
│  ⚠️ 3 gaps need attention              │
│  📅 2 deadlines this week              │
│  ✅ 5 tasks completed today            │
│                                         │
│  ── Recent Activity ──────────────────  │
│                                         │
│  [Contract uploaded - 2h ago]          │
│  [Task completed - 5h ago]             │
│                                         │
├─────────────────────────────────────────┤
│  🏠    💬    ➕    📋    👤            │
└─────────────────────────────────────────┘
```

**Mobile Optimizations:**

- **Score rings:** 80px diameter (large enough to read, small enough to fit 3 across)
- **Insights:** Icon + one-line summary
- **Activity:** Timestamp relative ("2h ago" not "April 16, 2026 10:30 AM")

### 5.3 Tasks (Monday.com Style)

**Purpose:** Structured, actionable task management

**Layout:**

```
┌─────────────────────────────────────────┐
│  [←] Tasks                 [Filter] [+]│
├─────────────────────────────────────────┤
│                                         │
│  [All] [Pending] [Overdue] [Done]      │
│                                         │
│  ┌─────────────────────────────────┐   │
│  │ 🔴 HIPAA Report          Due 3d │   │
│  │    [HIGH] [Review] [Complete]   │   │
│  └─────────────────────────────────┘   │
│                                         │
│  ┌─────────────────────────────────┐   │
│  │ 🟡 Policy Update         Due 7d │   │
│  │    [MED] [Review] [Complete]    │   │
│  └─────────────────────────────────┘   │
│                                         │
│  ┌─────────────────────────────────┐   │
│  │ 🟢 Training Complete     Done ✓ │   │
│  └─────────────────────────────────┘   │
│                                         │
├─────────────────────────────────────────┤
│  🏠    💬    ➕    📋    👤            │
└─────────────────────────────────────────┘
```

**Monday.com-inspired Features:**

| Feature | Implementation |
|---------|----------------|
| Status columns | Color-coded badges |
| Priority | Red/Yellow/Green dots |
| Assignee | Avatar circles |
| Due date | Relative time |
| Quick actions | Swipe to reveal |
| Bulk select | Long press to enter |

### 5.4 Onboarding Flow

**Purpose:** Streamlined new user experience

**Flow:** 4 steps maximum

```
Step 1: Welcome
┌─────────────────────────────────────────┐
│                                         │
│              [Logo]                     │
│                                         │
│         Welcome to REQUI                │
│                                         │
│  AI-powered compliance                  │
│  for healthcare teams                   │
│                                         │
│         [Get Started]                   │
│                                         │
│         [Skip → Login]                  │
│                                         │
└─────────────────────────────────────────┘

Step 2: Organization
┌─────────────────────────────────────────┐
│  [Progress: ●○○○]                       │
├─────────────────────────────────────────┤
│                                         │
│     Tell us about your org              │
│                                         │
│  ┌─────────────────────────┐           │
│  │ Organization name       │           │
│  └─────────────────────────┘           │
│                                         │
│  [Provider] [MSO] [Payer]              │
│                                         │
│         [Continue]                      │
│                                         │
└─────────────────────────────────────────┘

Step 3: Compliance Setup
┌─────────────────────────────────────────┐
│  [Progress: ●●●○]                       │
├─────────────────────────────────────────┤
│                                         │
│     Your compliance focus               │
│                                         │
│  ☑️ HIPAA                               │
│  ☐ FWA                                  │
│  ☑️ Quality Reporting                   │
│  ☐ State-specific                       │
│                                         │
│         [Continue]                      │
│                                         │
└─────────────────────────────────────────┘

Step 4: Ready
┌─────────────────────────────────────────┐
│  [Progress: ●●●●]                       │
├─────────────────────────────────────────┤
│                                         │
│         🎉 You're all set!              │
│                                         │
│  Start by uploading a                   │
│  contract or asking a                   │
│  question.                              │
│                                         │
│     [Upload Contract]                   │
│     [Ask a Question]                    │
│                                         │
└─────────────────────────────────────────┘
```

**Mobile Optimizations:**

- **One field per screen** (reduce cognitive load)
- **Smart defaults** (pre-select common options)
- **Skip option** always available
- **Progress indicator** (visual completion feedback)

### 5.5 Pricing Page

**Purpose:** Clear plan comparison with easy signup

**Layout:**

```
┌─────────────────────────────────────────┐
│  [←] Pricing                            │
├─────────────────────────────────────────┤
│                                         │
│     Simple, transparent                 │
│        pricing                          │
│                                         │
│  [Monthly] [Yearly - Save 20%]         │
│                                         │
│  ┌─────────────────────────────────┐   │
│  │ Starter         $99/mo          │   │
│  │ ─────────────────────────────── │   │
│  │ ✓ Up to 50 users                │   │
│  │ ✓ Basic AI queries              │   │
│  │ ✓ Task management               │   │
│  │                                 │   │
│  │      [Start Free Trial]         │   │
│  └─────────────────────────────────┘   │
│                                         │
│  ┌─────────────────────────────────┐   │
│  │ Professional    $299/mo         │   │
│  │ [MOST POPULAR]                  │   │
│  │ ─────────────────────────────── │   │
│  │ ✓ Unlimited users               │   │
│  │ ✓ Advanced AI                   │   │
│  │ ✓ CLM integrations              │   │
│  │                                 │   │
│  │      [Start Free Trial]         │   │
│  └─────────────────────────────────┘   │
│                                         │
│  ┌─────────────────────────────────┐   │
│  │ Enterprise      Custom          │   │
│  │ ─────────────────────────────── │   │
│  │ ✓ Everything in Pro             │   │
│  │ ✓ Custom integrations           │   │
│  │ ✓ Dedicated support             │   │
│  │                                 │   │
│  │      [Contact Sales]            │   │
│  └─────────────────────────────────┘   │
│                                         │
└─────────────────────────────────────────┘
```

**Mobile Optimizations:**

- **Vertical stack** (not side-by-side comparison)
- **Most popular** highlighted
- **One CTA per card** (clear action)
- **Swipe** between plans if needed

### 5.6 Legal Pages (Privacy, Terms)

**Purpose:** Complete legal content, mobile-readable

**Layout:**

```
┌─────────────────────────────────────────┐
│  [←] Privacy Policy                     │
├─────────────────────────────────────────┤
│                                         │
│  [Search this document...]              │
│                                         │
│  ── Contents ─────────────────────────  │
│                                         │
│  1. Information We Collect             │
│  2. How We Use Information             │
│  3. Data Sharing                       │
│  4. Your Rights                        │
│  5. Security                           │
│  6. Contact Us                         │
│                                         │
│  ── Section 1 ────────────────────────  │
│                                         │
│  We collect information...             │
│                                         │
│  [Read more]                           │
│                                         │
└─────────────────────────────────────────┘
```

**Mobile Optimizations:**

- **Collapsible sections** (expand/collapse)
- **Table of contents** (jump to section)
- **Search** (find specific terms)
- **Large text** (readable font size)
- **Adequate line height** (1.6 minimum)

---

## 6. Task System Redesign (Monday.com Style)

### 6.1 Visual Design

**Task Card Structure:**

```tsx
interface TaskCardProps {
  id: string;
  title: string;           // Short, action-oriented
  status: 'pending' | 'in-progress' | 'complete' | 'overdue';
  priority: 'critical' | 'high' | 'medium' | 'low';
  dueDate: Date;
  assignee?: User;
  tags: string[];
}
```

```
┌─────────────────────────────────────────┐
│ ● Task Title Here                [▶️]  │
│                                         │
│ [CRITICAL] [Due 2d] [👤]               │
│                                         │
│ ← Swipe for actions →                  │
└─────────────────────────────────────────┘
```

### 6.2 Status System

| Status | Color | Icon | Mobile Display |
|--------|-------|------|----------------|
| Pending | Gray | ○ | "To do" |
| In Progress | Blue | ◐ | "Doing" |
| Complete | Green | ● | "Done" |
| Overdue | Red | ⚠️ | "Overdue" |

### 6.3 Priority System

| Priority | Color | Badge | Mobile Display |
|----------|-------|-------|----------------|
| Critical | Red | 🔴 | "Critical" |
| High | Orange | 🟠 | "High" |
| Medium | Yellow | 🟡 | "Medium" |
| Low | Green | 🟢 | "Low" |

### 6.4 Interactions

**Swipe Actions:**

```
┌─────────────────────────────────────────┐
│ [Snooze] ← │ Task Title          │ → [✓]│
│            │ [HIGH] Due 2d              │
└─────────────────────────────────────────┘
```

| Direction | Action | Icon |
|-----------|--------|------|
| Swipe Left | Complete | ✓ |
| Swipe Right | Snooze | ⏰ |
| Long Press | More options | ⋯ |

**Quick Actions Menu:**

```
┌─────────────────────────────────────────┐
│                                         │
│  Task Title                             │
│                                         │
│  ── Actions ──────────────────────────  │
│                                         │
│  [✓] Mark complete                     │
│  [⏰] Snooze 1 day                     │
│  [👤] Reassign                         │
│  [📅] Change due date                  │
│  [🗑️] Delete                           │
│                                         │
│  [Cancel]                               │
│                                         │
└─────────────────────────────────────────┘
```

### 6.5 Task Detail View

```
┌─────────────────────────────────────────┐
│  [←] Task Details              [Edit]  │
├─────────────────────────────────────────┤
│                                         │
│  HIPAA Quarterly Report                 │
│                                         │
│  [🔴 Critical] [📅 Due Mar 31]         │
│                                         │
│  ── Description ──────────────────────  │
│                                         │
│  Submit quarterly compliance            │
│  report per HIPAA requirements.         │
│                                         │
│  ── Requirements ─────────────────────  │
│                                         │
│  Linked: HIPAA Security Rule            │
│                                         │
│  ── Activity ─────────────────────────  │
│                                         │
│  Created: Mar 1, 2026                  │
│  Assigned to: John Doe                 │
│                                         │
│  ┌─────────────────────────────────┐   │
│  │      [Mark Complete]            │   │
│  └─────────────────────────────────┘   │
│                                         │
└─────────────────────────────────────────┘
```

---

## 7. PWA Technical Setup

### 7.1 Web App Manifest

```json
{
  "name": "REQUI - Healthcare Compliance AI",
  "short_name": "REQUI",
  "description": "AI-powered compliance management for healthcare organizations",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#0f0f23",
  "theme_color": "#6366f1",
  "orientation": "portrait",
  "scope": "/",
  "lang": "en",
  "icons": [
    {
      "src": "/icons/icon-72x72.png",
      "sizes": "72x72",
      "type": "image/png",
      "purpose": "maskable any"
    },
    {
      "src": "/icons/icon-96x96.png",
      "sizes": "96x96",
      "type": "image/png",
      "purpose": "maskable any"
    },
    {
      "src": "/icons/icon-128x128.png",
      "sizes": "128x128",
      "type": "image/png",
      "purpose": "maskable any"
    },
    {
      "src": "/icons/icon-144x144.png",
      "sizes": "144x144",
      "type": "image/png",
      "purpose": "maskable any"
    },
    {
      "src": "/icons/icon-152x152.png",
      "sizes": "152x152",
      "type": "image/png",
      "purpose": "maskable any"
    },
    {
      "src": "/icons/icon-192x192.png",
      "sizes": "192x192",
      "type": "image/png",
      "purpose": "maskable any"
    },
    {
      "src": "/icons/icon-384x384.png",
      "sizes": "384x384",
      "type": "image/png",
      "purpose": "maskable any"
    },
    {
      "src": "/icons/icon-512x512.png",
      "sizes": "512x512",
      "type": "image/png",
      "purpose": "maskable any"
    }
  ],
  "categories": ["business", "productivity", "healthcare"],
  "screenshots": [
    {
      "src": "/screenshots/mobile-intelligence.png",
      "sizes": "750x1334",
      "type": "image/png",
      "form_factor": "narrow",
      "label": "AI Intelligence Interface"
    },
    {
      "src": "/screenshots/mobile-tasks.png",
      "sizes": "750x1334",
      "type": "image/png",
      "form_factor": "narrow",
      "label": "Task Management"
    }
  ],
  "shortcuts": [
    {
      "name": "New Query",
      "short_name": "Query",
      "description": "Ask the AI a question",
      "url": "/intelligence",
      "icons": [{ "src": "/icons/shortcut-query.png", "sizes": "96x96" }]
    },
    {
      "name": "My Tasks",
      "short_name": "Tasks",
      "description": "View your tasks",
      "url": "/tasks",
      "icons": [{ "src": "/icons/shortcut-tasks.png", "sizes": "96x96" }]
    }
  ]
}
```

### 7.2 Service Worker

```typescript
// sw/service-worker.ts

const CACHE_NAME = 'requi-pwa-v1';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icons/icon-192x192.png',
  '/icons/icon-512x512.png',
];

// Install: Cache static assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(STATIC_ASSETS);
    })
  );
  self.skipWaiting();
});

// Activate: Clean old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_NAME)
          .map((name) => caches.delete(name))
      );
    })
  );
  self.clients.claim();
});

// Fetch: Cache-first strategy for static, network-first for API
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // API requests: Network first, cache fallback
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(
      fetch(request)
        .then((response) => {
          // Cache successful GET requests
          if (request.method === 'GET' && response.ok) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(request, clone);
            });
          }
          return response;
        })
        .catch(() => {
          return caches.match(request);
        })
    );
    return;
  }

  // Static assets: Cache first
  event.respondWith(
    caches.match(request).then((cached) => {
      return cached || fetch(request);
    })
  );
});

// Background sync for offline actions
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-tasks') {
    event.waitUntil(syncPendingTasks());
  }
});

// Push notifications (future)
self.addEventListener('push', (event) => {
  const data = event.data?.json() ?? {};
  event.waitUntil(
    self.registration.showNotification(data.title ?? 'REQUI', {
      body: data.body,
      icon: '/icons/icon-192x192.png',
      badge: '/icons/badge-72x72.png',
      data: data.url,
    })
  );
});
```

### 7.3 Install Prompt Logic

```typescript
// hooks/usePWA.ts

import { useState, useEffect } from 'react';

interface PWAState {
  isInstallable: boolean;
  isInstalled: boolean;
  isStandalone: boolean;
  promptInstall: () => Promise<void>;
  dismissPrompt: () => void;
}

export const usePWA = (): PWAState => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);
  const [showPrompt, setShowPrompt] = useState(false);

  useEffect(() => {
    // Check if already installed
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
    setIsInstalled(isStandalone);

    // Listen for install prompt
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
      
      // Show prompt after 3 page views or 30 seconds
      setTimeout(() => {
        if (!isStandalone) setShowPrompt(true);
      }, 30000);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    // Listen for app installed
    window.addEventListener('appinstalled', () => {
      setIsInstalled(true);
      setIsInstallable(false);
      setDeferredPrompt(null);
    });

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const promptInstall = async () => {
    if (!deferredPrompt) return;
    
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    
    if (outcome === 'accepted') {
      setIsInstalled(true);
    }
    setDeferredPrompt(null);
    setIsInstallable(false);
  };

  const dismissPrompt = () => {
    setShowPrompt(false);
  };

  return {
    isInstallable,
    isInstalled,
    isStandalone: window.matchMedia('(display-mode: standalone)').matches,
    promptInstall,
    dismissPrompt,
  };
};
```

### 7.4 Install Prompt UI

```tsx
// components/InstallPrompt.tsx

export const InstallPrompt = () => {
  const { isInstallable, isInstalled, promptInstall, dismissPrompt } = usePWA();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // Show after delay if installable
    if (isInstallable && !isInstalled) {
      const timer = setTimeout(() => setVisible(true), 5000);
      return () => clearTimeout(timer);
    }
  }, [isInstallable, isInstalled]);

  if (!visible || !isInstallable || isInstalled) return null;

  return (
    <div className="fixed bottom-20 left-4 right-4 bg-white rounded-xl shadow-lg p-4 z-50 animate-slide-up">
      <div className="flex items-start gap-3">
        <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center">
          <img src="/icons/icon-48x48.png" alt="REQUI" className="w-8 h-8" />
        </div>
        <div className="flex-1">
          <h3 className="font-semibold text-gray-900">Add REQUI to Home Screen</h3>
          <p className="text-sm text-gray-600 mt-1">
            Install for quick access and offline support
          </p>
        </div>
        <button onClick={dismissPrompt} className="text-gray-400">
          ✕
        </button>
      </div>
      <div className="flex gap-2 mt-4">
        <button 
          onClick={dismissPrompt}
          className="flex-1 py-2 px-4 rounded-lg border border-gray-200 text-gray-700"
        >
          Not now
        </button>
        <button 
          onClick={promptInstall}
          className="flex-1 py-2 px-4 rounded-lg bg-indigo-600 text-white font-medium"
        >
          Install
        </button>
      </div>
    </div>
  );
};
```

### 7.5 Vite PWA Configuration

```typescript
// vite.config.ts

import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      injectRegister: 'auto',
      workbox: {
        globPatterns: ['**/*.{js,css,html,ico,png,svg,woff2}'],
        runtimeCaching: [
          {
            urlPattern: /^https://api\.requi\.com\/.*/i,
            handler: 'NetworkFirst',
            options: {
              cacheName: 'api-cache',
              expiration: {
                maxEntries: 100,
                maxAgeSeconds: 60 * 60 * 24, // 24 hours
              },
            },
          },
          {
            urlPattern: /^https:\/\/.+\.amazonaws\.com\/.*/i,
            handler: 'CacheFirst',
            options: {
              cacheName: 's3-assets',
              expiration: {
                maxEntries: 50,
                maxAgeSeconds: 60 * 60 * 24 * 7, // 7 days
              },
            },
          },
        ],
      },
      manifest: {
        name: 'REQUI - Healthcare Compliance AI',
        short_name: 'REQUI',
        description: 'AI-powered compliance management for healthcare',
        theme_color: '#6366f1',
        background_color: '#0f0f23',
        display: 'standalone',
        scope: '/',
        start_url: '/',
        icons: [
          { src: '/icons/icon-192x192.png', sizes: '192x192', type: 'image/png' },
          { src: '/icons/icon-512x512.png', sizes: '512x512', type: 'image/png' },
        ],
      },
    }),
  ],
  build: {
    outDir: 'pwa-dist',
    sourcemap: true,
  },
});
```

---

## 8. UI Consistency Rules

### 8.1 Brand Alignment

| Element | Desktop | Mobile PWA | Rule |
|---------|---------|------------|------|
| Primary Color | `#6366f1` | `#6366f1` | Identical |
| Secondary Color | `#8b5cf6` | `#8b5cf6` | Identical |
| Background | `#0f0f23` | `#0f0f23` | Identical |
| Text Primary | `#ffffff` | `#ffffff` | Identical |
| Text Secondary | `#94a3b8` | `#94a3b8` | Identical |
| Font Family | Inter | Inter | Identical |
| Logo | Full SVG | Simplified SVG | Maintain recognition |

### 8.2 Component Mapping

| Desktop Component | Mobile Equivalent | Notes |
|-------------------|-------------------|-------|
| Sidebar navigation | Bottom tab bar | 5 tabs max |
| Full-width tables | Card lists | Swipeable rows |
| Multi-column layout | Single column stack | Full-width cards |
| Hover tooltips | Tap to reveal | Long press for info |
| Right-click menus | Action sheets | Bottom sheet UI |
| Modal dialogs | Full-screen sheets | Slide up from bottom |
| Pagination | Infinite scroll | Load more on scroll |

### 8.3 Typography Scale

```css
/* Mobile-optimized type scale */
--text-xs: 12px;     /* Captions, labels */
--text-sm: 14px;     /* Secondary text */
--text-base: 16px;   /* Body text (min for readability) */
--text-lg: 18px;     /* Emphasized body */
--text-xl: 20px;     /* Small headings */
--text-2xl: 24px;    /* Section headings */
--text-3xl: 30px;    /* Page titles */

/* Line heights */
--leading-tight: 1.25;   /* Headings */
--leading-normal: 1.5;   /* Body text */
--leading-relaxed: 1.75; /* Long-form content */
```

### 8.4 Spacing Consistency

| Context | Desktop | Mobile |
|---------|---------|--------|
| Page padding | 24px | 16px |
| Card padding | 24px | 16px |
| Section gap | 32px | 24px |
| Element gap | 16px | 12px |
| Button height | 44px | 48px (larger for touch) |
| Input height | 44px | 48px |

---

## 9. Final Implementation Notes

### 9.1 Build Commands

```bash
# Initialize project
cd /mnt/okcomputer/output
mkdir requi-pwa
cd requi-pwa

# Setup with Vite + React + TypeScript
npm create vite@latest . -- --template react-ts

# Install dependencies
npm install

# Install PWA plugin
npm install vite-plugin-pwa -D

# Install UI dependencies
npm install @radix-ui/react-* lucide-react class-variance-authority clsx tailwind-merge

# Install shadcn/ui components
npx shadcn add button card input badge tabs scroll-area sheet

# Development server
npm run dev

# Production build
npm run build

# Preview production build
npm run preview
```

### 9.2 Deployment Checklist

- [ ] Build completes without errors
- [ ] All icons generated (72x72 through 512x512)
- [ ] Manifest.json validated (https://manifest-validator.appspot.com/)
- [ ] Service Worker registers successfully
- [ ] Lighthouse PWA audit passes
- [ ] All pages render correctly on iOS Safari
- [ ] All pages render correctly on Android Chrome
- [ ] Install prompt works on both platforms
- [ ] Offline mode shows appropriate UI
- [ ] Touch targets are minimum 44px
- [ ] Font sizes are minimum 16px for inputs

### 9.3 Testing Requirements

| Test Type | Tool | Target |
|-----------|------|--------|
| PWA Audit | Lighthouse | Score > 90 |
| Performance | Lighthouse | Score > 90 |
| Accessibility | axe-core | 0 violations |
| Responsiveness | Chrome DevTools | iPhone SE → iPad Pro |
| Offline | Network throttling | Graceful degradation |
| Install | Real devices | Works on iOS + Android |

### 9.4 File Output Location

```
/mnt/okcomputer/output/requi-pwa/
├── src/           # Source code
├── public/        # Static assets
├── pwa-dist/      # Build output (deploy this)
└── README.md      # Setup instructions
```

### 9.5 Key Decisions Summary

| Decision | Rationale |
|----------|-----------|
| Separate codebase | Zero risk to desktop, independent deployment |
| Bottom navigation | Thumb-friendly, native app pattern |
| Monday.com tasks | Users familiar, proven UX |
| 4-step onboarding | Minimizes friction, higher completion |
| Cache-first static | Fast load, offline support |
| Network-first API | Fresh data, offline fallback |

---

## Appendix: Mobile-First CSS Framework

```css
/* src/styles/mobile-optimizations.css */

/* Safe area insets for notched devices */
@supports (padding-top: env(safe-area-inset-top)) {
  .safe-top {
    padding-top: env(safe-area-inset-top);
  }
  .safe-bottom {
    padding-bottom: env(safe-area-inset-bottom);
  }
}

/* Prevent text size adjustment on orientation change */
html {
  -webkit-text-size-adjust: 100%;
  -ms-text-size-adjust: 100%;
}

/* Smooth scrolling */
html {
  scroll-behavior: smooth;
  -webkit-overflow-scrolling: touch;
}

/* Remove tap highlight on mobile */
* {
  -webkit-tap-highlight-color: transparent;
}

/* Prevent pull-to-refresh on PWA */
body {
  overscroll-behavior-y: none;
}

/* Touch action optimization */
.swipeable {
  touch-action: pan-y;
  user-select: none;
}

/* Hardware acceleration for animations */
.animate-gpu {
  transform: translateZ(0);
  will-change: transform;
}

/* Reduced motion preference */
@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
```

---

**Document Status:** Complete  
**Next Step:** Initialize project and begin implementation
