'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { 
  Shield, 
  LayoutDashboard, 
  CheckCircle, 
  AlertTriangle, 
  Calendar, 
  FileText, 
  Bell,
  Settings,
  Users,
  BookOpen,
  ChevronRight,
  TrendingUp,
  TrendingDown,
  Clock
} from 'lucide-react';
import toast from 'react-hot-toast';

// Mock data for demo
const MOCK_DATA = {
  complianceScore: 78,
  riskScore: 42,
  auditReadiness: 65,
  trialDaysRemaining: 18,
  upcomingDeadlines: [
    { id: 1, title: 'Annual HIPAA Risk Assessment', date: 'Jan 15, 2024', daysLeft: 8, type: 'critical' },
    { id: 2, title: 'Quarterly FWA Report', date: 'Jan 22, 2024', daysLeft: 15, type: 'high' },
    { id: 3, title: 'Network Adequacy Review', date: 'Feb 1, 2024', daysLeft: 25, type: 'medium' },
  ],
  priorityActions: [
    { id: 1, title: 'Review updated HIPAA Security Rule requirements', completed: false },
    { id: 2, title: 'Complete Q4 FWA training attestation', completed: false },
    { id: 3, title: 'Upload evidence for network adequacy audit', completed: true },
  ],
  recentIntelligence: [
    { id: 1, title: 'CMS Final Rule: Medicare Advantage and Part D', source: 'CMS', date: '2 hours ago', type: 'federal' },
    { id: 2, title: 'Texas Medicaid: HB 21 Implementation Guidance', source: 'Texas HHS', date: '1 day ago', type: 'state' },
    { id: 3, title: 'OIG Work Plan Updates for 2024', source: 'OIG', date: '2 days ago', type: 'federal' },
  ],
  gaps: {
    critical: 2,
    high: 5,
    medium: 4,
    low: 3
  }
};

interface User {
  name: string;
  email: string;
  role: string;
  organization: string;
}

export default function DashboardPage() {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for logged in user
    const storedUser = localStorage.getItem('user');
    const token = localStorage.getItem('token');
    
    if (!token || !storedUser) {
      router.push('/login');
      return;
    }
    
    setUser(JSON.parse(storedUser));
    setIsLoading(false);
  }, [router]);

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    if (score >= 40) return 'text-orange-600';
    return 'text-red-600';
  };

  const getScoreBg = (score: number) => {
    if (score >= 80) return 'bg-green-100';
    if (score >= 60) return 'bg-yellow-100';
    if (score >= 40) return 'bg-orange-100';
    return 'bg-red-100';
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Trial Banner */}
      <div className="bg-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Clock className="w-5 h-5" />
              <span className="font-medium">
                Your trial ends in {MOCK_DATA.trialDaysRemaining} days
              </span>
              <span className="text-blue-200">
                — Upgrade to keep full access
              </span>
            </div>
            <Link href="/organization/billing">
              <Button size="sm" className="bg-white text-blue-600 hover:bg-blue-50">
                Upgrade Now
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-900">Requi Health</span>
                <Badge variant="blue" className="text-xs">v2.0</Badge>
              </div>
            </div>

            {/* Navigation */}
            <nav className="hidden md:flex items-center gap-1">
              <Link href="/dashboard" className="px-4 py-2 rounded-lg bg-blue-50 text-blue-700 font-medium text-sm">
                Dashboard
              </Link>
              <Link href="/compliance" className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-50 font-medium text-sm">
                Compliance
              </Link>
              <Link href="/tasks" className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-50 font-medium text-sm">
                Tasks
              </Link>
              <Link href="/intelligence" className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-50 font-medium text-sm">
                Intelligence
              </Link>
            </nav>

            {/* Right Side */}
            <div className="flex items-center gap-3">
              <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg">
                <Bell className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-3 pl-3 border-l border-slate-200">
                <div className="text-right hidden sm:block">
                  <p className="text-sm font-medium text-slate-900">{user?.name}</p>
                  <p className="text-xs text-slate-500">{user?.organization}</p>
                </div>
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-blue-700 font-medium">
                    {user?.name?.charAt(0) || 'U'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-slate-900">
            Good morning, {user?.name?.split(' ')[0]} 👋
          </h1>
          <p className="text-slate-500 mt-1">
            You have {MOCK_DATA.upcomingDeadlines.length} deadlines this week and {MOCK_DATA.gaps.critical} critical gaps to address
          </p>
        </div>

        {/* Score Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Compliance Score */}
          <Card className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">Compliance Score</p>
                <p className={`text-4xl font-bold mt-2 ${getScoreColor(MOCK_DATA.complianceScore)}`}>
                  {MOCK_DATA.complianceScore}
                  <span className="text-lg text-slate-400 font-normal">/100</span>
                </p>
                <div className="flex items-center gap-1 mt-2 text-green-600 text-sm">
                  <TrendingUp className="w-4 h-4" />
                  <span>+5 this month</span>
                </div>
              </div>
              <div className={`w-16 h-16 rounded-full flex items-center justify-center ${getScoreBg(MOCK_DATA.complianceScore)}`}>
                <CheckCircle className={`w-8 h-8 ${getScoreColor(MOCK_DATA.complianceScore)}`} />
              </div>
            </div>
            <div className="mt-4 pt-4 border-t border-slate-100">
              <Link href="/compliance" className="text-sm text-blue-600 hover:underline flex items-center gap-1">
                View details <ChevronRight className="w-4 h-4" />
              </Link>
            </div>
          </Card>

          {/* Risk Score */}
          <Card className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">Risk Score</p>
                <p className={`text-4xl font-bold mt-2 ${getScoreColor(100 - MOCK_DATA.riskScore)}`}>
                  {MOCK_DATA.riskScore}
                  <span className="text-lg text-slate-400 font-normal">/100</span>
                </p>
                <div className="flex items-center gap-1 mt-2 text-red-600 text-sm">
                  <TrendingUp className="w-4 h-4" />
                  <span>+2 this month</span>
                </div>
              </div>
              <div className={`w-16 h-16 rounded-full flex items-center justify-center ${getScoreBg(100 - MOCK_DATA.riskScore)}`}>
                <AlertTriangle className={`w-8 h-8 ${getScoreColor(100 - MOCK_DATA.riskScore)}`} />
              </div>
            </div>
            <div className="mt-4 pt-4 border-t border-slate-100">
              <Link href="/compliance/gaps" className="text-sm text-blue-600 hover:underline flex items-center gap-1">
                View gaps <ChevronRight className="w-4 h-4" />
              </Link>
            </div>
          </Card>

          {/* Audit Readiness */}
          <Card className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">Audit Readiness</p>
                <p className={`text-4xl font-bold mt-2 ${getScoreColor(MOCK_DATA.auditReadiness)}`}>
                  {MOCK_DATA.auditReadiness}
                  <span className="text-lg text-slate-400 font-normal">/100</span>
                </p>
                <div className="flex items-center gap-1 mt-2 text-green-600 text-sm">
                  <TrendingUp className="w-4 h-4" />
                  <span>+8 this month</span>
                </div>
              </div>
              <div className={`w-16 h-16 rounded-full flex items-center justify-center ${getScoreBg(MOCK_DATA.auditReadiness)}`}>
                <FileText className={`w-8 h-8 ${getScoreColor(MOCK_DATA.auditReadiness)}`} />
              </div>
            </div>
            <div className="mt-4 pt-4 border-t border-slate-100">
              <Link href="/compliance/documents" className="text-sm text-blue-600 hover:underline flex items-center gap-1">
                View documents <ChevronRight className="w-4 h-4" />
              </Link>
            </div>
          </Card>
        </div>

        {/* Two Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - 2/3 */}
          <div className="lg:col-span-2 space-y-8">
            {/* Upcoming Deadlines */}
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-slate-400" />
                  Upcoming Deadlines
                </h2>
                <Link href="/tasks/calendar" className="text-sm text-blue-600 hover:underline">
                  View Calendar
                </Link>
              </div>
              <div className="space-y-4">
                {MOCK_DATA.upcomingDeadlines.map((deadline) => (
                  <div key={deadline.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        deadline.type === 'critical' ? 'bg-red-100' :
                        deadline.type === 'high' ? 'bg-orange-100' : 'bg-blue-100'
                      }`}>
                        <Calendar className={`w-5 h-5 ${
                          deadline.type === 'critical' ? 'text-red-600' :
                          deadline.type === 'high' ? 'text-orange-600' : 'text-blue-600'
                        }`} />
                      </div>
                      <div>
                        <p className="font-medium text-slate-900">{deadline.title}</p>
                        <p className="text-sm text-slate-500">Due {deadline.date}</p>
                      </div>
                    </div>
                    <Badge variant={deadline.type === 'critical' ? 'red' : deadline.type === 'high' ? 'orange' : 'blue'}>
                      {deadline.daysLeft} days
                    </Badge>
                  </div>
                ))}
              </div>
            </Card>

            {/* Priority Actions */}
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-slate-400" />
                  Priority Actions
                </h2>
                <Link href="/tasks" className="text-sm text-blue-600 hover:underline">
                  View All Tasks
                </Link>
              </div>
              <div className="space-y-3">
                {MOCK_DATA.priorityActions.map((action) => (
                  <div key={action.id} className="flex items-center gap-4 p-4 border border-slate-200 rounded-lg">
                    <div className={`w-6 h-6 rounded border-2 flex items-center justify-center ${
                      action.completed ? 'bg-green-500 border-green-500' : 'border-slate-300'
                    }`}>
                      {action.completed && <CheckCircle className="w-4 h-4 text-white" />}
                    </div>
                    <span className={`flex-1 ${action.completed ? 'text-slate-400 line-through' : 'text-slate-700'}`}>
                      {action.title}
                    </span>
                    {!action.completed && (
                      <Button size="sm" variant="outline">Start</Button>
                    )}
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Right Column - 1/3 */}
          <div className="space-y-8">
            {/* Compliance Gaps Summary */}
            <Card className="p-6">
              <h2 className="text-lg font-semibold text-slate-900 mb-4 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-slate-400" />
                Compliance Gaps
              </h2>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-red-500" />
                    <span className="text-slate-600">Critical</span>
                  </div>
                  <span className="font-semibold text-red-600">{MOCK_DATA.gaps.critical}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-orange-500" />
                    <span className="text-slate-600">High</span>
                  </div>
                  <span className="font-semibold text-orange-600">{MOCK_DATA.gaps.high}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-yellow-500" />
                    <span className="text-slate-600">Medium</span>
                  </div>
                  <span className="font-semibold text-yellow-600">{MOCK_DATA.gaps.medium}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-blue-500" />
                    <span className="text-slate-600">Low</span>
                  </div>
                  <span className="font-semibold text-blue-600">{MOCK_DATA.gaps.low}</span>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-slate-100">
                <Link href="/compliance/gaps">
                  <Button variant="outline" className="w-full">
                    View All Gaps
                  </Button>
                </Link>
              </div>
            </Card>

            {/* Recent Intelligence */}
            <Card className="p-6">
              <h2 className="text-lg font-semibold text-slate-900 mb-4 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-slate-400" />
                Recent Intelligence
              </h2>
              <div className="space-y-4">
                {MOCK_DATA.recentIntelligence.map((item) => (
                  <div key={item.id} className="group cursor-pointer">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <FileText className="w-4 h-4 text-blue-600" />
                      </div>
                      <div>
                        <p className="font-medium text-slate-900 group-hover:text-blue-600 transition-colors line-clamp-2">
                          {item.title}
                        </p>
                        <div className="flex items-center gap-2 mt-1 text-xs text-slate-500">
                          <span>{item.source}</span>
                          <span>•</span>
                          <span>{item.date}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 pt-4 border-t border-slate-100">
                <Link href="/intelligence" className="text-sm text-blue-600 hover:underline flex items-center gap-1">
                  View all updates <ChevronRight className="w-4 h-4" />
                </Link>
              </div>
            </Card>

            {/* Quick Links */}
            <Card className="p-6">
              <h2 className="text-lg font-semibold text-slate-900 mb-4">Quick Links</h2>
              <div className="space-y-2">
                <Link href="/organization/billing" className="flex items-center gap-3 p-3 rounded-lg hover:bg-slate-50 transition-colors">
                  <Settings className="w-5 h-5 text-slate-400" />
                  <span className="text-slate-700">Billing & Plan</span>
                </Link>
                <Link href="/organization/team" className="flex items-center gap-3 p-3 rounded-lg hover:bg-slate-50 transition-colors">
                  <Users className="w-5 h-5 text-slate-400" />
                  <span className="text-slate-700">Team Members</span>
                </Link>
                <Link href="/support" className="flex items-center gap-3 p-3 rounded-lg hover:bg-slate-50 transition-colors">
                  <Bell className="w-5 h-5 text-slate-400" />
                  <span className="text-slate-700">Help & Support</span>
                </Link>
              </div>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
