import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule } from '@nestjs/throttler';
import { ScheduleModule } from '@nestjs/schedule';

// Feature modules
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { WorkspacesModule } from './workspaces/workspaces.module';
import { ConversationsModule } from './conversations/conversations.module';
import { SourcesModule } from './sources/sources.module';
import { MissingKnowledgeModule } from './missing-knowledge/missing-knowledge.module';
import { HealthModule } from './health/health.module';
import { BillingModule } from './billing/billing.module';

// WebSocket
import { ChatGateway } from './websocket/chat.gateway';

// Common modules
import { PrismaModule } from './prisma/prisma.module';
import { RedisModule } from './redis/redis.module';
import { AiModule } from './ai/ai.module';
import { VectorStoreModule } from './vector-store/vector-store.module';
import { QueueModule } from './queue/queue.module';
import { NotificationModule } from './notification/notification.module';

@Module({
  imports: [
    // Configuration
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: ['.env', '../../.env'],
    }),

    // Rate limiting
    ThrottlerModule.forRoot([
      {
        name: 'short',
        ttl: 1000,
        limit: 10,
      },
      {
        name: 'long',
        ttl: 60000,
        limit: 100,
      },
    ]),

    // Scheduling
    ScheduleModule.forRoot(),

    // Common modules
    PrismaModule,
    RedisModule,
    AiModule,
    VectorStoreModule,
    QueueModule,
    NotificationModule,

    // Feature modules
    AuthModule,
    UsersModule,
    WorkspacesModule,
    ConversationsModule,
    SourcesModule,
    MissingKnowledgeModule,
    HealthModule,
    BillingModule,
  ],
  providers: [ChatGateway],
})
export class AppModule {}
