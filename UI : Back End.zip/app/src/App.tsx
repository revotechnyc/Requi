import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useState, createContext, useContext } from 'react';
import { SplashScreen } from './pages/SplashScreen';
import { Login } from './pages/Login';
import { SignUp } from './pages/SignUp';
import { Onboarding } from './pages/Onboarding';
import { Dashboard } from './pages/Dashboard';
import { AIWorkspace } from './pages/AIWorkspace';
import { Library } from './pages/Library';
import { Files } from './pages/Files';
import { Templates } from './pages/Templates';
import { Teams } from './pages/Teams';
import { AdminConsole } from './pages/AdminConsole';
import { Billing } from './pages/Billing';
import { Settings } from './pages/Settings';
import { Profile } from './pages/Profile';

// Auth Context
interface AuthContextType {
  isAuthenticated: boolean;
  user: User | null;
  login: (user: User) => void;
  logout: () => void;
}

interface User {
  id: string;
  name: string;
  email: string;
  role: 'owner' | 'admin' | 'manager' | 'contributor' | 'viewer';
  workspace: string;
  avatar?: string;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<User | null>(null);

  const login = (userData: User) => {
    setUser(userData);
    setIsAuthenticated(true);
  };

  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, user, login, logout }}>
      <Router>
        <Routes>
          <Route path="/" element={<SplashScreen />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/onboarding" element={
            isAuthenticated ? <Onboarding /> : <Navigate to="/login" />
          } />
          <Route path="/dashboard" element={
            isAuthenticated ? <Dashboard /> : <Navigate to="/login" />
          } />
          <Route path="/workspace" element={
            isAuthenticated ? <AIWorkspace /> : <Navigate to="/login" />
          } />
          <Route path="/library" element={
            isAuthenticated ? <Library /> : <Navigate to="/login" />
          } />
          <Route path="/files" element={
            isAuthenticated ? <Files /> : <Navigate to="/login" />
          } />
          <Route path="/templates" element={
            isAuthenticated ? <Templates /> : <Navigate to="/login" />
          } />
          <Route path="/teams" element={
            isAuthenticated ? <Teams /> : <Navigate to="/login" />
          } />
          <Route path="/admin" element={
            isAuthenticated ? <AdminConsole /> : <Navigate to="/login" />
          } />
          <Route path="/billing" element={
            isAuthenticated ? <Billing /> : <Navigate to="/login" />
          } />
          <Route path="/settings" element={
            isAuthenticated ? <Settings /> : <Navigate to="/login" />
          } />
          <Route path="/profile" element={
            isAuthenticated ? <Profile /> : <Navigate to="/login" />
          } />
        </Routes>
      </Router>
    </AuthContext.Provider>
  );
}

export default App;
