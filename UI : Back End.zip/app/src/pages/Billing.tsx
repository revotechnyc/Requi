import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Sparkles, CreditCard, Check, Download, Calendar,
  Users
} from 'lucide-react';

export function Billing() {
  const navigate = useNavigate();
  const [selectedPlan, setSelectedPlan] = useState('growth');

  const plans = [
    {
      id: 'starter',
      name: 'Starter',
      seats: 15,
      pricePerUser: 400,
      totalPrice: 6000,
      discount: 0,
      features: [
        'All compliance modules',
        'Federal + 3 states',
        'Email support',
        'Basic analytics',
      ],
    },
    {
      id: 'growth',
      name: 'Growth',
      seats: 30,
      pricePerUser: 384,
      totalPrice: 11520,
      discount: 4,
      features: [
        'All compliance modules',
        'Federal + 10 states',
        'Priority support',
        'Advanced analytics',
        'Template engine',
      ],
      popular: true,
    },
    {
      id: 'enterprise',
      name: 'Enterprise',
      seats: 50,
      pricePerUser: 368,
      totalPrice: 18400,
      discount: 8,
      features: [
        'All compliance modules',
        'All 50 states + territories',
        'Dedicated support',
        'Custom integrations',
        'Template engine',
        'Admin console',
        'SSO & SAML',
      ],
    },
  ];

  const invoices = [
    { id: 'INV-2025-001', date: 'Apr 1, 2025', amount: 11520, status: 'paid' },
    { id: 'INV-2025-002', date: 'Mar 1, 2025', amount: 11520, status: 'paid' },
    { id: 'INV-2025-003', date: 'Feb 1, 2025', amount: 11520, status: 'paid' },
  ];

  return (
    <div className="min-h-screen bg-[#F8F8F8]">
      {/* Header */}
      <header className="bg-white border-b border-[#E5E7EB] px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => navigate('/workspace')}
              className="p-2 hover:bg-[#F3F4F6] rounded-lg transition-colors"
            >
              <Sparkles className="w-5 h-5 text-[#6B7280]" />
            </button>
            <div>
              <h1 className="text-xl font-semibold text-[#121212]">Billing</h1>
              <p className="text-sm text-[#6B7280]">Manage your subscription and payments</p>
            </div>
          </div>
        </div>
      </header>

      <main className="p-8">
        <div className="max-w-5xl mx-auto">
          {/* Current Plan */}
          <div className="bg-gradient-to-br from-[#C3ACFF] to-[#CBD5FF] rounded-2xl p-8 mb-8">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="px-3 py-1 bg-white/20 text-white rounded-full text-sm font-medium">
                    Current Plan
                  </span>
                </div>
                <h2 className="text-3xl font-bold text-white mb-2">Growth Plan</h2>
                <p className="text-white/80 mb-4">30 users · $11,520/year · Renews April 1, 2026</p>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2 text-white/80">
                    <Users className="w-4 h-4" />
                    <span className="text-sm">24 of 30 seats used</span>
                  </div>
                  <div className="flex items-center gap-2 text-white/80">
                    <Calendar className="w-4 h-4" />
                    <span className="text-sm">14 days remaining in trial</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <p className="text-4xl font-bold text-white">$11,520</p>
                <p className="text-white/80">per year</p>
              </div>
            </div>
          </div>

          {/* Plan Selection */}
          <div className="mb-12">
            <h2 className="text-lg font-semibold text-[#121212] mb-6">Select Plan</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {plans.map((plan) => (
                <div
                  key={plan.id}
                  onClick={() => setSelectedPlan(plan.id)}
                  className={`relative bg-white rounded-2xl p-6 cursor-pointer transition-all ${
                    selectedPlan === plan.id
                      ? 'ring-2 ring-[#C3ACFF] shadow-elevated'
                      : 'shadow-soft hover:shadow-elevated'
                  }`}
                >
                  {plan.popular && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-[#C3ACFF] text-white text-xs font-medium rounded-full">
                      Most Popular
                    </div>
                  )}
                  
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold text-[#121212]">{plan.name}</h3>
                    {selectedPlan === plan.id && (
                      <div className="w-6 h-6 rounded-full bg-[#C3ACFF] flex items-center justify-center">
                        <Check className="w-4 h-4 text-white" />
                      </div>
                    )}
                  </div>

                  <div className="mb-4">
                    <span className="text-3xl font-bold text-[#121212]">${plan.totalPrice.toLocaleString()}</span>
                    <span className="text-[#6B7280]">/year</span>
                  </div>

                  <p className="text-sm text-[#6B7280] mb-4">
                    {plan.seats} users · ${plan.pricePerUser}/user
                    {plan.discount > 0 && (
                      <span className="ml-2 px-2 py-0.5 bg-green-100 text-green-700 text-xs rounded-full">
                        {plan.discount}% off
                      </span>
                    )}
                  </p>

                  <ul className="space-y-2 mb-6">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-center gap-2 text-sm text-[#6B7280]">
                        <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>

                  <button
                    className={`w-full py-3 rounded-xl font-semibold transition-colors ${
                      selectedPlan === plan.id
                        ? 'bg-[#121212] text-white'
                        : 'bg-[#F3F4F6] text-[#121212] hover:bg-[#E5E7EB]'
                    }`}
                  >
                    {selectedPlan === plan.id ? 'Current Plan' : 'Select Plan'}
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Payment Method */}
          <div className="bg-white rounded-2xl p-6 shadow-soft mb-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-semibold text-[#121212]">Payment Method</h3>
              <button className="text-sm font-medium text-[#C3ACFF] hover:text-[#A88FEF] transition-colors">
                + Add New
              </button>
            </div>
            <div className="flex items-center gap-4 p-4 bg-[#F9FAFB] rounded-xl">
              <div className="w-12 h-8 bg-[#1A1F71] rounded flex items-center justify-center">
                <span className="text-white text-xs font-bold">VISA</span>
              </div>
              <div className="flex-1">
                <p className="font-medium text-[#121212]">Visa ending in 4242</p>
                <p className="text-sm text-[#6B7280]">Expires 12/26</p>
              </div>
              <span className="px-3 py-1 bg-green-100 text-green-700 text-sm font-medium rounded-full">
                Default
              </span>
            </div>
          </div>

          {/* Invoice History */}
          <div className="bg-white rounded-2xl p-6 shadow-soft">
            <h3 className="font-semibold text-[#121212] mb-6">Invoice History</h3>
            <div className="space-y-3">
              {invoices.map((invoice) => (
                <div
                  key={invoice.id}
                  className="flex items-center justify-between p-4 bg-[#F9FAFB] rounded-xl"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg bg-[#C3ACFF]/10 flex items-center justify-center">
                      <CreditCard className="w-5 h-5 text-[#C3ACFF]" />
                    </div>
                    <div>
                      <p className="font-medium text-[#121212]">{invoice.id}</p>
                      <p className="text-sm text-[#6B7280]">{invoice.date}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="font-semibold text-[#121212]">${invoice.amount.toLocaleString()}</span>
                    <span className="px-3 py-1 bg-green-100 text-green-700 text-sm font-medium rounded-full">
                      {invoice.status}
                    </span>
                    <button className="p-2 hover:bg-white rounded-lg transition-colors">
                      <Download className="w-4 h-4 text-[#9CA3AF]" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
