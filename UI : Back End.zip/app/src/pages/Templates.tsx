import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Sparkles, Plus, Search, FileText, MoreHorizontal, Edit,
  Check, ChevronRight, Upload, Layout, Shield
} from 'lucide-react';

interface Template {
  id: string;
  name: string;
  description: string;
  category: string;
  usageCount: number;
  lastUsed: string;
  status: 'approved' | 'pending' | 'locked';
  letterhead?: boolean;
}

export function Templates() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    { id: 'all', name: 'All Templates' },
    { id: 'legal', name: 'Legal Documents' },
    { id: 'compliance', name: 'Compliance' },
    { id: 'contracts', name: 'Contracts' },
    { id: 'communications', name: 'Communications' },
    { id: 'reports', name: 'Reports' },
  ];

  const templates: Template[] = [
    {
      id: '1',
      name: 'Legal Memo Template',
      description: 'Standard legal memorandum with company letterhead',
      category: 'legal',
      usageCount: 245,
      lastUsed: '2 hours ago',
      status: 'approved',
      letterhead: true,
    },
    {
      id: '2',
      name: 'Compliance Checklist',
      description: 'Federal and state compliance verification checklist',
      category: 'compliance',
      usageCount: 189,
      lastUsed: 'Yesterday',
      status: 'approved',
    },
    {
      id: '3',
      name: 'Provider Contract Review',
      description: 'Template for reviewing managed care provider contracts',
      category: 'contracts',
      usageCount: 156,
      lastUsed: '3 days ago',
      status: 'approved',
      letterhead: true,
    },
    {
      id: '4',
      name: 'Regulatory Update Notice',
      description: 'Internal communication for new regulatory requirements',
      category: 'communications',
      usageCount: 98,
      lastUsed: '1 week ago',
      status: 'pending',
    },
    {
      id: '5',
      name: 'Quarterly Compliance Report',
      description: 'Executive summary of compliance activities',
      category: 'reports',
      usageCount: 67,
      lastUsed: '2 weeks ago',
      status: 'locked',
    },
    {
      id: '6',
      name: 'HIPAA Breach Notification',
      description: 'Required notification template for privacy breaches',
      category: 'compliance',
      usageCount: 12,
      lastUsed: '1 month ago',
      status: 'approved',
      letterhead: true,
    },
  ];

  const filteredTemplates = templates.filter(t => 
    (selectedCategory === 'all' || t.category === selectedCategory) &&
    (t.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
     t.description.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="min-h-screen bg-[#F8F8F8]">
      {/* Header */}
      <header className="bg-white border-b border-[#E5E7EB] px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => navigate('/workspace')}
              className="p-2 hover:bg-[#F3F4F6] rounded-lg transition-colors"
            >
              <Sparkles className="w-5 h-5 text-[#6B7280]" />
            </button>
            <div>
              <h1 className="text-xl font-semibold text-[#121212]">Templates</h1>
              <p className="text-sm text-[#6B7280]">Company letterheads and document templates</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button className="px-4 py-2 bg-[#C3ACFF]/10 text-[#C3ACFF] rounded-xl text-sm font-medium hover:bg-[#C3ACFF]/20 transition-colors flex items-center gap-2">
              <Upload className="w-4 h-4" />
              Upload Letterhead
            </button>
            <button className="px-4 py-2 bg-[#121212] text-white rounded-xl text-sm font-medium hover:bg-[#2D2D2D] transition-colors flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Create Template
            </button>
          </div>
        </div>
      </header>

      <main className="p-8">
        <div className="max-w-6xl mx-auto">
          {/* Search & Filters */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#9CA3AF]" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search templates..."
                  className="pl-12 pr-4 py-3 bg-white border border-[#E5E7EB] rounded-xl text-[#121212] placeholder:text-[#9CA3AF] focus:outline-none focus:border-[#C3ACFF] transition-colors w-80"
                />
              </div>
            </div>
            <div className="flex items-center gap-2">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
                    selectedCategory === cat.id
                      ? 'bg-[#121212] text-white'
                      : 'bg-white text-[#6B7280] hover:bg-[#F3F4F6]'
                  }`}
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>

          {/* Templates Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Create New Card */}
            <button className="p-6 bg-white rounded-2xl border-2 border-dashed border-[#E5E7EB] hover:border-[#C3ACFF] hover:bg-[#C3ACFF]/5 transition-all flex flex-col items-center justify-center min-h-[240px] group">
              <div className="w-14 h-14 rounded-xl bg-[#F3F4F6] group-hover:bg-[#C3ACFF]/20 flex items-center justify-center mb-4 transition-colors">
                <Plus className="w-7 h-7 text-[#9CA3AF] group-hover:text-[#C3ACFF] transition-colors" />
              </div>
              <h3 className="font-semibold text-[#121212] mb-1">Create Template</h3>
              <p className="text-sm text-[#6B7280] text-center">Build a new template with AI assistance</p>
            </button>

            {filteredTemplates.map((template) => (
              <div
                key={template.id}
                className="bg-white rounded-2xl p-6 shadow-soft card-hover group"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-[#C3ACFF]/10 flex items-center justify-center">
                    <Layout className="w-6 h-6 text-[#C3ACFF]" />
                  </div>
                  <div className="flex items-center gap-2">
                    {template.letterhead && (
                      <span className="px-2 py-1 bg-[#CBD5FF]/30 text-[#121212] text-xs font-medium rounded-lg flex items-center gap-1">
                        <FileText className="w-3 h-3" />
                        Letterhead
                      </span>
                    )}
                    <span className={`px-2 py-1 rounded-lg text-xs font-medium ${
                      template.status === 'approved' ? 'bg-green-100 text-green-700' :
                      template.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-[#F3F4F6] text-[#6B7280]'
                    }`}>
                      {template.status === 'approved' && <Check className="w-3 h-3 inline mr-1" />}
                      {template.status}
                    </span>
                  </div>
                </div>

                <h3 className="font-semibold text-[#121212] mb-2">{template.name}</h3>
                <p className="text-sm text-[#6B7280] mb-4">{template.description}</p>

                <div className="flex items-center justify-between text-sm text-[#9CA3AF] mb-4">
                  <span>{template.usageCount} uses</span>
                  <span>Last used {template.lastUsed}</span>
                </div>

                <div className="flex items-center gap-2 pt-4 border-t border-[#E5E7EB]">
                  <button className="flex-1 py-2 bg-[#121212] text-white rounded-lg text-sm font-medium hover:bg-[#2D2D2D] transition-colors">
                    Use Template
                  </button>
                  <button className="p-2 hover:bg-[#F3F4F6] rounded-lg transition-colors">
                    <Edit className="w-4 h-4 text-[#9CA3AF]" />
                  </button>
                  <button className="p-2 hover:bg-[#F3F4F6] rounded-lg transition-colors">
                    <MoreHorizontal className="w-4 h-4 text-[#9CA3AF]" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Template Governance */}
          <div className="mt-12 p-6 bg-gradient-to-br from-[#C3ACFF]/10 to-[#CBD5FF]/10 rounded-2xl">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-[#C3ACFF] flex items-center justify-center flex-shrink-0">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-[#121212] mb-2">Template Governance</h3>
                <p className="text-[#6B7280] mb-4">
                  Templates require approval before they can be used by the team. 
                  Locked templates can only be edited by admins.
                </p>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-green-600" />
                    <span className="text-sm text-[#121212]">4 approved</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded-full border-2 border-yellow-500" />
                    <span className="text-sm text-[#121212]">1 pending</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded-full bg-[#E5E7EB]" />
                    <span className="text-sm text-[#121212]">1 locked</span>
                  </div>
                </div>
              </div>
              <button 
                onClick={() => navigate('/admin')}
                className="px-4 py-2 bg-white text-[#121212] rounded-xl text-sm font-medium hover:bg-[#F9FAFB] transition-colors flex items-center gap-2"
              >
                Manage
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
