import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Sparkles, AlertCircle, CheckCircle, Clock, Search,
  Flag, BookOpen, FileText, Users, BarChart3, Settings,
  X, RefreshCw
} from 'lucide-react';

interface MissingKnowledgeEvent {
  id: string;
  originalQuestion: string;
  normalizedQuestion: string;
  jurisdiction: string;
  program: string;
  topic: string;
  missingLayer: string;
  failureType: string;
  confidence: string;
  frequency: number;
  firstSeen: string;
  lastSeen: string;
  status: 'new' | 'under_review' | 'research_in_progress' | 'pending_validation' | 'approved' | 'closed';
  assignedTo?: string;
}

export function AdminConsole() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('gaps');
  const [selectedEvent, setSelectedEvent] = useState<MissingKnowledgeEvent | null>(null);

  const missingEvents: MissingKnowledgeEvent[] = [
    {
      id: 'MKE-001',
      originalQuestion: 'Does Nevada have something like California All Plan Letters?',
      normalizedQuestion: 'What Nevada Medicaid guidance documents function as statewide operational directives comparable to California All Plan Letters?',
      jurisdiction: 'Nevada',
      program: 'Medicaid Managed Care',
      topic: 'Operational Guidance',
      missingLayer: 'State Agency Guidance',
      failureType: 'No answer possible',
      confidence: 'low',
      frequency: 12,
      firstSeen: '2025-03-15',
      lastSeen: '2025-04-05',
      status: 'under_review',
      assignedTo: 'Sarah B.',
    },
    {
      id: 'MKE-002',
      originalQuestion: 'What are the network adequacy standards for Texas Medicaid MCOs?',
      normalizedQuestion: 'Texas Medicaid managed care organization network adequacy requirements and standards',
      jurisdiction: 'Texas',
      program: 'Medicaid Managed Care',
      topic: 'Network Adequacy',
      missingLayer: 'State Regulations',
      failureType: 'Answer incomplete',
      confidence: 'medium',
      frequency: 8,
      firstSeen: '2025-03-20',
      lastSeen: '2025-04-03',
      status: 'research_in_progress',
      assignedTo: 'Mike T.',
    },
    {
      id: 'MKE-003',
      originalQuestion: 'How does the Arizona ALTCS waiver interact with federal Medicaid rules?',
      normalizedQuestion: 'Arizona Long Term Care System waiver federal Medicaid compliance requirements',
      jurisdiction: 'Arizona',
      program: 'Medicaid Waivers',
      topic: 'Waiver Compliance',
      missingLayer: 'Waiver Documents',
      failureType: 'Low confidence',
      confidence: 'low',
      frequency: 5,
      firstSeen: '2025-03-28',
      lastSeen: '2025-04-01',
      status: 'new',
    },
  ];

  const statusColors: Record<string, string> = {
    new: 'bg-blue-100 text-blue-700',
    under_review: 'bg-yellow-100 text-yellow-700',
    research_in_progress: 'bg-purple-100 text-purple-700',
    pending_validation: 'bg-orange-100 text-orange-700',
    approved: 'bg-green-100 text-green-700',
    closed: 'bg-gray-100 text-gray-700',
  };

  const stats = [
    { label: 'Open Gaps', value: '24', change: '+3 this week', icon: AlertCircle, color: 'text-orange-600' },
    { label: 'Under Review', value: '12', change: '5 pending', icon: Clock, color: 'text-yellow-600' },
    { label: 'Resolved', value: '156', change: '+12 this month', icon: CheckCircle, color: 'text-green-600' },
    { label: 'Avg Resolution', value: '4.2 days', change: '-0.8 days', icon: BarChart3, color: 'text-blue-600' },
  ];

  return (
    <div className="min-h-screen bg-[#F8F8F8]">
      {/* Header */}
      <header className="bg-white border-b border-[#E5E7EB] px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => navigate('/workspace')}
              className="p-2 hover:bg-[#F3F4F6] rounded-lg transition-colors"
            >
              <Sparkles className="w-5 h-5 text-[#6B7280]" />
            </button>
            <div>
              <h1 className="text-xl font-semibold text-[#121212]">Admin Console</h1>
              <p className="text-sm text-[#6B7280]">Knowledge management and system governance</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button className="px-4 py-2 bg-[#C3ACFF]/10 text-[#C3ACFF] rounded-xl text-sm font-medium hover:bg-[#C3ACFF]/20 transition-colors flex items-center gap-2">
              <RefreshCw className="w-4 h-4" />
              Sync Sources
            </button>
            <button className="px-4 py-2 bg-[#121212] text-white rounded-xl text-sm font-medium hover:bg-[#2D2D2D] transition-colors">
              System Settings
            </button>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r border-[#E5E7EB] min-h-[calc(100vh-73px)] p-6">
          <div className="space-y-1">
            {[
              { id: 'gaps', label: 'Knowledge Gaps', icon: AlertCircle, count: 24 },
              { id: 'sources', label: 'Source Ingestion', icon: BookOpen },
              { id: 'users', label: 'User Management', icon: Users },
              { id: 'templates', label: 'Template Governance', icon: FileText },
              { id: 'analytics', label: 'Analytics', icon: BarChart3 },
              { id: 'settings', label: 'System Settings', icon: Settings },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                  activeTab === item.id 
                    ? 'bg-[#C3ACFF]/10 text-[#C3ACFF]' 
                    : 'text-[#6B7280] hover:bg-[#F3F4F6]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <item.icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </div>
                {item.count && (
                  <span className="px-2 py-0.5 bg-[#C3ACFF]/20 text-[#C3ACFF] text-xs rounded-full">
                    {item.count}
                  </span>
                )}
              </button>
            ))}
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          {activeTab === 'gaps' && (
            <div>
              {/* Stats */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                {stats.map((stat, i) => {
                  const Icon = stat.icon;
                  return (
                    <div key={i} className="bg-white rounded-2xl p-6 shadow-soft">
                      <div className="flex items-start justify-between mb-4">
                        <div className="w-10 h-10 rounded-xl bg-[#F3F4F6] flex items-center justify-center">
                          <Icon className={`w-5 h-5 ${stat.color}`} />
                        </div>
                      </div>
                      <p className="text-3xl font-bold text-[#121212] mb-1">{stat.value}</p>
                      <p className="text-sm text-[#6B7280]">{stat.label}</p>
                      <p className="text-xs text-[#9CA3AF] mt-1">{stat.change}</p>
                    </div>
                  );
                })}
              </div>

              {/* Filters */}
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-[#121212]">Missing Knowledge Events</h2>
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9CA3AF]" />
                    <input
                      type="text"
                      placeholder="Search events..."
                      className="pl-9 pr-4 py-2 bg-white border border-[#E5E7EB] rounded-lg text-sm text-[#121212] placeholder:text-[#9CA3AF] focus:outline-none focus:border-[#C3ACFF]"
                    />
                  </div>
                  <select className="px-3 py-2 bg-white border border-[#E5E7EB] rounded-lg text-sm text-[#121212] focus:outline-none focus:border-[#C3ACFF]">
                    <option>All Status</option>
                    <option>New</option>
                    <option>Under Review</option>
                    <option>In Progress</option>
                  </select>
                  <select className="px-3 py-2 bg-white border border-[#E5E7EB] rounded-lg text-sm text-[#121212] focus:outline-none focus:border-[#C3ACFF]">
                    <option>All Jurisdictions</option>
                  </select>
                </div>
              </div>

              {/* Events Table */}
              <div className="bg-white rounded-2xl shadow-soft overflow-hidden">
                <div className="grid grid-cols-12 gap-4 px-6 py-3 border-b border-[#E5E7EB] text-sm font-medium text-[#9CA3AF]">
                  <div className="col-span-1">ID</div>
                  <div className="col-span-3">Question</div>
                  <div className="col-span-1">Jurisdiction</div>
                  <div className="col-span-2">Missing Layer</div>
                  <div className="col-span-1">Freq</div>
                  <div className="col-span-2">Status</div>
                  <div className="col-span-2">Assigned</div>
                </div>
                {missingEvents.map((event) => (
                  <div
                    key={event.id}
                    onClick={() => setSelectedEvent(event)}
                    className="grid grid-cols-12 gap-4 px-6 py-4 hover:bg-[#F9FAFB] transition-colors border-b border-[#E5E7EB] last:border-0 items-center cursor-pointer"
                  >
                    <div className="col-span-1 text-sm font-medium text-[#C3ACFF]">{event.id}</div>
                    <div className="col-span-3">
                      <p className="text-sm text-[#121212] truncate">{event.originalQuestion}</p>
                      <p className="text-xs text-[#9CA3AF]">{event.program}</p>
                    </div>
                    <div className="col-span-1 text-sm text-[#6B7280]">{event.jurisdiction}</div>
                    <div className="col-span-2 text-sm text-[#6B7280]">{event.missingLayer}</div>
                    <div className="col-span-1 text-sm text-[#6B7280]">{event.frequency}x</div>
                    <div className="col-span-2">
                      <span className={`px-2.5 py-1 rounded-lg text-xs font-medium ${statusColors[event.status]}`}>
                        {event.status.replace(/_/g, ' ')}
                      </span>
                    </div>
                    <div className="col-span-2 text-sm text-[#6B7280]">{event.assignedTo || '—'}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'sources' && (
            <div>
              <h2 className="text-lg font-semibold text-[#121212] mb-6">Source Ingestion</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[
                  { name: 'Federal', count: 1247, lastSync: '2 hours ago', status: 'synced' },
                  { name: 'California', count: 892, lastSync: '4 hours ago', status: 'synced' },
                  { name: 'Texas', count: 567, lastSync: '1 day ago', status: 'pending' },
                  { name: 'Florida', count: 423, lastSync: '2 days ago', status: 'synced' },
                  { name: 'New York', count: 345, lastSync: '3 days ago', status: 'error' },
                  { name: 'Academic', count: 234, lastSync: '1 week ago', status: 'synced' },
                ].map((source, i) => (
                  <div key={i} className="bg-white rounded-2xl p-6 shadow-soft">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="font-semibold text-[#121212]">{source.name}</h3>
                        <p className="text-sm text-[#6B7280]">{source.count.toLocaleString()} documents</p>
                      </div>
                      <span className={`w-2 h-2 rounded-full ${
                        source.status === 'synced' ? 'bg-green-500' :
                        source.status === 'pending' ? 'bg-yellow-500' : 'bg-red-500'
                      }`} />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-[#9CA3AF]">Last sync: {source.lastSync}</span>
                      <button className="p-2 hover:bg-[#F3F4F6] rounded-lg transition-colors">
                        <RefreshCw className="w-4 h-4 text-[#9CA3AF]" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'analytics' && (
            <div>
              <h2 className="text-lg font-semibold text-[#121212] mb-6">System Analytics</h2>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white rounded-2xl p-6 shadow-soft">
                  <h3 className="font-semibold text-[#121212] mb-4">Query Volume</h3>
                  <div className="h-48 flex items-end gap-2">
                    {[40, 65, 45, 80, 55, 90, 70, 85, 60, 75, 95, 88].map((h, i) => (
                      <div key={i} className="flex-1 bg-[#C3ACFF]/20 rounded-t-lg relative group">
                        <div 
                          className="absolute bottom-0 left-0 right-0 bg-[#C3ACFF] rounded-t-lg transition-all"
                          style={{ height: `${h}%` }}
                        />
                      </div>
                    ))}
                  </div>
                  <div className="flex justify-between mt-4 text-xs text-[#9CA3AF]">
                    <span>Jan</span>
                    <span>Mar</span>
                    <span>May</span>
                    <span>Jul</span>
                    <span>Sep</span>
                    <span>Nov</span>
                  </div>
                </div>

                <div className="bg-white rounded-2xl p-6 shadow-soft">
                  <h3 className="font-semibold text-[#121212] mb-4">Answer Confidence</h3>
                  <div className="space-y-4">
                    {[
                      { label: 'High Confidence', value: 68, color: 'bg-green-500' },
                      { label: 'Medium Confidence', value: 22, color: 'bg-yellow-500' },
                      { label: 'Low Confidence', value: 7, color: 'bg-orange-500' },
                      { label: 'Not Supported', value: 3, color: 'bg-red-500' },
                    ].map((item, i) => (
                      <div key={i}>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm text-[#6B7280]">{item.label}</span>
                          <span className="text-sm font-medium text-[#121212]">{item.value}%</span>
                        </div>
                        <div className="h-2 bg-[#F3F4F6] rounded-full overflow-hidden">
                          <div className={`h-full ${item.color} rounded-full`} style={{ width: `${item.value}%` }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Event Detail Modal */}
      {selectedEvent && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-8">
          <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-auto animate-scale-in">
            <div className="sticky top-0 bg-white border-b border-[#E5E7EB] px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="px-3 py-1 bg-[#C3ACFF]/10 text-[#C3ACFF] rounded-lg text-sm font-medium">
                  {selectedEvent.id}
                </span>
                <h3 className="font-semibold text-[#121212]">Missing Knowledge Event</h3>
              </div>
              <button 
                onClick={() => setSelectedEvent(null)}
                className="p-2 hover:bg-[#F3F4F6] rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-[#9CA3AF]" />
              </button>
            </div>
            
            <div className="p-6 space-y-6">
              <div>
                <label className="text-xs font-semibold text-[#9CA3AF] uppercase tracking-wider">Original Question</label>
                <p className="mt-1 text-[#121212]">{selectedEvent.originalQuestion}</p>
              </div>
              
              <div>
                <label className="text-xs font-semibold text-[#9CA3AF] uppercase tracking-wider">Normalized Question</label>
                <p className="mt-1 text-[#6B7280]">{selectedEvent.normalizedQuestion}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-[#9CA3AF] uppercase tracking-wider">Jurisdiction</label>
                  <p className="mt-1 text-[#121212]">{selectedEvent.jurisdiction}</p>
                </div>
                <div>
                  <label className="text-xs font-semibold text-[#9CA3AF] uppercase tracking-wider">Program</label>
                  <p className="mt-1 text-[#121212]">{selectedEvent.program}</p>
                </div>
                <div>
                  <label className="text-xs font-semibold text-[#9CA3AF] uppercase tracking-wider">Topic</label>
                  <p className="mt-1 text-[#121212]">{selectedEvent.topic}</p>
                </div>
                <div>
                  <label className="text-xs font-semibold text-[#9CA3AF] uppercase tracking-wider">Missing Authority Layer</label>
                  <p className="mt-1 text-[#121212]">{selectedEvent.missingLayer}</p>
                </div>
              </div>

              <div className="p-4 bg-[#F9FAFB] rounded-xl">
                <div className="flex items-center gap-2 mb-2">
                  <Flag className="w-4 h-4 text-orange-500" />
                  <span className="font-medium text-[#121212]">Action Required</span>
                </div>
                <p className="text-sm text-[#6B7280]">
                  Add official {selectedEvent.jurisdiction} {selectedEvent.missingLayer.toLowerCase()} 
                  documents to the knowledge base to resolve this gap.
                </p>
              </div>

              <div className="flex gap-3">
                <button className="flex-1 py-3 bg-[#121212] text-white rounded-xl font-semibold hover:bg-[#2D2D2D] transition-colors">
                  Assign to Researcher
                </button>
                <button className="flex-1 py-3 bg-white border border-[#E5E7EB] text-[#121212] rounded-xl font-semibold hover:bg-[#F9FAFB] transition-colors">
                  Mark as Duplicate
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
