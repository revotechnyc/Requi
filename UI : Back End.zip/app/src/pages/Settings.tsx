import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Sparkles, User, Bell, Shield, Database, Palette
} from 'lucide-react';

export function Settings() {
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState('general');
  const [notifications, setNotifications] = useState({
    email: true,
    push: true,
    updates: true,
    alerts: true,
  });

  const sections = [
    { id: 'general', label: 'General', icon: User },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'integrations', label: 'Integrations', icon: Database },
    { id: 'appearance', label: 'Appearance', icon: Palette },
  ];

  return (
    <div className="min-h-screen bg-[#F8F8F8]">
      {/* Header */}
      <header className="bg-white border-b border-[#E5E7EB] px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => navigate('/workspace')}
              className="p-2 hover:bg-[#F3F4F6] rounded-lg transition-colors"
            >
              <Sparkles className="w-5 h-5 text-[#6B7280]" />
            </button>
            <div>
              <h1 className="text-xl font-semibold text-[#121212]">Settings</h1>
              <p className="text-sm text-[#6B7280]">Manage your preferences and account</p>
            </div>
          </div>
        </div>
      </header>

      <div className="flex max-w-6xl mx-auto">
        {/* Sidebar */}
        <aside className="w-64 p-6">
          <div className="space-y-1">
            {sections.map((section) => (
              <button
                key={section.id}
                onClick={() => setActiveSection(section.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                  activeSection === section.id 
                    ? 'bg-[#C3ACFF]/10 text-[#C3ACFF]' 
                    : 'text-[#6B7280] hover:bg-[#F3F4F6]'
                }`}
              >
                <section.icon className="w-4 h-4" />
                <span>{section.label}</span>
              </button>
            ))}
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {activeSection === 'general' && (
            <div className="bg-white rounded-2xl p-6 shadow-soft">
              <h2 className="text-lg font-semibold text-[#121212] mb-6">General Settings</h2>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-[#121212] mb-2">Workspace Name</label>
                  <input
                    type="text"
                    defaultValue="Sterling Health Systems"
                    className="w-full px-4 py-3 bg-[#F3F4F6] rounded-xl text-[#121212] focus:outline-none focus:ring-2 focus:ring-[#C3ACFF]/30"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#121212] mb-2">Default Jurisdiction</label>
                  <select className="w-full px-4 py-3 bg-[#F3F4F6] rounded-xl text-[#121212] focus:outline-none focus:ring-2 focus:ring-[#C3ACFF]/30 appearance-none">
                    <option>California</option>
                    <option>Texas</option>
                    <option>Florida</option>
                    <option>New York</option>
                    <option>Federal</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#121212] mb-2">Time Zone</label>
                  <select className="w-full px-4 py-3 bg-[#F3F4F6] rounded-xl text-[#121212] focus:outline-none focus:ring-2 focus:ring-[#C3ACFF]/30 appearance-none">
                    <option>Pacific Time (PT)</option>
                    <option>Mountain Time (MT)</option>
                    <option>Central Time (CT)</option>
                    <option>Eastern Time (ET)</option>
                  </select>
                </div>

                <div className="pt-4 border-t border-[#E5E7EB]">
                  <button className="px-6 py-3 bg-[#121212] text-white rounded-xl font-semibold hover:bg-[#2D2D2D] transition-colors">
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeSection === 'notifications' && (
            <div className="bg-white rounded-2xl p-6 shadow-soft">
              <h2 className="text-lg font-semibold text-[#121212] mb-6">Notification Preferences</h2>
              
              <div className="space-y-4">
                {[
                  { key: 'email', label: 'Email Notifications', desc: 'Receive updates via email' },
                  { key: 'push', label: 'Push Notifications', desc: 'Browser push notifications' },
                  { key: 'updates', label: 'Product Updates', desc: 'New features and improvements' },
                  { key: 'alerts', label: 'Compliance Alerts', desc: 'Important regulatory changes' },
                ].map((item) => (
                  <div key={item.key} className="flex items-center justify-between p-4 bg-[#F9FAFB] rounded-xl">
                    <div>
                      <p className="font-medium text-[#121212]">{item.label}</p>
                      <p className="text-sm text-[#6B7280]">{item.desc}</p>
                    </div>
                    <button
                      onClick={() => setNotifications(prev => ({ ...prev, [item.key]: !prev[item.key as keyof typeof notifications] }))}
                      className={`w-12 h-6 rounded-full transition-colors relative ${
                        notifications[item.key as keyof typeof notifications] ? 'bg-[#C3ACFF]' : 'bg-[#E5E7EB]'
                      }`}
                    >
                      <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${
                        notifications[item.key as keyof typeof notifications] ? 'left-7' : 'left-1'
                      }`} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeSection === 'security' && (
            <div className="space-y-6">
              <div className="bg-white rounded-2xl p-6 shadow-soft">
                <h2 className="text-lg font-semibold text-[#121212] mb-6">Security Settings</h2>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-[#F9FAFB] rounded-xl">
                    <div>
                      <p className="font-medium text-[#121212]">Two-Factor Authentication</p>
                      <p className="text-sm text-[#6B7280]">Add an extra layer of security</p>
                    </div>
                    <button className="px-4 py-2 bg-[#121212] text-white rounded-lg text-sm font-medium hover:bg-[#2D2D2D] transition-colors">
                      Enable
                    </button>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-[#F9FAFB] rounded-xl">
                    <div>
                      <p className="font-medium text-[#121212]">Change Password</p>
                      <p className="text-sm text-[#6B7280]">Last changed 30 days ago</p>
                    </div>
                    <button className="px-4 py-2 bg-white border border-[#E5E7EB] text-[#121212] rounded-lg text-sm font-medium hover:bg-[#F9FAFB] transition-colors">
                      Update
                    </button>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-[#F9FAFB] rounded-xl">
                    <div>
                      <p className="font-medium text-[#121212]">Active Sessions</p>
                      <p className="text-sm text-[#6B7280]">3 devices currently logged in</p>
                    </div>
                    <button className="px-4 py-2 bg-white border border-[#E5E7EB] text-[#121212] rounded-lg text-sm font-medium hover:bg-[#F9FAFB] transition-colors">
                      Manage
                    </button>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-2xl p-6 shadow-soft">
                <h3 className="font-semibold text-[#121212] mb-4">API Keys</h3>
                <p className="text-sm text-[#6B7280] mb-4">
                  Manage API keys for integrating with external systems.
                </p>
                <button className="px-4 py-2 bg-[#C3ACFF]/10 text-[#C3ACFF] rounded-lg text-sm font-medium hover:bg-[#C3ACFF]/20 transition-colors">
                  + Generate New Key
                </button>
              </div>
            </div>
          )}

          {activeSection === 'integrations' && (
            <div className="bg-white rounded-2xl p-6 shadow-soft">
              <h2 className="text-lg font-semibold text-[#121212] mb-6">Integrations</h2>
              
              <div className="space-y-4">
                {[
                  { name: 'Salesforce', desc: 'CRM integration', connected: true },
                  { name: 'Slack', desc: 'Team notifications', connected: true },
                  { name: 'Microsoft 365', desc: 'Document sync', connected: false },
                  { name: 'Google Workspace', desc: 'Calendar and docs', connected: false },
                ].map((integration) => (
                  <div key={integration.name} className="flex items-center justify-between p-4 bg-[#F9FAFB] rounded-xl">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-white flex items-center justify-center">
                        <span className="text-lg font-bold text-[#121212]">{integration.name[0]}</span>
                      </div>
                      <div>
                        <p className="font-medium text-[#121212]">{integration.name}</p>
                        <p className="text-sm text-[#6B7280]">{integration.desc}</p>
                      </div>
                    </div>
                    <button className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      integration.connected
                        ? 'bg-green-100 text-green-700'
                        : 'bg-[#121212] text-white hover:bg-[#2D2D2D]'
                    }`}>
                      {integration.connected ? 'Connected' : 'Connect'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeSection === 'appearance' && (
            <div className="bg-white rounded-2xl p-6 shadow-soft">
              <h2 className="text-lg font-semibold text-[#121212] mb-6">Appearance</h2>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-[#121212] mb-3">Theme</label>
                  <div className="grid grid-cols-3 gap-4">
                    {['Light', 'Dark', 'System'].map((theme) => (
                      <button
                        key={theme}
                        className={`p-4 rounded-xl border-2 transition-all ${
                          theme === 'Light' ? 'border-[#C3ACFF] bg-[#C3ACFF]/5' : 'border-[#E5E7EB] hover:border-[#C3ACFF]/50'
                        }`}
                      >
                        <div className="w-8 h-8 rounded-lg bg-[#F3F4F6] mx-auto mb-2" />
                        <p className="text-sm font-medium text-[#121212]">{theme}</p>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#121212] mb-3">Accent Color</label>
                  <div className="flex items-center gap-3">
                    {['#C3ACFF', '#CBD5FF', '#A78BFA', '#818CF8', '#60A5FA'].map((color) => (
                      <button
                        key={color}
                        className={`w-10 h-10 rounded-full transition-all ${
                          color === '#C3ACFF' ? 'ring-2 ring-offset-2 ring-[#121212]' : ''
                        }`}
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#121212] mb-3">Font Size</label>
                  <input
                    type="range"
                    min="1"
                    max="3"
                    defaultValue="2"
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-[#9CA3AF] mt-1">
                    <span>Small</span>
                    <span>Medium</span>
                    <span>Large</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
