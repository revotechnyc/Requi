import { useNavigate } from 'react-router-dom';
import { 
  Sparkles, MessageSquare, BookOpen, FolderOpen, FileText, Users, 
  Settings, ChevronRight, TrendingUp, Shield, AlertCircle,
  CheckCircle
} from 'lucide-react';
import { useAuth } from '../App';

export function Dashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();

  const stats = [
    { label: 'Queries This Month', value: '1,247', change: '+12%', icon: MessageSquare },
    { label: 'Documents Analyzed', value: '342', change: '+8%', icon: FileText },
    { label: 'Compliance Checks', value: '89', change: '+23%', icon: Shield },
    { label: 'Team Members', value: '24', change: '+4', icon: Users },
  ];

  const recentActivity = [
    { type: 'query', title: 'Medicaid managed care emergency services', time: '2 min ago', user: 'Sarah B.' },
    { type: 'document', title: 'California APL 20-015 uploaded', time: '15 min ago', user: 'Mike T.' },
    { type: 'template', title: 'Compliance memo template created', time: '1 hour ago', user: 'You' },
    { type: 'alert', title: 'New federal regulation: 42 CFR update', time: '3 hours ago', user: 'System' },
  ];

  const quickLinks = [
    { label: 'AI Workspace', icon: MessageSquare, path: '/workspace', color: 'bg-[#C3ACFF]' },
    { label: 'Library', icon: BookOpen, path: '/library', color: 'bg-[#CBD5FF]' },
    { label: 'Files', icon: FolderOpen, path: '/files', color: 'bg-[#C3ACFF]/70' },
    { label: 'Templates', icon: FileText, path: '/templates', color: 'bg-[#CBD5FF]/70' },
    { label: 'Teams', icon: Users, path: '/teams', color: 'bg-[#C3ACFF]/50' },
    { label: 'Settings', icon: Settings, path: '/settings', color: 'bg-[#CBD5FF]/50' },
  ];

  return (
    <div className="min-h-screen bg-[#F8F8F8]">
      {/* Header */}
      <header className="bg-white border-b border-[#E5E7EB] px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#C3ACFF] to-[#CBD5FF] flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-[#121212]">Dashboard</h1>
              <p className="text-sm text-[#6B7280]">{user?.workspace}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => navigate('/workspace')}
              className="px-5 py-2.5 bg-[#121212] text-white rounded-xl font-medium hover:bg-[#2D2D2D] transition-colors flex items-center gap-2"
            >
              <MessageSquare className="w-4 h-4" />
              New Query
            </button>
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#C3ACFF] to-[#CBD5FF] flex items-center justify-center text-white font-medium">
              {user?.name?.split(' ').map(n => n[0]).join('')}
            </div>
          </div>
        </div>
      </header>

      <main className="p-8">
        <div className="max-w-7xl mx-auto">
          {/* Welcome */}
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-[#121212] mb-2">
              Welcome back, {user?.name?.split(' ')[0]}
            </h2>
            <p className="text-[#6B7280]">Here's what's happening in your workspace today.</p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {stats.map((stat, i) => {
              const Icon = stat.icon;
              return (
                <div key={i} className="bg-white rounded-2xl p-6 shadow-soft card-hover">
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-10 h-10 rounded-xl bg-[#C3ACFF]/10 flex items-center justify-center">
                      <Icon className="w-5 h-5 text-[#C3ACFF]" />
                    </div>
                    <span className="flex items-center gap-1 text-sm font-medium text-green-600">
                      <TrendingUp className="w-4 h-4" />
                      {stat.change}
                    </span>
                  </div>
                  <p className="text-3xl font-bold text-[#121212] mb-1">{stat.value}</p>
                  <p className="text-sm text-[#6B7280]">{stat.label}</p>
                </div>
              );
            })}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Quick Links */}
            <div className="lg:col-span-2">
              <h3 className="text-lg font-semibold text-[#121212] mb-4">Quick Access</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {quickLinks.map((link, i) => {
                  const Icon = link.icon;
                  return (
                    <button
                      key={i}
                      onClick={() => navigate(link.path)}
                      className="p-5 bg-white rounded-2xl shadow-soft card-hover text-left"
                    >
                      <div className={`w-12 h-12 ${link.color} rounded-xl flex items-center justify-center mb-4`}>
                        <Icon className="w-6 h-6 text-[#121212]" />
                      </div>
                      <p className="font-semibold text-[#121212]">{link.label}</p>
                    </button>
                  );
                })}
              </div>

              {/* Recent Documents */}
              <div className="mt-8">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-[#121212]">Recent Documents</h3>
                  <button 
                    onClick={() => navigate('/files')}
                    className="text-sm font-medium text-[#C3ACFF] hover:text-[#A88FEF] transition-colors flex items-center gap-1"
                  >
                    View all
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
                <div className="bg-white rounded-2xl shadow-soft overflow-hidden">
                  {[
                    { name: 'California Medicaid Managed Care Contract 2024.pdf', type: 'PDF', size: '2.4 MB', date: 'Today' },
                    { name: 'Federal Compliance Summary - Q4 2024.docx', type: 'DOCX', size: '1.8 MB', date: 'Yesterday' },
                    { name: 'Texas Provider Bulletin Archive.zip', type: 'ZIP', size: '45 MB', date: '2 days ago' },
                    { name: 'HIPAA Security Risk Assessment.xlsx', type: 'XLSX', size: '890 KB', date: '3 days ago' },
                  ].map((doc, i) => (
                    <div key={i} className="flex items-center justify-between p-4 hover:bg-[#F9FAFB] transition-colors border-b border-[#E5E7EB] last:border-0">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-lg bg-[#F3F4F6] flex items-center justify-center">
                          <FileText className="w-5 h-5 text-[#C3ACFF]" />
                        </div>
                        <div>
                          <p className="font-medium text-[#121212]">{doc.name}</p>
                          <p className="text-sm text-[#9CA3AF]">{doc.type} · {doc.size}</p>
                        </div>
                      </div>
                      <span className="text-sm text-[#9CA3AF]">{doc.date}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Activity Feed */}
              <div className="bg-white rounded-2xl p-6 shadow-soft">
                <h3 className="text-lg font-semibold text-[#121212] mb-4">Recent Activity</h3>
                <div className="space-y-4">
                  {recentActivity.map((activity, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                        activity.type === 'query' ? 'bg-[#C3ACFF]/10' :
                        activity.type === 'document' ? 'bg-[#CBD5FF]/20' :
                        activity.type === 'template' ? 'bg-green-100' : 'bg-orange-100'
                      }`}>
                        {activity.type === 'query' && <MessageSquare className="w-4 h-4 text-[#C3ACFF]" />}
                        {activity.type === 'document' && <FileText className="w-4 h-4 text-[#CBD5FF]" />}
                        {activity.type === 'template' && <CheckCircle className="w-4 h-4 text-green-600" />}
                        {activity.type === 'alert' && <AlertCircle className="w-4 h-4 text-orange-600" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-[#121212] truncate">{activity.title}</p>
                        <p className="text-xs text-[#9CA3AF]">{activity.time} · {activity.user}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Compliance Status */}
              <div className="bg-white rounded-2xl p-6 shadow-soft">
                <h3 className="text-lg font-semibold text-[#121212] mb-4">Compliance Status</h3>
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-[#6B7280]">Federal</span>
                      <span className="text-sm font-medium text-green-600">98%</span>
                    </div>
                    <div className="h-2 bg-[#F3F4F6] rounded-full overflow-hidden">
                      <div className="h-full w-[98%] bg-green-500 rounded-full" />
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-[#6B7280]">State (CA)</span>
                      <span className="text-sm font-medium text-green-600">95%</span>
                    </div>
                    <div className="h-2 bg-[#F3F4F6] rounded-full overflow-hidden">
                      <div className="h-full w-[95%] bg-green-500 rounded-full" />
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-[#6B7280]">Contracts</span>
                      <span className="text-sm font-medium text-yellow-600">87%</span>
                    </div>
                    <div className="h-2 bg-[#F3F4F6] rounded-full overflow-hidden">
                      <div className="h-full w-[87%] bg-yellow-500 rounded-full" />
                    </div>
                  </div>
                </div>
              </div>

              {/* Knowledge Gaps */}
              <div className="bg-gradient-to-br from-[#C3ACFF]/10 to-[#CBD5FF]/10 rounded-2xl p-6">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-[#C3ACFF] flex items-center justify-center">
                    <AlertCircle className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-[#121212]">Knowledge Gaps</h3>
                    <p className="text-sm text-[#6B7280]">3 items need attention</p>
                  </div>
                </div>
                <button 
                  onClick={() => navigate('/admin')}
                  className="w-full py-2.5 bg-white rounded-xl text-sm font-medium text-[#121212] hover:bg-[#F9FAFB] transition-colors"
                >
                  Review in Admin
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
