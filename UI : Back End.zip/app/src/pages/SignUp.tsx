import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sparkles, Eye, EyeOff, Mail, Lock, User, Building2, ArrowLeft, Check } from 'lucide-react';
import { useAuth } from '../App';

export function SignUp() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [showPassword, setShowPassword] = useState(false);
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    company: '',
    role: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock signup
    login({
      id: '1',
      name: `${formData.firstName} ${formData.lastName}`,
      email: formData.email,
      role: 'owner',
      workspace: formData.company
    });
    
    navigate('/onboarding');
  };

  const updateFormData = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen bg-[#F8F8F8] flex">
      {/* Left Side - Form */}
      <div className="flex-1 flex flex-col justify-center px-8 sm:px-12 lg:px-20 py-12">
        <div className="max-w-md w-full mx-auto">
          {/* Back Button */}
          <button 
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-[#6B7280] hover:text-[#121212] transition-colors mb-8"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm font-medium">Back to home</span>
          </button>

          {/* Logo */}
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#C3ACFF] to-[#CBD5FF] flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-semibold text-[#121212]">Requi Health</span>
          </div>

          {/* Progress */}
          <div className="flex items-center gap-2 mb-8">
            <div className={`flex-1 h-1 rounded-full transition-colors ${step >= 1 ? 'bg-[#C3ACFF]' : 'bg-[#E5E7EB]'}`} />
            <div className={`flex-1 h-1 rounded-full transition-colors ${step >= 2 ? 'bg-[#C3ACFF]' : 'bg-[#E5E7EB]'}`} />
            <div className={`flex-1 h-1 rounded-full transition-colors ${step >= 3 ? 'bg-[#C3ACFF]' : 'bg-[#E5E7EB]'}`} />
          </div>

          {/* Title */}
          <h1 className="text-3xl font-bold text-[#121212] mb-2">
            {step === 1 && 'Create your account'}
            {step === 2 && 'Company details'}
            {step === 3 && 'Choose your plan'}
          </h1>
          <p className="text-[#6B7280] mb-8">
            {step === 1 && 'Start your 14-day free trial'}
            {step === 2 && 'Tell us about your organization'}
            {step === 3 && 'Select the right plan for your team'}
          </p>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            {step === 1 && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-[#121212] mb-2">First name</label>
                    <div className="relative">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#9CA3AF]" />
                      <input
                        type="text"
                        value={formData.firstName}
                        onChange={(e) => updateFormData('firstName', e.target.value)}
                        placeholder="John"
                        className="w-full pl-12 pr-4 py-3.5 bg-white border border-[#E5E7EB] rounded-xl text-[#121212] placeholder:text-[#9CA3AF] focus:border-[#C3ACFF] transition-colors"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#121212] mb-2">Last name</label>
                    <input
                      type="text"
                      value={formData.lastName}
                      onChange={(e) => updateFormData('lastName', e.target.value)}
                      placeholder="Doe"
                      className="w-full px-4 py-3.5 bg-white border border-[#E5E7EB] rounded-xl text-[#121212] placeholder:text-[#9CA3AF] focus:border-[#C3ACFF] transition-colors"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#121212] mb-2">Work email</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#9CA3AF]" />
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => updateFormData('email', e.target.value)}
                      placeholder="you@company.com"
                      className="w-full pl-12 pr-4 py-3.5 bg-white border border-[#E5E7EB] rounded-xl text-[#121212] placeholder:text-[#9CA3AF] focus:border-[#C3ACFF] transition-colors"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#121212] mb-2">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#9CA3AF]" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={formData.password}
                      onChange={(e) => updateFormData('password', e.target.value)}
                      placeholder="Create a strong password"
                      className="w-full pl-12 pr-12 py-3.5 bg-white border border-[#E5E7EB] rounded-xl text-[#121212] placeholder:text-[#9CA3AF] focus:border-[#C3ACFF] transition-colors"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-[#9CA3AF] hover:text-[#6B7280] transition-colors"
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="w-full py-4 bg-[#121212] text-white rounded-xl font-semibold hover:bg-[#2D2D2D] transition-all"
                >
                  Continue
                </button>
              </>
            )}

            {step === 2 && (
              <>
                <div>
                  <label className="block text-sm font-medium text-[#121212] mb-2">Company name</label>
                  <div className="relative">
                    <Building2 className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#9CA3AF]" />
                    <input
                      type="text"
                      value={formData.company}
                      onChange={(e) => updateFormData('company', e.target.value)}
                      placeholder="Acme Healthcare"
                      className="w-full pl-12 pr-4 py-3.5 bg-white border border-[#E5E7EB] rounded-xl text-[#121212] placeholder:text-[#9CA3AF] focus:border-[#C3ACFF] transition-colors"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#121212] mb-2">Your role</label>
                  <select
                    value={formData.role}
                    onChange={(e) => updateFormData('role', e.target.value)}
                    className="w-full px-4 py-3.5 bg-white border border-[#E5E7EB] rounded-xl text-[#121212] focus:border-[#C3ACFF] transition-colors appearance-none"
                    required
                  >
                    <option value="">Select your role</option>
                    <option value="compliance">Compliance Officer</option>
                    <option value="legal">Legal Counsel</option>
                    <option value="operations">Operations Director</option>
                    <option value="executive">Executive</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="flex-1 py-4 bg-white border border-[#E5E7EB] text-[#121212] rounded-xl font-semibold hover:bg-[#F9FAFB] transition-all"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={() => setStep(3)}
                    className="flex-1 py-4 bg-[#121212] text-white rounded-xl font-semibold hover:bg-[#2D2D2D] transition-all"
                  >
                    Continue
                  </button>
                </div>
              </>
            )}

            {step === 3 && (
              <>
                <div className="space-y-4">
                  {[
                    { seats: 15, price: 6000, discount: 0, label: 'Starter' },
                    { seats: 30, price: 11520, discount: 4, label: 'Growth' },
                    { seats: 50, price: 18400, discount: 8, label: 'Enterprise' }
                  ].map((plan) => (
                    <label
                      key={plan.seats}
                      className="flex items-center gap-4 p-4 bg-white border border-[#E5E7EB] rounded-xl cursor-pointer hover:border-[#C3ACFF] transition-colors"
                    >
                      <input
                        type="radio"
                        name="plan"
                        className="w-5 h-5 text-[#C3ACFF] focus:ring-[#C3ACFF]"
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-[#121212]">{plan.label}</span>
                          {plan.discount > 0 && (
                            <span className="px-2 py-0.5 bg-[#C3ACFF]/20 text-[#C3ACFF] text-xs font-medium rounded-full">
                              {plan.discount}% off
                            </span>
                          )}
                        </div>
                        <span className="text-sm text-[#6B7280]">{plan.seats} users</span>
                      </div>
                      <div className="text-right">
                        <span className="font-semibold text-[#121212]">${plan.price.toLocaleString()}</span>
                        <span className="text-sm text-[#6B7280]">/year</span>
                      </div>
                    </label>
                  ))}
                </div>

                <div className="flex items-start gap-3 p-4 bg-[#C3ACFF]/10 rounded-xl">
                  <Check className="w-5 h-5 text-[#C3ACFF] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-[#121212]">14-day free trial</p>
                    <p className="text-sm text-[#6B7280]">No credit card required. Cancel anytime.</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className="flex-1 py-4 bg-white border border-[#E5E7EB] text-[#121212] rounded-xl font-semibold hover:bg-[#F9FAFB] transition-all"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="flex-1 py-4 bg-[#121212] text-white rounded-xl font-semibold hover:bg-[#2D2D2D] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    {isLoading ? (
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      'Start Free Trial'
                    )}
                  </button>
                </div>
              </>
            )}
          </form>

          <p className="text-center text-sm text-[#6B7280] mt-6">
            Already have an account?{' '}
            <button onClick={() => navigate('/login')} className="font-medium text-[#C3ACFF] hover:text-[#A88FEF] transition-colors">
              Sign in
            </button>
          </p>
        </div>
      </div>

      {/* Right Side - Decorative */}
      <div className="hidden lg:flex flex-1 bg-gradient-to-br from-[#C3ACFF]/10 via-[#CBD5FF]/10 to-[#F8F8F8] items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-96 h-96 rounded-full bg-gradient-to-br from-[#C3ACFF]/20 to-[#CBD5FF]/20 blur-3xl animate-pulse-glow" />
        </div>
        
        {/* Testimonial Card */}
        <div className="relative z-10 bg-white/80 backdrop-blur-xl rounded-2xl p-8 shadow-elevated max-w-sm mx-8">
          <div className="flex items-center gap-1 mb-4">
            {[...Array(5)].map((_, i) => (
              <svg key={i} className="w-5 h-5 text-[#C3ACFF]" fill="currentColor" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
              </svg>
            ))}
          </div>
          <p className="text-[#121212] mb-6 leading-relaxed">
            "Requi Health transformed our compliance workflow. What used to take weeks now takes minutes. The AI's understanding of federal and state regulations is remarkable."
          </p>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#C3ACFF] to-[#CBD5FF] flex items-center justify-center text-white font-semibold">
              SB
            </div>
            <div>
              <p className="font-semibold text-[#121212]">Sarah Bennett</p>
              <p className="text-sm text-[#6B7280]">Chief Compliance Officer, MedCare Systems</p>
            </div>
          </div>
        </div>
        
        {/* Floating elements */}
        <div className="absolute top-20 right-20 w-16 h-16 rounded-full bg-[#C3ACFF]/20 blur-xl animate-float" />
        <div className="absolute bottom-32 left-20 w-20 h-20 rounded-full bg-[#CBD5FF]/30 blur-xl animate-float" style={{ animationDelay: '1s' }} />
      </div>
    </div>
  );
}
