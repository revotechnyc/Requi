import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Sparkles, Search, Filter, ChevronDown, FileText, Download, 
  ExternalLink, BookOpen, Scale, Building2, Folder, Tag,
  ChevronRight, MoreHorizontal, Shield, AlertCircle
} from 'lucide-react';

interface Document {
  id: string;
  title: string;
  jurisdiction: string;
  layer: string;
  program: string;
  topic: string;
  effectiveDate: string;
  status: 'active' | 'superseded' | 'pending';
  type: string;
}

export function Library() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedJurisdiction, setSelectedJurisdiction] = useState('all');
  const [selectedLayer, setSelectedLayer] = useState('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list');

  const jurisdictions = ['Federal', 'California', 'Texas', 'Florida', 'New York', 'Illinois'];
  
  const layers = [
    'Federal Statutes',
    'Federal Regulations',
    'Federal Agency Guidance',
    'State Statutes',
    'State Regulations',
    'State Agency Guidance',
    'Program Documents',
    'Contracts',
    'Case Law',
    'Academic',
  ];

  const documents: Document[] = [
    {
      id: '1',
      title: '42 CFR § 438.210 - Coverage and authorization of services',
      jurisdiction: 'Federal',
      layer: 'Federal Regulations',
      program: 'Medicaid',
      topic: 'Managed Care',
      effectiveDate: '2024-01-01',
      status: 'active',
      type: 'Regulation',
    },
    {
      id: '2',
      title: 'California All Plan Letter 20-015 - Emergency Services',
      jurisdiction: 'California',
      layer: 'State Agency Guidance',
      program: 'Medicaid',
      topic: 'Emergency Services',
      effectiveDate: '2020-06-15',
      status: 'active',
      type: 'Guidance',
    },
    {
      id: '3',
      title: 'CMS Medicaid Managed Care Final Rule 2024',
      jurisdiction: 'Federal',
      layer: 'Federal Agency Guidance',
      program: 'Medicaid',
      topic: 'Managed Care',
      effectiveDate: '2024-03-01',
      status: 'active',
      type: 'Rule',
    },
    {
      id: '4',
      title: 'Texas Medicaid Provider Manual - Chapter 4',
      jurisdiction: 'Texas',
      layer: 'State Agency Guidance',
      program: 'Medicaid',
      topic: 'Provider Requirements',
      effectiveDate: '2023-09-01',
      status: 'active',
      type: 'Manual',
    },
    {
      id: '5',
      title: 'HIPAA Privacy Rule - 45 CFR § 164.500',
      jurisdiction: 'Federal',
      layer: 'Federal Regulations',
      program: 'HIPAA',
      topic: 'Privacy',
      effectiveDate: '2013-09-23',
      status: 'active',
      type: 'Regulation',
    },
    {
      id: '6',
      title: 'Florida Medicaid Managed Care Contract Template',
      jurisdiction: 'Florida',
      layer: 'Contracts',
      program: 'Medicaid',
      topic: 'Managed Care',
      effectiveDate: '2024-01-01',
      status: 'active',
      type: 'Contract',
    },
  ];

  const folderStructure = [
    { name: 'Federal', count: 1247, icon: Scale },
    { name: 'States', count: 3421, icon: Building2 },
    { name: 'Programs', count: 892, icon: Folder },
    { name: 'Contracts', count: 456, icon: FileText },
    { name: 'Case Law', count: 234, icon: BookOpen },
    { name: 'Academic', count: 567, icon: BookOpen },
  ];

  return (
    <div className="min-h-screen bg-[#F8F8F8]">
      {/* Header */}
      <header className="bg-white border-b border-[#E5E7EB] px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => navigate('/workspace')}
              className="p-2 hover:bg-[#F3F4F6] rounded-lg transition-colors"
            >
              <Sparkles className="w-5 h-5 text-[#6B7280]" />
            </button>
            <div>
              <h1 className="text-xl font-semibold text-[#121212]">Library</h1>
              <p className="text-sm text-[#6B7280]">Knowledge Base & Document Repository</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button className="px-4 py-2 bg-[#C3ACFF]/10 text-[#C3ACFF] rounded-xl text-sm font-medium hover:bg-[#C3ACFF]/20 transition-colors flex items-center gap-2">
              <Download className="w-4 h-4" />
              Export
            </button>
            <button className="px-4 py-2 bg-[#121212] text-white rounded-xl text-sm font-medium hover:bg-[#2D2D2D] transition-colors">
              Add Document
            </button>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r border-[#E5E7EB] min-h-[calc(100vh-73px)] p-6">
          <div className="mb-6">
            <h3 className="text-xs font-semibold text-[#9CA3AF] uppercase tracking-wider mb-3">Browse</h3>
            <div className="space-y-1">
              {folderStructure.map((folder, i) => {
                const Icon = folder.icon;
                return (
                  <button
                    key={i}
                    className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-sm text-[#6B7280] hover:bg-[#F3F4F6] transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="w-4 h-4" />
                      <span>{folder.name}</span>
                    </div>
                    <span className="text-xs text-[#9CA3AF]">{folder.count}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-xs font-semibold text-[#9CA3AF] uppercase tracking-wider mb-3">Topics</h3>
            <div className="space-y-1">
              {['Managed Care', 'Privacy', 'Fraud & Abuse', 'Reimbursement', 'Network Adequacy', 'Grievances'].map((topic, i) => (
                <button
                  key={i}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm text-[#6B7280] hover:bg-[#F3F4F6] transition-colors"
                >
                  <Tag className="w-4 h-4" />
                  <span>{topic}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="p-4 bg-gradient-to-br from-[#C3ACFF]/10 to-[#CBD5FF]/10 rounded-xl">
            <div className="flex items-center gap-2 mb-2">
              <Shield className="w-4 h-4 text-[#C3ACFF]" />
              <span className="text-sm font-medium text-[#121212]">Authority Stack</span>
            </div>
            <p className="text-xs text-[#6B7280] mb-3">
              Documents are organized by governance layer for precise authority ranking.
            </p>
            <button className="text-xs font-medium text-[#C3ACFF] hover:text-[#A88FEF] transition-colors flex items-center gap-1">
              Learn more
              <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          {/* Search & Filters */}
          <div className="mb-6">
            <div className="flex items-center gap-4 mb-4">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#9CA3AF]" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search documents by title, jurisdiction, or topic..."
                  className="w-full pl-12 pr-4 py-3 bg-white border border-[#E5E7EB] rounded-xl text-[#121212] placeholder:text-[#9CA3AF] focus:outline-none focus:border-[#C3ACFF] transition-colors"
                />
              </div>
              <button className="p-3 bg-white border border-[#E5E7EB] rounded-xl hover:bg-[#F9FAFB] transition-colors">
                <Filter className="w-5 h-5 text-[#6B7280]" />
              </button>
            </div>

            <div className="flex items-center gap-3">
              <div className="relative">
                <select
                  value={selectedJurisdiction}
                  onChange={(e) => setSelectedJurisdiction(e.target.value)}
                  className="appearance-none px-4 py-2 pr-10 bg-white border border-[#E5E7EB] rounded-lg text-sm text-[#121212] focus:outline-none focus:border-[#C3ACFF] cursor-pointer"
                >
                  <option value="all">All Jurisdictions</option>
                  {jurisdictions.map((j) => (
                    <option key={j} value={j}>{j}</option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9CA3AF] pointer-events-none" />
              </div>

              <div className="relative">
                <select
                  value={selectedLayer}
                  onChange={(e) => setSelectedLayer(e.target.value)}
                  className="appearance-none px-4 py-2 pr-10 bg-white border border-[#E5E7EB] rounded-lg text-sm text-[#121212] focus:outline-none focus:border-[#C3ACFF] cursor-pointer"
                >
                  <option value="all">All Layers</option>
                  {layers.map((l) => (
                    <option key={l} value={l}>{l}</option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9CA3AF] pointer-events-none" />
              </div>

              <div className="flex-1" />

              <div className="flex items-center gap-2 bg-white border border-[#E5E7EB] rounded-lg p-1">
                <button
                  onClick={() => setViewMode('list')}
                  className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                    viewMode === 'list' ? 'bg-[#F3F4F6] text-[#121212]' : 'text-[#6B7280]'
                  }`}
                >
                  List
                </button>
                <button
                  onClick={() => setViewMode('grid')}
                  className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                    viewMode === 'grid' ? 'bg-[#F3F4F6] text-[#121212]' : 'text-[#6B7280]'
                  }`}
                >
                  Grid
                </button>
              </div>
            </div>
          </div>

          {/* Results */}
          <div className="bg-white rounded-2xl shadow-soft overflow-hidden">
            <div className="px-6 py-4 border-b border-[#E5E7EB] flex items-center justify-between">
              <p className="text-sm text-[#6B7280]">
                Showing <span className="font-medium text-[#121212]">{documents.length}</span> documents
              </p>
              <div className="flex items-center gap-2">
                <span className="text-sm text-[#9CA3AF]">Sort by:</span>
                <select className="text-sm text-[#121212] bg-transparent focus:outline-none cursor-pointer">
                  <option>Relevance</option>
                  <option>Date</option>
                  <option>Jurisdiction</option>
                </select>
              </div>
            </div>

            <div className="divide-y divide-[#E5E7EB]">
              {documents.map((doc) => (
                <div key={doc.id} className="p-6 hover:bg-[#F9FAFB] transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-xl bg-[#C3ACFF]/10 flex items-center justify-center flex-shrink-0">
                        <FileText className="w-5 h-5 text-[#C3ACFF]" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-[#121212] mb-1">{doc.title}</h3>
                        <div className="flex items-center gap-3 text-sm">
                          <span className="px-2 py-0.5 bg-[#F3F4F6] rounded text-[#6B7280]">{doc.jurisdiction}</span>
                          <span className="text-[#9CA3AF]">·</span>
                          <span className="text-[#6B7280]">{doc.layer}</span>
                          <span className="text-[#9CA3AF]">·</span>
                          <span className="text-[#6B7280]">{doc.program}</span>
                        </div>
                        <div className="flex items-center gap-4 mt-2 text-sm text-[#9CA3AF]">
                          <span>Effective: {doc.effectiveDate}</span>
                          <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                            doc.status === 'active' ? 'bg-green-100 text-green-700' :
                            doc.status === 'superseded' ? 'bg-red-100 text-red-700' :
                            'bg-yellow-100 text-yellow-700'
                          }`}>
                            {doc.status}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button className="p-2 hover:bg-[#F3F4F6] rounded-lg transition-colors">
                        <ExternalLink className="w-4 h-4 text-[#9CA3AF]" />
                      </button>
                      <button className="p-2 hover:bg-[#F3F4F6] rounded-lg transition-colors">
                        <Download className="w-4 h-4 text-[#9CA3AF]" />
                      </button>
                      <button className="p-2 hover:bg-[#F3F4F6] rounded-lg transition-colors">
                        <MoreHorizontal className="w-4 h-4 text-[#9CA3AF]" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Missing Sources Alert */}
          <div className="mt-6 p-4 bg-orange-50 border border-orange-200 rounded-xl flex items-center gap-4">
            <AlertCircle className="w-5 h-5 text-orange-600 flex-shrink-0" />
            <div className="flex-1">
              <p className="text-sm font-medium text-orange-800">Missing Source Events</p>
              <p className="text-sm text-orange-600">
                3 documents flagged for knowledge-base review. These gaps may affect answer confidence.
              </p>
            </div>
            <button 
              onClick={() => navigate('/admin')}
              className="px-4 py-2 bg-orange-600 text-white rounded-lg text-sm font-medium hover:bg-orange-700 transition-colors"
            >
              Review
            </button>
          </div>
        </main>
      </div>
    </div>
  );
}
