import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Sparkles, Camera, Mail, Building2, Briefcase, MapPin, Link,
  Edit2, Check
} from 'lucide-react';
import { useAuth } from '../App';

export function Profile() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [isEditing, setIsEditing] = useState(false);

  return (
    <div className="min-h-screen bg-[#F8F8F8]">
      {/* Header */}
      <header className="bg-white border-b border-[#E5E7EB] px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => navigate('/workspace')}
              className="p-2 hover:bg-[#F3F4F6] rounded-lg transition-colors"
            >
              <Sparkles className="w-5 h-5 text-[#6B7280]" />
            </button>
            <div>
              <h1 className="text-xl font-semibold text-[#121212]">Profile</h1>
              <p className="text-sm text-[#6B7280]">Manage your personal information</p>
            </div>
          </div>
          <button 
            onClick={() => setIsEditing(!isEditing)}
            className="px-4 py-2 bg-[#121212] text-white rounded-xl text-sm font-medium hover:bg-[#2D2D2D] transition-colors flex items-center gap-2"
          >
            {isEditing ? (
              <>
                <Check className="w-4 h-4" />
                Save Changes
              </>
            ) : (
              <>
                <Edit2 className="w-4 h-4" />
                Edit Profile
              </>
            )}
          </button>
        </div>
      </header>

      <main className="p-8">
        <div className="max-w-3xl mx-auto">
          {/* Profile Card */}
          <div className="bg-white rounded-2xl shadow-soft overflow-hidden mb-8">
            {/* Cover */}
            <div className="h-32 bg-gradient-to-r from-[#C3ACFF] to-[#CBD5FF]" />
            
            {/* Avatar & Info */}
            <div className="px-8 pb-8">
              <div className="relative -mt-16 mb-6">
                <div className="w-32 h-32 rounded-2xl bg-gradient-to-br from-[#C3ACFF] to-[#CBD5FF] flex items-center justify-center text-white text-3xl font-bold border-4 border-white shadow-elevated">
                  {user?.name?.split(' ').map(n => n[0]).join('')}
                </div>
                <button className="absolute bottom-0 right-0 p-2 bg-white rounded-lg shadow-soft hover:bg-[#F9FAFB] transition-colors">
                  <Camera className="w-4 h-4 text-[#6B7280]" />
                </button>
              </div>

              <div className="flex items-start justify-between">
                <div>
                  <h2 className="text-2xl font-bold text-[#121212] mb-1">{user?.name}</h2>
                  <p className="text-[#6B7280]">Chief Compliance Officer</p>
                </div>
                <span className="px-3 py-1 bg-[#C3ACFF]/10 text-[#C3ACFF] rounded-full text-sm font-medium">
                  {user?.role}
                </span>
              </div>
            </div>
          </div>

          {/* Details */}
          <div className="bg-white rounded-2xl p-8 shadow-soft">
            <h3 className="text-lg font-semibold text-[#121212] mb-6">Personal Information</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-[#9CA3AF] mb-2">Full Name</label>
                {isEditing ? (
                  <input
                    type="text"
                    defaultValue={user?.name}
                    className="w-full px-4 py-3 bg-[#F3F4F6] rounded-xl text-[#121212] focus:outline-none focus:ring-2 focus:ring-[#C3ACFF]/30"
                  />
                ) : (
                  <p className="text-[#121212] font-medium">{user?.name}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-[#9CA3AF] mb-2">Email</label>
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-[#9CA3AF]" />
                  {isEditing ? (
                    <input
                      type="email"
                      defaultValue={user?.email}
                      className="flex-1 px-4 py-3 bg-[#F3F4F6] rounded-xl text-[#121212] focus:outline-none focus:ring-2 focus:ring-[#C3ACFF]/30"
                    />
                  ) : (
                    <p className="text-[#121212] font-medium">{user?.email}</p>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-[#9CA3AF] mb-2">Company</label>
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-[#9CA3AF]" />
                  {isEditing ? (
                    <input
                      type="text"
                      defaultValue={user?.workspace}
                      className="flex-1 px-4 py-3 bg-[#F3F4F6] rounded-xl text-[#121212] focus:outline-none focus:ring-2 focus:ring-[#C3ACFF]/30"
                    />
                  ) : (
                    <p className="text-[#121212] font-medium">{user?.workspace}</p>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-[#9CA3AF] mb-2">Department</label>
                <div className="flex items-center gap-2">
                  <Briefcase className="w-4 h-4 text-[#9CA3AF]" />
                  {isEditing ? (
                    <select className="flex-1 px-4 py-3 bg-[#F3F4F6] rounded-xl text-[#121212] focus:outline-none focus:ring-2 focus:ring-[#C3ACFF]/30 appearance-none">
                      <option>Compliance</option>
                      <option>Legal</option>
                      <option>Operations</option>
                      <option>Finance</option>
                    </select>
                  ) : (
                    <p className="text-[#121212] font-medium">Compliance</p>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-[#9CA3AF] mb-2">Location</label>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-[#9CA3AF]" />
                  {isEditing ? (
                    <input
                      type="text"
                      defaultValue="San Francisco, CA"
                      className="flex-1 px-4 py-3 bg-[#F3F4F6] rounded-xl text-[#121212] focus:outline-none focus:ring-2 focus:ring-[#C3ACFF]/30"
                    />
                  ) : (
                    <p className="text-[#121212] font-medium">San Francisco, CA</p>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-[#9CA3AF] mb-2">Website</label>
                <div className="flex items-center gap-2">
                  <Link className="w-4 h-4 text-[#9CA3AF]" />
                  {isEditing ? (
                    <input
                      type="text"
                      defaultValue="https://sterlinghealth.com"
                      className="flex-1 px-4 py-3 bg-[#F3F4F6] rounded-xl text-[#121212] focus:outline-none focus:ring-2 focus:ring-[#C3ACFF]/30"
                    />
                  ) : (
                    <a href="#" className="text-[#C3ACFF] font-medium hover:underline">sterlinghealth.com</a>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Activity */}
          <div className="mt-8 bg-white rounded-2xl p-8 shadow-soft">
            <h3 className="text-lg font-semibold text-[#121212] mb-6">Recent Activity</h3>
            <div className="space-y-4">
              {[
                { action: 'Updated compliance checklist template', time: '2 hours ago' },
                { action: 'Reviewed Texas Medicaid contract', time: 'Yesterday' },
                { action: 'Added new team member: David Chen', time: '2 days ago' },
                { action: 'Exported quarterly compliance report', time: '3 days ago' },
              ].map((activity, i) => (
                <div key={i} className="flex items-center justify-between p-4 bg-[#F9FAFB] rounded-xl">
                  <p className="text-[#121212]">{activity.action}</p>
                  <span className="text-sm text-[#9CA3AF]">{activity.time}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
