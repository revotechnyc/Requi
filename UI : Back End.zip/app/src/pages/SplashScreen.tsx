import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sparkles, Shield, Brain, ChevronRight } from 'lucide-react';

export function SplashScreen() {
  const navigate = useNavigate();
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  return (
    <div className="min-h-screen bg-[#F8F8F8] flex flex-col">
      {/* Navigation */}
      <nav className="w-full px-8 py-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#C3ACFF] to-[#CBD5FF] flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <span className="text-xl font-semibold text-[#121212]">Requi Health</span>
        </div>
        <div className="flex items-center gap-6">
          <button 
            onClick={() => navigate('/login')}
            className="text-[#6B7280] hover:text-[#121212] transition-colors font-medium"
          >
            Log In
          </button>
          <button 
            onClick={() => navigate('/signup')}
            className="px-5 py-2.5 bg-[#121212] text-white rounded-full font-medium hover:bg-[#2D2D2D] transition-colors flex items-center gap-2"
          >
            Try for Free
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="flex-1 flex flex-col items-center justify-center px-8 py-12">
        <div className={`max-w-4xl mx-auto text-center transition-all duration-700 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-full shadow-soft mb-8">
            <span className="w-2 h-2 rounded-full bg-[#C3ACFF] animate-pulse"></span>
            <span className="text-sm font-medium text-[#6B7280]">Healthcare Compliance AI</span>
          </div>

          {/* Main Title */}
          <h1 className="text-5xl md:text-7xl font-bold text-[#121212] leading-tight mb-6">
            One System.
            <br />
            <span className="text-gradient">All Your Compliance.</span>
          </h1>

          {/* Subtitle */}
          <p className="text-xl text-[#6B7280] max-w-2xl mx-auto mb-10 leading-relaxed">
            Requi Health is the enterprise AI workspace for regulated healthcare. 
            Federal, state, and program compliance — unified.
          </p>

          {/* CTA Buttons */}
          <div className="flex items-center justify-center gap-4 mb-16">
            <button 
              onClick={() => navigate('/signup')}
              className="px-8 py-4 bg-[#121212] text-white rounded-full font-semibold hover:bg-[#2D2D2D] transition-all flex items-center gap-2 shadow-elevated"
            >
              Get Started
              <ChevronRight className="w-5 h-5" />
            </button>
            <button 
              onClick={() => navigate('/login')}
              className="px-8 py-4 bg-white text-[#121212] rounded-full font-semibold hover:bg-[#F3F4F6] transition-all border border-[#E5E7EB]"
            >
              Sign In
            </button>
          </div>

          {/* Feature Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white rounded-2xl p-6 shadow-soft card-hover">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#C3ACFF]/20 to-[#CBD5FF]/20 flex items-center justify-center mb-4">
                <Brain className="w-6 h-6 text-[#C3ACFF]" />
              </div>
              <h3 className="text-lg font-semibold text-[#121212] mb-2">AI Reasoning</h3>
              <p className="text-sm text-[#6B7280]">Jurisdiction-aware compliance engine with authority-ranked reasoning</p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-soft card-hover">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#C3ACFF]/20 to-[#CBD5FF]/20 flex items-center justify-center mb-4">
                <Shield className="w-6 h-6 text-[#C3ACFF]" />
              </div>
              <h3 className="text-lg font-semibold text-[#121212] mb-2">Enterprise Security</h3>
              <p className="text-sm text-[#6B7280]">Role-based access, audit logs, and closed-corpus enforcement</p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-soft card-hover">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#C3ACFF]/20 to-[#CBD5FF]/20 flex items-center justify-center mb-4">
                <Sparkles className="w-6 h-6 text-[#C3ACFF]" />
              </div>
              <h3 className="text-lg font-semibold text-[#121212] mb-2">Template Engine</h3>
              <p className="text-sm text-[#6B7280]">Company letterheads, legal docs, and compliance workflows</p>
            </div>
          </div>
        </div>

        {/* Floating Elements */}
        <div className="absolute top-1/4 left-10 w-20 h-20 rounded-full bg-gradient-to-br from-[#C3ACFF]/30 to-transparent blur-2xl animate-float" />
        <div className="absolute bottom-1/4 right-10 w-32 h-32 rounded-full bg-gradient-to-br from-[#CBD5FF]/30 to-transparent blur-2xl animate-float" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/3 right-1/4 w-16 h-16 rounded-full bg-gradient-to-br from-[#C3ACFF]/20 to-transparent blur-xl animate-float" style={{ animationDelay: '2s' }} />
      </main>

      {/* Footer */}
      <footer className="w-full px-8 py-6 border-t border-[#E5E7EB]">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <p className="text-sm text-[#6B7280]">© 2025 Requi Health. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <a href="#" className="text-sm text-[#6B7280] hover:text-[#121212] transition-colors">Privacy</a>
            <a href="#" className="text-sm text-[#6B7280] hover:text-[#121212] transition-colors">Terms</a>
            <a href="#" className="text-sm text-[#6B7280] hover:text-[#121212] transition-colors">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
