import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Sparkles, Plus, Search, Compass, BookOpen, FolderOpen, Clock, 
  FileText, Users, Settings, ChevronDown, Paperclip, Send, 
  MessageSquare, Zap, Shield, FileCheck, 
  Download, Share2, Copy
} from 'lucide-react';
import { useAuth } from '../App';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  sources?: Source[];
  confidence?: 'high' | 'medium' | 'low';
}

interface Source {
  title: string;
  layer: string;
  jurisdiction: string;
}

interface QuickAction {
  id: string;
  icon: React.ElementType;
  label: string;
  description: string;
}

export function AIWorkspace() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeTab, setActiveTab] = useState('chat');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickActions: QuickAction[] = [
    { id: 'draft', icon: FileText, label: 'Draft Legal Doc', description: 'Generate compliance documents' },
    { id: 'review', icon: FileCheck, label: 'Contract Review', description: 'Analyze contract clauses' },
    { id: 'check', icon: Shield, label: 'Compliance Check', description: 'Verify regulatory compliance' },
    { id: 'template', icon: Zap, label: 'Create Template', description: 'Build reusable templates' },
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate AI response
    await new Promise(resolve => setTimeout(resolve, 2000));

    const aiMessage: Message = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: `Based on my analysis of federal and state authority layers, here's what I found:

**Federal Layer (42 CFR § 438.210)**
Medicaid managed care organizations must provide coverage for emergency services without prior authorization, regardless of whether the provider is in-network.

**State Implementation (California)**
California's All Plan Letter 20-015 clarifies that MCOs must cover emergency services when a "prudent layperson" would believe the condition requires immediate attention.

**Confidence: High**
This interpretation is supported by binding federal regulation and official state guidance.

Would you like me to explore specific scenarios or compare this with other states?`,
      timestamp: new Date(),
      sources: [
        { title: '42 CFR § 438.210', layer: 'Federal Regulation', jurisdiction: 'Federal' },
        { title: 'APL 20-015', layer: 'State Guidance', jurisdiction: 'California' },
      ],
      confidence: 'high',
    };

    setMessages(prev => [...prev, aiMessage]);
    setIsTyping(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="h-screen bg-[#F8F8F8] flex overflow-hidden">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-72' : 'w-0'} bg-white border-r border-[#E5E7EB] flex flex-col transition-all duration-300 overflow-hidden`}>
        {/* Logo */}
        <div className="p-4 flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#C3ACFF] to-[#CBD5FF] flex items-center justify-center flex-shrink-0">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <span className="font-semibold text-[#121212]">Requi Health</span>
        </div>

        {/* New Chat Button */}
        <div className="px-4 pb-4">
          <button 
            onClick={() => setMessages([])}
            className="w-full py-3 px-4 bg-[#121212] text-white rounded-xl font-medium hover:bg-[#2D2D2D] transition-colors flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            New Chat
          </button>
        </div>

        {/* Search */}
        <div className="px-4 pb-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9CA3AF]" />
            <input
              type="text"
              placeholder="Search conversations..."
              className="w-full pl-9 pr-4 py-2.5 bg-[#F3F4F6] rounded-xl text-sm text-[#121212] placeholder:text-[#9CA3AF] focus:outline-none focus:ring-2 focus:ring-[#C3ACFF]/30"
            />
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 overflow-y-auto">
          <div className="space-y-1">
            <button 
              onClick={() => setActiveTab('explore')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                activeTab === 'explore' ? 'bg-[#C3ACFF]/10 text-[#C3ACFF]' : 'text-[#6B7280] hover:bg-[#F3F4F6]'
              }`}
            >
              <Compass className="w-4 h-4" />
              Explore
            </button>
            <button 
              onClick={() => navigate('/library')}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-[#6B7280] hover:bg-[#F3F4F6] transition-colors"
            >
              <BookOpen className="w-4 h-4" />
              Library
            </button>
            <button 
              onClick={() => navigate('/files')}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-[#6B7280] hover:bg-[#F3F4F6] transition-colors"
            >
              <FolderOpen className="w-4 h-4" />
              Files
            </button>
            <button 
              onClick={() => navigate('/templates')}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-[#6B7280] hover:bg-[#F3F4F6] transition-colors"
            >
              <FileText className="w-4 h-4" />
              Templates
              <span className="ml-auto px-2 py-0.5 bg-[#C3ACFF]/20 text-[#C3ACFF] text-xs rounded-full">New</span>
            </button>
            <button 
              onClick={() => navigate('/teams')}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-[#6B7280] hover:bg-[#F3F4F6] transition-colors"
            >
              <Users className="w-4 h-4" />
              Teams
              <span className="ml-auto px-2 py-0.5 bg-[#C3ACFF]/20 text-[#C3ACFF] text-xs rounded-full">New</span>
            </button>
          </div>

          {/* History */}
          <div className="mt-6">
            <div className="flex items-center justify-between px-3 mb-2">
              <span className="text-xs font-medium text-[#9CA3AF] uppercase tracking-wider">History</span>
            </div>
            <div className="space-y-1">
              {[
                'Medicaid managed care emergency services',
                'California APL 20-015 interpretation',
                'HIPAA breach notification requirements',
                'Medicare Advantage marketing rules',
              ].map((item, i) => (
                <button
                  key={i}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm text-[#6B7280] hover:bg-[#F3F4F6] transition-colors text-left"
                >
                  <Clock className="w-4 h-4 flex-shrink-0" />
                  <span className="truncate">{item}</span>
                </button>
              ))}
            </div>
          </div>
        </nav>

        {/* User */}
        <div className="p-4 border-t border-[#E5E7EB]">
          <button 
            onClick={() => navigate('/profile')}
            className="w-full flex items-center gap-3 p-2 rounded-xl hover:bg-[#F3F4F6] transition-colors"
          >
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#C3ACFF] to-[#CBD5FF] flex items-center justify-center text-white text-sm font-medium">
              {user?.name?.split(' ').map(n => n[0]).join('')}
            </div>
            <div className="flex-1 text-left overflow-hidden">
              <p className="text-sm font-medium text-[#121212] truncate">{user?.name}</p>
              <p className="text-xs text-[#9CA3AF] truncate">{user?.workspace}</p>
            </div>
            <Settings className="w-4 h-4 text-[#9CA3AF]" />
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="h-16 px-6 flex items-center justify-between border-b border-[#E5E7EB] bg-white/50 backdrop-blur-sm">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 hover:bg-[#F3F4F6] rounded-lg transition-colors"
            >
              <MessageSquare className="w-5 h-5 text-[#6B7280]" />
            </button>
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-[#121212]">{user?.workspace}</span>
              <ChevronDown className="w-4 h-4 text-[#9CA3AF]" />
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button className="p-2 hover:bg-[#F3F4F6] rounded-lg transition-colors">
              <Share2 className="w-5 h-5 text-[#6B7280]" />
            </button>
            <button className="p-2 hover:bg-[#F3F4F6] rounded-lg transition-colors">
              <Download className="w-5 h-5 text-[#6B7280]" />
            </button>
            <button 
              onClick={() => navigate('/admin')}
              className="px-4 py-2 bg-[#C3ACFF]/10 text-[#C3ACFF] rounded-lg text-sm font-medium hover:bg-[#C3ACFF]/20 transition-colors"
            >
              Admin
            </button>
          </div>
        </header>

        {/* Chat Area */}
        <div className="flex-1 overflow-y-auto">
          {messages.length === 0 ? (
            // Empty State
            <div className="h-full flex flex-col items-center justify-center px-6">
              {/* AI Orb */}
              <div className="relative mb-8">
                <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[#C3ACFF] to-[#CBD5FF] flex items-center justify-center animate-pulse-glow">
                  <Sparkles className="w-10 h-10 text-white" />
                </div>
                <div className="absolute -inset-4 rounded-full bg-gradient-to-br from-[#C3ACFF]/20 to-[#CBD5FF]/20 blur-xl" />
              </div>

              <h1 className="text-3xl font-bold text-[#121212] mb-2">
                Hello, {user?.name?.split(' ')[0]}
              </h1>
              <p className="text-[#6B7280] mb-10">How can I assist you today?</p>

              {/* Quick Actions */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl w-full">
                {quickActions.map((action) => {
                  const Icon = action.icon;
                  return (
                    <button
                      key={action.id}
                      onClick={() => setInputValue(action.description)}
                      className="p-4 bg-white rounded-xl border border-[#E5E7EB] hover:border-[#C3ACFF] hover:shadow-soft transition-all text-left"
                    >
                      <Icon className="w-5 h-5 text-[#C3ACFF] mb-3" />
                      <h3 className="text-sm font-semibold text-[#121212] mb-1">{action.label}</h3>
                      <p className="text-xs text-[#6B7280]">{action.description}</p>
                    </button>
                  );
                })}
              </div>
            </div>
          ) : (
            // Messages
            <div className="max-w-3xl mx-auto px-6 py-8 space-y-6">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex gap-4 ${message.role === 'user' ? 'flex-row-reverse' : ''}`}
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    message.role === 'user'
                      ? 'bg-gradient-to-br from-[#C3ACFF] to-[#CBD5FF]'
                      : 'bg-[#121212]'
                  }`}>
                    {message.role === 'user' ? (
                      <span className="text-white text-xs font-medium">
                        {user?.name?.split(' ').map(n => n[0]).join('')}
                      </span>
                    ) : (
                      <Sparkles className="w-4 h-4 text-white" />
                    )}
                  </div>
                  <div className={`flex-1 ${message.role === 'user' ? 'text-right' : ''}`}>
                    <div className={`inline-block max-w-full text-left ${
                      message.role === 'user'
                        ? 'bg-[#121212] text-white'
                        : 'bg-white border border-[#E5E7EB]'
                    } rounded-2xl px-5 py-4`}>
                      <div className="whitespace-pre-wrap text-sm leading-relaxed">
                        {message.content}
                      </div>
                      
                      {/* Sources */}
                      {message.sources && (
                        <div className="mt-4 pt-4 border-t border-[#E5E7EB]/50">
                          <p className="text-xs font-medium text-[#9CA3AF] mb-2">Sources</p>
                          <div className="flex flex-wrap gap-2">
                            {message.sources.map((source, i) => (
                              <span
                                key={i}
                                className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-[#F3F4F6] rounded-lg text-xs"
                              >
                                <span className="w-1.5 h-1.5 rounded-full bg-[#C3ACFF]" />
                                <span className="text-[#121212]">{source.title}</span>
                                <span className="text-[#9CA3AF]">· {source.jurisdiction}</span>
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Confidence */}
                      {message.confidence && (
                        <div className="mt-3 flex items-center gap-2">
                          <span className={`w-2 h-2 rounded-full ${
                            message.confidence === 'high' ? 'bg-green-500' :
                            message.confidence === 'medium' ? 'bg-yellow-500' : 'bg-orange-500'
                          }`} />
                          <span className="text-xs text-[#9CA3AF]">
                            {message.confidence === 'high' ? 'High confidence' :
                             message.confidence === 'medium' ? 'Medium confidence' : 'Low confidence'}
                          </span>
                        </div>
                      )}
                    </div>
                    <div className="mt-1 flex items-center gap-2">
                      <span className="text-xs text-[#9CA3AF]">
                        {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                      {message.role === 'assistant' && (
                        <button className="p-1 hover:bg-[#F3F4F6] rounded transition-colors">
                          <Copy className="w-3 h-3 text-[#9CA3AF]" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
              
              {isTyping && (
                <div className="flex gap-4">
                  <div className="w-8 h-8 rounded-full bg-[#121212] flex items-center justify-center">
                    <Sparkles className="w-4 h-4 text-white" />
                  </div>
                  <div className="bg-white border border-[#E5E7EB] rounded-2xl px-5 py-4">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-[#C3ACFF] animate-typing" />
                      <span className="w-2 h-2 rounded-full bg-[#C3ACFF] animate-typing" style={{ animationDelay: '0.2s' }} />
                      <span className="w-2 h-2 rounded-full bg-[#C3ACFF] animate-typing" style={{ animationDelay: '0.4s' }} />
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="p-6 bg-white border-t border-[#E5E7EB]">
          <div className="max-w-3xl mx-auto">
            <div className="relative">
              <textarea
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask about federal regulations, state guidance, contracts, or compliance..."
                className="w-full pl-5 pr-24 py-4 bg-[#F3F4F6] rounded-2xl text-[#121212] placeholder:text-[#9CA3AF] resize-none focus:outline-none focus:ring-2 focus:ring-[#C3ACFF]/30 min-h-[60px] max-h-[200px]"
                rows={1}
              />
              <div className="absolute right-3 bottom-3 flex items-center gap-2">
                <button className="p-2 hover:bg-[#E5E7EB] rounded-lg transition-colors">
                  <Paperclip className="w-5 h-5 text-[#9CA3AF]" />
                </button>
                <button
                  onClick={handleSend}
                  disabled={!inputValue.trim() || isTyping}
                  className="p-2 bg-[#121212] text-white rounded-lg hover:bg-[#2D2D2D] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="flex items-center justify-between mt-3">
              <div className="flex items-center gap-4">
                <button className="flex items-center gap-2 px-3 py-1.5 bg-[#C3ACFF]/10 text-[#C3ACFF] rounded-lg text-sm font-medium hover:bg-[#C3ACFF]/20 transition-colors">
                  <Zap className="w-4 h-4" />
                  Deeper Research
                </button>
                <button className="flex items-center gap-2 px-3 py-1.5 bg-[#F3F4F6] text-[#6B7280] rounded-lg text-sm font-medium hover:bg-[#E5E7EB] transition-colors">
                  <FileText className="w-4 h-4" />
                  Template
                </button>
              </div>
              <p className="text-xs text-[#9CA3AF]">
                Requi Health may produce inaccurate information. Always verify with primary sources.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
