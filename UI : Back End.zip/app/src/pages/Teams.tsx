import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Sparkles, Plus, Search, Mail, MoreHorizontal,
  Users, Check, X, Crown
} from 'lucide-react';

interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: 'owner' | 'admin' | 'manager' | 'contributor' | 'viewer';
  department: string;
  status: 'active' | 'pending' | 'inactive';
  avatar?: string;
  lastActive: string;
}

interface Team {
  id: string;
  name: string;
  description: string;
  memberCount: number;
  color: string;
}

export function Teams() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [showInviteModal, setShowInviteModal] = useState(false);

  const teams: Team[] = [
    { id: '1', name: 'Legal', description: 'Legal counsel and contract review', memberCount: 8, color: 'bg-[#C3ACFF]' },
    { id: '2', name: 'Compliance', description: 'Regulatory compliance and audits', memberCount: 12, color: 'bg-[#CBD5FF]' },
    { id: '3', name: 'Operations', description: 'Clinical and administrative operations', memberCount: 15, color: 'bg-[#C3ACFF]/70' },
    { id: '4', name: 'Finance', description: 'Revenue cycle and billing', memberCount: 6, color: 'bg-[#CBD5FF]/70' },
  ];

  const members: TeamMember[] = [
    { id: '1', name: 'Bianca Sterling', email: 'bianca@company.com', role: 'owner', department: 'Legal', status: 'active', lastActive: 'Now' },
    { id: '2', name: 'Sarah Bennett', email: 'sarah@company.com', role: 'admin', department: 'Compliance', status: 'active', lastActive: '5 min ago' },
    { id: '3', name: 'Michael Torres', email: 'mike@company.com', role: 'manager', department: 'Operations', status: 'active', lastActive: '1 hour ago' },
    { id: '4', name: 'Jennifer Walsh', email: 'jen@company.com', role: 'contributor', department: 'Legal', status: 'active', lastActive: '2 hours ago' },
    { id: '5', name: 'David Chen', email: 'david@company.com', role: 'contributor', department: 'Compliance', status: 'pending', lastActive: 'Never' },
    { id: '6', name: 'Emily Rodriguez', email: 'emily@company.com', role: 'viewer', department: 'Finance', status: 'active', lastActive: '1 day ago' },
  ];

  const roleLabels: Record<string, { label: string; color: string }> = {
    owner: { label: 'Owner', color: 'bg-purple-100 text-purple-700' },
    admin: { label: 'Admin', color: 'bg-blue-100 text-blue-700' },
    manager: { label: 'Manager', color: 'bg-green-100 text-green-700' },
    contributor: { label: 'Contributor', color: 'bg-yellow-100 text-yellow-700' },
    viewer: { label: 'Viewer', color: 'bg-gray-100 text-gray-700' },
  };

  const filteredMembers = members.filter(m => 
    m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.department.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#F8F8F8]">
      {/* Header */}
      <header className="bg-white border-b border-[#E5E7EB] px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => navigate('/workspace')}
              className="p-2 hover:bg-[#F3F4F6] rounded-lg transition-colors"
            >
              <Sparkles className="w-5 h-5 text-[#6B7280]" />
            </button>
            <div>
              <h1 className="text-xl font-semibold text-[#121212]">Teams</h1>
              <p className="text-sm text-[#6B7280]">Manage users, roles, and permissions</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="px-4 py-2 bg-[#F3F4F6] rounded-xl text-sm text-[#6B7280]">
              <span className="font-medium text-[#121212]">24</span> of <span className="font-medium text-[#121212]">30</span> seats used
            </div>
            <button 
              onClick={() => setShowInviteModal(true)}
              className="px-4 py-2 bg-[#121212] text-white rounded-xl text-sm font-medium hover:bg-[#2D2D2D] transition-colors flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Invite Member
            </button>
          </div>
        </div>
      </header>

      <main className="p-8">
        <div className="max-w-6xl mx-auto">
          {/* Teams Overview */}
          <div className="mb-8">
            <h2 className="text-lg font-semibold text-[#121212] mb-4">Teams</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {teams.map((team) => (
                <div
                  key={team.id}
                  className="bg-white rounded-2xl p-5 shadow-soft card-hover cursor-pointer"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className={`w-10 h-10 ${team.color} rounded-xl flex items-center justify-center`}>
                      <Users className="w-5 h-5 text-[#121212]" />
                    </div>
                    <span className="text-sm text-[#9CA3AF]">{team.memberCount} members</span>
                  </div>
                  <h3 className="font-semibold text-[#121212] mb-1">{team.name}</h3>
                  <p className="text-sm text-[#6B7280]">{team.description}</p>
                </div>
              ))}
              <button className="p-5 bg-white rounded-2xl border-2 border-dashed border-[#E5E7EB] hover:border-[#C3ACFF] hover:bg-[#C3ACFF]/5 transition-all flex flex-col items-center justify-center min-h-[140px]">
                <Plus className="w-6 h-6 text-[#9CA3AF] mb-2" />
                <span className="text-sm font-medium text-[#6B7280]">Create Team</span>
              </button>
            </div>
          </div>

          {/* Members List */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-[#121212]">All Members</h2>
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9CA3AF]" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search members..."
                    className="pl-9 pr-4 py-2 bg-white border border-[#E5E7EB] rounded-lg text-sm text-[#121212] placeholder:text-[#9CA3AF] focus:outline-none focus:border-[#C3ACFF]"
                  />
                </div>
                <button className="px-3 py-2 bg-white border border-[#E5E7EB] rounded-lg text-sm text-[#6B7280] hover:bg-[#F9FAFB] transition-colors">
                  Filter
                </button>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-soft overflow-hidden">
              <div className="grid grid-cols-12 gap-4 px-6 py-3 border-b border-[#E5E7EB] text-sm font-medium text-[#9CA3AF]">
                <div className="col-span-4">Member</div>
                <div className="col-span-2">Role</div>
                <div className="col-span-2">Department</div>
                <div className="col-span-2">Status</div>
                <div className="col-span-2">Last Active</div>
              </div>
              {filteredMembers.map((member) => (
                <div
                  key={member.id}
                  className="grid grid-cols-12 gap-4 px-6 py-4 hover:bg-[#F9FAFB] transition-colors border-b border-[#E5E7EB] last:border-0 items-center"
                >
                  <div className="col-span-4 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#C3ACFF] to-[#CBD5FF] flex items-center justify-center text-white font-medium">
                      {member.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div>
                      <p className="font-medium text-[#121212]">{member.name}</p>
                      <p className="text-sm text-[#9CA3AF]">{member.email}</p>
                    </div>
                  </div>
                  <div className="col-span-2">
                    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium ${roleLabels[member.role].color}`}>
                      {member.role === 'owner' && <Crown className="w-3 h-3" />}
                      {roleLabels[member.role].label}
                    </span>
                  </div>
                  <div className="col-span-2 text-sm text-[#6B7280]">{member.department}</div>
                  <div className="col-span-2">
                    <span className={`inline-flex items-center gap-1.5 text-sm ${
                      member.status === 'active' ? 'text-green-600' :
                      member.status === 'pending' ? 'text-yellow-600' : 'text-gray-500'
                    }`}>
                      <span className={`w-2 h-2 rounded-full ${
                        member.status === 'active' ? 'bg-green-500' :
                        member.status === 'pending' ? 'bg-yellow-500' : 'bg-gray-400'
                      }`} />
                      {member.status.charAt(0).toUpperCase() + member.status.slice(1)}
                    </span>
                  </div>
                  <div className="col-span-2 flex items-center justify-between">
                    <span className="text-sm text-[#9CA3AF]">{member.lastActive}</span>
                    <button className="p-1.5 hover:bg-[#F3F4F6] rounded-lg transition-colors opacity-0 group-hover:opacity-100">
                      <MoreHorizontal className="w-4 h-4 text-[#9CA3AF]" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Role Permissions */}
          <div className="mt-8 p-6 bg-white rounded-2xl shadow-soft">
            <h3 className="text-lg font-semibold text-[#121212] mb-4">Role Permissions</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              {[
                { role: 'Owner', desc: 'Full control', permissions: ['Everything'] },
                { role: 'Admin', desc: 'Manage users & settings', permissions: ['Users', 'Templates', 'Billing'] },
                { role: 'Manager', desc: 'Team-level control', permissions: ['Team users', 'Projects', 'Reports'] },
                { role: 'Contributor', desc: 'Create & edit', permissions: ['Documents', 'Queries', 'Files'] },
                { role: 'Viewer', desc: 'Read-only access', permissions: ['View documents', 'Run queries'] },
              ].map((r, i) => (
                <div key={i} className="p-4 bg-[#F9FAFB] rounded-xl">
                  <h4 className="font-semibold text-[#121212] mb-1">{r.role}</h4>
                  <p className="text-xs text-[#6B7280] mb-3">{r.desc}</p>
                  <div className="space-y-1">
                    {r.permissions.map((p, j) => (
                      <div key={j} className="flex items-center gap-1.5 text-xs text-[#6B7280]">
                        <Check className="w-3 h-3 text-green-500" />
                        {p}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>

      {/* Invite Modal */}
      {showInviteModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md animate-scale-in">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-[#121212]">Invite Team Member</h3>
              <button 
                onClick={() => setShowInviteModal(false)}
                className="p-2 hover:bg-[#F3F4F6] rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-[#9CA3AF]" />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#121212] mb-2">Email address</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#9CA3AF]" />
                  <input
                    type="email"
                    placeholder="colleague@company.com"
                    className="w-full pl-12 pr-4 py-3 bg-[#F3F4F6] rounded-xl text-[#121212] placeholder:text-[#9CA3AF] focus:outline-none focus:ring-2 focus:ring-[#C3ACFF]/30"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#121212] mb-2">Role</label>
                <select className="w-full px-4 py-3 bg-[#F3F4F6] rounded-xl text-[#121212] focus:outline-none focus:ring-2 focus:ring-[#C3ACFF]/30 appearance-none">
                  <option>Contributor</option>
                  <option>Viewer</option>
                  <option>Manager</option>
                  <option>Admin</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#121212] mb-2">Team</label>
                <select className="w-full px-4 py-3 bg-[#F3F4F6] rounded-xl text-[#121212] focus:outline-none focus:ring-2 focus:ring-[#C3ACFF]/30 appearance-none">
                  <option>Legal</option>
                  <option>Compliance</option>
                  <option>Operations</option>
                  <option>Finance</option>
                </select>
              </div>
              <button 
                onClick={() => setShowInviteModal(false)}
                className="w-full py-3 bg-[#121212] text-white rounded-xl font-semibold hover:bg-[#2D2D2D] transition-colors"
              >
                Send Invitation
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
