import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sparkles, Check, ChevronRight, Building2, Users, FileText, Shield, ArrowRight } from 'lucide-react';

export function Onboarding() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [selectedModules, setSelectedModules] = useState<string[]>([]);
  const [selectedStates, setSelectedStates] = useState<string[]>([]);

  const modules = [
    { id: 'compliance', name: 'Compliance', icon: Shield, description: 'Federal and state regulatory compliance' },
    { id: 'finance', name: 'Finance', icon: FileText, description: 'Revenue cycle and billing compliance' },
    { id: 'hr', name: 'Human Resources', icon: Users, description: 'Workforce and labor compliance' },
    { id: 'clinical', name: 'Clinical Operations', icon: Building2, description: 'Care delivery and quality standards' },
  ];

  const states = [
    'California', 'Texas', 'Florida', 'New York', 'Illinois',
    'Pennsylvania', 'Ohio', 'Michigan', 'Arizona', 'Washington'
  ];

  const toggleModule = (id: string) => {
    setSelectedModules(prev => 
      prev.includes(id) ? prev.filter(m => m !== id) : [...prev, id]
    );
  };

  const toggleState = (state: string) => {
    setSelectedStates(prev => 
      prev.includes(state) ? prev.filter(s => s !== state) : [...prev, state]
    );
  };

  return (
    <div className="min-h-screen bg-[#F8F8F8] flex flex-col">
      {/* Header */}
      <header className="w-full px-8 py-6 flex items-center justify-between border-b border-[#E5E7EB]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#C3ACFF] to-[#CBD5FF] flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <span className="text-xl font-semibold text-[#121212]">Requi Health</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-[#6B7280]">Step {step} of 3</span>
          <div className="flex gap-1">
            {[1, 2, 3].map((s) => (
              <div
                key={s}
                className={`w-8 h-1 rounded-full transition-colors ${s <= step ? 'bg-[#C3ACFF]' : 'bg-[#E5E7EB]'}`}
              />
            ))}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center px-8 py-12">
        <div className="max-w-2xl w-full">
          {step === 1 && (
            <div className="animate-fade-in">
              <h1 className="text-3xl font-bold text-[#121212] mb-3">Welcome to Requi Health</h1>
              <p className="text-[#6B7280] mb-8">
                Let's set up your workspace. First, tell us which departments will be using the platform.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                {modules.map((module) => {
                  const Icon = module.icon;
                  const isSelected = selectedModules.includes(module.id);
                  return (
                    <button
                      key={module.id}
                      onClick={() => toggleModule(module.id)}
                      className={`p-5 rounded-xl border-2 text-left transition-all ${
                        isSelected
                          ? 'border-[#C3ACFF] bg-[#C3ACFF]/5'
                          : 'border-[#E5E7EB] bg-white hover:border-[#C3ACFF]/50'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                          isSelected ? 'bg-[#C3ACFF]' : 'bg-[#F3F4F6]'
                        }`}>
                          <Icon className={`w-5 h-5 ${isSelected ? 'text-white' : 'text-[#6B7280]'}`} />
                        </div>
                        {isSelected && <Check className="w-5 h-5 text-[#C3ACFF]" />}
                      </div>
                      <h3 className="font-semibold text-[#121212] mb-1">{module.name}</h3>
                      <p className="text-sm text-[#6B7280]">{module.description}</p>
                    </button>
                  );
                })}
              </div>

              <button
                onClick={() => setStep(2)}
                disabled={selectedModules.length === 0}
                className="w-full py-4 bg-[#121212] text-white rounded-xl font-semibold hover:bg-[#2D2D2D] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                Continue
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          )}

          {step === 2 && (
            <div className="animate-fade-in">
              <h1 className="text-3xl font-bold text-[#121212] mb-3">Select your states</h1>
              <p className="text-[#6B7280] mb-8">
                Choose the states where you operate. We'll configure compliance sources for each jurisdiction.
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-8">
                {states.map((state) => {
                  const isSelected = selectedStates.includes(state);
                  return (
                    <button
                      key={state}
                      onClick={() => toggleState(state)}
                      className={`p-4 rounded-xl border-2 text-left transition-all flex items-center gap-3 ${
                        isSelected
                          ? 'border-[#C3ACFF] bg-[#C3ACFF]/5'
                          : 'border-[#E5E7EB] bg-white hover:border-[#C3ACFF]/50'
                      }`}
                    >
                      <div className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-colors ${
                        isSelected ? 'bg-[#C3ACFF] border-[#C3ACFF]' : 'border-[#D1D5DB]'
                      }`}>
                        {isSelected && <Check className="w-3 h-3 text-white" />}
                      </div>
                      <span className="font-medium text-[#121212]">{state}</span>
                    </button>
                  );
                })}
              </div>

              <div className="flex items-center gap-3 p-4 bg-[#CBD5FF]/20 rounded-xl mb-8">
                <div className="w-10 h-10 rounded-lg bg-[#CBD5FF] flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-[#121212]" />
                </div>
                <div>
                  <p className="font-medium text-[#121212]">Need more states?</p>
                  <p className="text-sm text-[#6B7280]">You can add all 50 states and territories from your settings later.</p>
                </div>
              </div>

              <div className="flex gap-4">
                <button
                  onClick={() => setStep(1)}
                  className="flex-1 py-4 bg-white border border-[#E5E7EB] text-[#121212] rounded-xl font-semibold hover:bg-[#F9FAFB] transition-all"
                >
                  Back
                </button>
                <button
                  onClick={() => setStep(3)}
                  disabled={selectedStates.length === 0}
                  className="flex-1 py-4 bg-[#121212] text-white rounded-xl font-semibold hover:bg-[#2D2D2D] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  Continue
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="animate-fade-in text-center">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#C3ACFF] to-[#CBD5FF] flex items-center justify-center mx-auto mb-6">
                <Check className="w-10 h-10 text-white" />
              </div>
              <h1 className="text-3xl font-bold text-[#121212] mb-3">You're all set!</h1>
              <p className="text-[#6B7280] mb-8 max-w-md mx-auto">
                Your workspace is configured with {selectedModules.length} departments and {selectedStates.length} states. 
                Start exploring the AI compliance engine.
              </p>

              <div className="bg-white rounded-2xl p-6 shadow-soft mb-8 text-left">
                <h3 className="font-semibold text-[#121212] mb-4">Your configuration</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[#6B7280]">Departments</span>
                    <span className="font-medium text-[#121212]">{selectedModules.length} selected</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#6B7280]">States</span>
                    <span className="font-medium text-[#121212]">{selectedStates.length} selected</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#6B7280]">Plan</span>
                    <span className="font-medium text-[#121212]">14-day free trial</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => navigate('/workspace')}
                className="w-full py-4 bg-[#121212] text-white rounded-xl font-semibold hover:bg-[#2D2D2D] transition-all flex items-center justify-center gap-2"
              >
                Launch Workspace
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
