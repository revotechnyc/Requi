import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Sparkles, Search, Upload, Folder, FileText, Image, FileSpreadsheet,
  MoreVertical, Download, Share2, Grid, List, ChevronRight,
  Plus, Filter
} from 'lucide-react';

interface FileItem {
  id: string;
  name: string;
  type: 'folder' | 'pdf' | 'doc' | 'image' | 'spreadsheet';
  size: string;
  modified: string;
  owner: string;
}

export function Files() {
  const navigate = useNavigate();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [currentFolder, setCurrentFolder] = useState('All Files');

  const files: FileItem[] = [
    { id: '1', name: 'Health Plan Contracts', type: 'folder', size: '--', modified: 'Today', owner: 'You' },
    { id: '2', name: 'State Compliance', type: 'folder', size: '--', modified: 'Yesterday', owner: 'You' },
    { id: '3', name: 'Internal Templates', type: 'folder', size: '--', modified: '2 days ago', owner: 'Team' },
    { id: '4', name: 'CA Medicaid Contract 2024.pdf', type: 'pdf', size: '2.4 MB', modified: 'Today', owner: 'You' },
    { id: '5', name: 'Federal Compliance Summary.docx', type: 'doc', size: '1.8 MB', modified: 'Yesterday', owner: 'Sarah B.' },
    { id: '6', name: 'Provider Network Analysis.xlsx', type: 'spreadsheet', size: '890 KB', modified: '3 days ago', owner: 'Mike T.' },
    { id: '7', name: 'Compliance Workflow Diagram.png', type: 'image', size: '2.1 MB', modified: '1 week ago', owner: 'You' },
    { id: '8', name: 'Texas Provider Bulletin.pdf', type: 'pdf', size: '4.5 MB', modified: '2 weeks ago', owner: 'Team' },
  ];

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'folder': return <Folder className="w-8 h-8 text-[#C3ACFF]" />;
      case 'pdf': return <FileText className="w-8 h-8 text-red-500" />;
      case 'doc': return <FileText className="w-8 h-8 text-blue-500" />;
      case 'image': return <Image className="w-8 h-8 text-green-500" />;
      case 'spreadsheet': return <FileSpreadsheet className="w-8 h-8 text-green-600" />;
      default: return <FileText className="w-8 h-8 text-[#6B7280]" />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F8F8]">
      {/* Header */}
      <header className="bg-white border-b border-[#E5E7EB] px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => navigate('/workspace')}
              className="p-2 hover:bg-[#F3F4F6] rounded-lg transition-colors"
            >
              <Sparkles className="w-5 h-5 text-[#6B7280]" />
            </button>
            <div>
              <h1 className="text-xl font-semibold text-[#121212]">Files</h1>
              <p className="text-sm text-[#6B7280]">Manage your documents and projects</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button className="px-4 py-2 bg-[#C3ACFF]/10 text-[#C3ACFF] rounded-xl text-sm font-medium hover:bg-[#C3ACFF]/20 transition-colors flex items-center gap-2">
              <Upload className="w-4 h-4" />
              Upload
            </button>
            <button className="px-4 py-2 bg-[#121212] text-white rounded-xl text-sm font-medium hover:bg-[#2D2D2D] transition-colors flex items-center gap-2">
              <Plus className="w-4 h-4" />
              New Folder
            </button>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r border-[#E5E7EB] min-h-[calc(100vh-73px)] p-6">
          <div className="space-y-1">
            {['All Files', 'Recent', 'Shared with me', 'Favorites', 'Trash'].map((item, i) => (
              <button
                key={i}
                onClick={() => setCurrentFolder(item)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                  currentFolder === item 
                    ? 'bg-[#C3ACFF]/10 text-[#C3ACFF]' 
                    : 'text-[#6B7280] hover:bg-[#F3F4F6]'
                }`}
              >
                <Folder className="w-4 h-4" />
                <span>{item}</span>
              </button>
            ))}
          </div>

          <div className="mt-8">
            <h3 className="text-xs font-semibold text-[#9CA3AF] uppercase tracking-wider mb-3">Projects</h3>
            <div className="space-y-1">
              {['Health Plan Contracts', 'State Compliance', 'Internal Templates'].map((project, i) => (
                <button
                  key={i}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm text-[#6B7280] hover:bg-[#F3F4F6] transition-colors"
                >
                  <div className="w-2 h-2 rounded-full bg-[#C3ACFF]" />
                  <span className="truncate">{project}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="mt-8 p-4 bg-gradient-to-br from-[#C3ACFF]/10 to-[#CBD5FF]/10 rounded-xl">
            <p className="text-sm font-medium text-[#121212] mb-1">Storage</p>
            <p className="text-2xl font-bold text-[#121212] mb-2">45.2 GB</p>
            <p className="text-xs text-[#6B7280] mb-3">of 100 GB used</p>
            <div className="h-2 bg-white rounded-full overflow-hidden">
              <div className="h-full w-[45%] bg-gradient-to-r from-[#C3ACFF] to-[#CBD5FF] rounded-full" />
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          {/* Breadcrumb & Controls */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2 text-sm">
              <span className="text-[#6B7280]">Files</span>
              <ChevronRight className="w-4 h-4 text-[#9CA3AF]" />
              <span className="text-[#121212] font-medium">{currentFolder}</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9CA3AF]" />
                <input
                  type="text"
                  placeholder="Search files..."
                  className="pl-9 pr-4 py-2 bg-white border border-[#E5E7EB] rounded-lg text-sm text-[#121212] placeholder:text-[#9CA3AF] focus:outline-none focus:border-[#C3ACFF]"
                />
              </div>
              <button className="p-2 bg-white border border-[#E5E7EB] rounded-lg hover:bg-[#F9FAFB] transition-colors">
                <Filter className="w-4 h-4 text-[#6B7280]" />
              </button>
              <div className="flex items-center gap-1 bg-white border border-[#E5E7EB] rounded-lg p-1">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-1.5 rounded-md transition-colors ${viewMode === 'grid' ? 'bg-[#F3F4F6]' : ''}`}
                >
                  <Grid className="w-4 h-4 text-[#6B7280]" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-1.5 rounded-md transition-colors ${viewMode === 'list' ? 'bg-[#F3F4F6]' : ''}`}
                >
                  <List className="w-4 h-4 text-[#6B7280]" />
                </button>
              </div>
            </div>
          </div>

          {/* Files Grid */}
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {files.map((file) => (
                <div
                  key={file.id}
                  className="bg-white rounded-2xl p-5 shadow-soft card-hover group cursor-pointer"
                >
                  <div className="flex items-start justify-between mb-4">
                    {getFileIcon(file.type)}
                    <button className="opacity-0 group-hover:opacity-100 p-1.5 hover:bg-[#F3F4F6] rounded-lg transition-all">
                      <MoreVertical className="w-4 h-4 text-[#9CA3AF]" />
                    </button>
                  </div>
                  <h3 className="font-medium text-[#121212] mb-1 truncate">{file.name}</h3>
                  <p className="text-sm text-[#9CA3AF]">{file.size} · {file.modified}</p>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-2xl shadow-soft overflow-hidden">
              <div className="grid grid-cols-12 gap-4 px-6 py-3 border-b border-[#E5E7EB] text-sm font-medium text-[#9CA3AF]">
                <div className="col-span-5">Name</div>
                <div className="col-span-2">Size</div>
                <div className="col-span-2">Modified</div>
                <div className="col-span-2">Owner</div>
                <div className="col-span-1"></div>
              </div>
              {files.map((file) => (
                <div
                  key={file.id}
                  className="grid grid-cols-12 gap-4 px-6 py-4 hover:bg-[#F9FAFB] transition-colors border-b border-[#E5E7EB] last:border-0 items-center"
                >
                  <div className="col-span-5 flex items-center gap-3">
                    {getFileIcon(file.type)}
                    <span className="font-medium text-[#121212] truncate">{file.name}</span>
                  </div>
                  <div className="col-span-2 text-sm text-[#6B7280]">{file.size}</div>
                  <div className="col-span-2 text-sm text-[#6B7280]">{file.modified}</div>
                  <div className="col-span-2 text-sm text-[#6B7280]">{file.owner}</div>
                  <div className="col-span-1 flex items-center justify-end gap-1">
                    <button className="p-1.5 hover:bg-[#F3F4F6] rounded-lg transition-colors">
                      <Download className="w-4 h-4 text-[#9CA3AF]" />
                    </button>
                    <button className="p-1.5 hover:bg-[#F3F4F6] rounded-lg transition-colors">
                      <Share2 className="w-4 h-4 text-[#9CA3AF]" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
